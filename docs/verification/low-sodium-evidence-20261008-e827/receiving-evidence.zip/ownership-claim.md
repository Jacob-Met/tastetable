## Current ownership

`estate-e82707f2bc62` owns a narrow correction to the positive evidence selected by `constraints.py::check_low_sodium`, with an independently reviewed helper if needed, one native regression test file, and scoped evidence documentation. A separate source worker will receive the frozen candidate; the execution lead owns source review and publication.

The receiving source is main [`0758d2cca881fb5b5041f80bae2174cf485f4bdd`](https://github.com/Jacob-Met/tastetable/tree/0758d2cca881fb5b5041f80bae2174cf485f4bdd), with `constraints.py` blob `53138a106455cc3fa40d812d1ade3c60fcbbb916`. Current central ownership and the complete #4 thread were read, along with #20/#21. The wheelchair correction in #20/#21 retains its separate function and tests; this contribution does not change those spans.

## Reproduced user-visible problem

The literal synthetic keyword `no low sodium options` is currently labeled `pass`, with reason `lower-sodium signals: no low sodium options`. Through the existing offline `FixtureTransport`, `QlooClient`, `ScriptedModel` and `run_agent` path, that text also overrides an existing high-sodium cue (`ramen`) and appears as a positive check in a selected Wednesday meal. The unmodified source produced two failing regression methods and one passing policy-control method, with no errors or skips. Source and synthetic input bytes remained unchanged, and the receiver prohibited network access.

## Bounded correction and qualification

Exclude explicit local negations of the existing `LOW_SODIUM` cues from the positive evidence set. A denial alone follows the existing `unknown` outcome; with an existing high cue it follows the existing `fail` outcome. Independent affirmative evidence retains the existing positive-over-high precedence. The vocabulary, permissive dietary-unknown rule, outing exemption, `STRICT`, shared `_hits`, other constraint functions, agent, fixtures, UI and provider behavior remain unchanged.

This is a software evidence-labeling correction using synthetic data. It does not add nutritional thresholds, interpret arbitrary prose, validate venue data, or establish a health outcome. Preserve the original failing evidence, freeze source and tests before independent receiving, and require the repository's existing full pytest CI before integration.
