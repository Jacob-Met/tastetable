"""Offline source reproduction of a literal dietary evidence label.

This uses synthetic fixtures and existing keyword policy. It makes no health
claim and does not contact providers.
"""
import hashlib
import json
import sys
import unittest
from pathlib import Path

SOURCE = Path(sys.argv[1]).resolve()
DESTINATION = Path(sys.argv[2]).resolve()
sys.argv = [sys.argv[0]]
sys.path.insert(0, str(SOURCE))

import agent
from constraints import check_low_sodium, evaluate
from personas import PERSONAS
from qloo_client import FixtureTransport, QlooClient, parse_entity


def deny_network(event, args):
    if event in {"socket.connect", "socket.getaddrinfo"}:
        raise AssertionError("offline receiving attempted network access")


sys.addaudithook(deny_network)
DESTINATION.mkdir(parents=True, exist_ok=True)
OBSERVATIONS = {}


def entity(keywords):
    return parse_entity({
        "entity_id": "FIX-E827-SYNTHETIC",
        "name": "Synthetic literal evidence control",
        "properties": {"keywords": [{"name": value} for value in keywords]},
    })


class DietaryEvidenceReproduction(unittest.TestCase):
    def test_literal_denial_is_not_affirmative_evidence(self):
        value = entity(["no low sodium options"])
        verdict = evaluate(value, ["low_sodium"])
        OBSERVATIONS["denial_only"] = verdict.to_dict()
        self.assertEqual(verdict.checks[0].status, "unknown")
        self.assertTrue(verdict.ok, "keep the existing permissive dietary unknown policy")

    def test_denial_cannot_override_existing_high_signal_in_native_plan(self):
        transport = FixtureTransport()
        target = next(place for place in transport.data["places"]
                      if place["entity_id"] == "FIX-P-03")
        target["properties"]["keywords"] = [
            {"name": "caldo de pollo"},
            {"name": "ramen"},
            {"name": "no low sodium options"},
        ]
        input_before = json.dumps(transport.data, sort_keys=True)
        result = agent.run_agent(PERSONAS["rosa"],
                                 qloo=QlooClient(api_key="SYNTHETIC-OFFLINE", transport=transport),
                                 model=agent.ScriptedModel())
        output = DESTINATION / "native-plan-denial.json"
        output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        check = check_low_sodium(parse_entity(target)).to_dict()
        meals = [meal for meal in result["plan"]["meals"]
                 if meal["entity_id"] == "FIX-P-03"]
        rejected = [item for item in result["plan"]["rejected"]
                    if item["entity_id"] == "FIX-P-03"]
        OBSERVATIONS["native_plan"] = {
            "check": check, "target_meals": meals, "target_rejected": rejected,
            "fixture_requests": transport.log, "mock": result["mock"],
            "synthetic_input_unchanged": input_before == json.dumps(transport.data, sort_keys=True),
            "complete_result_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        }
        self.assertEqual(check["status"], "fail")
        self.assertEqual(meals, [])
        self.assertEqual(len(rejected), 1)
        self.assertTrue(result["mock"])
        self.assertEqual(input_before, json.dumps(transport.data, sort_keys=True))

    def test_existing_affirmative_high_and_unknown_policy_controls(self):
        cases = [
            (["low sodium options"], "pass", True),
            (["ramen"], "fail", False),
            (["ramen", "low sodium options"], "pass", True),
            (["seasonal menu"], "unknown", True),
            ([], "unknown", True),
        ]
        records = []
        for keywords, expected_status, expected_ok in cases:
            verdict = evaluate(entity(keywords), ["low_sodium"])
            records.append({"keywords": keywords, "verdict": verdict.to_dict()})
            self.assertEqual(verdict.checks[0].status, expected_status)
            self.assertEqual(verdict.ok, expected_ok)
        outing = evaluate(entity(["ramen"]), ["low_sodium"], kind="outing")
        self.assertTrue(outing.ok)
        self.assertEqual(outing.checks, [])
        OBSERVATIONS["policy_controls"] = records
        OBSERVATIONS["outing_control"] = outing.to_dict()


if __name__ == "__main__":
    frozen = json.loads((SOURCE.parent / "source-pin.json").read_text())
    initial = {item["path"]: hashlib.sha256((SOURCE / item["path"]).read_bytes()).hexdigest()
               for item in frozen["files"]}
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(DietaryEvidenceReproduction)
    outcome = unittest.TextTestRunner(verbosity=2).run(suite)
    final = {name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() for name in initial}
    receipt = {
        "source_commit": frozen["commit"], "source_tree": frozen["tree"],
        "source_root": str(SOURCE),
        "test_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "tests_run": outcome.testsRun, "failures": len(outcome.failures),
        "errors": len(outcome.errors), "skips": len(outcome.skipped),
        "source_unchanged": initial == final, "observations": OBSERVATIONS,
        "boundary": "Synthetic keyword evidence and actual native offline planner; no live provider or health outcome claim.",
    }
    (DESTINATION / "receiving.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: value for key, value in receipt.items() if key != "observations"}))
    raise SystemExit(not outcome.wasSuccessful())
