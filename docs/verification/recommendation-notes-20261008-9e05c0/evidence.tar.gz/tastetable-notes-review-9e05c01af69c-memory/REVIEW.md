# Independent TasteTable recommendation-note receiving review

## Decision

Accept the repaired `agent.py` with SHA-256
`4d2b2438c39635b34d98ce10d751c9e70f14be057b7c68b4fd298e505cc5787d`
within the exercised native fixture support envelope. The independent matrix
passes 16 methods across 18 scenarios in both normal and optimized Python.
Every final non-note result, checked selection, ordering, trace, actual request,
and model call count equals the exact receiving source for those scenarios.

This review did not edit production source, call a live provider, publish a PR,
change a service, or duplicate the author's retained native test gate.

## Exact sources and verifier

The receiving commit is `9f9105c29ab1a68a501b5f4c0b7180f0db968d38`.
Its unchanged native agent Git blob is
`15ae2c26dd14a8eec43dc328e87d6f12c8d460d2`.

| Item | SHA-256 |
| --- | --- |
| Receiving agent | `b301247b8e9459327afa19964d02a9647c0d39f36e55c380115af3b30d538817` |
| Held first candidate | `2101ecf2ae244cf6e9bbc57903dc2d9035941d5af0087e130afa15fccc29fdd8` |
| Repaired candidate | `4d2b2438c39635b34d98ce10d751c9e70f14be057b7c68b4fd298e505cc5787d` |
| Final independent test | `445069383261f8e25ef79d8a52b4ad3aa23c9fb8a95ed2745d9697fc0b641096` |
| Original independent oracle | `7d7ec04174b423a49bbe41fc2246920041a75c821c36064181957cd83bd8db6d` |
| Final verification receipt | `cb102ffdb5638ef08ada59e773533ee5674c139a0a85c2c2c11949e81eb60c49` |

Exact independent source copies are `baseline/`, `held-candidate-2101/`, and
`candidate-final-4d2b/`. Each contains only the agent and four unchanged native
dependency/fixture files. Their before/after manifests are in
`final-verification.json`; that receipt also confirms the producer's repaired
agent remained at the accepted hash throughout this run.

## Results and negative controls

| Source | Normal | Optimized | Meaning |
| --- | --- | --- | --- |
| Receiving baseline | 6 pass, 10 failed methods | 6 pass, 10 failed methods | 11 failure records per mode expose misleading or missing note provenance. |
| Held first candidate | 14 pass, 2 failed methods | 14 pass, 2 failed methods | Four failure records per mode expose direct iterable request/selection changes. |
| Repaired candidate | 16 pass | 16 pass | All 18 non-note native observations preserved. |

There are no test errors or skipped methods in these final six runs. The two
held-candidate failed methods are the direct iterable check and the aggregate
native-preservation check; they each report the same two concrete input cases.
They represent one production normalization defect, not four independent defects.

### Original note defect

Three actual synthetic 503 recommendation requests returned no candidates and
produced no rejected verdicts. The baseline still said that zero restaurants
passed every constraint and described an unsafe pick. Successful empty lookups,
pre-request argument errors, and response parsing errors received the same
unsupported explanation. An outing lookup failure could also leave no note when
all four meals were present.

The repaired source derives notes from lookup completion and freshly evaluated
constraint verdicts. It distinguishes restaurant and outing lookups, retains
checked suggestions through a partial failure, clears a failure when that same
normalized lookup completes later, and preserves a failure for a different
unresolved query. The wording says a lookup could not be completed; it does not
assert global provider availability or infer a network attempt from an exception
class. Provider diagnostics stay out of plan notes. Existing trace diagnostics
and the model's final message remain byte-equivalent in the captured results.

### Consequential first-candidate iterable regression

The native direct `Toolbox.qloo_recs` path already accepts single-use ID
iterables. The first candidate joined those iterables for bookkeeping before the
native client joined them for its request.

| Direct input | Native receiving behavior | Held candidate behavior | Repaired behavior |
| --- | --- | --- | --- |
| Single-use Cuban tag generator | Sends Cuban tag; returns 2 candidates and checks one meal, `FIX-P-01`. | Sends an empty tag; returns 18 places and changes the checked meals to `FIX-V-03`, `FIX-P-01`, `FIX-P-03`, `FIX-V-01`. | Exact receiving request, candidates, checked meal and metadata. |
| Single-use `FIX-A-celia` signal generator | Sends that signal; two affinities are 0.91 and 0.88. | Sends an empty signal; affinities become 0.248 and 0.231. | Exact receiving request, affinities and metadata. |

`iterable-negative-control.json` records full parameters, returned candidates,
and checked meal IDs for all three source pins. The repaired bookkeeping opts
out for unsupported carriers before consuming them, leaving existing native
dispatch and its diagnostics intact. It does not validate or materialize them
on behalf of the caller.

## Coverage and execution

The 18 cases cover healthy results; all-503 and all-OSError lookups; successful
empty responses; actual rejected fixture candidates; an outing-only failure;
partial checked restaurant results; invalid filter types and non-string tag IDs;
post-response parse errors; same-query recovery; a different query succeeding;
empty same-query recovery; equivalent omitted/empty optional inputs; untrusted
final model prose; the exact 12-step call budget; and the two direct single-use
ID cases.

The harness uses the actual native `QlooClient`, a subclass of the native
`FixtureTransport`, and the actual tool-calling loop with native `ScriptedModel`
or explicit model-shaped synthetic messages. The fixture logs requests before
injecting its synthetic outcome. `urllib.request.urlopen` is patched to raise
if anything attempts live network access. All credentials in this harness are
literal synthetic placeholders.

From this directory, a final receiving replay is:

```bash
PYTHONDONTWRITEBYTECODE=1 \
TASTETABLE_NOTES_SOURCE="$PWD/candidate-final-4d2b" \
TASTETABLE_NOTES_BASELINE_RESULTS="$PWD/expanded-baseline-results.json" \
TASTETABLE_NOTES_OBSERVATIONS="$PWD/replay-observations.json" \
python3 -B test_notes_receiving.py
```

Use `python3 -B -O` for the optimized mode. Each execution writes its configured
observation path. Existing acceptance logs and receipts should be preserved;
choose an owned fresh output path for a later receiving run.

This proves the recorded native fixture cases, not live provider availability,
real-model quality, or arbitrary third-party Qloo client behavior. Bookkeeping
is deliberately restricted to the ordinary builtin carriers emitted by JSON
tool calls. Direct unsupported carriers retain prior native behavior without a
new lookup-outcome record.

## Oracle history and artifact custody

The original 15-method oracle required the literal word `constraint` in a
genuine-rejection note. The first candidate accurately said `requested checks`.
Its initial 14-pass/1-fail result therefore included a reviewer wording error.
`initial-oracle-test.py`, the original baseline golden file, and the initial
candidate logs/receipt remain preserved. The final oracle accepts either
semantically accurate phrase while still requiring real rejected verdicts,
and adds the two direct iterable cases in one method. The production source was
not changed to satisfy that lexical preference.

The final six run logs and their observation JSON files are named in
`final-verification.json`. That receipt also preserves all source/dependency
hashes before and after execution, the test hash, scenario-specific non-note
equality, and equality between final normal and optimized observations.

All new review artifacts are in this agent's owned `/dev/shm` directory because
the shared overlay had no free space. They are ready for root's source/evidence
integration; no remote publication or additional custody transfer was performed
as part of this independent review.
