"""Replay the complete current Python suite using installed dependencies only."""
from pathlib import Path
import os
from unittest.mock import patch
import pytest

root = Path(__file__).resolve().parent
os.chdir(root / "candidate")
# Ambient provider settings are irrelevant to this synthetic-fixture receipt.
for key in ("TASTETABLE_LIVE", "TASTETABLE_LLM_LIVE", "OPENAI_API_KEY", "QLOO_API_KEY"):
    os.environ.pop(key, None)
with patch("urllib.request.urlopen", side_effect=AssertionError("external network forbidden in notes receiving suite")):
    raise SystemExit(pytest.main(["-p", "no:cacheprovider", "tests", "-q"]))
