"""Run the existing native gate without importing unavailable FastAPI tests."""
from pathlib import Path
import sys
import unittest

root = Path(__file__).resolve().parent / "candidate"
sys.path[:0] = [str(root), str(root / "tests")]
import test_tool_argument_recovery as arguments

names = [
    "test_constraint_binding.ConstraintBindingTests",
    "test_model_selection.ModelSelection",
    "test_tool_error_continuation.ToolErrorContinuation",
    "test_recommendation_purpose.RecommendationPurposeTests.test_invalid_purposes_cannot_fetch_or_reserve_candidate_state",
]
api_methods = {
    "test_real_app_routes_retain_checked_meals_and_the_parse_error",
    "test_unrenderable_decoded_arguments_do_not_lose_checked_api_work",
    "test_surrogate_tool_name_is_escaped_only_in_diagnostics",
}
for name in unittest.defaultTestLoader.getTestCaseNames(arguments.ToolArgumentRecovery):
    if name not in api_methods:
        names.append("test_tool_argument_recovery.ToolArgumentRecovery." + name)
suite = unittest.defaultTestLoader.loadTestsFromNames(names)
if suite.countTestCases() != 41:
    raise RuntimeError(f"Unexpected retained native count: {suite.countTestCases()}")
print("Retained current native gate: 41 methods; three existing PR11 FastAPI methods are outside this interpreter's installed dependencies.", flush=True)
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(not result.wasSuccessful())
