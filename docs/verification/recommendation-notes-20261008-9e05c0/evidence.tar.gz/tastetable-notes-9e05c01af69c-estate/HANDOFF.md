# Original notes candidate — frozen review

This receipt applies only to receiving main `9f9105c29ab1a68a501b5f4c0b7180f0db968d38`. Main later advanced through PR #11; the publication successor has a separate directory and receipt. This source and all tests/evidence remain frozen.

## Source and scope

- Receiving `agent.py`: Git blob `15ae2c26dd14a8eec43dc328e87d6f12c8d460d2`, SHA256 `b301247b8e9459327afa19964d02a9647c0d39f36e55c380115af3b30d538817`.
- Candidate `agent.py`: SHA256 `4d2b2438c39635b34d98ce10d751c9e70f14be057b7c68b4fd298e505cc5787d`, Git blob `dc5d1a54cef4c36de96a6d677808d251309b0656`.
- New `tests/test_recommendation_notes.py`: SHA256 `14d33c42bec3694215b9fdb3118cd1e200a8192f462b4c72ae2d8f1487a4b48b`.
- Only these two files differ. Eleven copied native dependencies and retained tests match the exact receiving blobs. `notes.patch` passed `git apply --check` against the baseline.

## Behavior

Native recommendation completion is tracked per purpose and normalized query. A valid lookup that throws gets a plain 'could not be completed' note; a later successful identical normalized query clears only that lookup. A different successful query preserves the factual incomplete-lookup note. Provider availability and rejection are never inferred from an exception class. Successful zero-candidate responses and actual checked rejections get separate factual notes. Missing slots use neutral checked-suggestion counts. Healthy fixture plans keep empty notes.

Bookkeeping only observes exact built-in JSON carriers. Iterators and custom values reach the original QlooClient without extra iteration or conversion and stay unclassified. No provider, ranking, requirement, purpose, retry, budget, or trace code changes.

## Qualification

| Carrier | Result |
|---|---|
| Author current candidate | 13/13 methods pass |
| Author current candidate under `-O` | 13/13 methods pass |
| Retained native selection/constraints/purpose/failure suite | 32/32 methods pass |
| Author receiving baseline negative control | 13 methods, 19 failed assertion/subtest records |
| Independent final current candidate | 16/16 methods, 18 scenarios pass, normal and `-O` |
| Independent receiving baseline | 6 passing and 10 failing methods, 11 failure records |
| Independent held first-cut `2101ecf2...` | 14 passing and 2 failing methods, 4 failure records |

All 18 independent candidate non-note result objects, checked picks, traces, actual requests, and call counts equal the receiving baseline. The initial independent lexical assertion expected the word 'constraint'; the accurate 'requested checks' wording was accepted with the old oracle and logs retained. This oracle correction is separate from the real first-cut iterable defect: joining a tag generator consumed it before native dispatch, changed a Cuban query from 2 to 18 candidates, and changed checked meals from 1 to 4. The held source is `first-cut/candidate/agent.py`; final repair opts out before consuming non-JSON carriers.

Author logs are in `evidence/`. Independent evidence remains owned by `/root/memory_path` at `/dev/shm/tastetable-notes-review-9e05c01af69c-memory`; `final-verification.json` SHA256 `cb102ffdb5638ef08ada59e773533ee5674c139a0a85c2c2c11949e81eb60c49`, final verifier SHA256 `445069383261f8e25ef79d8a52b4ad3aa23c9fb8a95ed2745d9697fc0b641096`.

This is native synthetic-fixture qualification. No live provider, API/FastAPI, or browser test is claimed for this notes snapshot.
