"""Compare the maintained API's trace encoder with JSON-only preflights."""
import hashlib
import json
from pathlib import Path
import sys

from fastapi.encoders import jsonable_encoder
from starlette.responses import JSONResponse

cases = [
    ('ordinary_object', '{"query":"café","kind":"tag"}'),
    ('shallow_list', '[0]'),
    ('nested_list_1100', '[' * 1100 + '0' + ']' * 1100),
    ('nested_object_1100', '{"unknown":' + '[' * 1100 + '0' + ']' * 1100 + '}'),
    ('nonfinite_scalar', 'NaN'),
    ('nonfinite_member', '{"take":NaN}'),
    ('lone_surrogate', '"\\ud800"'),
]
report = {'python': sys.version, 'recursion_limit': sys.getrecursionlimit(), 'cases': []}
for name, raw in cases:
    value = json.loads(raw)
    payload = {'trace': [{'step': 2, 'tool': 'qloo_recs', 'args': value, 'result_summary': 'TypeError: diagnostic control'}]}
    row = {'case': name, 'argument_characters': len(raw), 'decoded_type': type(value).__name__}
    operations = {
        'default_json_dumps': lambda: json.dumps(payload),
        'strict_json_utf8': lambda: json.dumps(payload, ensure_ascii=False, allow_nan=False).encode('utf-8'),
        'native_api_encoder_and_response': lambda: JSONResponse(jsonable_encoder(payload)).body,
    }
    for label, operation in operations.items():
        try:
            result = operation()
            row[label] = {'outcome': 'ok', 'length': len(result)}
        except Exception as error:
            row[label] = {'outcome': type(error).__name__, 'message': str(error)}
    report['cases'].append(row)

report['harness_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
output = Path(__file__).with_suffix('.json')
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
