"""Receiving-only prototype; no production source file is modified."""
import copy
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

SOURCE = Path('/dev/shm/tastetable-argument-de6263')
sys.path.insert(0, str(SOURCE))
import agent
import app
from fastapi.testclient import TestClient
from personas import PERSONAS
from qloo_client import QlooClient, FixtureTransport


def diagnostic_args(value):
    """Retain ordinary JSON values; bound only their diagnostic representation."""
    stack = [(value, 0)]
    nodes = 0
    while stack:
        current, depth = stack.pop()
        nodes += 1
        if depth > 32 or nodes > 2048:
            return {'omitted': True, 'reason': 'argument structure exceeds trace limits'}
        children = current.values() if isinstance(current, dict) else current if isinstance(current, list) else None
        if children is not None:
            if len(children) + nodes + len(stack) > 2048:
                return {'omitted': True, 'reason': 'argument structure exceeds trace limits'}
            stack.extend((item, depth + 1) for item in children)
    try:
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')
    except (TypeError, ValueError, RecursionError):
        return {'omitted': True, 'reason': 'arguments cannot be represented in a JSON trace'}
    if len(encoded) > 8192:
        return {'omitted': True, 'reason': 'argument text exceeds trace limits'}
    return value


def diagnostic_text(text):
    return text.encode('utf-8', 'backslashreplace').decode('utf-8')[:4096]


original_entry = app.run_agent
original_dispatch = agent.Toolbox.run
dispatches = []


def received_entry(*args, **kwargs):
    result = original_entry(*args, **kwargs)
    for row in result['trace']:
        row['args'] = diagnostic_args(row['args'])
        row['tool'] = diagnostic_text(row['tool'])
        row['result_summary'] = diagnostic_text(row['result_summary'])
    return result


def observe_dispatch(self, name, args):
    # The very same argument object is forwarded; the prototype changes only
    # completed response diagnostics, after the native tool loop has run.
    dispatches.append({'tool': name, 'argument_type': type(args).__name__})
    return original_dispatch(self, name, args)


class Model:
    def __init__(self, raw, tool):
        self.calls = 0
        self.messages = []
        self.batches = [
            [agent._call('fetched', 'qloo_recs', {'filter_type': 'urn:entity:place', 'purpose': 'restaurant',
                                               'tag_ids': ['urn:tag:genre:restaurant:Cuban']})],
            [agent._call('checked', 'constraint_check', {'entity_ids': ['FIX-P-01', 'FIX-P-04'],
                    'constraints': PERSONAS['rosa']['constraints'], 'kind': 'restaurant'})],
            [{'id': 'challenged', 'type': 'function', 'function': {'name': tool, 'arguments': raw}}],
            [agent._call('correction', 'qloo_search', {'query': '', 'kind': 'tag'})],
        ]
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

    def create(self, **kwargs):
        self.calls += 1
        self.messages = copy.deepcopy(kwargs['messages'])
        batch = self.batches.pop(0) if self.batches else []
        return agent._completion('Completed subsequent correction' if not batch else None, tool_calls=batch)


cases = [
    ('ordinary_object', '{"query":"","kind":"tag"}', 'qloo_search'),
    ('shallow_list', '[0]', 'qloo_recs'),
    ('nested_list_1100', '[' * 1100 + '0' + ']' * 1100, 'qloo_recs'),
    ('nested_object_1100', '{"unknown":' + '[' * 1100 + '0' + ']' * 1100 + '}', 'qloo_recs'),
    ('nonfinite_scalar', 'NaN', 'qloo_recs'),
    ('nonfinite_member', '{"take":NaN}', 'qloo_recs'),
    ('lone_surrogate', '"\\ud800"', 'qloo_recs'),
    ('lone_surrogate_key', '{"\\ud800":0}', 'qloo_recs'),
]
report = {'source': str(SOURCE), 'source_sha256_before': hashlib.sha256((SOURCE / 'agent.py').read_bytes()).hexdigest(),
          'prototype_only': True, 'production_source_modified': False,
          'decoder_limits_before': [sys.get_int_max_str_digits(), sys.getrecursionlimit()], 'cases': []}
with patch.object(agent.os, 'environ', {}), patch('urllib.request.urlopen', side_effect=RuntimeError('external network forbidden')):
    for name, raw, tool in cases:
        observations = []
        successful_results = []
        for normalized in (False, True):
            model = Model(raw, tool)
            fixture = FixtureTransport()
            qloo = QlooClient(api_key='synthetic-trace-prototype', transport=fixture)
            dispatches.clear()
            unhandled = []

            async def observer(scope, receive, send):
                try:
                    await app.app(scope, receive, send)
                except Exception as error:
                    unhandled.append(type(error).__name__)
                    raise

            with patch.object(app.QlooClient, 'from_env', return_value=qloo), \
                 patch.object(app, 'model_from_env', return_value=model), \
                 patch.object(app, 'run_agent', received_entry if normalized else original_entry), \
                 patch.object(agent.Toolbox, 'run', observe_dispatch), \
                 TestClient(observer, raise_server_exceptions=False) as client:
                response = client.post('/api/plan', json=PERSONAS['rosa'])
            item = {'diagnostic_normalization': normalized, 'http_status': response.status_code,
                    'unhandled': unhandled, 'model_exchanges': model.calls,
                    'fixture_requests': len(fixture.log), 'dispatches': list(dispatches)}
            if response.status_code == 200:
                result = response.json()
                if [meal['entity_id'] for meal in result['plan']['meals']] != ['FIX-P-01']:
                    raise RuntimeError('Checked meal changed')
                if result['model_message'] != 'Completed subsequent correction' or model.calls != 5:
                    raise RuntimeError('Subsequent correction was lost')
                item['challenged_trace'] = result['trace'][2]
                item['checked_meal'] = 'FIX-P-01'
                successful_results.append(result)
            elif normalized:
                raise RuntimeError(f'Prototype did not receive {name}: HTTP {response.status_code}, {unhandled}')
            observations.append(item)
        if observations[0]['dispatches'] != observations[1]['dispatches']:
            raise RuntimeError('Prototype changed valid decoded dispatch')
        if len(successful_results) == 2 and successful_results[0] != successful_results[1]:
            raise RuntimeError('Ordinary response changed')
        report['cases'].append({'name': name, 'observations': observations})

report['source_sha256_after'] = hashlib.sha256((SOURCE / 'agent.py').read_bytes()).hexdigest()
report['decoder_limits_after'] = [sys.get_int_max_str_digits(), sys.getrecursionlimit()]
if report['source_sha256_before'] != report['source_sha256_after'] or report['decoder_limits_before'] != report['decoder_limits_after']:
    raise RuntimeError('Production source or interpreter limits changed')
report['harness_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['passed'] = True
output = Path(__file__).with_suffix('.json')
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': True, 'output': str(output), 'cases': [
    {'name': row['name'], 'statuses': [o['http_status'] for o in row['observations']],
     'initial_errors': row['observations'][0]['unhandled']} for row in report['cases']]}))
