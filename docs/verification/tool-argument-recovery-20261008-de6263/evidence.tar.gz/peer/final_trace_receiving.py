"""Receive the frozen native trace correction without a prototype wrapper."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument('source', type=Path)
parser.add_argument('output', type=Path)
options = parser.parse_args()
source = options.source.resolve()
sys.path.insert(0, str(source))
import agent
import app
from fastapi.testclient import TestClient
from personas import PERSONAS
from qloo_client import QlooClient, FixtureTransport


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=True, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


class Model:
    def __init__(self, raw, tool, same_batch=False):
        self.calls = 0
        self.messages = []
        fetched = agent._call('fetched', 'qloo_recs', {'filter_type': 'urn:entity:place', 'purpose': 'restaurant',
                                                    'tag_ids': ['urn:tag:genre:restaurant:Cuban']})
        checked = agent._call('checked', 'constraint_check', {'entity_ids': ['FIX-P-01', 'FIX-P-04'],
                    'constraints': PERSONAS['rosa']['constraints'], 'kind': 'restaurant'})
        challenged = {'id': 'challenged', 'type': 'function', 'function': {'name': tool, 'arguments': raw}}
        correction = agent._call('correction', 'qloo_search', {'query': '', 'kind': 'tag'})
        self.batches = ([[challenged, fetched, checked], [correction]] if same_batch else
                        [[fetched], [checked], [challenged], [correction]])
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

    def create(self, **kwargs):
        self.calls += 1
        self.messages = copy.deepcopy(kwargs['messages'])
        batch = self.batches.pop(0) if self.batches else []
        return agent._completion('Completed subsequent correction' if not batch else None, tool_calls=batch)


original_dispatch = agent.Toolbox.run
dispatches = []


def observe_dispatch(self, name, args):
    dispatches.append({'tool': name, 'argument_type': type(args).__name__, 'argument_sha256': fingerprint(args)})
    return original_dispatch(self, name, args)


deep_list = '[' * 1100 + '0' + ']' * 1100
cases = [
    ('ordinary_object', '{"query":"","kind":"tag"}', 'qloo_search', False, False),
    ('shallow_list', '[0]', 'qloo_recs', False, False),
    ('nested_list_1100', deep_list, 'qloo_recs', True, False),
    ('nested_object_1100', '{"unknown":' + deep_list + '}', 'qloo_recs', True, False),
    ('nonfinite_scalar', 'NaN', 'qloo_recs', True, False),
    ('nonfinite_member', '{"take":NaN}', 'qloo_recs', True, False),
    ('lone_surrogate', '"\\ud800"', 'qloo_recs', True, False),
    ('lone_surrogate_key', '{"\\ud800":0}', 'qloo_recs', True, False),
    ('nested_dictionary_1100', '{"nested":' * 1100 + '0' + '}' * 1100, 'qloo_recs', True, False),
    ('same_batch_then_next_model', deep_list, 'qloo_recs', True, True),
    ('surrogate_tool_name', '{}', 'unknown-' + chr(0xd800), False, False),
]
files = ('agent.py', 'tests/test_tool_argument_recovery.py')
before = {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in files}
report = {'source': str(source), 'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
          'source_sha256_before': before, 'native_implementation_only': True,
          'python': sys.version, 'optimized': sys.flags.optimize,
          'decoder_limits_before': [sys.get_int_max_str_digits(), sys.getrecursionlimit()], 'cases': []}
with patch.object(agent.os, 'environ', {}), patch('urllib.request.urlopen', side_effect=RuntimeError('external network forbidden')) as network:
    for name, raw, tool, omitted, same_batch in cases:
        model = Model(raw, tool, same_batch)
        fixture = FixtureTransport()
        qloo = QlooClient(api_key='synthetic-final-trace-receiving', transport=fixture)
        dispatches.clear()
        unhandled = []

        async def observer(scope, receive, send):
            try:
                await app.app(scope, receive, send)
            except Exception as error:
                unhandled.append(type(error).__name__)
                raise

        route = '/api/plan/sample/rosa' if name == 'surrogate_tool_name' else '/api/plan'
        with patch.object(app.QlooClient, 'from_env', return_value=qloo), \
             patch.object(app, 'model_from_env', return_value=model), \
             patch.object(agent.Toolbox, 'run', observe_dispatch), \
             TestClient(observer, raise_server_exceptions=False) as client:
            response = client.post(route, json=PERSONAS['rosa'])
        require(response.status_code == 200, f'{name}: HTTP {response.status_code}, {unhandled}')
        result = response.json()
        require(not unhandled, f'{name}: unhandled exception')
        require([meal['entity_id'] for meal in result['plan']['meals']] == ['FIX-P-01'], f'{name}: checked meal changed')
        require(result['plan']['outing'] is None, f'{name}: unexpected outing')
        require([item['entity_id'] for item in result['plan']['rejected']] == ['FIX-P-04'], f'{name}: failed candidate changed')
        require(result['model_message'] == 'Completed subsequent correction', f'{name}: lost correction')
        require(model.calls == (3 if same_batch else 5) <= agent.MAX_STEPS, f'{name}: model budget changed')
        require(len(fixture.log) == 1, f'{name}: unexpected provider call')
        expected_dispatch = ([tool, 'qloo_recs', 'constraint_check', 'qloo_search'] if same_batch else
                             ['qloo_recs', 'constraint_check', tool, 'qloo_search'])
        require([item['tool'] for item in dispatches] == expected_dispatch, f'{name}: dispatch sequence changed')
        index = 0 if same_batch else 2
        require(dispatches[index]['argument_sha256'] == fingerprint(json.loads(raw)), f'{name}: decoded argument value changed before dispatch')
        trace = result['trace'][index]
        require(trace['tool'] == tool.encode('utf-8', 'backslashreplace').decode('utf-8'), f'{name}: wrong diagnostic tool name')
        if omitted:
            require(isinstance(trace['args'], dict) and isinstance(trace['args'].get('trace_omitted'), str), f'{name}: missing omission marker')
        else:
            require(fingerprint(trace['args']) == fingerprint(json.loads(raw)), f'{name}: ordinary trace argument changed')
        tool_reply = next(message for message in model.messages if message.get('tool_call_id') == 'challenged')
        reply = json.loads(tool_reply['content'])
        if name != 'ordinary_object':
            expected_prefix = 'unknown tool ' if name == 'surrogate_tool_name' else 'TypeError:'
            require(reply['error'].startswith(expected_prefix), f'{name}: original tool result changed')
            require(trace['result_summary'] == reply['error'].encode('utf-8', 'backslashreplace').decode('utf-8'), f'{name}: wrong diagnostic error text')
        wire_call = next(call for message in model.messages for call in (message.get('tool_calls') or []) if call['id'] == 'challenged')
        require(wire_call['function']['arguments'] == raw and wire_call['function']['name'] == tool, f'{name}: original model history was changed')
        report['cases'].append({'name': name, 'http_status': response.status_code, 'route': route,
            'model_exchanges': model.calls, 'fixture_requests': len(fixture.log), 'dispatches': list(dispatches),
            'challenged_trace': trace, 'checked_meal': 'FIX-P-01', 'unhandled': unhandled, 'passed': True})
    report['external_requests'] = network.call_count

report['source_sha256_after'] = {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in files}
report['decoder_limits_after'] = [sys.get_int_max_str_digits(), sys.getrecursionlimit()]
require(before == report['source_sha256_after'], 'Production source changed')
require(report['decoder_limits_before'] == report['decoder_limits_after'], 'Interpreter limits changed')
require(report['external_requests'] == 0, 'External request attempted')
report['harness_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
report['passed'] = True
options.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': True, 'output': str(options.output), 'cases': len(report['cases']),
                  'model_exchanges': sum(row['model_exchanges'] for row in report['cases'])}))
