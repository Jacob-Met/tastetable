"""Independent HTTP receiving probe for model-argument decoder recovery."""
import argparse
import copy
import hashlib
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
from unittest.mock import patch
from urllib.parse import urlsplit

parser = argparse.ArgumentParser()
parser.add_argument('source', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--case', default='later_recursion_limit')
options = parser.parse_args()
source = options.source.resolve()
sys.path.insert(0, str(source))
import agent
import app as application
import uvicorn
from personas import PERSONAS
from qloo_client import QlooClient, FixtureTransport


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def call(label, tool, arguments):
    return agent._call(label, tool, arguments)


def bad(label, raw='{', tool='qloo_recs'):
    return {'id': label, 'type': 'function', 'function': {'name': tool, 'arguments': raw}}


def fetched():
    return call('fetch', 'qloo_recs', {'filter_type': 'urn:entity:place', 'purpose': 'restaurant',
                                    'tag_ids': ['urn:tag:genre:restaurant:Cuban']})


def checked():
    return call('check', 'constraint_check', {'entity_ids': ['FIX-P-01', 'FIX-P-04'],
               'constraints': PERSONAS['rosa']['constraints'], 'kind': 'restaurant'})


active = {}
external_requests = []


class Peer(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_POST(self):
        require(self.path == '/v1/chat/completions', 'Wrong model path')
        require('Authorization' not in self.headers, 'Unexpected authorization')
        request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        require(request['model'] == 'independent-argument-recovery', 'Wrong model selection')
        active['messages'] = request['messages']
        active['requests'] += 1
        batch = active['batches'].pop(0) if active['batches'] else []
        response = agent._completion('Completed independent correction' if not batch else None,
                                     tool_calls=batch)
        body = json.dumps(response).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


peer = ThreadingHTTPServer(('127.0.0.1', 0), Peer)
peer_thread = threading.Thread(target=peer.serve_forever, daemon=True)
peer_thread.start()
peer_port = peer.server_address[1]
original_urlopen = agent.urllib.request.urlopen
original_dispatch = agent.Toolbox.run


def local_only(request, *args, **kwargs):
    parsed = urlsplit(request.full_url)
    if (parsed.scheme, parsed.hostname, parsed.port, parsed.path) != ('http', '127.0.0.1', peer_port, '/v1/chat/completions'):
        external_requests.append('blocked')
        raise RuntimeError('Unexpected external request')
    return original_urlopen(request, *args, **kwargs)


def fixture_client():
    active['fixture'] = FixtureTransport()
    return QlooClient(api_key='synthetic-independent-only', transport=active['fixture'])


def tracked_dispatch(self, name, args):
    active['dispatches'].append(name)
    return original_dispatch(self, name, args)


app_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
app_socket.bind(('127.0.0.1', 0))
app_socket.listen(16)
app_port = app_socket.getsockname()[1]
server = uvicorn.Server(uvicorn.Config(application.app, log_level='critical', lifespan='off'))
server_thread = threading.Thread(target=server.run, kwargs={'sockets': [app_socket]}, daemon=True)
files = ('agent.py', 'tests/test_tool_argument_recovery.py')
source_before = {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
                 for name in files if (source / name).exists()}
report = {'source': str(source),
          'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
          'python': sys.version, 'optimized': sys.flags.optimize,
          'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'source_before': source_before, 'cases': []}
report['decoder_limits_before'] = {'integer_digits': sys.get_int_max_str_digits(), 'recursion': sys.getrecursionlimit()}
patches = [patch.object(application.QlooClient, 'from_env', classmethod(lambda cls: fixture_client())),
           patch.object(application, 'model_from_env', lambda: agent.OpenAICompatModel(
               f'http://127.0.0.1:{peer_port}/v1', 'independent-argument-recovery')),
           patch.object(agent.urllib.request, 'urlopen', local_only),
           patch.object(agent.Toolbox, 'run', tracked_dispatch)]
for item in patches:
    item.start()


def scenario(name, batches, expected_meals, expected_errors, expected_dispatches,
             expected_requests, route='/api/plan'):
    if name != options.case:
        return
    active.clear()
    active.update(batches=copy.deepcopy(batches), messages=[], requests=0, dispatches=[])
    body = {key: copy.deepcopy(PERSONAS['rosa'][key]) for key in ('cuisines', 'music', 'films', 'constraints', 'city')}
    conn = http.client.HTTPConnection('127.0.0.1', app_port, timeout=10)
    try:
        conn.request('POST', route, json.dumps(body), {'Content-Type': 'application/json'})
        response = conn.getresponse()
        raw = response.read()
        result = json.loads(raw) if response.getheader('Content-Type', '').startswith('application/json') else None
    finally:
        conn.close()
    tool_messages = {message['tool_call_id']: json.loads(message['content'])
                     for message in active['messages'] if message['role'] == 'tool'}
    observed_errors = {label: value['error'] for label, value in tool_messages.items() if 'error' in value}
    row = {'name': name, 'route': route, 'http_status': response.status,
           'model_exchanges': active['requests'], 'dispatches': active['dispatches'],
           'fixture_requests': len(active['fixture'].log),
           'correlated_errors': observed_errors,
           'previously_checked_ids': sorted({v['entity_id'] for value in tool_messages.values()
                                            for v in value.get('verdicts', []) if v['ok']})}
    try:
        require(response.status == 200, f'Expected HTTP 200; received {response.status}: {raw.decode()}')
        require([p['entity_id'] for p in result['plan']['meals']] == expected_meals, 'Wrong surviving meals')
        require(result['plan']['outing'] is None, 'Unexpected outing')
        require(result['comparison']['grounded']['constraint_checked'] == len(expected_meals), 'Wrong verified-pick count')
        require(active['requests'] == expected_requests <= agent.MAX_STEPS, 'Wrong model request budget')
        require(active['dispatches'] == expected_dispatches, 'Malformed call dispatched or valid sibling lost')
        require(set(observed_errors) == set(expected_errors), 'Error correlation differs from call identifiers')
        for label, prefix in expected_errors.items():
            require(observed_errors[label].startswith(prefix), f'Wrong decoder error for {label}')
        trace_errors = [r for r in result['trace'] if any(r['result_summary'].startswith(prefix)
                        for prefix in expected_errors.values())]
        require(len(trace_errors) == len(expected_errors), 'API trace lost a decoder failure')
        require(all(r['args'] is None for r in trace_errors), 'Undecoded arguments escaped into trace')
        require(result['mock'] is True, 'Synthetic source marker missing')
        row.update(passed=True, surviving_meals=expected_meals, trace_errors=len(trace_errors))
    except Exception as error:
        row.update(passed=False, error=str(error))
    report['cases'].append(row)


try:
    server_thread.start()
    deadline = time.monotonic() + 5
    while not server.started and time.monotonic() < deadline and server_thread.is_alive():
        time.sleep(0.01)
    require(server.started, 'Local API did not start')
    kept = ['FIX-P-01']
    scenario('valid_control', [[fetched()], [checked()]], kept, {}, ['qloo_recs', 'constraint_check'], 3)
    scenario('later_truncated_json', [[fetched()], [checked()], [bad('late')]], kept,
             {'late': 'JSONDecodeError:'}, ['qloo_recs', 'constraint_check'], 4, '/api/plan/sample/rosa')
    scenario('same_batch_siblings', [[bad('syntax'), fetched(), bad('type', {'purpose': 'restaurant'}), checked()]], kept,
             {'syntax': 'JSONDecodeError:', 'type': 'TypeError:'}, ['qloo_recs', 'constraint_check'], 2)
    scenario('invalid_check_grants_nothing', [[fetched()], [bad('invalid_check', '{', 'constraint_check')]], [],
             {'invalid_check': 'JSONDecodeError:'}, ['qloo_recs'], 3)
    huge_number = '{"filter_type":"urn:entity:place","purpose":"restaurant","take":' + '1' * 5000 + '}'
    scenario('later_integer_conversion_limit', [[fetched()], [checked()], [bad('numeric', huge_number)]], kept,
             {'numeric': 'ValueError:'}, ['qloo_recs', 'constraint_check'], 4)
    deeply_nested = '{"take":' + '[' * 12000 + '0' + ']' * 12000 + '}'
    scenario('later_recursion_limit', [[fetched()], [checked()], [bad('nested', deeply_nested)]], kept,
             {'nested': 'RecursionError:'}, ['qloo_recs', 'constraint_check'], 4)
finally:
    server.should_exit = True
    server_thread.join(timeout=5)
    peer.shutdown()
    peer.server_close()
    peer_thread.join(timeout=5)
    app_socket.close()
    for item in reversed(patches):
        item.stop()

report['source_after'] = {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in source_before}
report['candidate_unchanged'] = report['source_before'] == report['source_after']
report['external_requests'] = len(external_requests)
report['cleanup_complete'] = not server_thread.is_alive() and not peer_thread.is_alive()
report['decoder_limits_after'] = {'integer_digits': sys.get_int_max_str_digits(), 'recursion': sys.getrecursionlimit()}
require(report['decoder_limits_before'] == report['decoder_limits_after'], 'Decoder limits changed')
report['passed'] = all(row['passed'] for row in report['cases']) and report['candidate_unchanged'] and not external_requests and report['cleanup_complete']
options.output.parent.mkdir(parents=True, exist_ok=True)
options.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'output': str(options.output), 'cases': report['cases']}))
raise SystemExit(0 if report['passed'] else 1)
