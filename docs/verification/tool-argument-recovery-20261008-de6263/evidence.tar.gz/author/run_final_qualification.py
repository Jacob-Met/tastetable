from pathlib import Path
import hashlib,json,subprocess,sys
home=Path('/dev/shm/tastetable-argument-evidence-de6263')
py='/workspace/scratch/de626312ee85/integration-review/venv/bin/python'
final=Path('/dev/shm/tastetable-argument-trace-de6263')
composition=Path('/dev/shm/tastetable-argument-composition-de6263')
for name in ['agent.py','tests/test_tool_argument_recovery.py']:
    (composition/name).write_bytes((final/name).read_bytes())
report={'python':sys.version,'accepted_decoder_commit':'e48aadf098c07b745217441a5a2bc77968f35ea8','final_local_commit':'ae8ae9b27737ce025ed68f4f8d7280929bd34c96','source_parent':'9f9105c29ab1a68a501b5f4c0b7180f0db968d38','cases':[]}
for label,source in [('upstream','/workspace/scratch/de626312ee85/integration-review/current-main'),('decoder-only','/dev/shm/tastetable-argument-de6263'),('complete',str(final))]:
    for optimized in [False,True]:
        name=label+('-optimized' if optimized else '-normal')
        command=[py,'-B']+(['-O'] if optimized else [])+[str(final/'tests/test_tool_argument_recovery.py')]
        env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','TASTETABLE_SOURCE_ROOT':source}
        result=subprocess.run(command,cwd=final,env=env,capture_output=True,text=True)
        (home/(name+'.stdout.log')).write_text(result.stdout)
        (home/(name+'.stderr.log')).write_text(result.stderr)
        report['cases'].append({'name':name,'command':command,'cwd':str(final),'env':env,'exit_code':result.returncode,'stderr_tail':result.stderr.splitlines()[-4:]})
command=[py,'-B','-m','pytest','-q','-p','no:cacheprovider','tests']
env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1'}
result=subprocess.run(command,cwd=composition,env=env,capture_output=True,text=True)
(home/'complete-composition.stdout.log').write_text(result.stdout)
(home/'complete-composition.stderr.log').write_text(result.stderr)
report['cases'].append({'name':'complete-composition','command':command,'cwd':str(composition),'env':env,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
report['source_hashes']={name:hashlib.sha256((final/name).read_bytes()).hexdigest() for name in ['agent.py','tests/test_tool_argument_recovery.py']}
(home/'complete-qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
if any(case['exit_code']!=0 for case in report['cases'] if case['name'].startswith('complete')):
    raise SystemExit(1)
