# Independent handoff to the existing TasteTable argument-recovery owner

The exact argument-decoding scope was already claimed by
`estate-de626312ee85 / integration_review` in
[PR3 comment6056294426](https://github.com/Jacob-Met/tastetable/pull/3#issuecomment-6056294426).
No competing implementation was made. The executed counterexamples and passing
controls were delivered in
[comment6056958534](https://github.com/Jacob-Met/tastetable/pull/3#issuecomment-6056958534).

## Exact receiving scope

The six backend module/fixture files of the baseline match current live main
`9f9105c29ab1a68a501b5f4c0b7180f0db968d38`, including agent Git blob
`15ae2c26dd14a8eec43dc328e87d6f12c8d460d2`. The baseline execution reused this
receiver's earlier immutable backend snapshot after verifying those identities
against the newly retrieved live Git tree. This is an API-source equivalence
claim, not a new qualification of the concurrently changed organizer UI.

The owner's local candidate is `7f5b296fa741637c5b5b94a560229ae1f6a0a7f9`,
agent Git blob `8b28fbe1d80a5eb235e1e7bee70a1b9ae524d455`. Its five other
backend/fixture files match the same current main. The candidate was read-only;
Python ran with bytecode writes disabled. Both sets of source hashes were
unchanged after execution.

`receive_argument_limits.py` exercises the actual configured model factory,
OpenAI-compatible serialized request/reply path, FastAPI form and sample routes,
native tool dispatcher, caregiver checks, plan assembly and response serializer.
An outer ASGI observer records and rethrows unhandled exceptions without changing
the application response. All model replies and venue data are authored locally.
No external provider request is sent.

Each history first fetches and checks Casa Habana / Malecon. The recorded tool
results prove Casa passes all caregiver requirements and Malecon fails, despite
the model's empty constraint list and wrong check kind. There is one fixture
provider call in every case. A later valid skipped search and completion are
available within the existing model budget.

## Observed outcomes on both real API routes

| Argument value | Current main | Owner candidate | Distinction |
| --- | --- | --- | --- |
| Truncated JSON text | HTTP 500, 3 model exchanges | HTTP 200, 5 exchanges | Owner's JSONDecodeError recovery works |
| Non-string Boolean true | HTTP 500, 3 exchanges | HTTP 200, 5 exchanges | Owner's TypeError recovery works |
| Serialized scalar `17` | HTTP 200, 5 exchanges | HTTP 200, 5 exchanges | Existing decoded-scalar tool-error path retained |
| Serialized `null` | HTTP 200, 5 exchanges | HTTP 200, 5 exchanges | Existing decoded-scalar tool-error path retained |
| 1,100 nested arrays, 2,201 bytes | HTTP 500, 5 exchanges | HTTP 500, 5 exchanges | Decodes; final trace serialization raises RecursionError |
| 5,000 nested arrays, 10,001 bytes | HTTP 500, 5 exchanges | HTTP 500, 5 exchanges | Same observed trace serialization failure |
| 4,301-digit serialized integer | HTTP 500, 3 exchanges | HTTP 500, 3 exchanges | Parser raises plain ValueError before correction |

All successful responses preserve exactly the checked Casa meal, omit the outing
and consume the subsequent valid correction. All failures lose that checked
meal from the HTTP response. The candidate's ordinary decoding correction is
qualified by four newly successful route histories; the remaining resource and
trace boundaries are separately reported, not represented as fixed.

### Small reproducible remaining inputs

Set the challenged function's `arguments` value to either Python expression:

```python
"9" * 4301
"[" * 1100 + "0" + "]" * 1100
```

The integer hits the default 4,300-digit conversion limit in this Python 3.12.14
runtime and raises ValueError, which the owner's current
`except (json.JSONDecodeError, TypeError)` does not catch.

The nested list successfully decodes in this runtime and takes the existing
TypeError tool-result path because it is not a keyword-argument object. The raw
decoded list then remains in `trace.args`. Both later model exchanges complete,
but the actual API serializer raises RecursionError. The configured Python
recursion limit is 1,000. This is an observed response-serialization failure;
neither nesting input is claimed to raise in the JSON parser. The larger case
retains its original exploratory label `parser_nesting_limit` in the raw receipt,
whose `standalone_parser` and `failure_stage` fields show what actually happened.

The first receiver draft assumed every HTTP 500 would occur after three model
exchanges. Its assertion exposed the distinct five-exchange serializer failure;
the final observer records both stages. No production source changed during
that receiver correction.

## Reproduction and evidence

The `sources/` subdirectories retain only the six exercised backend/fixture
files. Empty `static/` directories satisfy the unchanged app's mount setup; no
browser UI is included or exercised by this packet.

```sh
python -B receive_argument_limits.py sources/main-backend replay-main.json \
  --expected-agent-blob 15ae2c26dd14a8eec43dc328e87d6f12c8d460d2
python -B receive_argument_limits.py sources/owner-backend replay-owner.json \
  --expected-agent-blob 8b28fbe1d80a5eb235e1e7bee70a1b9ae524d455
```

Use the existing environment with TasteTable's unchanged FastAPI dependencies.
The script records observations and asserts the checked-meal preconditions,
source stability, no additional provider calls, and successful control behavior.
An exit code of zero means observation collection completed; it does not mean
all HTTP cases succeeded. Each source has 14 actual route histories.

The raw receipts retain the complete successful results and the unhandled
exception types/messages for failures. A manifest pins this harness, both source
snapshots, ownership record and receipts. No UI, provider policy, retry budget,
source branch or deployment was changed by this receiver.
