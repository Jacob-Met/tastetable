"""Independent read-only receiving for the existing argument-recovery owner."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--expected-agent-blob", required=True)
args = parser.parse_args()
source = args.source.resolve()
sys.path.insert(0, str(source))

from fastapi.testclient import TestClient
import app
from personas import PERSONAS
from qloo_client import FixtureTransport, QlooClient

main = json.loads((Path(__file__).parent / "upstream-main-tree.json").read_text())
expected = {row["path"]: row["sha"] for row in main["tree"] if row["type"] == "blob"}
files = ("agent.py", "app.py", "personas.py", "qloo_client.py", "constraints.py",
         "fixtures/qloo_fixtures.json")


def hashes():
    result = {}
    for name in files:
        raw = (source / name).read_bytes()
        result[name] = {"sha256": hashlib.sha256(raw).hexdigest(),
                       "git_blob": hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest()}
    return result


before = hashes()
for name in files:
    assert before[name]["git_blob"] == (args.expected_agent_blob if name == "agent.py" else expected[name])
cases = [
    ("truncated_json", '{"filter_type":'),
    ("nonstring_true", True),
    ("decoded_scalar_integer", "17"),
    ("decoded_scalar_null", "null"),
    ("decoded_trace_nesting_limit", "[" * 1100 + "0" + "]" * 1100),
    ("parser_nesting_limit", "[" * 5000 + "0" + "]" * 5000),
    ("parser_integer_digit_limit", "9" * 4301),
]
report = {"source": str(source), "source_sha256": before,
          "current_main_api_commit": main["requested_commit"],
          "scope": "Six backend module/fixture leaves; browser assets are not exercised.",
          "python": sys.version, "recursion_limit": sys.getrecursionlimit(),
          "integer_digit_limit": sys.get_int_max_str_digits(), "cases": []}

for label, raw in cases:
    try:
        decoded = json.loads(raw or "{}")
        parser_observation = {"decoded_type": type(decoded).__name__}
    except Exception as error:
        parser_observation = {"error_type": type(error).__name__, "message": str(error)[:1000]}
    for sample in (False, True):
        fixture = FixtureTransport()
        qloo = QlooClient(api_key="synthetic-argument-limit-fixture", transport=fixture)
        posted = []
        unhandled = []
        valid = [
            ("qloo_recs", json.dumps({"filter_type": "urn:entity:place", "purpose": "restaurant",
                                     "tag_ids": ["urn:tag:genre:restaurant:Cuban"]})),
            ("constraint_check", json.dumps({"entity_ids": ["FIX-P-01", "FIX-P-04"],
                                             "constraints": [], "kind": "outing"})),
            ("qloo_recs", raw),
            ("qloo_search", json.dumps({"query": "", "kind": "tag"})),
        ]

        def completion(request, timeout):
            assert request.full_url == "https://argument-limits.invalid/v1/chat/completions"
            assert request.get_method() == "POST"
            body = json.loads(request.data)
            assert body["model"] == "argument-limits-authored-model"
            posted.append(body)
            index = len(posted) - 1
            assert index <= len(valid)
            message = {"role": "assistant", "content": "received subsequent valid correction"}
            if index < len(valid):
                name, arguments = valid[index]
                message["tool_calls"] = [{"id": f"limit-{index}", "type": "function",
                    "function": {"name": name, "arguments": arguments}}]
            return io.BytesIO(json.dumps({"choices": [{"message": message}]}).encode())

        async def observe_unhandled(scope, receive, send):
            try:
                await app.app(scope, receive, send)
            except Exception as error:
                unhandled.append({"type": type(error).__name__, "message": str(error)[:1000]})
                raise

        env = {"TASTETABLE_LLM_BASE_URL": "https://argument-limits.invalid/v1",
               "TASTETABLE_LLM_MODEL": "argument-limits-authored-model"}
        with patch.dict(os.environ, env, clear=True), \
                patch("urllib.request.urlopen", side_effect=completion), \
                patch.object(app.QlooClient, "from_env", return_value=qloo), \
                TestClient(observe_unhandled, raise_server_exceptions=False) as client:
            response = (client.post("/api/plan/sample/rosa") if sample else
                        client.post("/api/plan", json=PERSONAS["rosa"]))
        checked = json.loads(posted[2]["messages"][-1]["content"])["verdicts"]
        assert [(row["entity_id"], row["ok"]) for row in checked] == [("FIX-P-01", True), ("FIX-P-04", False)]
        assert len(fixture.log) == 1
        item = {"case": label, "sample_route": sample, "raw_type": type(raw).__name__,
                "raw_string_length": len(raw) if isinstance(raw, str) else None,
                "raw_sha256": hashlib.sha256(raw.encode()).hexdigest() if isinstance(raw, str) else None,
                "standalone_parser": parser_observation,
                "status_code": response.status_code, "model_exchanges": len(posted),
                "provider_calls": len(fixture.log), "checked_before_fault": checked,
                "unhandled": unhandled}
        if response.status_code == 200:
            result = response.json()
            assert [meal["entity_id"] for meal in result["plan"]["meals"]] == ["FIX-P-01"]
            assert result["plan"]["outing"] is None
            assert result["model_message"] == "received subsequent valid correction"
            assert len(posted) == 5
            item["result"] = result
        else:
            assert response.status_code == 500
            assert len(posted) in (3, 5), json.dumps(item)
            item["failure_stage"] = ("before subsequent correction" if len(posted) == 3 else
                                      "response serialization after subsequent correction")
            item["body"] = response.text
        report["cases"].append(item)

assert hashes() == before
args.output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"output": str(args.output), "recursion_limit": report["recursion_limit"],
    "results": [{"case": row["case"], "sample_route": row["sample_route"],
                 "status_code": row["status_code"], "model_exchanges": row["model_exchanges"],
                 "unhandled_types": [e["type"] for e in row["unhandled"]]}
                for row in report["cases"]]}, indent=2))
