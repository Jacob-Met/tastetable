# TasteTable atomic-render receiving packet

This packet preserves the staged-render supplement and its independently authored browser evidence. It contains the complete frontend source needed by both browser harnesses, the exact one-file patch, the unchanged harnesses, full before/after reports, historical controls, and source provenance. It is a receiver handoff for the existing organizer/calendar/lifecycle owner.

## Current authority and adoption

Captured main is `9f9105c29ab1a68a501b5f4c0b7180f0db968d38`, tree `778b466e70b3d69f28dc49f574cb7002adf45c29`, the merge of [organizer PR #9](https://github.com/Jacob-Met/tastetable/pull/9). All four frontend files fetched from that exact GitHub commit match the earlier frozen organizer byte for byte. The complete current tree contains no AGENTS.md.

The organizer/composition owner explicitly acknowledged this attributed supplement in [issue #4 comment 6056696310](https://github.com/Jacob-Met/tastetable/issues/4#issuecomment-6056696310), following our [repair handoff](https://github.com/Jacob-Met/tastetable/issues/4#issuecomment-6056277672). Their active successor is composing the calendar occurrence seam, the published lifecycle controller, and this staged renderer. They retain app/index/style/README hooks and integrated receiving tests; week_plan.mjs stays unchanged. That successor is in receiving and is not yet published or deployed.

The minimal supported adoption is to incorporate this patch within that owned successor. Publish this packet as evidence only, then qualify their exact frozen composition; avoid a competing app PR while that integration is active. No shared publication was performed while preparing this packet.

Open PRs at the final authority read were #7 (lifecycle head `981118bbc2c7a2173e56ac1c26da754803b40b22`) and #8 (backend receiving head `1b8e07856b48318974fc20621975536424113cbe`). Full owner statements and source pins are preserved in `provenance/current-authority.json`.

## Exact source change

Only `static/app.js` changes between `source/baseline` and `source/candidate`:

| Source | Git blob | SHA256 |
| --- | --- | --- |
| Published organizer app | `fab0cb5398d3e6553373a99d9d56afa92f2bfcbb` | `cb666959df8a4921987e67b98efbeca0f0399502184f3743e732c7c295cfd395` |
| Staged app | `9f5c4fb39138e07f7243b7aa073740ed66aee655` | `376fb899f912b9e74b5869c0cc05eb863e86bc812602295f54af85802d15705c` |

The candidate stages all original-result fragments and the complete next-week view before committing any response-dependent DOM or week state. The exact root-authored source is preserved; this packet introduces no additional production edit. Original source evidence, weekday assignments, dates, and the existing narrow request-token policy remain unchanged on rejected rendering.

`patches/atomic-render.patch` applies cleanly to the captured main. `provenance/source-binding.json` records byte identity with the previously reviewed source. `provenance/patch-application.json` records actual patch application and comparison with the exact candidate.

## Fresh browser replay against published bytes

All runs use the unchanged prior harnesses, real Chromium 153, authored loopback responses, a fresh temporary profile, blocked service workers, and blocked requests outside the fixture origin. No provider, venue, calendar service, or storage operation is involved. Browser profiles were removed after each run; no profile or screenshot is included in this packet.

| Receiving control | Captured main | Staged candidate |
| --- | --- | --- |
| Original malformed-notes probe | Fails: mixed source evidence beside the edited week | Pass |
| Eight organizer checkpoints, including 56 individual day moves | Preserved earlier passing report | All 8 pass in fresh replay |
| Seven additional malformed-response histories | 6 failures, 1 preserved early-failure control | All 7 pass in fresh replay |

The additional histories cover null trace, constraints as a string, an array-like constraints object, malformed baseline meals and outing, affinity as a string, and null rejected-constraint details. Every candidate history preserves the captured plan, assignments, date input, source label, and controls, allows another local edit without a request, accepts a fresh valid partial response, and allows that replacement to be edited. The negative-control affinity case already failed before the original renderer's first DOM write, and therefore correctly continues to pass.

All five fresh runs reported zero unhandled page errors and zero external page request attempts. Full reports and logs are under `evidence/current`; prior reports remain under `evidence/historical`. The current-main negative cases intentionally exit 1. These are product regression controls, not failed positive qualifications.

The original browser harness SHA256 is `105b33bf6142af7cc1d3100d0f3c93d592861a9aabb12a14f0380afc2821c12e`; the late-render harness is `a5b7cd6bf6840a7b17215fd52e404650cc91db7c907e48ed9987b5f397b5b5f3`. `provenance/current-replay.json` records exact commands and exits.

## Replay

Use Node.js with Playwright available through `CODEX_PRIMARY_RUNTIME_NODE_MODULES`, or the ordinary Node module resolution path. Supply an installed Chromium executable via `--browser` when the recorded local executable is unavailable. Place output in a new writable directory outside this frozen packet; set TMPDIR to a writable temporary location if necessary.

```sh
node harness/review-week-browser.cjs --root source/candidate --output ../replay/candidate-browser
node harness/review-week-browser.cjs --probe-malformed --root source/baseline --output ../replay/main-malformed
node harness/review-week-browser.cjs --probe-malformed --root source/candidate --output ../replay/candidate-malformed
node harness/review-week-late-render.cjs --root source/baseline --output ../replay/main-late
node harness/review-week-late-render.cjs --root source/candidate --output ../replay/candidate-late
```

These source snapshots are complete for the isolated browser fixture server; they are not whole backend checkouts. The upstream README and native week-state tests are included as unchanged source context. This replay did not run the Python backend, hosted CI, or those additional state tests.

## Composition boundaries

The staged-render qualification is not a general schema validator. A constraints object without a nonzero length does not throw in either renderer. The array-like object control deliberately reaches the late map failure.

The broader lifecycle contract intentionally retires old results/week/print/export on request start, input invalidation, cancellation, and errors. The future composed browser review must assert that retired state cannot become visible or downloadable; it must not require the legacy old plan to remain visible. Preserve the original harnesses here when authoring that receiving successor.

The calendar owner supplies `createWeekExport(initialWeekState)` with `preview(state, weekRows(state))` and `download(state, weekRows(state))`. The existing composer owns its UI hooks, one visible week input, current-input validity gating, occurrence identity, and export-session retirement. Neither calendar coherence nor the combined lifecycle UI is claimed by this packet. The separate provider-unavailability presentation finding in comment 6056065906 also remains with the existing UI owners.

Every packet member is indexed by SHA256 and Git blob hash in `manifest.json`. The enclosing archive is content-addressed separately. Recheck main, owner scope, and the exact receiving composition before any later shared mutation.
