import {readWeekFile} from "./source/static/week_file.mjs";
import {readVenueNoteFile} from "./source/static/venue_note_file.mjs";
import {createVenueFollowup} from "./source/static/venue_followup.mjs";

export const weekName="week-Ω.json";
export const savedLabel=name=>"Saved copy opened from “"+name+"” (saved 2026-10-05T09:00:00.000Z). Source labels and checks below are retained from the file; they have not been run again.";
export function makeCase() {
  const counts={picks:3,with_qloo_entity_id:3,with_affinity_evidence:0,constraint_checked:3,unsafe_candidates_rejected:0};
  const inputs={city:"Authored City",cuisines:["Soup"],music:[],films:[],constraints:["wheelchair"],literal:"Whole origin <&> preserved"};
  const response={mock:true,plan:{meals:[
    {name:"Twin Café 🍵",why:"First occurrence <&>\nAuthored second line.",entity_id:"same-entity",kind:"restaurant",day:"Monday",affinity:null},
    {name:"Twin Café 🍵",why:"Second occurrence has its own record.",entity_id:"same-entity",kind:"restaurant",day:"Wednesday",affinity:null}],
    outing:{name:"Omitted Hall",why:"Omitted source explanation.",entity_id:"other-entity",kind:"outing",day:"Thursday"},
    notes:[],rejected:[]},
    llm_only:{meals:[],outing:{name:"Unverified comparison",why:"Not in the current visits.",day:"Friday"}},
    comparison:{constraints:["wheelchair"],grounded:{...counts},llm_only:{...counts}},
    trace:[{tool:"authored-fixture",args:{literal:"No live provider call"},result_summary:"Synthetic saved response"}]};
  const week={format:"tastetable.saved-week.v1",receivedAt:"2026-10-04T12:00:00.000Z",savedAt:"2026-10-05T09:00:00.000Z",
    calendarId:"0123456789abcdef0123456789abcdef",inputs,response,
    week:{start:"2026-10-05",assignments:{"pick-0":"Tuesday","pick-1":"Tuesday","pick-2":null}}};
  const notes={format:"tastetable.venue-notes.v1",savedAt:"2026-10-06T10:00:00.000Z",
    origin:{receivedAt:week.receivedAt,calendarId:week.calendarId,inputs:structuredClone(inputs),response:structuredClone(response)},
    records:[
      {key:"pick-0",date:"2026-10-06",note:{status:"follow_up",question:"Revised access question?\nLiteral <&> follow-up.",reply:"Earlier reply\r\nSecond reply line.",replyQuestions:"Earlier question.",nextStep:"Ask again; no reservation inferred."}},
      {key:"pick-1",date:"2026-10-06",note:{status:"awaiting_reply",question:"",reply:"",replyQuestions:null,nextStep:"Call this occurrence separately."}},
      {key:"pick-0",date:"2026-09-29",note:{status:"reply_recorded",question:"Historical question.",reply:"HISTORICAL_REPLY_MUST_STAY_OUT",replyQuestions:"Historical question.",nextStep:"HISTORICAL_NEXT_STEP_MUST_STAY_OUT"}},
      {key:"pick-2",date:"2026-10-08",note:{status:"not_contacted",question:"OMITTED_QUESTION_MUST_STAY_OUT",reply:"",replyQuestions:null,nextStep:"OMITTED_NEXT_STEP_MUST_STAY_OUT"}}
    ]};
  return {week,notes,weekText:JSON.stringify(week,null,2)+"\n",notesText:JSON.stringify(notes,null,2)+"\n"};
}
export function nativeReference(weekText,notesText,name=weekName) {
  const origin=readWeekFile(weekText);
  const model=createVenueFollowup(origin.state,
    "Saved copy opened from “"+name+"” (saved "+origin.savedAt+"). Source labels and checks below are retained from the file; they have not been run again.");
  const admitted=readVenueNoteFile(notesText,{origin,state:origin.state,model});
  model.replaceRecords(admitted.records);
  return {text:model.text(origin.state),records:admitted.records,entries:model.entries(origin.state),origin,model};
}
export function handText(name=weekName) {
  return [
    "TasteTable — venue call sheet",
    "Week beginning 2026-10-05",
    "Demo plan: fictional venues and synthetic source data. Use this sheet to practise the workflow.",
    savedLabel(name),
    "Caregiver-entered notes. A recorded reply is not a safety check, reservation or confirmation by TasteTable.",
    "Confirm venue details and care needs before going. Do not include names or private health information.",
    "Notes apply to the pick occurrence and date shown. Later edits do not update this copy.",
    "",
    "Tuesday 2026-10-06 — Twin Café 🍵",
    "Suggested visit 1; Qloo entity: same-entity",
    "Original plan explanation (heuristic):",
    "  First occurrence <&>",
    "  Authored second line.",
    "Questions to ask:",
    "  • Revised access question?",
    "  • Literal <&> follow-up.",
    "Caregiver contact status: Needs follow-up",
    "Questions changed after these notes were entered. Follow up on the revised questions.",
    "Questions for the earlier reply / notes:",
    "  Earlier question.",
    "Earlier reply / notes (for the previous questions):",
    "  Earlier reply",
    "  Second reply line.",
    "Next step:",
    "  Ask again; no reservation inferred.",
    "",
    "Tuesday 2026-10-06 — Twin Café 🍵",
    "Suggested visit 2; Qloo entity: same-entity",
    "Original plan explanation (heuristic):",
    "  Second occurrence has its own record.",
    "Questions to ask:",
    "  No questions entered.",
    "Caregiver contact status: Awaiting reply",
    "Venue reply / your notes:",
    "  No reply details entered.",
    "Next step:",
    "  Call this occurrence separately.",
    ""
  ].join("\n");
}
