import assert from "node:assert/strict";
import fs from "node:fs/promises";
import syncFs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {spawnSync} from "node:child_process";
import {fileURLToPath,pathToFileURL} from "node:url";
import {makeCase,nativeReference,handText,weekName} from "./oracle-before-candidate.mjs";
const home=path.dirname(fileURLToPath(import.meta.url));
const candidate=path.resolve(process.argv[2]??path.join(home,"source/tools/saved_week_to_call_sheet.mjs"));
const area=await fs.mkdtemp(path.join(home,"candidate-receiving-"));
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const receipt={schema:"tastetable-independent-file-consumer-receiving/1",base:"145d27981b3c5fe6afa72e205b42582fd72c7734",candidate,area,node:process.version,groups:[],runs:[],sourceBefore:{},sourceAfter:{}};
const nativePaths=["week_file","week_plan","venue_note_file","venue_followup"].map(s=>"source/static/"+s+".mjs");
for(const p of nativePaths)receipt.sourceBefore[p]=sha(await fs.readFile(path.join(home,p)));
receipt.candidateSha256=sha(await fs.readFile(candidate));
let serial=0;
const expectedReceiptKeys=["format","input","inputSha256","venueNotes","venueNotesSha256","output","outputSha256","outputBytes","weekStart","sourceMode","savedWeekAt","venueNotesSavedAt","originalPicks","scheduledVisits","omittedPicks","retainedNoteRecords","currentNoteRecords","excludedNoteRecords"].sort();
async function setup(name,{weekText,notesText}={}) {
 const d=path.join(area,String(++serial).padStart(2,"0")+"-"+name);await fs.mkdir(d);
 const c=makeCase(),input=path.join(d,weekName),notes=path.join(d,"notes.json"),output=path.join(d,"call sheet.txt");
 await fs.writeFile(input,weekText??c.weekText);await fs.writeFile(notes,notesText??c.notesText);
 return{d,input,notes,output,argv:["--input",input,"--venue-notes",notes,"--output",output]};
}
async function execute(c,{args=c.argv,hook=null}={}) {
 let command=[candidate,...args],hookResult=null;
 if(hook){
  const spec={...hook,root:c.d,input:c.input,output:c.output,candidate,argv:args,result:path.join(c.d,"hook-result.json")};
  await fs.writeFile(path.join(c.d,"hook-spec.json"),JSON.stringify(spec,null,2)+"\n");
  command=[path.join(home,"selected-fault-child.mjs"),path.join(c.d,"hook-spec.json")];
 }
 const r=spawnSync(process.execPath,command,{cwd:c.d,encoding:"utf8",timeout:12000,env:{...process.env,NODE_OPTIONS:""}});
 if(hook)hookResult=JSON.parse(await fs.readFile(path.join(c.d,"hook-result.json"),"utf8"));
 await fs.writeFile(path.join(c.d,"process.stdout"),r.stdout??"");await fs.writeFile(path.join(c.d,"process.stderr"),r.stderr??"");
 const run={directory:c.d,command,exit:r.status,signal:r.signal,error:r.error?String(r.error):null,stdout:r.stdout??"",stderr:r.stderr??"",hook:hookResult};
 receipt.runs.push(run);assert.equal(r.error,undefined);assert.equal(r.signal,null);
 return run;
}
async function absent(p){await assert.rejects(fs.stat(p),e=>e.code==="ENOENT");}
async function success(c,r,expected) {
 assert.equal(r.exit,0);assert.equal(r.stderr,"");assert.ok(r.stdout.endsWith("\n"));assert.equal(r.stdout.split("\n").filter(Boolean).length,1);
 const bytes=await fs.readFile(c.output);assert.deepEqual(bytes,Buffer.from(expected,"utf8"));
 const summary=JSON.parse(r.stdout);assert.deepEqual(Object.keys(summary).sort(),expectedReceiptKeys);
 assert.deepEqual(summary,{format:"tastetable.venue-call-sheet.v1",input:path.resolve(c.input),inputSha256:sha(await fs.readFile(c.input)),venueNotes:path.resolve(c.notes),venueNotesSha256:sha(await fs.readFile(c.notes)),output:path.resolve(c.output),outputSha256:sha(bytes),outputBytes:bytes.length,weekStart:"2026-10-05",sourceMode:"mock",savedWeekAt:"2026-10-05T09:00:00.000Z",venueNotesSavedAt:"2026-10-06T10:00:00.000Z",originalPicks:3,scheduledVisits:2,omittedPicks:1,retainedNoteRecords:4,currentNoteRecords:2,excludedNoteRecords:2});
 assert.deepEqual((await fs.readdir(c.d)).sort(),[weekName,"notes.json","call sheet.txt","process.stdout","process.stderr"].sort());
}
async function refused(c,r,code=2){assert.equal(r.exit,code);assert.equal(r.stdout,"");assert.match(r.stderr,/tastetable-call-sheet:/);await absent(c.output);}
async function group(name,fn){await fn();receipt.groups.push({name,passed:true});}
try{
 await group("exact-hand-and-native-text-receipt-and-input-custody",async()=>{
  const c=await setup("ordinary");const before=[sha(await fs.readFile(c.input)),sha(await fs.readFile(c.notes))];
  const r=await execute(c);await success(c,r,handText());assert.deepEqual(before,[sha(await fs.readFile(c.input)),sha(await fs.readFile(c.notes))]);
  const f=makeCase();assert.equal(await fs.readFile(c.output,"utf8"),nativeReference(f.weekText,f.notesText).text);
 });
 await group("native-origin-history-and-zero-schedule-refusals",async()=>{
  const cases=[];
  {const f=makeCase();f.notes.origin.response.trace[0].args.literal="Changed full origin";cases.push(["origin",f]);}
  {const f=makeCase();f.notes.records[0].note.status="reply_recorded";cases.push(["inconsistent-history",f]);}
  {const f=makeCase();f.notes.records.push(structuredClone(f.notes.records[0]));cases.push(["duplicate-record",f]);}
  {const f=makeCase();for(const k of Object.keys(f.week.week.assignments))f.week.week.assignments[k]=null;cases.push(["no-current-visits",f]);}
  for(const[name,f]of cases){const c=await setup(name,{weekText:JSON.stringify(f.week),notesText:JSON.stringify(f.notes)});await refused(c,await execute(c));}
 });
 await group("empty-notes-and-native-current-visit-projection",async()=>{
  const f=makeCase();f.notes.records=[];const nt=JSON.stringify(f.notes);const c=await setup("empty-notes",{notesText:nt});
  const r=await execute(c);assert.equal(r.exit,0);assert.equal(r.stderr,"");
  assert.equal(await fs.readFile(c.output,"utf8"),nativeReference(f.weekText,nt).text);
  const s=JSON.parse(r.stdout);assert.equal(s.retainedNoteRecords,0);assert.equal(s.currentNoteRecords,0);assert.equal(s.excludedNoteRecords,0);assert.equal(s.scheduledVisits,2);
 });
 await group("raw-byte-bounds-native-bom-and-fatal-utf8",async()=>{
  const f=makeCase();
  const bounded=await setup("exact-cap",{weekText:"\uFEFF"+f.weekText+" ".repeat(4194304-3-Buffer.byteLength(f.weekText)),notesText:f.notesText+" ".repeat(2097152-Buffer.byteLength(f.notesText))});
  await success(bounded,await execute(bounded),handText());
  const large=await setup("week-over-cap",{weekText:f.weekText+" ".repeat(4194305-Buffer.byteLength(f.weekText))});await refused(large,await execute(large));
  const notesLarge=await setup("notes-over-cap",{notesText:f.notesText+" ".repeat(2097153-Buffer.byteLength(f.notesText))});await refused(notesLarge,await execute(notesLarge));
  const double=await setup("double-bom",{weekText:"\uFEFF\uFEFF"+f.weekText});await refused(double,await execute(double));
  const bad=await setup("invalid-utf8");await fs.writeFile(bad.notes,Buffer.from([0xc3,0x28]));await refused(bad,await execute(bad));
 });
 await group("existing-output-aliases-and-regular-input-symlink",async()=>{
  for(const kind of ["file","hardlink","symlink","dangling","directory"]){
   const c=await setup("collision-"+kind);const original=await fs.readFile(c.input);
   if(kind==="file")await fs.writeFile(c.output,"KEEP ORIGINAL");
   if(kind==="hardlink")await fs.link(c.input,c.output);
   if(kind==="symlink")await fs.symlink(c.input,c.output);
   if(kind==="dangling")await fs.symlink(path.join(c.d,"absent"),c.output);
   if(kind==="directory")await fs.mkdir(c.output);
   const before=await fs.lstat(c.output);const r=await execute(c);assert.equal(r.exit,2);assert.equal(r.stdout,"");
   const after=await fs.lstat(c.output);assert.equal(after.ino,before.ino);assert.equal(after.mode,before.mode);assert.deepEqual(await fs.readFile(c.input),original);
   if(kind==="file")assert.equal(await fs.readFile(c.output,"utf8"),"KEEP ORIGINAL");
  }
  const c=await setup("input-symlink");const target=path.join(c.d,"target-week.json");await fs.rename(c.input,target);await fs.symlink(target,c.input);
  const r=await execute(c);assert.equal(r.exit,0);assert.equal(await fs.readFile(c.output,"utf8"),handText());assert.ok((await fs.lstat(c.input)).isSymbolicLink());
 });
 await group("selected-input-change-and-publication-race-failures",async()=>{
  const changed=await setup("input-changed");const cr=await execute(changed,{hook:{mode:"input-change",changedText:makeCase().weekText+" "}});
  assert.ok(cr.hook.count>0);await refused(changed,cr);assert.equal(cr.hook.published,false);
  const race=await setup("race");const rr=await execute(race,{hook:{mode:"publication-race"}});
  assert.ok(rr.hook.count>0);assert.equal(rr.exit,2);assert.equal(rr.stdout,"");assert.equal(await fs.readFile(race.output,"utf8"),"INDEPENDENT_RACE_WINNER");assert.equal(rr.hook.published,false);
  if(rr.hook.stage)await absent(rr.hook.stage);
  const failed=await setup("link-failure");const fr=await execute(failed,{hook:{mode:"link-failure"}});
  assert.ok(fr.hook.count>0);await refused(failed,fr,1);assert.equal(fr.hook.published,false);if(fr.hook.stage)await absent(fr.hook.stage);
 });
 await group("post-publication-cleanup-and-receipt-delivery-failures",async()=>{
  for(const mode of ["cleanup-failure","stdout-failure"]){
   const c=await setup(mode);const r=await execute(c,{hook:{mode}});
   assert.ok(r.hook.count>0);assert.equal(r.hook.published,true);assert.equal(r.exit,1);assert.equal(r.stdout,"");
   assert.equal(await fs.readFile(c.output,"utf8"),handText());assert.match(r.stderr,/created/i);
  }
  const c=await setup("primary-refusal-stderr-failure");
  const r=await execute(c,{args:["--unknown"],hook:{mode:"stderr-failure"}});
  assert.ok(r.hook.count>0);assert.equal(r.exit,2);assert.equal(r.stdout,"");await absent(c.output);
 });
 await group("strict-grammar-help-import-and-source-boundary",async()=>{
  const c=await setup("usage");
  for(const args of [[],["--input",c.input,"--input",c.input,"--venue-notes",c.notes,"--output",c.output],["--input","-","--venue-notes",c.notes,"--output",c.output],["--help","--input",c.input],["--force"]]){
   const r=await execute(c,{args});assert.equal(r.exit,2);assert.equal(r.stdout,"");await absent(c.output);
  }
  const help=await execute(c,{args:["--help"]});assert.equal(help.exit,0);assert.match(help.stdout,/--input/);assert.equal(help.stderr,"");await absent(c.output);
  const imported=spawnSync(process.execPath,["--input-type=module","-e","await import("+JSON.stringify(pathToFileURL(candidate).href)+")"],{cwd:c.d,encoding:"utf8",timeout:12000});
  assert.equal(imported.status,0);assert.equal(imported.stdout,"");assert.equal(imported.stderr,"");
  for(const p of nativePaths)receipt.sourceAfter[p]=sha(await fs.readFile(path.join(home,p)));
  assert.deepEqual(receipt.sourceAfter,receipt.sourceBefore);assert.equal(sha(await fs.readFile(candidate)),receipt.candidateSha256);
 });
 receipt.passed=true;
}catch(error){receipt.passed=false;receipt.failure={name:error.name,message:error.message,stack:error.stack};process.exitCode=1;}
const body=JSON.stringify(receipt,null,2)+"\n";await fs.writeFile(path.join(area,"receipt.json"),body,{flag:"wx"});
console.log(JSON.stringify({area,passed:receipt.passed,groups:receipt.groups,runs:receipt.runs.length,receiptSha256:sha(body),failure:receipt.failure??null}));
