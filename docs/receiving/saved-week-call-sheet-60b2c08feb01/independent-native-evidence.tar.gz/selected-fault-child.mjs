// Selected-disposable-path fault harness, sealed before candidate access.
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import {syncBuiltinESMExports} from "node:module";
import {pathToFileURL} from "node:url";
const spec=JSON.parse(fs.readFileSync(process.argv[2],"utf8"));
const root=fs.realpathSync(spec.root);
const selected=p=>typeof p==="string"&&path.resolve(p).startsWith(root+path.sep);
if(!selected(spec.output)||!selected(spec.input)||!selected(spec.result))throw Error("Outside owned receiving root");
const original={open:fsp.open,link:fsp.link,unlink:fsp.unlink,openSync:fs.openSync,linkSync:fs.linkSync,unlinkSync:fs.unlinkSync,writeSync:fs.writeSync,writeFileSync:fs.writeFileSync,stdout:process.stdout.write,stderr:process.stderr.write};
let count=0,sourceOpens=0,published=false,stage=null;
const log=[];
const injected=message=>Object.assign(new Error("receiver selected fault: "+message),{code:"EIO"});
function beforeOpen(p) {
 if(path.resolve(String(p))!==spec.input)return;
 sourceOpens++;
 if(spec.mode==="input-change"&&sourceOpens===2){
  count++;original.writeFileSync(spec.input,spec.changedText);log.push({hook:"input-change",path:spec.input,occurrence:sourceOpens});
 }
}
function beforeLink(a,b) {
 if(path.resolve(String(b))!==spec.output)return;
 if(!selected(String(a)))throw Error("Unowned staging path");
 stage=String(a);
 if(spec.mode==="publication-race"){
  count++;original.writeFileSync(spec.output,"INDEPENDENT_RACE_WINNER",{flag:"wx"});log.push({hook:"publication-race",stage,destination:spec.output});
 }else if(spec.mode==="link-failure"){
  count++;log.push({hook:"link-failure",stage,destination:spec.output});throw injected("before actual link");
 }
}
function beforeUnlink(p) {
 if(spec.mode==="cleanup-failure"&&published&&String(p)===stage){
  count++;log.push({hook:"cleanup-failure",stage,destination:spec.output});throw injected("after actual publication");
 }
}
fsp.open=async function(p,...args){beforeOpen(p);return original.open.call(this,p,...args);};
fs.openSync=function(p,...args){beforeOpen(p);return original.openSync.call(this,p,...args);};
fsp.link=async function(a,b,...args){beforeLink(a,b);const r=await original.link.call(this,a,b,...args);if(path.resolve(String(b))===spec.output)published=true;return r;};
fs.linkSync=function(a,b,...args){beforeLink(a,b);const r=original.linkSync.call(this,a,b,...args);if(path.resolve(String(b))===spec.output)published=true;return r;};
fsp.unlink=async function(p,...args){beforeUnlink(p);return original.unlink.call(this,p,...args);};
fs.unlinkSync=function(p,...args){beforeUnlink(p);return original.unlinkSync.call(this,p,...args);};
function refuseWrite(fd) {
 if((spec.mode==="stdout-failure"&&fd===1)||(spec.mode==="stderr-failure"&&fd===2)){
  count++;log.push({hook:spec.mode,fd});throw injected("diagnostic/delivery");
 }
}
fs.writeSync=function(fd,...args){refuseWrite(fd);return original.writeSync.call(this,fd,...args);};
process.stdout.write=function(...args){refuseWrite(1);return original.stdout.apply(this,args);};
process.stderr.write=function(...args){refuseWrite(2);return original.stderr.apply(this,args);};
syncBuiltinESMExports();
let code,thrown=null;
try{const candidate=await import(pathToFileURL(spec.candidate).href);code=await candidate.main(spec.argv);}
catch(error){thrown={name:error.name,message:error.message,stack:error.stack};code=99;}
finally{
 original.writeFileSync(spec.result,JSON.stringify({mode:spec.mode,count,sourceOpens,published,stage,log,code,thrown},null,2)+"\n",{flag:"wx"});
}
process.exitCode=code;
