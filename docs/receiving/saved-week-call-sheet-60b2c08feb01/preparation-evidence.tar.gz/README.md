# TasteTable saved-week call-sheet proposal custody

This packet preserves the public proposal, exact current inherited source and fixture projection, full native issue 54/55 records and comments, and complete current workflow bodies before candidate implementation. It is a read-only preparation packet, not a qualified candidate or ownership claim.

Canonical source admission: Jacob-Met/tastetable main 145d27981b3c5fe6afa72e205b42582fd72c7734, tree 71f2c5b144e2a54787cb92b37d6e639bbfef6ba6. The recursive tree was untruncated with 818 leaves. No AGENTS file was found. All 12 materialized native files are Git-blob and SHA256 verified in current-source-manifest.json.

The public contract names three new product paths. Existing optional HTML notes handoff issue 54 and editable combined-file issue 55 remain owned and unchanged. The source/reference projection deliberately contains no unmerged issue 55 implementation.

The three workflow bodies are preserved exactly under source/.github/workflows/. Their declared events are push to main and/or pull_request. Root must independently review the event and ownership boundary before any native claim. No workflow, branch, ref, PR, merge, comment, provider request, installation or product execution was performed while preparing this packet.

The prior native discovery result survives only as an observed summary. Its actual 4,417-byte raw receipt was lost with controller 80653 and is not reconstructed or rerun here. historical-discovery-observation-raw-lost.json states that custody limitation. The new source recapture is a separate milestone.

Member identities are in members.json. Hashes establish byte identity, not authentication. Extract to a private directory for review. This packet does not contain candidate code, a new runtime, or a scientific/caregiver safety claim.
