# TasteTable saved-week call-sheet author evidence

This packet qualifies only the three new issue 67 files on main 145d27981b3c5fe6afa72e205b42582fd72c7734. No other product source was edited. Root retains README/integration ownership, and the independent receiver remains a separate gate.

The first actual author command was:

    node --test tests/test_saved_week_to_call_sheet.mjs

It passed all 16 maintained groups on existing Node v24.19.0, exit 0, with empty stderr and no skipped groups. The exact executable test and candidate are in source/. Raw stdout, stderr, receipt and source-before manifest are under author-first/. stdout.txt preserves the native runner's actual output; it is not reformatted as TAP. author-review.json binds all hashes and limits.

To replay in an isolated copy, first obtain the unchanged four native modules pinned in the raw receipt (or recover them from canonical preparation archive e8245fb5cea814579ae76707d94c070b5e3ec60a). Place the three source/ files at their repository paths and run the command above using an existing Node 22+ runtime. No npm install is required. Replay creates and removes only owned test temporary files. POSIX-specific controls use existing mkfifo, symlink and /dev/full facilities; this packet does not claim Windows execution.

The controlled source-change test intentionally appends to its own fictional copy; the collision control intentionally creates its own foreign-marker destination. Their assertions distinguish intended mutations from source preservation. The actual four inherited modules and three candidate files were hash-identical before/after the complete gate, and the test temporary directory was empty.

Public contract 935225216c18877c7c018858c1b80883ac832984 was canonical before implementation. The independent receiver's recovered pre-candidate code archive is 78eaf6bf85de254d8320e7042b0b09cf6c2895b1; no independent result is implied here. Existing HTML/combined-handoff owners 54/55 retain their scopes.

Earlier discovery receipt 03710382575f2269d3b06e2ed8df720a2a41a5c6 is raw-lost; its historical observation remains explicitly separate in the preparation packet. This first candidate run did not reconstruct or repeat that discovery.

No provider, venue, browser, installation or Actions operation occurred. No full-suite, Windows, installed-adoption, integration, safety or efficacy result is asserted. Hashes establish byte identity, not authentication. members.json inventories the exact packet contents.
