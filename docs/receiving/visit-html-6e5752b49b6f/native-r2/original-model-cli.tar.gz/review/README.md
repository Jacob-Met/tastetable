# TasteTable65 R2 native source capsule and independent source receiving

This archive preserves the complete original native capsule without replaying its tests or rewriting original files. It includes root-authored original-R1 failure and corrected-R2 14-test success, exact controller/bootstrap/payload/runtime pins, source bytes, logs and receipt. All21 tracked source inputs and recorded Node launcher/libnode hashes and mtimes were independently checked. The original directory/file inventory before and after packaging is exact (including modes, ownership, size, mtime and ctime; read-access times are intentionally excluded). Empty original directories are retained as tar directory entries.

Independent source review accepts commit0c7a99ada6c0b53e69d2049e9d2fe823d8f26317/tree70fd963f09a20a00889b87cb008e204b6464857e, sole parentb734d5f880a0199259435f8de8dafb71115c8530:823 leaves,821 unchanged, only escapeText and the focused model regression changed. The native 14 tests are authored tests and are not relabeled independent execution.

The independent DOM helper and contract were frozen before R2 exposure and are included unchanged. Their synthetic sensitivity controls and actual browser geometry remain pending root execution; this packet claims no corrected browser/PDF pass. Native-runtime owns the separate original-PDF span receiver. R1 independent9-group/22-process evidence remains historical and unchanged.

No source/ref/PR/merge/Actions mutation or browser/service installation occurred. Packaging ran as ordinary UID1000 under the existing Node22.22.1. Reproduction must use a fresh own output directory; all outputs here are exclusive-created. Archive membership and every regular-file byte/hash are verified after decompression.
