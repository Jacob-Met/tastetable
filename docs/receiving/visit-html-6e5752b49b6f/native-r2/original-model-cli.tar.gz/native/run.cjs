"use strict";
const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),os=require("node:os"),cp=require("node:child_process"),{performance}=require("node:perf_hooks");
const ROOT=__dirname,P=JSON.parse(fs.readFileSync(path.join(ROOT,"payload.json"),"utf8")),sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const pin=f=>{const s=fs.lstatSync(f,{bigint:true});if(!s.isFile()||s.isSymbolicLink())throw Error("Nonregular admitted input "+f);const b=fs.readFileSync(f);return{path:f,bytes:b.length,sha256:sha(b),gitBlob:crypto.createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex"),mtimeNs:String(s.mtimeNs)};};
function capacity(){const s=fs.statfsSync(ROOT),m=Number(fs.readFileSync("/proc/meminfo","utf8").match(/^MemAvailable:\s+(\d+)/m)[1])*1024;const r={at:new Date().toISOString(),availableRAM:m,freeRAM:os.freemem(),diskFree:s.bavail*s.bsize};if(m<268435456||r.diskFree<67108864)throw Error("Native Node test capacity refusal");return r;}
const started=performance.now(),out={schema:"taste65-visible-cr-native-r2/1",at:new Date().toISOString(),accepted:false,sourceR1:P.sourceR1,findingGit:P.findingGit,uid:process.getuid(),node:process.version,sourceBefore:[],sourceAfter:[],runs:[],errors:[],limits:["Author source/CLI regression tests only; actual corrected browser/PDF receiving remains pending.","One original-renderer focused regression is intentionally red; historical R1 source and artifacts are unchanged.","No Actions, network service, account, privileged identity or installed product mutation."]};
let sourceFiles=[];
function save(name,data){const f=path.join(ROOT,name);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,data,{flag:"wx"});return f;}
function run(label,folder,args){const pre=capacity(),t=performance.now();const r=cp.spawnSync(process.execPath,["--max-old-space-size=96",...args],{cwd:folder,env:{...process.env,TMPDIR:path.join(ROOT,"test-tmp")},encoding:"utf8",timeout:60000,maxBuffer:4*1024**2});save(label+".stdout",r.stdout||"");save(label+".stderr",r.stderr||"");const rec={label,capacity:pre,pid:r.pid,args:["--max-old-space-size=96",...args],cwd:folder,status:r.status,signal:r.signal,error:r.error?String(r.error):null,elapsedMs:performance.now()-t,stdout:pin(path.join(ROOT,label+".stdout")),stderr:pin(path.join(ROOT,label+".stderr"))};out.runs.push(rec);return{...rec,text:r.stdout||""};}
try {
  if(out.uid!==1000||out.node!=="v22.22.1"||process.execPath!=="/usr/bin/node"||process.env.NODE_OPTIONS)throw Error("Unexpected runtime identity/options");
  out.entryCapacity=capacity();
  const libPaths=[...new Set(fs.readFileSync("/proc/self/maps","utf8").split("\n").map(x=>x.trim().split(/\s+/).at(-1)).filter(x=>x&&x.includes("/libnode.so.")))];
  out.runtimePins=[pin(process.execPath),...libPaths.map(pin)];
  if(out.runtimePins[0].sha256!=="d0efb6fcb9d023ba4e2b160ec2384dc28fe4f17732141ef47f676828fa960505"||libPaths.length!==1)throw Error("Runtime pin or shared library closure changed");
  out.payloadPin=pin(path.join(ROOT,"payload.json"));out.controllerPin=pin(__filename);out.bootstrapPin=pin(path.join(ROOT,"bootstrap.cjs"));
  if(sha(Buffer.from(P.originalManifest))!=="b7b53724957cc775382323e8bff65e40f88209ad65d41e0fe64bd04ba7cccafc")throw Error("Original manifest bytes changed");
  save("original-source-manifest-r1.json",P.originalManifest);
  const original=new Map(P.originalPins.map(x=>[x.path,x])),updates=new Map(P.updatedPins.map(x=>[x.path,x]));
  for(const [dir,isNew] of [["original-r1",false],["candidate-r2",true]])for(const entry of P.files){
    const changed=isNew&&P.updates.find(x=>x.path===entry.path),content=changed?changed.content:entry.content,expected=changed?updates.get(entry.path):original.get(entry.path);
    const f=save(path.join(dir,entry.path),content),actual=pin(f);if(!expected||actual.bytes!==expected.bytes||actual.sha256!==expected.sha256||actual.gitBlob!==expected.gitBlob)throw Error("Stage pin mismatch "+f);sourceFiles.push(f);
  }
  const regression=save("baseline-visible-cr.test.mjs",P.regressionSource);sourceFiles.push(regression);
  fs.mkdirSync(path.join(ROOT,"test-tmp"));out.sourceBefore=sourceFiles.map(pin);
  const old=run("baseline-lone-cr",ROOT,["--test","--test-concurrency=1",regression]);
  out.baselineExpectedFailure=old.status===1&&old.signal===null&&!old.error&&/# tests 1\b/.test(old.text)&&/# fail 1\b/.test(old.text)&&old.text.includes("first&#13;<br>second")&&old.text.includes("first&#13;second");
  if(!out.baselineExpectedFailure)throw Error("Original source did not reproduce the admitted single focused regression");
  const candidate=run("candidate-authored",path.join(ROOT,"candidate-r2"),["--test","--test-concurrency=1","tests/test_visit_record_report.mjs","tests/test_visit_record_to_html.mjs"]);
  out.candidateTestsPassed=candidate.status===0&&candidate.signal===null&&!candidate.error&&/# tests 14\b/.test(candidate.text)&&/# pass 14\b/.test(candidate.text)&&/# fail 0\b/.test(candidate.text);
  if(!out.candidateTestsPassed)throw Error("R2 authored source/CLI tests failed");
  out.sourceAfter=sourceFiles.map(pin);out.sourceUnchanged=JSON.stringify(out.sourceBefore)===JSON.stringify(out.sourceAfter);if(!out.sourceUnchanged)throw Error("Native source custody changed");
  out.finalCapacity=capacity();out.runtimeAfter=out.runtimePins.map(x=>pin(x.path));out.runtimeUnchanged=JSON.stringify(out.runtimePins)===JSON.stringify(out.runtimeAfter);if(!out.runtimeUnchanged)throw Error("Runtime changed");
  out.accepted=true;
} catch(e){out.errors.push({name:e.name,message:e.message,stack:e.stack});}
out.elapsedMs=performance.now()-started;out.ended=new Date().toISOString();save("native-receiving-r2.json",JSON.stringify(out,null,2)+"\n");process.stdout.write(JSON.stringify({accepted:out.accepted,receipt:path.join(ROOT,"native-receiving-r2.json"),baselineExpectedFailure:out.baselineExpectedFailure,candidateTestsPassed:out.candidateTestsPassed,sourceUnchanged:out.sourceUnchanged,runs:out.runs.map(({text,...r})=>r),errors:out.errors,elapsedMs:out.elapsedMs})+"\n");process.exitCode=out.accepted?0:1;
