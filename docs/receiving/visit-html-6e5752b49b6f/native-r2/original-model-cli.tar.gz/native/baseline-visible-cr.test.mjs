import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { renderVisitRecordReport } from "./original-r1/static/visit_record_report.mjs";
const original = await readFile(new URL("./original-r1/tests/fixtures/visit-record-csv.json", import.meta.url), "utf8");
const mutate = fn => { const value = JSON.parse(original); const week = JSON.parse(value.source.weekText); fn(value, week); value.source.weekText = JSON.stringify(week); return JSON.stringify(value); };
const field = (html, name) => [...html.matchAll(new RegExp('data-field="' + name + '">([\\s\\S]*?)<\\/', 'g'))].map(x => x[1]);
const escape = text => text.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#39;").replaceAll("\r","&#13;");

test("lone CR has a visible break while CRLF, literal markup and source characters stay distinct", () => {
  const cases = [
    ["first\rsecond", "first&#13;<br>second"],
    ["first\r\nsecond", "first&#13;\nsecond"],
    ["\rfirst\r\rsecond\r", "&#13;<br>first&#13;<br>&#13;<br>second&#13;<br>"],
    ["<br>\r</p>", "&lt;br&gt;&#13;<br>&lt;/p&gt;"],
    ["first\r\n\rsecond", "first&#13;\n&#13;<br>second"],
  ];
  for (const [literal, expected] of cases) {
    const text = mutate((value, week) => {
      week.response.plan.meals[0].name = literal;
      week.response.plan.meals[0].why = literal;
      week.response.plan.meals[0].entity_id = literal;
      value.visits.find(visit => visit.key === "pick-0").note = literal;
    });
    const html = renderVisitRecordReport(text).html;
    for (const name of ["venue_name", "entity_id", "original_explanation", "note"]) {
      assert.equal(field(html, name)[0], expected, name + ": " + JSON.stringify(literal));
    }
    assert.equal(html.includes("\r"), false, "source CR stays encoded until DOM parsing");
  }
});
