# TasteTable65 — unchanged independent root browser and print-output custody

This archive preserves every one of the58 existing regular files in the root's frozen taste-visit-html-receiving-root-r0 directory. It adds only this custody README, a complete original file/directory inventory and the archive member manifest. The production custody writer ran no archived product, receiver, CLI or browser and regenerated no HTML, PDF, PNG or DOM record.

The frozen original folder retains the unrun R0 receiver/controller and explicit pre-execution correction, corrected R1 source, frozen blind fixtures and baseline, offered-source snapshot, actual execution and receipt, and all22 physical artifacts:3 HTML files,3 original PDFs,7 PNG screenshots and9 DOM records. Original names, Unicode filenames and bytes are retained under original/.

Root reported accepted independent receiving of3 groups: actual Node89040 exit0/nullsignal; Chrome100724 observedclose0/nullsignal after sent/confirmed close; temporary profile absent;35 input/source/runtime records unchanged. Root inspected all7 PNGs. Original actual receipts are preserved rather than rewritten by this custodian. Physical PDF extraction/raster inspection belongs to native_runtime and remains separately qualified; browser print creation alone is not physical-page acceptance.

Source under test is the immutable TasteTable65 R1 renderer/CLI offered at b734d5f880a0199259435f8de8dafb71115c8530/treebcdb055b6fcd7547ee6349323b31277a79da5338. Native source manifest b7b53724957cc775382323e8bff65e40f88209ad65d41e0fe64bd04ba7cccafc; original root snapshot includes exact copied source.

Custody checks re-read every original file, verify all bytes/SHA256/computedGit blobs, check all original file and directory mtimes and membership unchanged, and re-extract every archive member in memory. All archive/manifests/custody receipts are written outside the frozen root folder, only in the production worker's root-browser-custody-r0 directory. No ref, Actions, service, policy, permission, profile or runtime change.
