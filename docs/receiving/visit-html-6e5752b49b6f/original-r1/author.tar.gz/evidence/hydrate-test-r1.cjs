'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),os=require('node:os'),{spawnSync}=require('node:child_process');
const root=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex'),git=b=>crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex');
const before=fs.readFileSync(path.join(root,'baseline-receipt.json'));assert.equal(sha(before),'518fe0362ae745ca4853ad76593b9774f2b5126e162b7480ac781873e7cf29c0');
const baseline=JSON.parse(before),input=JSON.parse(fs.readFileSync(path.join(root,'candidate-r1-input.json'))),dest=path.join(root,'candidate-r1');assert.equal(input.length,5);
const disk=fs.statfsSync(root),resources={at:new Date().toISOString(),freeMemory:os.freemem(),freeDisk:Number(disk.bavail)*Number(disk.bsize)};assert.ok(resources.freeMemory>=512*1024**2);assert.ok(resources.freeDisk>=100*1024**2);
assert.equal(sha(fs.readFileSync(process.execPath)),'ba4e6d110e8c1592a1ecd390f6b05f3da124b13871a5be62b341a07a853c6c32');
fs.mkdirSync(dest);const files=[];
for(const row of baseline.files){const b=fs.readFileSync(path.join(root,'baseline',row.path));assert.equal(sha(b),row.sha256);const target=path.join(dest,row.path);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,b,{flag:'wx'});files.push({...row,owned:false});}
for(const row of input){assert.ok(!baseline.files.some(x=>x.path===row.path));const b=Buffer.from(row.content),target=path.join(dest,row.path);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,b,{flag:'wx'});files.push({path:row.path,bytes:b.length,sha256:sha(b),gitBlob:git(b),owned:true});}
const tmp=path.join(root,'r1-tests-tmp');fs.mkdirSync(tmp);const syntax=[];
for(const row of input.filter(x=>x.path.endsWith('.mjs'))){const r=spawnSync(process.execPath,['--check',path.join(dest,row.path)],{encoding:'utf8',timeout:10000,maxBuffer:1024*1024});syntax.push({path:row.path,status:r.status,signal:r.signal,error:r.error?String(r.error):null,stdout:r.stdout,stderr:r.stderr});}
fs.writeFileSync(path.join(root,'syntax-r1.json'),JSON.stringify(syntax,null,2)+'\n',{flag:'wx'});assert.ok(syntax.every(x=>x.status===0&&x.signal===null),'Syntax');
const r=spawnSync(process.execPath,['--max-old-space-size=192','--test','--test-concurrency=1','tests/test_visit_record_report.mjs','tests/test_visit_record_to_html.mjs'],{cwd:dest,env:{...process.env,TMP:tmp,TEMP:tmp,TMPDIR:tmp},encoding:'utf8',timeout:90000,maxBuffer:4*1024**2});
const result={format:'tastetable-visit-html-native-r1/1',started:resources.at,status:r.status,signal:r.signal,error:r.error?String(r.error):null,stdout:r.stdout,stderr:r.stderr,timeoutMs:90000,resources,runtime:baseline.runtime,claim:'New renderer and real CLI tests only; no browser or PDF pass'};
fs.writeFileSync(path.join(root,'native-tests-r1.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
for(const row of files)assert.equal(sha(fs.readFileSync(path.join(dest,row.path))),row.sha256);
for(const row of baseline.files)assert.equal(sha(fs.readFileSync(path.join(root,'baseline',row.path))),row.sha256);
const manifest={format:'tastetable-visit-html-source-r1/1',base:baseline.base,tree:baseline.tree,contractSHA256:'137629ad8e711adf55b1b491b1a546bd8a3be9a84573af1c1ae59da09dc35f6c',files,syntax,tests:{path:'native-tests-r1.json',sha256:sha(fs.readFileSync(path.join(root,'native-tests-r1.json'))),status:r.status},sourceUnchanged:true};
const b=Buffer.from(JSON.stringify(manifest,null,2)+'\n');fs.writeFileSync(path.join(root,'source-manifest-r1.json'),b,{flag:'wx'});console.log(JSON.stringify({status:r.status,signal:r.signal,error:result.error,stdout:r.stdout,stderr:r.stderr,sourceManifestSHA256:sha(b),sourceFiles:files.length,resources}));if(r.status!==0||r.signal!==null)process.exitCode=1;
