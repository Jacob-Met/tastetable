
## Offline report of recorded visits

A saved visit-record JSON can also become a standalone, printable HTML handoff:

```sh
node tools/visit_record_to_html.mjs --input "visits.json" --output "visits.html"
```

Open the HTML offline or use the browser's Print command. It includes every original occurrence, the saved planned schedule, separately recorded outcomes and actual dates, literal notes, original explanations and source timestamps. It contains no scripts or external assets and makes no new recommendations or interpretations. The command requires Node.js 22+, preserves its input and refuses an existing output. Keep the original JSON for editing and complete source/trace. See the [visit-record HTML guide](docs/visit-record-html/README.md) for limits, provenance, refusal behavior and checks.
