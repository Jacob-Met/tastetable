"""Independent native Poppler decode of exact corrected original PDFs, no reprint."""
import base64,hashlib,importlib.util,json,os,pathlib,re,shutil,subprocess,sys,time,traceback,xml.etree.ElementTree as ET
R=pathlib.Path(__file__).resolve().parent;O=R/"poppler-corrected-r3"
PINS=[(111620,"3bfb91bf804b35a3aae6c713a35e8f11cec0931cba116a8c9acd847c159aac7d"),(138007,"cd0668ec9febc67e2235d8cc8ada95b58e5280e4e59e38cc898f70f12aa613d2"),(60299,"581ad80dae27e0f56e71c4cecb7d3fddb78d21565c64bf7dda9cbefa192aeb99")]
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":sha(b)}
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def write(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=True,indent=2)+"\n")
assert os.getuid()==1000
available=int(re.search(r"MemAvailable:\s+(\d+)",pathlib.Path("/proc/meminfo").read_text()).group(1))*1024
capacity={"hostAvailableMemory":available,"ownFilesystemFree":shutil.disk_usage(R).free,"memoryFloor":256*1024**2,"filesystemFloor":64*1024**2}
assert available>=capacity["memoryFloor"] and capacity["ownFilesystemFree"]>=capacity["filesystemFloor"],capacity
assert not O.exists();O.mkdir()
r={"scope":"Original corrected PDF decoding and page accounting; actual visual acceptance recorded separately","completed":False,"capacity":capacity,"started":time.time(),"commands":[],"pdfs":[]}
paths=[];before=[]
try:
 manifest=R/"runtime-admission.json";assert sha(manifest.read_bytes())=="6a877eb470d37fb784c8391375d3dbdb40648208fd0a3b91b48ddb631191f1e9"
 admitted=json.loads(manifest.read_text())
 for row in admitted["files"]:assert rec(pathlib.Path(row["path"]))==row
 assert sha(pathlib.Path("/usr/bin/python3.14").read_bytes())=="52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41"
 paths=[pathlib.Path(row["path"]) for row in admitted["files"]]+[pathlib.Path("/usr/bin/python3.14"),manifest,pathlib.Path(__file__).resolve(),R/"account-fields-r1.py",R/"frozen-fixture-ledger.json"]+[R/("corrected-original-%d.pdf.b64"%i) for i in range(3)]
 before=[rec(p) for p in paths];write("input-before.json",before)
 a=load("frozen_accounting",R/"account-fields-r1.py");ledger=json.loads((R/"frozen-fixture-ledger.json").read_text())
 def run(label,args):
  start=time.time();p=subprocess.run(args,capture_output=True,timeout=60)
  (O/(label+".stdout")).write_bytes(p.stdout);(O/(label+".stderr")).write_bytes(p.stderr)
  row={"label":label,"args":args,"exit":p.returncode,"elapsedSeconds":time.time()-start,"stdout":rec(O/(label+".stdout")),"stderr":rec(O/(label+".stderr"))}
  r["commands"].append(row);assert p.returncode==0,row
  return p.stdout
 for i,(size,digest) in enumerate(PINS):
  raw=base64.b64decode("".join((R/("corrected-original-%d.pdf.b64"%i)).read_text().split()),validate=True)
  assert len(raw)==size and sha(raw)==digest
  pdf=O/("original-%d.pdf"%i);pdf.write_bytes(raw)
  info=run("pdf%d-info"%i,["/usr/bin/pdfinfo",str(pdf)])
  text=run("pdf%d-text"%i,["/usr/bin/pdftotext","-enc","UTF-8",str(pdf),"-"]).decode("utf-8")
  pages=text.split("\f")
  if pages[-1]=="":pages.pop()
  xml=run("pdf%d-bbox"%i,["/usr/bin/pdftotext","-bbox-layout","-enc","UTF-8",str(pdf),"-"])
  root=ET.fromstring(xml)
  pageEls=[p for p in root.iter() if p.tag.rsplit("}",1)[-1]=="page"]
  assert len(pages)==len(pageEls)==[4,7,2][i]
  boxes=[];outside=[];selected=[]
  for num,page in enumerate(pageEls,1):
   width=float(page.attrib["width"]);height=float(page.attrib["height"])
   for word in page.iter():
    if word.tag.rsplit("}",1)[-1]!="word":continue
    box={k:float(word.attrib[k]) for k in ["xMin","yMin","xMax","yMax"]}
    row={"page":num,"text":"".join(word.itertext()),**box};boxes.append(row)
    if not (0<=box["xMin"]<=box["xMax"]<=width and 0<=box["yMin"]<=box["yMax"]<=height):outside.append(row)
    if row["text"] in ["A","B","C","WHY_BEGIN","CR_ONLY","CRLF_PAIR","LF_LINE","NOTE2_BEGIN","CR","CRLF","LF"]:selected.append(row)
  write("pdf%d-word-boxes.json"%i,boxes)
  run("pdf%d-raster"%i,["/usr/bin/pdftoppm","-r","110","-png",str(pdf),str(O/("pdf%d-page"%i))])
  images=sorted(O.glob("pdf%d-page-*.png"%i));assert len(images)==len(pages)
  account=a.account(pages,ledger["fixtures"][i])
  r["pdfs"].append({"pdf":i,"original":rec(pdf),"pageCount":len(pages),"accounting":account,"outOfPageWordBoxes":outside,"selectedWordBoxes":selected,"images":[rec(p) for p in images]})
  assert not outside,outside
  assert pdf.read_bytes()==raw
 r["completed"]=True
except BaseException as e:r["failure"]={"type":type(e).__name__,"message":str(e),"traceback":traceback.format_exc()}
finally:
 if before:
  after=[rec(p) for p in paths];write("input-after.json",after);r["inputCount"]=len(before);r["inputsUnchanged"]=before==after
  if not r["inputsUnchanged"]:r["completed"]=False
 r["elapsedSeconds"]=time.time()-r["started"];write("receiving.json",r);print(json.dumps(r,ensure_ascii=True))
sys.exit(0 if r["completed"] else 1)
