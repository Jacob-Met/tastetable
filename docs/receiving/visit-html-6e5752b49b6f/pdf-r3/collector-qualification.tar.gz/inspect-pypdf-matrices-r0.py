import pathlib,inspect,json,hashlib,pypdf._page
import pypdf._text_extraction as t
r=pathlib.Path(__file__).parent
code=inspect.getsource(pypdf._page.TextExtraction)
m=inspect.getsource(t.mult)
data={"textExtraction":code,"mult":m,"path":inspect.getsourcefile(pypdf._page.TextExtraction)}
raw=(json.dumps(data,indent=2)+"\n").encode();(r/"pypdf-text-extraction-r0.json").write_bytes(raw)
print(json.dumps({"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"path":data["path"]}))
