import pathlib,inspect,json,hashlib,importlib.metadata,sys
import pypdf
from pypdf._page import PageObject
root=pathlib.Path(__file__).parent
records=[]
for name,fn in [("extract_text",PageObject.extract_text),("_extract_text",PageObject._extract_text)]:
 source=inspect.getsource(fn);path=pathlib.Path(inspect.getsourcefile(fn));raw=path.read_bytes()
 records.append({"name":name,"path":str(path),"fileBytes":len(raw),"fileSHA256":hashlib.sha256(raw).hexdigest(),"source":source})
data={"pypdfVersion":importlib.metadata.version("pypdf"),"modulePath":pypdf.__file__,"python":sys.version,"executable":sys.executable,"records":records,"pdfOpened":False}
raw=(json.dumps(data,indent=2)+"\n").encode()
(root/"pypdf-source-inspection-r0.json").write_bytes(raw)
print(json.dumps({"version":data["pypdfVersion"],"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"path":str(root/"pypdf-source-inspection-r0.json"),"functions":[{"name":r["name"],"chars":len(r["source"])} for r in records]}))
