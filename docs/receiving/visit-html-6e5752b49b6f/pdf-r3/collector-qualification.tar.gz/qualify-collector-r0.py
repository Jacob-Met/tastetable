"""Independent collector qualification; original product bytes never regenerated."""
import base64, ctypes, hashlib, importlib.util, io, json, os, pathlib, platform, shutil, sys, tarfile, time, traceback
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/"collector-qualification-r0"
ARCHIVE_SHA="c194ea6190b3962dbec829e5e4c15724a3639ccc76ef7bbc74d86f598cbfe944"
PDFS=[
(94824,"c4cc774c9fb5c7fb049279ad9fdce7920a32e25b21cea5f8139e5c9b6db46b34"),
(120987,"fa75132474be12d4dcf3c5107b976a42a5e03114ca83c7d93ef441e5aac7f8f6"),
(60296,"8c28b58debf13651dc2b50e8d99c7841aacf2ce442ebd10422761cc5461683be")]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def write(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=True,indent=2)+"\n",encoding="utf-8")
def record(path):
 b=path.read_bytes();return {"path":str(path),"bytes":len(b),"sha256":sha(b)}
class Memory(ctypes.Structure):
 _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
mem=Memory();mem.dwLength=ctypes.sizeof(mem)
assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem))
capacity={"freeMemory":mem.ullAvailPhys,"freeDisk":shutil.disk_usage(ROOT).free,"memoryFloor":256*1024**2,"diskFloor":64*1024**2}
assert capacity["freeMemory"]>=capacity["memoryFloor"] and capacity["freeDisk"]>=capacity["diskFloor"],capacity
assert not OUT.exists(),"Never overwrite a receiving run"
OUT.mkdir()
result={"passed":False,"scope":"Qualification of PDF origin collector, not corrected product acceptance","capacity":capacity,"python":sys.version,"executable":sys.executable,"started":time.time(),"positive":[],"negative":[],"original":[]}
paths=[]
try:
 assert sha(pathlib.Path(sys.executable).read_bytes())=="cce21c0e8710e304273e98ac4b2b0f5aceb639acbcd2343cbaa5c4e81619c45b"
 helper=ROOT/"pdf-visible-separators-r0.py"
 collector=ROOT/"pypdf-origin-collector-r0.py"
 assert sha(helper.read_bytes())=="a730f9f470ab0f770f6e24198b90eabffce07a4c31d41de188c365e0b5fb461d"
 assert git(collector.read_bytes())=="e90f1463c4c296db7ac4e8d85b2dd770ef5494a5"
 import pypdf
 assert pypdf.__version__=="6.14.2"
 package=pathlib.Path(pypdf.__file__).parent
 paths=[pathlib.Path(sys.executable),helper,collector,pathlib.Path(__file__).resolve(),ROOT/"original-r1-root-archive.b64"]
 paths+=sorted(package.rglob("*.py"))
 before=[record(p) for p in paths];write("input-before.json",before)
 predicate=load("frozen_predicate",helper);origin=load("origin_collector",collector)
 raw=base64.b64decode((ROOT/"original-r1-root-archive.b64").read_text(encoding="utf-8").strip(),validate=True)
 assert len(raw)==628636 and sha(raw)==ARCHIVE_SHA
 originals=[]
 with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz") as tf:
  members=tf.getmembers();assert len(members)==61
  for i,(size,digest) in enumerate(PDFS):
   matches=[m for m in members if m.isfile() and m.name.endswith("outputs-r1/original-%d.pdf"%i)]
   assert len(matches)==1
   b=tf.extractfile(matches[0]).read();assert len(b)==size and sha(b)==digest
   (OUT/("original-%d.pdf"%i)).write_bytes(b);originals.append(b)
 result["originalArchive"]={"bytes":len(raw),"sha256":sha(raw),"members":61,"git":"821366ae605e6a5f42723a515b4282f4e3e498ec","mirrorGit":"65423c728363abe5785731648f488c6bd5b5e5ff"}
 # This byte writer is independent of pypdf and the collector. All toy pages
 # use literal PDF operator matrices and an independently specified baseline table.
 def toy(markers,baselines,kind="ordinary"):
  assert len(markers)==len(baselines)
  cmds=[]
  for text,y in zip(markers,baselines):
   # Physical page baseline = 792 - (1.5 * tm_y + 20).
   tm_y=(772-y)/1.5
   matrix="2 0 0 1.5 10 20" if kind!="skew" else "2 .25 0 1.5 10 20"
   cmds.append("q "+matrix+" cm BT /F1 8 Tf 1 0 0 1 20 %.12g Tm (%s) Tj ET Q"%(tm_y,text))
  stream=("\n".join(cmds)+"\n").encode("ascii")
  objs=[b"<< /Type /Catalog /Pages 2 0 R >>",b"<< /Type /Pages /Count 1 /Kids [3 0 R] >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length "+str(len(stream)).encode()+b" >>\nstream\n"+stream+b"endstream"]
  data=b"%PDF-1.4\n";offset=[0]
  for n,obj in enumerate(objs,1):
   offset.append(len(data));data+=str(n).encode()+b" 0 obj\n"+obj+b"\nendobj\n"
  xref=len(data);data+=b"xref\n0 6\n0000000000 65535 f \n"
  for p in offset[1:]:data+=("%010d 00000 n \n"%p).encode()
  data+=b"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n"+str(xref).encode()+b"\n%%EOF\n"
  return data
 def reject(label,b,case):
  (OUT/(label+".pdf")).write_bytes(b)
  try:
   collected=origin.collect(b);write(label+"-origins.json",collected)
   predicate.check_case(collected["lines"],case)
  except ValueError as exc:
   result["negative"].append({"label":label,"sha256":sha(b),"exception":str(exc)})
  else:raise AssertionError("Negative was accepted: "+label)
 for index,case in enumerate(predicate.CASES):
  markers=list(case["markers"]);ys=[100+18.75*i for i in range(len(markers))]
  b=toy(markers,ys);(OUT/("controlled-positive-%d.pdf"%index)).write_bytes(b)
  collected=origin.collect(b);write("controlled-positive-%d-origins.json"%index,collected)
  measured=predicate.check_case(collected["lines"],case)
  assert len(collected["lines"])==len(markers)
  for row,wanted in zip(collected["lines"],ys):
   assert abs(row["baseline"]-wanted)<1e-8 and row["fontSize"]==12,(row,wanted)
  result["positive"].append({"case":case["field"],"sha256":sha(b),"expectedBaselines":ys,"measured":measured})
  joined=[markers[0]+markers[1]]+markers[2:]
  reject("collapsed-%d"%index,toy(joined,[ys[0]]+ys[2:]),case)
  bad=ys[:];bad[1:]=[x+18.75 for x in bad[1:]]
  reject("double-first-break-%d"%index,toy(markers,bad),case)
 reject("skewed-selected-text",toy(["A","B","C"],[100,118.75,137.5],"skew"),predicate.CASES[0])
 # The unchanged original report is a known visual negative, not product success.
 for i in range(3):
  try:
   collected=origin.collect(originals[i]);write("original-%d-origins.json"%i,collected)
   for case in [c for c in predicate.CASES if c["pdf"]==i]:
    try:predicate.check_case(collected["lines"],case)
    except ValueError as exc:result["original"].append({"pdf":i,"field":case["field"],"expectedRefusal":str(exc),"collectorReturned":True})
    else:raise AssertionError("Visibly joined original unexpectedly passed")
   if i==2:result["original"].append({"pdf":2,"collectorReturned":True,"noSeparatorCase":True,"pageCount":collected["pageCount"]})
  except ValueError as exc:
   result["original"].append({"pdf":i,"expectedRefusal":str(exc),"collectorReturned":False,
       "limit":"Collector scope refusal is not independent localization of the joined glyphs."})
 result["passed"]=True
except BaseException as exc:
 result["failure"]={"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}
finally:
 if paths:
  after=[record(p) for p in paths];write("input-after.json",after)
  result["inputsUnchanged"]=after==before
  if not result["inputsUnchanged"]:result["passed"]=False
 result["elapsedSeconds"]=time.time()-result["started"]
 write("receiving.json",result)
 print(json.dumps(result,ensure_ascii=True))
sys.exit(0 if result["passed"] else 1)
