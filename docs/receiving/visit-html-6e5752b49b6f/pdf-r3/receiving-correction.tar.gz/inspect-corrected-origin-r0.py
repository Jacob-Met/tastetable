import pathlib,json,hashlib,importlib.util
R=pathlib.Path(__file__).resolve().parent
def load(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def sha(b):return hashlib.sha256(b).hexdigest()
f=load("frozen",R/"pdf-visible-separators-r0.py")
out={"geometry":[],"rawSelected":[],"unicodeContext":[],"inputPins":[]}
for folder in ["collector-qualification-r0","corrected-originals-r3"]:
 for i in [0,1]:
  p=R/folder/("original-%d-origins.json"%i);raw=p.read_bytes();v=json.loads(raw);out["inputPins"].append({"path":str(p),"sha256":sha(raw),"bytes":len(raw)})
  for case in f.CASES:
   if case["pdf"]!=i:continue
   for marker in case["markers"]:
    hits=[row for row in v["visitorRecords"] if f._matches(row["text"],marker)]
    out["rawSelected"].append({"folder":folder,"pdf":i,"marker":marker,"rows":[{"raw":row["rawVisitorText"],"page":row["page"],"tm":row["tm"],"cm":row["cm"]} for row in hits]})
   if folder=="corrected-originals-r3":
    try:out["geometry"].append({"case":case["field"],"pass":True,"result":f.check_case(v["lines"],case)})
    except Exception as e:out["geometry"].append({"case":case["field"],"pass":False,"error":str(e)})
  if folder=="corrected-originals-r3" and i==1:
   for n,t in enumerate(v["pageText"],1):
    for needle in ["Earlier explanation","NOTE2_BEGIN","ORIGINAL_ORDER_END"]:
     at=t.find(needle)
     if at>=0:out["unicodeContext"].append({"page":n,"needle":needle,"text":t[max(0,at-60):at+200]})
p=R/"corrected-origin-inspection-r0.json";assert not p.exists()
p.write_text(json.dumps(out,ensure_ascii=True,indent=2)+"\n",encoding="utf-8")
print(json.dumps(out,ensure_ascii=True))
