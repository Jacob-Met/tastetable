"""Read original corrected PDF's marked text and CMaps; no text rewrite."""
import hashlib,io,json,pathlib
from pypdf import PdfReader
from pypdf.generic import ContentStream
R=pathlib.Path(__file__).resolve().parent;P=R/"corrected-originals-r3"/"original-1.pdf"
raw=P.read_bytes();assert hashlib.sha256(raw).hexdigest()=="cd0668ec9febc67e2235d8cc8ada95b58e5280e4e59e38cc898f70f12aa613d2"
reader=PdfReader(io.BytesIO(raw),strict=True)
out={"pdfSha256":hashlib.sha256(raw).hexdigest(),"pages":[],"installedNormalizationReferences":[]}
def clean(x):
 if isinstance(x,bytes):return {"hex":x.hex()}
 if isinstance(x,str):
  d={"text":str(x)}
  try:d["originalBytesHex"]=x.original_bytes.hex()
  except Exception:pass
  return d
 if isinstance(x,(list,tuple)):return [clean(v) for v in x]
 if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
 return str(x)
for n in [5,6]:
 page=reader.pages[n];cs=ContentStream(page.get_contents(),reader);ops=cs.operations;rows=[];font=None
 for j,(args,op) in enumerate(ops):
  if op==b"Tf":font=str(args[0])
  if op==b"BDC" and "/ActualText" in str(args):
   rows.append({"operationIndex":j,"font":font,"operation":clean(args),"nearby":[{"op":op2.decode("ascii"),"args":clean(args2)} for args2,op2 in ops[max(0,j-2):min(len(ops),j+6)]]})
 fonts={}
 for name,ref in page["/Resources"]["/Font"].items():
  f=ref.get_object()
  if "/ToUnicode" in f:
   b=f["/ToUnicode"].get_data();text=b.decode("latin-1")
   fonts[str(name)]={"BaseFont":str(f.get("/BaseFont")),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"cmap":text}
 out["pages"].append({"page":n+1,"actualText":rows,"fonts":fonts})
import pypdf
for p in pathlib.Path(pypdf.__file__).parent.rglob("*.py"):
 text=p.read_text(encoding="utf-8")
 hits=[{"line":n,"text":line} for n,line in enumerate(text.splitlines(),1) if "normalize(" in line or "ActualText" in line]
 if hits:out["installedNormalizationReferences"].append({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"hits":hits})
assert P.read_bytes()==raw
target=R/"corrected-unicode-cmaps-r0.json";assert not target.exists()
target.write_text(json.dumps(out,ensure_ascii=True,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"path":str(target),"bytes":len(target.read_bytes()),"sha256":hashlib.sha256(target.read_bytes()).hexdigest(),"actualText":[{"page":p["page"],"rows":p["actualText"]} for p in out["pages"]],"installedReferences":out["installedNormalizationReferences"]},ensure_ascii=True))
