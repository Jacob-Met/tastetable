import ctypes,hashlib,importlib.util,json,pathlib,shutil,sys
R=pathlib.Path(__file__).resolve().parent;O=R/"corrected-originals-r3";S=R.parent/"taste-visit-html-receiving-root-r3"/"outputs-r3"
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pins=[(111620,"3bfb91bf804b35a3aae6c713a35e8f11cec0931cba116a8c9acd847c159aac7d"),(138007,"cd0668ec9febc67e2235d8cc8ada95b58e5280e4e59e38cc898f70f12aa613d2"),(60299,"581ad80dae27e0f56e71c4cecb7d3fddb78d21565c64bf7dda9cbefa192aeb99")]
class M(ctypes.Structure):
 _fields_=[("size",ctypes.c_ulong),("load",ctypes.c_ulong)]+[(n,ctypes.c_ulonglong) for n in ["total","free","pageTotal","pageFree","virtualTotal","virtualFree","extended"]]
m=M();m.size=ctypes.sizeof(m);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));assert m.free>=256*1024**2 and shutil.disk_usage(R).free>=64*1024**2
for row in json.loads((R/"collector-qualification-r0"/"input-before.json").read_text()):assert sha(pathlib.Path(row["path"]).read_bytes())==row["sha256"]
sources=[]
for i,(size,h) in enumerate(pins):
 b=(S/("original-%d.pdf"%i)).read_bytes();assert len(b)==size and sha(b)==h;sources.append(b)
p=O/"original-2.pdf";assert not p.exists();p.write_bytes(sources[2])
origin=load("origin",R/"pypdf-origin-collector-r0.py");f=load("predicate",R/"pdf-visible-separators-r0.py");a=load("account",R/"account-fields-r1.py")
v=origin.collect(sources[2]);(O/"original-2-origins.json").write_text(json.dumps(v,ensure_ascii=True,indent=2)+"\n",encoding="utf-8")
ledger=json.loads((R/"frozen-fixture-ledger.json").read_text(encoding="utf-8"));account=a.account(v["pageText"],ledger["fixtures"][2]);assert account["passed"]
guards=[]
for i in [0,1]:
 v=json.loads((O/("original-%d-origins.json"%i)).read_text())
 for case in f.CASES:
  if case["pdf"]!=i:continue
  for marker in case["markers"]:
   hits=[row for row in v["visitorRecords"] if f._matches(row["text"],marker)]
   assert len(hits)==1 and hits[0]["rawVisitorText"]==hits[0]["text"] and not any(c in hits[0]["rawVisitorText"] for c in "\r\n"),marker
   guards.append({"pdf":i,"marker":marker,"raw":hits[0]["rawVisitorText"]})
for i,b in enumerate(sources):assert (S/("original-%d.pdf"%i)).read_bytes()==b and (O/("original-%d.pdf"%i)).read_bytes()==b
r={"emptyOriginalPDF":{"pageCount":2,"accounting":account},"rawSelectedAdmission":guards,"inputPDFsUnchanged":True,"scope":"Complete third original only plus admission guard on already collected selected callback text; unchanged known failures remain in receiving.json; no whole-presentation acceptance."}
out=O/"empty-and-raw-admission-r0.json";assert not out.exists();out.write_text(json.dumps(r,ensure_ascii=True,indent=2)+"\n",encoding="utf-8");print(json.dumps(r,ensure_ascii=True))
