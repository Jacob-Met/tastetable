"""Read-only intake and text/geometry receiving of corrected ORIGINAL PDFs.
No report generation, printing, browser launch or rasterization."""
import ctypes,hashlib,importlib.util,json,pathlib,shutil,sys,time,traceback
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT.parent/"taste-visit-html-receiving-root-r3"/"outputs-r3"
OUT=ROOT/"corrected-originals-r3"
PINS=[
(111620,"3bfb91bf804b35a3aae6c713a35e8f11cec0931cba116a8c9acd847c159aac7d","02d83282b87203547430abda9bb676f23f61e239"),
(138007,"cd0668ec9febc67e2235d8cc8ada95b58e5280e4e59e38cc898f70f12aa613d2","a119af45af2a19278eb394ac2881d3dbadba2682"),
(60299,"581ad80dae27e0f56e71c4cecb7d3fddb78d21565c64bf7dda9cbefa192aeb99","8a43a9961fdad463783af306162e0079075af624")]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def rec(p):
 b=p.read_bytes();return {"path":str(p),"bytes":len(b),"sha256":sha(b),"git":git(b)}
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def write(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=True,indent=2)+"\n",encoding="utf-8")
class Memory(ctypes.Structure):
 _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
mem=Memory();mem.dwLength=ctypes.sizeof(mem);assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(mem))
capacity={"freeMemory":mem.ullAvailPhys,"freeDisk":shutil.disk_usage(ROOT).free,"memoryFloor":256*1024**2,"diskFloor":64*1024**2}
assert capacity["freeMemory"]>=capacity["memoryFloor"] and capacity["freeDisk"]>=capacity["diskFloor"],capacity
assert not OUT.exists(),"Never overwrite a receiving run"
OUT.mkdir()
r={"textAndGeometryPassed":False,"wholePresentationAcceptance":"pending native raster/page inspection","scope":"Original corrected R3 PDFs only, exact frozen accounting and geometry predicates","capacity":capacity,"sourceRendererGit":"0c7a99 (full root source receipt binds exact pin)","started":time.time(),"fixtures":[],"geometry":[]}
paths=[];before=[]
try:
 expected=json.loads((ROOT/"collector-qualification-r0"/"input-before.json").read_text())
 for row in expected:
  assert sha(pathlib.Path(row["path"]).read_bytes())==row["sha256"],row
 ownpins=[
 ("pypdf-origin-collector-r0.py","e90f1463c4c296db7ac4e8d85b2dd770ef5494a5"),
 ("pdf-visible-separators-r0.py","2b60e392c939621c4220fe1e8255ead36a93eab3"),
 ("account-fields-r1.py","d2933d18b0e38569768b5136b073ad213342d50d"),
 ("frozen-fixture-ledger.json","f4af9e1197ded2ee1b732ad21265786122b7bb41")]
 for name,digest in ownpins:assert git((ROOT/name).read_bytes())==digest,name
 paths=[pathlib.Path(row["path"]) for row in expected]
 paths += [ROOT/name for name,digest in ownpins]+[pathlib.Path(__file__).resolve()]
 sources=[SOURCE/("original-%d.pdf"%i) for i in range(3)]
 paths+=sources
 paths=list(dict.fromkeys(paths));before=[rec(p) for p in paths];write("input-before.json",before)
 collector=load("qualified_origin_collector",ROOT/"pypdf-origin-collector-r0.py")
 predicate=load("frozen_geometry",ROOT/"pdf-visible-separators-r0.py")
 accounting=load("frozen_accounting",ROOT/"account-fields-r1.py")
 ledger=json.loads((ROOT/"frozen-fixture-ledger.json").read_text(encoding="utf-8"))
 collected=[]
 for i,(size,digest,blob) in enumerate(PINS):
  raw=sources[i].read_bytes()
  assert len(raw)==size and sha(raw)==digest and git(raw)==blob,("PDF admission",i)
  copy=OUT/("original-%d.pdf"%i)
  with copy.open("xb") as f:f.write(raw)
  assert copy.read_bytes()==raw
  data=collector.collect(raw);collected.append(data);write("original-%d-origins.json"%i,data)
  report=accounting.account(data["pageText"],ledger["fixtures"][i])
  r["fixtures"].append({"pdf":i,"source":str(sources[i]),"copy":rec(copy),"pageCount":data["pageCount"],"accounting":report})
  assert report["passed"],report
 for case in predicate.CASES:r["geometry"].append(predicate.check_case(collected[case["pdf"]]["lines"],case))
 r["textAndGeometryPassed"]=True
except BaseException as exc:r["failure"]={"type":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc()}
finally:
 if before:
  after=[rec(p) for p in paths];write("input-after.json",after)
  r["inputCount"]=len(before);r["inputsUnchanged"]=before==after
  if not r["inputsUnchanged"]:r["textAndGeometryPassed"]=False
 r["elapsedSeconds"]=time.time()-r["started"];write("receiving.json",r);print(json.dumps(r,ensure_ascii=True))
sys.exit(0 if r["textAndGeometryPassed"] else 1)
