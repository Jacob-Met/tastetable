'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const ROOT=__dirname;
function pin(p){const st=fs.lstatSync(p);assert.ok(st.isFile());assert.equal(fs.realpathSync.native(p).toLowerCase(),p.toLowerCase());const sh=crypto.createHash('sha256'),gh=crypto.createHash('sha1').update('blob '+st.size+'\0'),fd=fs.openSync(p,'r'),b=Buffer.alloc(1048576);let n,total=0;try{while((n=fs.readSync(fd,b,0,b.length,null))>0){total+=n;sh.update(b.subarray(0,n));gh.update(b.subarray(0,n));}}finally{fs.closeSync(fd);}assert.equal(total,st.size);return{path:p,bytes:total,sha256:sh.digest('hex'),gitBlob:gh.digest('hex'),mtimeMs:st.mtimeMs};}
function same(p,e){for(const k of ['bytes','sha256','gitBlob'])if(e[k]!==undefined)assert.equal(p[k],e[k],e.path+' '+k);}
function capacity(){const s=fs.statfsSync(ROOT),c={at:new Date().toISOString(),freeRAM:os.freemem(),diskFree:s.bavail*s.bsize};assert.ok(c.freeRAM>=2*1024**3,'2GiB RAM floor');assert.ok(c.diskFree>=1024**3,'1GiB disk floor');return c;}
function identity(){assert.equal(process.platform,'win32');assert.equal(process.version,'v24.14.0');assert.equal(os.userInfo().username,'jacob');assert.equal(os.hostname(),'MSI');assert.equal(process.execPath.toLowerCase(),'c:\\program files\\nodejs\\node.exe');assert.ok(!process.env.NODE_OPTIONS&&!process.env.NODE_PATH);return{pid:process.pid,node:process.version,execPath:process.execPath,user:os.userInfo().username,hostname:os.hostname(),root:ROOT};}

const {spawnSync}=require('node:child_process');
const report={format:'taste65-r2-native-browser-execution/1',at:new Date().toISOString(),accepted:false};const started=performance.now();
try{
 report.identity=identity();report.capacity=capacity();
 const stage=JSON.parse(fs.readFileSync(path.join(ROOT,'stage-receiving-r2.json'),'utf8'));assert.equal(stage.accepted,true);assert.equal(stage.written.length,25);
 for(const p of stage.written)same(pin(p.path),p);
 report.before=['run.cjs','stage.cjs','stage-payload.json','stage-receiving-r2.json'].map(n=>pin(path.join(ROOT,n)));
 for(const n of ['browser-execution-r2.json','receiver-r2.stdout','receiver-r2.stderr','browser-receiving-r2.json'])assert.equal(fs.existsSync(path.join(ROOT,n)),false,'fresh result '+n);
 report.argv=[process.execPath,'--max-old-space-size=256',path.join(ROOT,'receive-browser-r2.mjs')];
 const t=performance.now(),p=spawnSync(report.argv[0],report.argv.slice(1),{cwd:ROOT,encoding:'utf8',windowsHide:true,timeout:180000,maxBuffer:2*1024*1024});
 report.child={pid:p.pid,status:p.status,signal:p.signal,error:p.error?{name:p.error.name,code:p.error.code,message:p.error.message}:null,elapsedMs:performance.now()-t,stdout:p.stdout,stderr:p.stderr};
 fs.writeFileSync(path.join(ROOT,'receiver-r2.stdout'),p.stdout??'',{flag:'wx'});fs.writeFileSync(path.join(ROOT,'receiver-r2.stderr'),p.stderr??'',{flag:'wx'});
 report.logPins=['receiver-r2.stdout','receiver-r2.stderr'].map(n=>pin(path.join(ROOT,n)));
 assert.equal(p.status,0);assert.equal(p.signal,null);assert.equal(p.error,undefined);
 const received=JSON.parse(fs.readFileSync(path.join(ROOT,'browser-receiving-r2.json'),'utf8'));report.browserReceipt=pin(path.join(ROOT,'browser-receiving-r2.json'));assert.equal(received.accepted,true);
 report.browser={pid:received.browserPid,version:received.browserVersion,close:received.browserClose,groups:received.groups.length,artifacts:received.artifacts.length,requests:received.requests,errors:received.errors,separatorControls:received.separatorControls?.passed,inputsUnchanged:received.inputsUnchanged};
 report.after=report.before.map(x=>pin(x.path));assert.deepEqual(report.after,report.before);report.accepted=true;
}catch(e){report.failure={name:e.name,message:e.message,stack:e.stack};}
report.elapsedMs=performance.now()-started;report.ended=new Date().toISOString();
fs.writeFileSync(path.join(ROOT,'browser-execution-r2.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({accepted:report.accepted,pid:process.pid,child:report.child?{pid:report.child.pid,status:report.child.status,signal:report.child.signal,error:report.child.error}:null,browser:report.browser,elapsedMs:report.elapsedMs,failure:report.failure}));process.exitCode=report.accepted?0:1;
