'use strict';
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const ROOT=__dirname;
function pin(p){const st=fs.lstatSync(p);assert.ok(st.isFile());assert.equal(fs.realpathSync.native(p).toLowerCase(),p.toLowerCase());const sh=crypto.createHash('sha256'),gh=crypto.createHash('sha1').update('blob '+st.size+'\0'),fd=fs.openSync(p,'r'),b=Buffer.alloc(1048576);let n,total=0;try{while((n=fs.readSync(fd,b,0,b.length,null))>0){total+=n;sh.update(b.subarray(0,n));gh.update(b.subarray(0,n));}}finally{fs.closeSync(fd);}assert.equal(total,st.size);return{path:p,bytes:total,sha256:sh.digest('hex'),gitBlob:gh.digest('hex'),mtimeMs:st.mtimeMs};}
function same(p,e){for(const k of ['bytes','sha256','gitBlob'])if(e[k]!==undefined)assert.equal(p[k],e[k],e.path+' '+k);}
function capacity(){const s=fs.statfsSync(ROOT),c={at:new Date().toISOString(),freeRAM:os.freemem(),diskFree:s.bavail*s.bsize};assert.ok(c.freeRAM>=2*1024**3,'2GiB RAM floor');assert.ok(c.diskFree>=1024**3,'1GiB disk floor');return c;}
function identity(){assert.equal(process.platform,'win32');assert.equal(process.version,'v24.14.0');assert.equal(os.userInfo().username,'jacob');assert.equal(os.hostname(),'MSI');assert.equal(process.execPath.toLowerCase(),'c:\\program files\\nodejs\\node.exe');assert.ok(!process.env.NODE_OPTIONS&&!process.env.NODE_PATH);return{pid:process.pid,node:process.version,execPath:process.execPath,user:os.userInfo().username,hostname:os.hostname(),root:ROOT};}

const EXPECTED=[
  {
    "path": "candidate-r2/static/visit_record.mjs",
    "bytes": 7525,
    "sha256": "feab129527c2b596cbc64f26c59901dbfb878bf590d3927f1819af4edc1a3b2f",
    "gitBlob": "2b5b37e3d4a227e00a5b0052a962d13512b53e48"
  },
  {
    "path": "candidate-r2/static/week_file.mjs",
    "bytes": 6642,
    "sha256": "914291b97250a97f6e09f47e6fed58b607b3b1ed9e4c60e3242ff39546913614",
    "gitBlob": "420ddb8f63fca264dcf97be7147801105696155d"
  },
  {
    "path": "candidate-r2/static/week_plan.mjs",
    "bytes": 3913,
    "sha256": "e739adc10d9ae9ba1cb82c6d800c453e8f7bec53e343e0685adeabe98e6f4809",
    "gitBlob": "8ed28163e0273c510fdd8e6f7c5d1c8476efb862"
  },
  {
    "path": "candidate-r2/static/visit_record_csv.mjs",
    "bytes": 1646,
    "sha256": "a233a983918291ef93577f91eb64c56adb4644c10cd8f4046e875d4536cc970c",
    "gitBlob": "b001286f411bec6a9088b1902e9455f2fc3540c2"
  },
  {
    "path": "candidate-r2/tests/fixtures/visit-record-csv.json",
    "bytes": 1934,
    "sha256": "ee45bdd3fb7dd31d48094a9752e88be7fc15331cad4e702e29b0eb5626df0624",
    "gitBlob": "69d1c226ab9b7ed25a08f9372a0534d2be00d27f"
  },
  {
    "path": "candidate-r2/docs/visit-record-html/README.md",
    "bytes": 3612,
    "sha256": "46cf2e6fb09b51e0607115c3418bb1ef39b1e5996f2dc01917827adae1c41d64",
    "gitBlob": "c59fe76e6e57ecb87cf6045d01ed1d67e1802f44"
  },
  {
    "path": "candidate-r2/static/visit_record_report.mjs",
    "bytes": 8975,
    "sha256": "228f65b99c6826753e12d79c504bcd8c8d91915b2d4bbc6c78e0881b00cd5e55",
    "gitBlob": "2ccb10513cf9df1461e16f56c22cbbba55c6966a"
  },
  {
    "path": "candidate-r2/tools/visit_record_to_html.mjs",
    "bytes": 6062,
    "sha256": "1ca419d6faa34c9c11a80ae18113f1058ba1bd2447f8fd69547a19d044410e02",
    "gitBlob": "5da2eac3dd7a8aeb3c1deef981245155b39aa3e4"
  },
  {
    "path": "candidate-r2/tests/test_visit_record_report.mjs",
    "bytes": 7747,
    "sha256": "7a3f23995147d1c537a105ee66f939ed9e4759bdf688d83a55263bbe49340b95",
    "gitBlob": "42a899322e7bc12e1d9c8cc2234e2057648d4577"
  },
  {
    "path": "candidate-r2/tests/test_visit_record_to_html.mjs",
    "bytes": 7522,
    "sha256": "7361101622a9ff6c79abbf65995b106886f460bdd588bc511ba4bfdf4bb37e95",
    "gitBlob": "07f4a9b0a41f25976e83a0c2fb6e204794d964f6"
  },
  {
    "path": "reference-baseline-receiving.json",
    "bytes": 11004,
    "sha256": "6e8279aca4de0aa15a66ae93384aa9566d895cd2dd8815ba05a59864fb16aea0",
    "gitBlob": "95dcc475abb03b37121a64806e225c2c4c04f622"
  },
  {
    "path": "original-baseline-receipt.json",
    "bytes": 3391,
    "sha256": "518fe0362ae745ca4853ad76593b9774f2b5126e162b7480ac781873e7cf29c0",
    "gitBlob": "c82ad45f7ef4596f9c754c81301e27c26e99a924"
  },
  {
    "path": "public-contract-r1.json",
    "bytes": 6164,
    "sha256": "137629ad8e711adf55b1b491b1a546bd8a3be9a84573af1c1ae59da09dc35f6c",
    "gitBlob": "86c9c81101df9799065416640cbcd883f0beb43f"
  },
  {
    "path": "blind-reference.json",
    "bytes": 22917,
    "sha256": "5add127a6a05851626b5b7e69604c9390f055d8f0bb1ba1f8712c33f92c6f5d6",
    "gitBlob": "d39576d94d9199fc3868fa89e362c17bbabdac02"
  },
  {
    "path": "baseline/static/visit_record.mjs",
    "bytes": 7525,
    "sha256": "feab129527c2b596cbc64f26c59901dbfb878bf590d3927f1819af4edc1a3b2f",
    "gitBlob": "2b5b37e3d4a227e00a5b0052a962d13512b53e48"
  },
  {
    "path": "baseline/static/week_file.mjs",
    "bytes": 6642,
    "sha256": "914291b97250a97f6e09f47e6fed58b607b3b1ed9e4c60e3242ff39546913614",
    "gitBlob": "420ddb8f63fca264dcf97be7147801105696155d"
  },
  {
    "path": "baseline/static/week_plan.mjs",
    "bytes": 3913,
    "sha256": "e739adc10d9ae9ba1cb82c6d800c453e8f7bec53e343e0685adeabe98e6f4809",
    "gitBlob": "8ed28163e0273c510fdd8e6f7c5d1c8476efb862"
  },
  {
    "path": "fixtures/original-record.json",
    "bytes": 1934,
    "sha256": "ee45bdd3fb7dd31d48094a9752e88be7fc15331cad4e702e29b0eb5626df0624",
    "gitBlob": "69d1c226ab9b7ed25a08f9372a0534d2be00d27f"
  },
  {
    "path": "fixtures/literal-notes-世界.json",
    "bytes": 6744,
    "sha256": "ff26f0b6f09f949279ec2a998a4f66a4bfb8c27d6aaa34fe011e4e9bd13bf900",
    "gitBlob": "93ae95559a4ce38134dd6ae541e7b8828a10b226"
  },
  {
    "path": "fixtures/unknown-empty-BOM.json",
    "bytes": 1409,
    "sha256": "00bed0e900bd5287615469d81a8f52da2a588bd2a3798315391d183460fe0e2d",
    "gitBlob": "958dea692c5fc289cb26a76f2300cfe8a628b877"
  },
  {
    "path": "candidate-manifest-r2.json",
    "bytes": 3656,
    "sha256": "00edfeee6dbda6772a317f62faada8f2a611a55cc54a2659bf1d2c26d7e4ddca",
    "gitBlob": "d9aa51725caaf6a3a13200722f079df251a342aa"
  },
  {
    "path": "visible-separators.mjs",
    "bytes": 7637,
    "sha256": "c5e0de3aa61d98dac205011ac62139512bbb184d23d2bcc91e26e67dc233852c",
    "gitBlob": "34f1db68f56859c4084a39bdc4c54d672a55e6ae"
  },
  {
    "path": "receive-browser-r2.mjs",
    "bytes": 25931,
    "sha256": "eb78a9afac17b81741897a89cc4cd3a79abe56dd6fab41fa0d646acdcbaa7995",
    "gitBlob": "1d1efb71a96887ee406b48171f4830937abec62c"
  },
  {
    "path": "original-receive-browser-r1.mjs",
    "bytes": 22451,
    "sha256": "adebc3cfdd98571fb14c4354763c0c8248d5bdc0689900b19da2681be019026d",
    "gitBlob": "f5782867fab8132c3d81bd0a9b83ac155ed5b9ac"
  },
  {
    "path": "native-receiving-r2.json",
    "bytes": 18807,
    "sha256": "c45b60447992b75d9f1f7d8ca6004985b808d8ae8457ef95cc888b402332e8a7",
    "gitBlob": "bd3ca497076e7a1981e7e1e97ec3a3317cd1b538"
  }
];
const RUNTIMES=[
  {
    "path": "C:\\Program Files\\nodejs\\node.exe",
    "bytes": 91380224,
    "sha256": "63c259c81e5d472b5f11c8d506070130cb04a1ecf84b80377a34ed6ec9048088"
  },
  {
    "path": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "bytes": 4496024,
    "sha256": "977d6483df6c457eab24a3241b44645c66067f52b73bc2c8dbd7e6469bf15d1f"
  },
  {
    "path": "C:\\Program Files\\Google\\Chrome\\Application\\154.0.8037.97\\chrome.dll",
    "bytes": 302382744,
    "sha256": "01cfba363a06b5aee6ccb9a2691062b506bac411e3b80cca54246c691784c241"
  },
  {
    "path": "C:\\Program Files\\Google\\Chrome\\Application\\154.0.8037.98\\chrome.dll",
    "bytes": 302382744,
    "sha256": "ee522fdc3adafa17c48d351e4613d40b61fe98ddbd7de57b3f20a36b43561c5d"
  }
];
const report={format:'taste65-r2-native-browser-staging/1',at:new Date().toISOString(),accepted:false};const started=performance.now();
try{
 report.identity=identity();report.capacity=capacity();
 assert.deepEqual(fs.readdirSync(ROOT).sort(),['run.cjs','stage-payload.json','stage.cjs']);
 report.controllersBefore=['stage.cjs','run.cjs','stage-payload.json'].map(n=>pin(path.join(ROOT,n)));
 report.runtimeBefore=RUNTIMES.map(x=>{const p=pin(x.path);same(p,x);return p;});
 const raw=fs.readFileSync(path.join(ROOT,'stage-payload.json'));assert.ok(raw.length<512*1024);
 const payload=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));
 assert.equal(payload.format,'taste65-r2-browser-staging/1');assert.equal(payload.sourceCommit,'0c7a99ada6c0b53e69d2049e9d2fe823d8f26317');
 assert.deepEqual(payload.files.map(x=>x.path),EXPECTED.map(x=>x.path));
 for(let i=0;i<EXPECTED.length;i++){const f=payload.files[i],e=EXPECTED[i],b=Buffer.from(f.content,'utf8');assert.equal(typeof f.content,'string');assert.ok(!f.path.includes('..')&&!path.isAbsolute(f.path)&&!f.path.includes('\\'));assert.equal(b.length,e.bytes);assert.equal(crypto.createHash('sha256').update(b).digest('hex'),e.sha256);assert.equal(crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex'),e.gitBlob);assert.equal(fs.existsSync(path.join(ROOT,...f.path.split('/'))),false);}
 report.written=[];
 for(let i=0;i<EXPECTED.length;i++){const f=payload.files[i],p=path.join(ROOT,...f.path.split('/'));assert.ok(p.startsWith(ROOT+path.sep));fs.mkdirSync(path.dirname(p),{recursive:true});assert.equal(fs.realpathSync.native(path.dirname(p)).toLowerCase(),path.dirname(p).toLowerCase());fs.writeFileSync(p,f.content,{encoding:'utf8',flag:'wx'});const got=pin(p);same(got,EXPECTED[i]);report.written.push(got);}
 report.controllersAfter=report.controllersBefore.map(x=>pin(x.path));assert.deepEqual(report.controllersAfter,report.controllersBefore);
 report.runtimeAfter=report.runtimeBefore.map(x=>pin(x.path));assert.deepEqual(report.runtimeAfter,report.runtimeBefore);
 report.productExecution=false;report.accepted=true;
}catch(e){report.failure={name:e.name,message:e.message,stack:e.stack};}
report.elapsedMs=performance.now()-started;report.ended=new Date().toISOString();
fs.writeFileSync(path.join(ROOT,'stage-receiving-r2.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({accepted:report.accepted,pid:process.pid,files:report.written?.length,elapsedMs:report.elapsedMs,failure:report.failure}));process.exitCode=report.accepted?0:1;
