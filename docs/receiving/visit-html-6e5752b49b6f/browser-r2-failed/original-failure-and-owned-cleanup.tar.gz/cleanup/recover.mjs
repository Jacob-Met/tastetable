import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {observeOwnedChromeProcess} from './owned-chrome-observer.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url));
const admission=JSON.parse(fs.readFileSync(path.join(ROOT,'admission.json'),'utf8'));
const report={format:'taste65-own-browser-startup-reconciliation/1',at:new Date().toISOString(),scope:'Graceful recovery of the exact owned browser handed off by the failed R2 launcher. No product browser or PDF acceptance.',accepted:false,identity:{pid:process.pid,node:process.version,user:os.userInfo().username,host:os.hostname()},admission};
const started=performance.now();let observer,socket,serial=1;const pending=new Map();
function pin(p){const st=fs.lstatSync(p);assert.ok(st.isFile());const sh=createHash('sha256'),fd=fs.openSync(p,'r'),b=Buffer.alloc(1048576);let n,total=0;try{while((n=fs.readSync(fd,b,0,b.length,null))>0){total+=n;sh.update(b.subarray(0,n));}}finally{fs.closeSync(fd);}return{path:p,bytes:total,sha256:sh.digest('hex'),mtimeMs:st.mtimeMs};}
function cmd(method){return new Promise((resolve,reject)=>{const id=serial++,timer=setTimeout(()=>{pending.delete(id);reject(Error('CDP deadline '+method));},10000);pending.set(id,{resolve,reject,timer,method});try{socket.send(JSON.stringify({id,method}));if(method==='Browser.close')report.closeRequestSent={id,at:new Date().toISOString()};}catch(e){clearTimeout(timer);pending.delete(id);if(method==='Browser.close')report.closeSendError=e.message;reject(e);}});}
async function connect(url){socket=new WebSocket(url);socket.addEventListener('message',e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(JSON.stringify(m.error))):p.resolve(m.result);}});socket.addEventListener('close',()=>{for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('CDP socket closed '+p.method));}pending.clear();});await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('CDP open deadline')),10000);socket.addEventListener('open',()=>{clearTimeout(t);resolve();},{once:true});socket.addEventListener('error',()=>{clearTimeout(t);reject(Error('CDP open error'));},{once:true});});}
try{
 assert.equal(process.version,'v24.14.0');assert.equal(os.userInfo().username,'jacob');assert.equal(os.hostname(),'MSI');
 const helper=pin(path.join(ROOT,'owned-chrome-observer.mjs'));assert.equal(helper.bytes,9286);assert.equal(helper.sha256,'42ee5938f9eaea96b8f494e71c21f624a936b315580a15b33d14bfe19c1bdb8e');
 const ps=pin(admission.PowerShell.path);assert.equal(ps.bytes,admission.PowerShell.bytes);assert.equal(ps.sha256,admission.PowerShell.sha256);
 report.before=[helper,ps,pin(path.join(ROOT,'recover.mjs')),pin(path.join(ROOT,'admission.json'))];
 const active=path.join(admission.Profile,'DevToolsActivePort');report.activePort=pin(active);const [port,endpoint]=fs.readFileSync(active,'utf8').trim().split(/\r?\n/);
 assert.equal(port,'59677');assert.equal(endpoint,'/devtools/browser/aa4add04-abc1-4125-b01f-9cec01382a60');
 observer=await observeOwnedChromeProcess({pid:admission.PID,parentPid:admission.ParentPID,executablePath:admission.Exe,profilePath:admission.Profile,startTimeUtcTicks:admission.StartTimeUtcTicks,waitMs:60000});
 report.observerReady=observer.identity;
 await connect('ws://127.0.0.1:'+port+endpoint);
 report.processInfo=await cmd('SystemInfo.getProcessInfo');const browsers=report.processInfo.processInfo.filter(x=>x.type==='browser');assert.equal(browsers.length,1);assert.equal(browsers[0].id,admission.PID);
 report.browserVersion=await cmd('Browser.getVersion');assert.ok(['Chrome/154.0.8037.97','Chrome/154.0.8037.98'].includes(report.browserVersion.product));
 try{await cmd('Browser.close');report.closeResponse='confirmed';}catch(e){report.closeResponseError=e.message;if(!(report.closeRequestSent&&!report.closeSendError&&e.message==='CDP socket closed Browser.close'))throw e;}
 report.actualBrowserExit=await observer.closed;assert.equal(report.actualBrowserExit.confirmedExit,true);assert.equal(report.actualBrowserExit.exitCode,0);assert.equal(report.actualBrowserExit.observerExitCode,0);assert.equal(report.actualBrowserExit.observerSignal,null);
 assert.ok(report.closeRequestSent&&!report.closeSendError);
 fs.rmSync(admission.Profile,{recursive:true,maxRetries:4,retryDelay:100});report.profileRemoved=!fs.existsSync(admission.Profile);assert.equal(report.profileRemoved,true);
 report.after=report.before.map(x=>pin(x.path));assert.deepEqual(report.after,report.before);report.accepted=true;
}catch(e){report.failure={name:e.name,message:e.message,stack:e.stack,receipt:e.receipt??null};if(e.observerClosed){try{report.failedObserver=await e.observerClosed;}catch(f){report.failedObserver={message:f.message,receipt:f.receipt??null};}}}
finally{socket?.close();for(const p of pending.values())clearTimeout(p.timer);pending.clear();if(observer&&!report.actualBrowserExit){try{report.actualBrowserExit=await observer.closed;}catch(e){report.unconfirmedBrowserExit={message:e.message,receipt:e.receipt??null};}}report.elapsedMs=performance.now()-started;report.ended=new Date().toISOString();fs.writeFileSync(path.join(ROOT,'receiving.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({accepted:report.accepted,pid:process.pid,actualBrowserPID:report.admission.PID,browserExit:report.actualBrowserExit?.exitCode,observerExit:report.actualBrowserExit?.observerExitCode,profileRemoved:report.profileRemoved,elapsedMs:report.elapsedMs,failure:report.failure}));process.exitCode=report.accepted?0:1;}
