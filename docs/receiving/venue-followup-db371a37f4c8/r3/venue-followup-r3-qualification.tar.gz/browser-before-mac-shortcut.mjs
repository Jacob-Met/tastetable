// Independent Save/Open → visit-only worksheet receiving. The CDP transport
// follows our already-qualified ShadeWindow receiver. API responses here are
// explicitly recorded fixtures; this is not a FastAPI or provider qualification.
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const sourceRoot = path.resolve(process.argv[2] ?? path.join(here, 'proposed'));
const ownedRoot = path.resolve(process.env.TASTETABLE_RECEIVING_ROOT ?? here);
const evidence = path.join(ownedRoot, 'browser-evidence');
const downloads = path.join(evidence, 'downloads');
const browserPath = process.env.TASTETABLE_CHROMIUM ?? '/snap/bin/chromium';
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
await fs.mkdir(downloads, { recursive: true });
await fs.mkdir(path.join(ownedRoot, 'profiles'), { recursive: true });
const fixtureBytes = await fs.readFile(path.join(here, 'fixture.json'));
const fixture = JSON.parse(fixtureBytes);
const manifest = JSON.parse(await fs.readFile(path.join(sourceRoot, 'source-manifest.json')));
async function pinSources() {
  return Promise.all(manifest.files.map(async item => {
    const bytes = await fs.readFile(path.join(sourceRoot, item.path));
    assert.equal(hash(bytes), item.sha256, `Exact source pin: ${item.path}`);
    return { path: item.path, bytes: bytes.length, sha256: hash(bytes) };
  }));
}
const before = await pinSources();
const checks = [], served = [], api = [], network = [], networkFailures = [], exceptions = [], events = [], artifacts = [], inputWitnesses = [];
let browser, socket, nextId = 0, profile, capacityGuard, lowSpace = false, version, failure;
let exit = null, serverRunning = false, activeSession;
const pending = new Map();
const started = new Date().toISOString();
const persona = { id: 'receiving-rosa', label: 'Recorded Rosa fixture', cuisines: ['Cuban', 'Mexican'],
  music: ['Celia Cruz'], films: ['West Side Story'], city: 'Pasadena',
  constraints: ['soft_foods', 'low_sodium', 'wheelchair'] };
const types = { '.html': 'text/html', '.mjs': 'text/javascript', '.js': 'text/javascript', '.css': 'text/css' };
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      let body = ''; for await (const chunk of req) body += chunk;
      api.push({ method: req.method, path: url.pathname, body });
      const value = url.pathname === '/api/health' ? { qloo_mode: 'mock' }
        : url.pathname === '/api/personas' ? [persona]
        : req.method === 'POST' && url.pathname.startsWith('/api/plan') ? fixture : null;
      if (!value) throw new Error('Unrecognized isolated API route');
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      res.end(JSON.stringify(value)); return;
    }
    const relative = url.pathname === '/' ? 'static/index.html' : decodeURIComponent(url.pathname).slice(1);
    const filename = path.resolve(sourceRoot, relative);
    if (!filename.startsWith(sourceRoot + path.sep)) throw new Error('Outside source');
    const bytes = await fs.readFile(filename);
    served.push({ path: relative, sha256: hash(bytes), bytes: bytes.length, probe: req.headers['x-receiving-probe'] === 'native-node' });
    res.writeHead(200, { 'content-type': types[path.extname(filename)] ?? 'application/octet-stream', 'cache-control': 'no-store' });
    res.end(bytes);
  } catch { res.writeHead(404); res.end('Unavailable in isolated receiving'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
serverRunning = true;
const appUrl = `http://127.0.0.1:${server.address().port}/`;
let pageProbe;

function send(method, params = {}, sessionId) {
  const id = ++nextId;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { pending.delete(id); reject(new Error(`CDP timeout: ${method}`)); }, method === 'Page.navigate' ? 45000 : 15000);
    pending.set(id, { resolve, reject, timer });
    socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
  });
}
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }, activeSession);
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
  return result.result.value;
}
async function waitFor(predicate, label) {
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) { if (lowSpace) throw new Error('Owned browser stopped at the 256 MiB capacity floor'); if (await predicate()) return; await delay(70); }
  throw new Error(`Expected state not reached: ${label}`);
}
async function click(selector) {
  await evaluate(`(() => {
    const e = document.querySelector(${JSON.stringify(selector)});
    if (!e || e.disabled) throw new Error('Missing or disabled control');
    e.scrollIntoView({block:'center',behavior:'instant'});
  })()`);
  // The app scrolls newly opened results smoothly, and print-media restoration
  // changes layout. Verify the actual target has stopped moving before one
  // native click; do not invoke its handler or retry a missed click silently.
  let point, previous;
  await waitFor(async () => {
    const current = await evaluate(`(() => {
      const e=document.querySelector(${JSON.stringify(selector)});
      if(!e||e.disabled)throw new Error('Missing or disabled control');
      const r=e.getBoundingClientRect(),x=r.x+r.width/2,y=r.y+r.height/2;
      const hit=document.elementFromPoint(x,y);
      return {x,y,hit:Boolean(hit&&(hit===e||e.contains(hit))),target:hit?.id??hit?.tagName??null};
    })()`);
    const ready=current.hit&&previous?.x===current.x&&previous?.y===current.y;
    previous=current; if(ready)point={x:current.x,y:current.y}; return ready;
  }, `stable visible click target ${selector}`);
  inputWitnesses.push({selector,...previous});
  await send('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, ...point }, activeSession);
  await send('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, ...point }, activeSession);
}
async function edit(selector, value, type = 'input') {
  await evaluate(`(() => {const e=document.querySelector(${JSON.stringify(selector)}); if(!e)throw new Error('Missing edit control'); e.value=${JSON.stringify(value)};e.dispatchEvent(new Event(${JSON.stringify(type)},{bubbles:true}));})()`);
}
async function state() {
  return evaluate(`(() => ({
    hidden:document.querySelector('#results').hidden,
    worksheetHidden:document.querySelector('#venueFollowup').hidden,
    listHidden:document.querySelector('[data-contact-list]').hidden,
    saveDisabled:document.querySelector('#saveWeek').disabled,
    printDisabled:document.querySelector('#printWeek').disabled,
    downloadDisabled:document.querySelector('[data-contact-download]').disabled,
    date:document.querySelector('#weekDate').value,
    assignments:Object.fromEntries([...document.querySelectorAll('select[data-pick-key]')].map(e=>[e.dataset.pickKey,e.value||null])),
    visits:[...document.querySelectorAll('[data-contact-key]')].map(e=>({key:e.dataset.contactKey,date:e.dataset.contactDate,
      question:e.querySelector('[data-contact-field="question"]').value,
      earlierQuestions:e.querySelector('[data-contact-reply-questions]').textContent,
      earlierHidden:e.querySelector('[data-contact-earlier]').hidden,
      reply:e.querySelector('[data-contact-field="reply"]').value,
      status:e.querySelector('[data-contact-field="status"]').value,
      printReply:e.querySelector('[data-contact-print="reply"]').textContent,
      why:e.querySelector('.contact-explanation').textContent})),
    worksheetStatus:document.querySelector('[data-contact-status]').textContent,
    worksheetSource:document.querySelector('[data-contact-source]').textContent,
    original:document.querySelector('#plan').innerHTML,
    savedSource:document.querySelector('#savedWeekSource').textContent,
    request:document.querySelector('#requestStatus').textContent,
    injected:window.__worksheetExecuted??false,
    activeImages:document.querySelectorAll('#venueFollowup img').length,
    stored:localStorage.length+sessionStorage.length
  }))()`);
}
function check(description, details = {}) { checks.push({ description, passed:true, ...details }); console.log(`PASS ${description}`); }
async function download(selector) {
  const previous = new Set(await fs.readdir(downloads));
  const count = events.filter(e => e.method === 'Browser.downloadWillBegin').length;
  await click(selector);
  await waitFor(() => events.filter(e => e.method === 'Browser.downloadWillBegin').length === count + 1, 'one download begins');
  const event = events.filter(e => e.method === 'Browser.downloadWillBegin').at(-1).params;
  await waitFor(() => events.some(e => e.params.guid === event.guid && e.params.state === 'completed'), 'actual file completes');
  const names = (await fs.readdir(downloads)).filter(name => !previous.has(name) && !name.endsWith('.crdownload'));
  assert.equal(names.length, 1);
  const filename = path.join(downloads, names[0]), bytes = await fs.readFile(filename);
  const item = { filename, suggestedFilename: event.suggestedFilename, bytes: bytes.length, sha256: hash(bytes) };
  artifacts.push(item); return { ...item, content: bytes.toString('utf8') };
}
async function openFile(filename, hold = false) {
  await evaluate(`window.__holdReads=${hold}`);
  const count = events.filter(e => e.method === 'Page.fileChooserOpened').length;
  await click('#openWeek');
  await waitFor(() => events.filter(e => e.method === 'Page.fileChooserOpened').length === count + 1, 'actual Open button file chooser');
  const chooser = events.filter(e => e.method === 'Page.fileChooserOpened').at(-1).params;
  await send('DOM.setFileInputFiles', { files: [filename], backendNodeId: chooser.backendNodeId }, activeSession);
  if (hold) await waitFor(() => evaluate('window.__heldReads.length===1'), 'underlying actual file read held');
}
async function releaseFile() {
  await evaluate('window.__holdReads=false;window.__heldReads.splice(0).forEach(release=>release());void 0');
  await waitFor(() => evaluate('window.__inFlightReads===0'), 'actual file read settles');
  await evaluate('new Promise(resolve=>setTimeout(resolve,0))');
}
const note = 'Receiving α <img src=x onerror="window.__worksheetExecuted=true"> & literal reply';
const first = '[data-contact-key="pick-0"]';

try {
  const response = await fetch(appUrl, { headers: { 'x-receiving-probe': 'native-node' }, signal: AbortSignal.timeout(5000) });
  const pageBytes = Buffer.from(await response.arrayBuffer());
  assert.equal(response.status, 200);
  assert.equal(hash(pageBytes), before.find(item => item.path === 'static/index.html').sha256);
  pageProbe = { status: response.status, bytes: pageBytes.length, sha256: hash(pageBytes) };
  const capacity = await fs.statfs(ownedRoot);
  assert.ok(capacity.bavail * capacity.bsize >= 256 * 1024 * 1024, '256 MiB capacity floor before Chromium');
  version = execFileSync(browserPath, ['--version'], { encoding: 'utf8', timeout: 45000 }).trim();
  profile = await fs.mkdtemp(path.join(ownedRoot, 'profiles', 'venue-seam-'));
  browser = spawn(browserPath, ['--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--disable-background-networking', '--disable-component-update', '--disable-sync', '--disable-extensions',
    '--disk-cache-size=1048576', '--media-cache-size=1048576', '--password-store=basic',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', `--user-data-dir=${profile}`, 'about:blank'],
  { stdio: ['ignore', 'ignore', 'pipe'], detached: true });
  browser.once('exit', (code, signal) => { exit = { code, signal }; });
  capacityGuard = setInterval(async () => {
    const s = await fs.statfs(ownedRoot);
    if (s.bavail * s.bsize < 256 * 1024 * 1024) { lowSpace = true; try { process.kill(-browser.pid, 'SIGTERM'); } catch {} }
  }, 2000);
  const endpoint = await new Promise((resolve, reject) => {
    let stderr = '';
    const timer = setTimeout(() => reject(new Error(`Chromium startup: ${stderr.slice(-2000)}`)), 45000);
    browser.once('error', error => { clearTimeout(timer); reject(error); });
    browser.once('exit', code => { clearTimeout(timer); reject(new Error(`Chromium exited before connection: ${code}`)); });
    browser.stderr.on('data', bytes => { stderr += bytes.toString();
      void fs.writeFile(path.join(evidence, 'chromium.log'), stderr);
      const match = stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);
      if (match) { clearTimeout(timer); resolve(match[1]); }
    });
  });
  socket = new WebSocket(endpoint);
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
  socket.addEventListener('message', event => {
    const message = JSON.parse(event.data);
    if (message.id && pending.has(message.id)) { const p=pending.get(message.id); pending.delete(message.id); clearTimeout(p.timer);
      if(message.error)p.reject(new Error(JSON.stringify(message.error)));else p.resolve(message.result); }
    if (message.method === 'Runtime.exceptionThrown') exceptions.push(message.params.exceptionDetails);
    if (message.method === 'Network.requestWillBeSent') network.push(message.params.request.url);
    if (message.method === 'Network.loadingFailed') networkFailures.push(message.params);
    if (message.method?.startsWith('Browser.download') || message.method === 'Page.fileChooserOpened') events.push(message);
  });
  await send('Browser.setDownloadBehavior', { behavior: 'allow', downloadPath: downloads, eventsEnabled: true });
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  ({ sessionId: activeSession } = await send('Target.attachToTarget', { targetId, flatten: true }));
  for (const domain of ['Runtime', 'Page', 'Network']) await send(`${domain}.enable`, {}, activeSession);
  await send('Page.setInterceptFileChooserDialog', { enabled: true }, activeSession);
  await send('Emulation.setDeviceMetricsOverride', { width: 1280, height: 960, deviceScaleFactor: 1, mobile: false }, activeSession);
  await send('Page.navigate', { url: appUrl }, activeSession);
  await waitFor(() => evaluate('Boolean(document.querySelector("#sampleBtn")&&!document.querySelector("#sampleBtn").disabled)'), 'fixture persona available');
  // This timing hook delays the real File.text() only when requested. It does
  // not invent file contents, alter product modules, or replace request handlers.
  await evaluate(`(() => {const real=File.prototype.text;window.__holdReads=false;window.__heldReads=[];window.__inFlightReads=0;
    File.prototype.text=function(){const file=this;if(!window.__holdReads)return real.call(file);window.__inFlightReads++;
      return new Promise((resolve,reject)=>window.__heldReads.push(()=>real.call(file).then(resolve,reject).finally(()=>window.__inFlightReads--)));};})()`);
  async function typeText(selector, value) {
    await click(selector);
    await send('Input.dispatchKeyEvent', {type:'rawKeyDown',key:'a',code:'KeyA',windowsVirtualKeyCode:65,modifiers:2}, activeSession);
    await send('Input.dispatchKeyEvent', {type:'keyUp',key:'a',code:'KeyA',windowsVirtualKeyCode:65,modifiers:2}, activeSession);
    await send('Input.dispatchKeyEvent', {type:'rawKeyDown',key:'Backspace',code:'Backspace',windowsVirtualKeyCode:8}, activeSession);
    await send('Input.dispatchKeyEvent', {type:'keyUp',key:'Backspace',code:'Backspace',windowsVirtualKeyCode:8}, activeSession);
    if (value) await send('Input.insertText', {text:value}, activeSession);
    assert.equal(await evaluate('document.querySelector('+JSON.stringify(selector)+').value'), value);
  }
  async function question(value) {
    const isOpen=await evaluate('document.querySelector('+JSON.stringify(first+' .contact-question-editor')+').open');
    if(!isOpen) await click(first+' .contact-question-editor summary');
    await typeText(first+' [data-contact-field="question"]',value);
  }
  function softCheck(description, passed, details) {
    checks.push({description,passed,...details}); console.log((passed?'PASS ':'FAIL ')+description);
  }
  async function capture(name) {
    const clip=await evaluate("(() => {const e=document.querySelector('#venueFollowup');e.scrollIntoView({block:'start',behavior:'instant'});const r=e.getBoundingClientRect();return{x:r.x,y:r.y+scrollY,width:r.width,height:Math.min(r.height,1500),scale:1};})()");
    const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip},activeSession);
    const bytes=Buffer.from(shot.data,'base64');await fs.writeFile(path.join(evidence,name),bytes);
    artifacts.push({filename:path.join(evidence,name),bytes:bytes.length,sha256:hash(bytes)});
  }
  await click('#sampleBtn');
  await waitFor(async()=>!(await state()).hidden,'actual application accepts recorded response');
  await edit('#weekDate','2026-12-28');
  const unchangedPlan=(await state()).original;
  const a='\nCan we enter through the north door? <img src=x onerror="window.__worksheetExecuted=true">\nPlease confirm opening hours.';
  const b='\nCan we enter through the side door after 6pm? <script>literal question</script>\nPlease describe the route.';
  const reply='The caregiver recorded an answer about the north door.\nThat answer has not been updated.';
  await question(a);
  await typeText(first+' [data-contact-field="reply"]',reply);
  await edit(first+' [data-contact-field="status"]','reply_recorded','change');
  await question(b);
  let s=await state(),visit=s.visits.find(v=>v.key==='pick-0');
  assert.equal(visit.question,b);assert.equal(visit.reply,reply);assert.equal(visit.earlierQuestions,a);
  assert.equal(visit.status,'follow_up');assert.equal(visit.earlierHidden,false);
  assert.equal(s.original,unchangedPlan);assert.equal(s.injected,false);assert.equal(s.activeImages,0);
  await edit(first+' [data-contact-field="status"]','reply_recorded','change');
  s=await state();visit=s.visits.find(v=>v.key==='pick-0');
  assert.equal(visit.status,'follow_up');assert.equal(visit.reply,reply);assert.equal(visit.earlierQuestions,a);
  assert.match(s.worksheetStatus,/Update the reply for the revised questions/);
  const revised=await download('[data-contact-download]');
  for(const literal of [a.split('\n')[1],b.split('\n')[1],reply.split('\n')[0],fixture.plan.meals[0].why])assert.ok(revised.content.includes(literal));
  assert.match(revised.content,/Earlier reply \/ notes \(for the previous questions\)/);
  assert.match(revised.content,/not a safety check, reservation or confirmation by TasteTable/);
  await send('Emulation.setEmulatedMedia',{media:'print'},activeSession);
  const printable=await evaluate("(() => {const e=document.querySelector('[data-contact-key=\"pick-0\"]');return{edit:getComputedStyle(e.querySelector('.contact-edit')).display,old:getComputedStyle(e.querySelector('[data-contact-earlier]')).display,reply:e.querySelector('[data-contact-print=\"reply\"]').textContent};})()");
  assert.equal(printable.edit,'none');assert.notEqual(printable.old,'none');assert.equal(printable.reply,reply);
  await capture('revised-question-print.png');
  await send('Emulation.setEmulatedMedia',{media:''},activeSession);
  check('Native edited questions retain the earlier reply and literal question context; stale Reply recorded status is refused in UI, print and actual call-sheet export');

  await edit('select[data-pick-key="pick-0"]','Thursday','change');
  s=await state();visit=s.visits.find(v=>v.key==='pick-0');assert.equal(visit.date,'2026-12-31');assert.equal(visit.reply,'');assert.notEqual(visit.question,b);
  await edit('select[data-pick-key="pick-0"]','Monday','change');
  s=await state();visit=s.visits.find(v=>v.key==='pick-0');assert.equal(visit.question,b);assert.equal(visit.reply,reply);assert.equal(visit.earlierQuestions,a);
  await edit('#weekDate','2027-01-04');
  assert.equal((await state()).visits.find(v=>v.key==='pick-0').reply,'');
  await edit('#weekDate','2026-12-28');
  s=await state();visit=s.visits.find(v=>v.key==='pick-0');assert.equal(visit.question,b);assert.equal(visit.reply,reply);assert.equal(visit.earlierQuestions,a);assert.equal(s.original,unchangedPlan);
  assert.equal(await evaluate('document.querySelector('+JSON.stringify(first+' [data-contact-field="question"]')+').value'),b);
  check('Moving and changing weeks separates the revised question/reply pair; returning restores exact leading-newline editor values and earlier context');

  const saved=await download('#saveWeek'),envelope=JSON.parse(saved.content);
  assert.equal(envelope.format,'tastetable.saved-week.v1');assert.deepEqual(envelope.response,fixture);
  assert.equal(saved.content.includes('north door'),false);assert.equal(saved.content.includes('side door'),false);
  const posts=api.filter(x=>x.method==='POST').length;
  await openFile(saved.filename);
  await waitFor(async()=>(await state()).request.startsWith('Saved week opened'),'actual saved file accepted');
  s=await state();visit=s.visits.find(v=>v.key==='pick-0');
  assert.equal(visit.reply,'');assert.notEqual(visit.question,b);assert.equal(visit.earlierHidden,true);
  assert.match(s.worksheetSource,/have not been run again/);assert.ok(s.worksheetSource.includes(saved.suggestedFilename));
  assert.equal(api.filter(x=>x.method==='POST').length,posts);assert.equal(s.original,unchangedPlan);
  const savedSheet=await download('[data-contact-download]');
  assert.ok(savedSheet.content.includes(s.worksheetSource));assert.ok(savedSheet.content.includes(saved.suggestedFilename));
  check('Actual Save/Open retires edited questions and replies and carries the exact saved-source filename and unchanged-check notice into the new worksheet and real download');

  await edit(first+' [data-contact-field="status"]','reply_recorded','change');
  s=await state();visit=s.visits.find(v=>v.key==='pick-0');
  assert.equal(visit.reply,'');assert.equal(visit.status,'reply_recorded');
  const blankSheet=await download('[data-contact-download]');
  softCheck('Manual Reply recorded status has noncontradictory blank-detail wording in print and downloaded handoff',
    visit.printReply==='No reply details entered.'&&blankSheet.content.includes('No reply details entered.')&&!blankSheet.content.includes('No reply recorded.'),
    {observedPrintReply:visit.printReply,download:blankSheet.sha256,manualStatus:visit.status});

  const beforeFailure=await state();
  await evaluate("window.__originalURLcreate=URL.createObjectURL;window.__failNextBlob=true;URL.createObjectURL=function(blob){if(window.__failNextBlob){window.__failNextBlob=false;throw new Error('Receiver injected Blob setup failure');}return window.__originalURLcreate.call(URL,blob);};void 0");
  await click('[data-contact-download]');
  s=await state();assert.match(s.worksheetStatus,/Receiver injected Blob setup failure/);
  assert.deepEqual(s.visits,beforeFailure.visits);assert.equal(s.original,beforeFailure.original);
  const enabledImmediately=!s.downloadDisabled;
  await typeText(first+' [data-contact-field="nextStep"]','Retry the current call sheet without changing the schedule.');
  s=await state();
  const enabledAfterEdit=!s.downloadDisabled;
  let retry=null;
  if(enabledAfterEdit){retry=await download('[data-contact-download]');assert.ok(retry.content.includes('Retry the current call sheet without changing the schedule.'));}
  softCheck('A transient Blob setup failure preserves the eligible worksheet and permits a direct real-download retry',
    enabledImmediately&&enabledAfterEdit&&Boolean(retry),
    {enabledImmediately,enabledAfterOrdinaryEdit:enabledAfterEdit,retry:retry?.sha256??null,scope:'Injected one synchronous Blob URL setup exception; product handlers and remaining download path are unchanged'});
  await evaluate('URL.createObjectURL=window.__originalURLcreate;delete window.__originalURLcreate;void 0');

  await edit('#weekDate','');
  s=await state();assert.equal(s.downloadDisabled,true);assert.equal(s.listHidden,true);
  await edit('#weekDate','2026-12-28');
  s=await state();assert.equal(s.downloadDisabled,false);assert.equal(s.listHidden,false);
  await question(a);await typeText(first+' [data-contact-field="reply"]',reply);await question(b);
  await click(first+' .contact-question-editor summary');
  await capture('r3-desktop.png');
  await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:false},activeSession);
  await question('Question with a long literal token: '+('Q'.repeat(700)));
  await click(first+' .contact-question-editor summary');
  const width=await evaluate('({scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth})');
  assert.ok(width.scroll<=width.client,'No horizontal document overflow at 390 CSS pixels');
  await capture('r3-phone.png');
  assert.equal((await state()).stored,0);assert.equal(exceptions.length,0);
  assert.ok(network.every(url=>url.startsWith(appUrl)||url.startsWith('blob:'+appUrl)||url.startsWith('data:image/svg+xml;base64,')));
  for(const item of before)assert.ok(served.some(x=>!x.probe&&x.path===item.path&&x.sha256===item.sha256),'Actual browser received '+item.path);
  check('Invalid-date refusal and recovery still work; native question editing and earlier-reply context remain readable at 390 pixels with no automatic storage or external HTTP');
  const failed=checks.filter(x=>x.passed===false);
  if(failed.length)throw new Error(failed.length+' concrete receiving contract(s) failed; see recorded observations');
} catch (error) {
  failure = { message: error.message, stack: error.stack };
  if (activeSession) try { failure.state = await state(); } catch {}
  console.error(error.stack);
} finally {
  clearInterval(capacityGuard);
  if (socket?.readyState === WebSocket.OPEN) await send('Browser.close').catch(() => {});
  if (browser && !exit) await Promise.race([new Promise(resolve => browser.once('exit', resolve)), delay(25000)]);
  if (browser && !exit) try { process.kill(-browser.pid, 'SIGTERM'); } catch {}
  if (browser && !exit) await Promise.race([new Promise(resolve => browser.once('exit', resolve)), delay(2000)]);
  if (browser && !exit) try { process.kill(-browser.pid, 'SIGKILL'); } catch {}
  if (browser && !exit) await Promise.race([new Promise(resolve => browser.once('exit', resolve)), delay(2000)]);
  socket?.close(); for (const p of pending.values()) { clearTimeout(p.timer); p.reject(new Error('Receiver closed')); } pending.clear();
  if (serverRunning) { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); serverRunning=false; }
  if (profile && exit) await fs.rm(profile, { recursive: true, force: true });
  const after = await pinSources(); assert.deepEqual(after, before);
  const receipt = { started, finished: new Date().toISOString(), node: process.version, browser: version,
    sourceRoot, appUrl, scope: 'Independent changed-contract receiving of owner r3 editable questions and saved-source binding, plus a two-fix proposal. HTTP API is the recorded canonical mock response, not FastAPI/provider receiving. No author test source was used.',
    inputMechanism: 'Native CDP mouse clicks, keyboard selection/deletion and text insertion for question/reply/next-step editors, plus a real disk-file chooser. Date and select controls use declared DOM input/change events. One explicit Blob URL setup fault tests eligible retry. The inherited File.text timing hook is inactive in this receiver.',
    fixture: { bytes: fixtureBytes.length, sha256: hash(fixtureBytes) }, before, after, pageProbe, checks, served, api, network, networkFailures,
    exceptions, artifacts, inputWitnesses, lowSpace, failure, cleanup: { browserPid: browser?.pid, exit, serverClosed: !serverRunning, profileRemoved: Boolean(profile && exit) } };
  await fs.writeFile(path.join(evidence, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
}
if (failure) process.exitCode = 1;
