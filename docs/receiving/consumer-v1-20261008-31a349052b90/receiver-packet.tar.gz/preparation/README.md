# Prepared TasteTable composed late-render receiver

**Status: prepared; no combined frontend has been executed or accepted.** The browser carrier is syntax-checked. Three actual published-module/fixture preflight checks pass on Node 24.19.0. The unresolved owner-pin template was deliberately refused before browser startup.

## Ownership and recovered authority

The existing organizer/composition owner remains universal-0df473646168. Their [issue #4 acknowledgment](https://github.com/Jacob-Met/tastetable/issues/4#issuecomment-6056696310) explicitly adopts the staged-render supplement while composing the calendar and lifecycle handoffs. Current recovery found no new composition among all 14 published branch refs; open PRs remain #10 (calendar producer), #8 (backend receiving), and #7 (lifecycle). The readable composer snapshot also remains the original organizer. A frozen combined app pin and its actual download selector are still required.

The calendar owner's prepared 14-history browser carrier deliberately leaves the broader malformed-response suite to this reviewer. This receiver supplies that complementary boundary. It contains no replacement app, DOM shell, organizer implementation, lifecycle controller or exporter.

The three files under `published/static/` are exact GitHub source copies:

| Module | Commit | SHA256 |
| --- | --- | --- |
| Calendar | PR #10, `674e67aa7cc5c1d7618da9cc9ba3047ebca73206` | `09dfe98a95da6c7fd0b7ee531c3ec4cf9ae5697dc730fab6cffdd07d8bd94b3b` |
| Lifecycle | PR #7, `981118bbc2c7a2173e56ac1c26da754803b40b22` | `b35d09ca6270cf6150bcc40501d2d6a6728aa592597bb8d3e49aa3ae26cdf995` |
| Week state | Main `9f9105c29ab1a68a501b5f4c0b7180f0db968d38` | `e739adc10d9ae9ba1cb82c6d800c453e8f7bec53e343e0685adeabe98e6f4809` |

`published-modules.json` also records their exact Git blob identities.

## Authored cases and preflight

`fixtures.cjs` produces eight explicitly authored response histories: null plan notes, null trace, constraints as a string or array-like object, null comparison-baseline meals or outing, string affinity, and null rejected-constraint details. Stable responses have seven meal occurrences and one outing, including two distinct occurrences sharing an entity ID. Recovery alternates a two-meal-only plan and an outing-only plan. No native backend or provider output is claimed.

The three preflight checks exercise actual published modules:

1. An arranged week exports seven events after one omission, preserving separate occurrence keys for duplicate entity IDs. The selected week spans the year boundary and four suggestions share Thursday.
2. Only the malformed-notes fixture is refused by the calendar writer itself. The other seven malformed renderer inputs can pass the producer's own data requirements, so producer acceptance cannot substitute for the pending renderer check.
3. The actual lifecycle controller fences an older non-cooperative authored result after a newer one is accepted, and routes a deliberate receiving-callback exception to its error callback. This is a module/callback check. Consumer DOM and export-session retirement are not represented as tested here.

`preflight-output/` retains the authored fixture bundle, the actual generated calendar, occurrence/UID receipt, fixture-boundary observations and lifecycle callback history. `preflight.log` is the unmodified Node output. `preparation-receipt.json` distinguishes these passing checks from the unexecuted browser carrier.

To repeat only the producer/fixture preflight, select a new output directory:

```sh
TASTE_RECEIVING_OUTPUT=/new/writable/preflight-output node --test preflight.test.cjs
```

## Pending actual browser history

`review-composed-late-render.cjs` will serve the owner's static files unchanged and fulfill actual browser HTTP requests with the authored cases. It does not patch fetch, Response.json, application globals, event handlers or any module. Requests outside the isolated loopback origin are blocked and fail receiving.

For each malformed case, the carrier accepts a stable source, moves two meal occurrences plus the outing onto Thursday, omits a pick, retains the chosen week, and reads an actual downloaded calendar. It then submits the malformed replacement and requires retired results plus disabled print/export, a visible failure status and preserved week preference. A fresh valid partial response must restore editable results with fresh occurrence assignments and a new export session. A local move and reset must preserve that new session's UIDs and cause no plan request. Downloaded event dates, names, source IDs, explanations, occurrence keys and tentative status are compared to the visible week and authored source.

This complements the calendar/lifecycle owners' broader arrangement, invalid-date, cancellation and held-response histories. Those carriers remain theirs. The original organizer and late-render runners also remain unchanged; their checked hashes are in the preparation receipt.

## Required owner pin

Copy `owner-pin.example.json` to a new file and populate the real owner commit, every static file's SHA256, and the actual calendar download selector after source review. The current template intentionally contains nulls. Every static source file must be pinned, and the three producer hashes must match the published handoffs. A changed producer requires an explicit receiving decision before updating this carrier.

Check the pin without starting a browser:

```sh
node review-composed-late-render.cjs --root /frozen/owner/source --pin /resolved/owner-pin.json --check-pin
```

Then run against an existing Chromium and Playwright installation:

```sh
node review-composed-late-render.cjs \
  --root /frozen/owner/source \
  --pin /resolved/owner-pin.json \
  --output /new/writable/browser-output \
  --chromium /absolute/existing/chromium \
  --playwright /absolute/existing/playwright-package
```

The output directory must be new and outside product source. Source selectors and rejection expectations require final review against the actual composition before the first browser run. This preparation is not combined UI, calendar import, deployment or provider qualification.
