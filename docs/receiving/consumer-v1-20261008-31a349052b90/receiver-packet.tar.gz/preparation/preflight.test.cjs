"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { pathToFileURL } = require("node:url");
const { fixture, cases, personas } = require("./fixtures.cjs");
const root = __dirname;
const output = process.env.TASTE_RECEIVING_OUTPUT;
assert.ok(output, "Set TASTE_RECEIVING_OUTPUT to a new writable output directory");
fs.mkdirSync(output, { recursive: false });
const pins = JSON.parse(fs.readFileSync(path.join(root, "published-modules.json"), "utf8"));
for (const item of pins.files) {
  const data = fs.readFileSync(path.join(root, "published", item.path));
  assert.equal(crypto.createHash("sha256").update(data).digest("hex"), item.sha256, item.path);
}
const calendar = require("./published/static/calendar.js");
const lifecycle = require("./published/static/plan-request.js");
const weekPromise = import(pathToFileURL(path.join(root, "published/static/week_plan.mjs")));
const dataset = { origin: "authored test responses; no backend or provider execution", personas, cases: cases() };
fs.writeFileSync(path.join(output, "authored-fixtures.json"), JSON.stringify(dataset, null, 2) + "\n");
const metadata = { id: "0123456789abcdef0123456789abcdef", createdAt: new Date("2026-10-08T12:00:00Z") };
const parseEvents = text => [...text.replace(/\r\n[ \t]/g, "").matchAll(/BEGIN:VEVENT\r\n([\s\S]*?)\r\nEND:VEVENT/g)].map(m => m[1]);
test("authored arrangements produce seven real calendar occurrences with distinct duplicate-entity keys", async () => {
  const week = await weekPromise;
  const original = week.createWeekPlan(dataset.cases[0].stable, "2026-12-30");
  let edited = original;
  for (const key of ["pick-0", "pick-2", "pick-7"]) edited = week.setPickDay(edited, key, "Thursday");
  edited = week.setPickDay(edited, "pick-1", null);
  const exporter = calendar.createWeekExport(original, metadata);
  const items = exporter.preview(edited, week.weekRows(edited));
  assert.equal(items.length, 7);
  assert.deepEqual(items.filter(p => p.day === "Thursday").map(p => p.key).sort(), ["pick-0", "pick-2", "pick-3", "pick-7"]);
  assert.equal(items.find(p => p.key === "pick-0").entityId, items.find(p => p.key === "pick-2").entityId);
  const file = exporter.download(edited, week.weekRows(edited));
  const events = parseEvents(file.text);
  assert.equal(events.length, 7);
  const uids = events.map(e => /^UID:(.+)$/m.exec(e)[1]);
  assert.equal(new Set(uids).size, 7);
  assert.ok(events.filter(e => e.includes("DTSTART;VALUE=DATE:20261231")).length === 4);
  assert.ok(uids.every(id => id.includes("-20261228-pick-")));
  fs.writeFileSync(path.join(output, "fixture-arranged-week.ics"), file.text);
  fs.writeFileSync(path.join(output, "fixture-calendar-receipt.json"), JSON.stringify({ sourcePins: pins, items, uids, sourceUnchanged: JSON.stringify(original.sourcePlan) === JSON.stringify(dataset.cases[0].stable.plan) }, null, 2) + "\n");
});
test("late-render fixtures remain distinct from the calendar writer's own validation", async () => {
  const week = await weekPromise;
  const result = [];
  for (const item of dataset.cases) {
    let calendarError = null;
    try {
      const state = week.createWeekPlan(item.malformed, "2026-12-30");
      const exporter = calendar.createWeekExport(state, metadata);
      exporter.download(state, week.weekRows(state));
    } catch (error) { calendarError = error.message; }
    assert.equal(Boolean(calendarError), item.field === "plan.notes = null", item.field);
    result.push({ field: item.field, calendarError, applicationRenderNotExecuted: true });
  }
  fs.writeFileSync(path.join(output, "fixture-boundaries.json"), JSON.stringify(result, null, 2) + "\n");
});
test("published lifecycle fences a late authored result and reports a receiving callback failure", async () => {
  const week = await weekPromise;
  const pending = [];
  const events = [];
  let accepted = null;
  const controller = lifecycle.create({
    send: (_url, _body, signal) => new Promise(resolve => pending.push({ resolve, signal })),
    onStart: () => events.push("start"),
    onResult: data => {
      if (data.trace === null) throw new Error("Authored receiving callback failure");
      const state = week.createWeekPlan(data, "2026-12-30");
      const exporter = calendar.createWeekExport(state, metadata);
      accepted = { label: data.plan.notes[0], items: exporter.preview(state, week.weekRows(state)) };
      events.push("result");
    },
    onError: error => events.push("error: " + error.message),
    onIdle: () => events.push("idle"),
  });
  const old = controller.run("/authored", {});
  const fresh = controller.run("/authored", {});
  assert.equal(pending[0].signal.aborted, true);
  pending[1].resolve(fixture("Fresh", [], "Sunday"));
  assert.equal(await fresh, true);
  const before = structuredClone(accepted);
  pending[0].resolve(fixture("Late"));
  assert.equal(await old, false);
  assert.deepEqual(accepted, before);
  const failed = controller.run("/authored", {});
  const malformed = fixture("Callback-failure");
  malformed.trace = null;
  pending[2].resolve(malformed);
  assert.equal(await failed, false);
  assert.equal(events.filter(e => e.startsWith("error:")).length, 1);
  controller.dispose();
  assert.equal(await controller.run("/authored", {}), false);
  fs.writeFileSync(path.join(output, "fixture-lifecycle-receipt.json"), JSON.stringify({ events, accepted, uiExecuted: false, note: "Only the actual published module/callback handoff is exercised; consumer DOM/session retirement requires the frozen composed app." }, null, 2) + "\n");
});
