import {readFile,mkdir,mkdtemp,rm,statfs} from 'node:fs/promises';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {resolve,join,extname} from 'node:path';

export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export async function waitFor(fn,label,attempts=120){let last;for(let i=0;i<attempts;i++){try{const v=await fn();if(v)return v;}catch(e){last=e;}await sleep(100);}throw new Error('Timed out '+label+(last?': '+last.message:''));}
export async function openBrowser({site,runName,report}){
 site=resolve(site);
 const parent='/home/jacob/snap/chromium/common/'+runName;
 const space=await statfs('/home/jacob/snap/chromium/common');
 report.browserDiskFreeBytes=space.bavail*space.bsize;
 if(report.browserDiskFreeBytes<250*1024*1024)throw new Error('Insufficient space for bounded browser session');
 await mkdir(parent);
 const profile=await mkdtemp(join(parent,'owned-profile-')),downloads=join(parent,'downloads');
 await mkdir(downloads);
 const server=createServer(async(req,res)=>{try{
  const u=new URL(req.url,'http://127.0.0.1'),p=resolve(site,'.'+decodeURIComponent(u.pathname));
  if(!p.startsWith(site+'/')){res.writeHead(403).end();return;}
  const bytes=await readFile(p);res.writeHead(200,{'Content-Type':({'.html':'text/html','.mjs':'text/javascript','.js':'text/javascript','.css':'text/css','.json':'application/json'}[extname(p)]||'application/octet-stream')+';charset=utf-8','Cache-Control':'no-store'}).end(bytes);
 }catch{res.writeHead(404).end();}});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+server.address().port;
 let socket,browser,sessionId,nextId=0,launchError,log='';
 const pending=new Map(),events=new Map();report.pageErrors=[];report.externalRequests=[];report.pageRequests=[];report.targets=[];
 function command(method,params={},scoped=true){const id=++nextId;return new Promise((yes,no)=>{const timer=setTimeout(()=>{pending.delete(id);no(new Error('CDP timeout '+method));},10000);pending.set(id,{yes,no,timer});socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));});}
 async function evaluate(expression){const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
 async function press(key,code=key,keyCode){for(const type of ['keyDown','keyUp'])await command('Input.dispatchKeyEvent',{type,key,code,...(keyCode?{windowsVirtualKeyCode:keyCode,nativeVirtualKeyCode:keyCode}:{}),...(key==='Enter'&&type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});}
 async function enter(selector){await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');await press('Enter','Enter',13);}
 async function chooseFile(selector,path){const {root}=await command('DOM.getDocument',{depth:0});const {nodeId}=await command('DOM.querySelector',{nodeId:root.nodeId,selector});if(!nodeId)throw new Error('No file input '+selector);await command('DOM.setFileInputFiles',{nodeId,files:[path]});}
 async function newPage(pathname,width=1280,height=960){
  const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);
  ({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));report.targets.push({targetId,sessionId});
  for(const m of ['Page.enable','Runtime.enable','Network.enable','DOM.enable'])await command(m);
  await command('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});
  await command('Page.navigate',{url:base+pathname});
  await waitFor(()=>evaluate('document.readyState==="complete"'),'page load');
  return {targetId,sessionId};
 }
 async function completedDownload(after=new Set()){
  return waitFor(async()=>{const event=[...events.values()].find(x=>x.state==='completed'&&!after.has(x.guid));if(!event)return null;return {event,path:join(downloads,event.guid),bytes:await readFile(join(downloads,event.guid))};},'completed physical download');
 }
 async function screenshot(){await command('Page.bringToFront');await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');await sleep(150);return Buffer.from((await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64');}
 async function close(){
  if(socket?.readyState===WebSocket.OPEN){try{await command('Browser.close',{},false);}catch{}}
  socket?.close();for(const p of pending.values())clearTimeout(p.timer);
  if(browser&&browser.exitCode===null&&browser.signalCode===null)browser.kill('SIGTERM');
  for(let i=0;browser&&browser.exitCode===null&&browser.signalCode===null&&i<30;i++)await sleep(100);
  report.browserExited=!browser||browser.exitCode!==null||browser.signalCode!==null;
  if(report.browserExited){await rm(profile,{recursive:true,force:true});report.ownedProfileRemoved=true;}else{report.cleanupError='Owned browser still running; profile preserved';process.exitCode=1;}
  server.closeAllConnections();await new Promise(r=>server.close(r));report.serverClosed=true;
  report.browserLog=log;report.downloadEvents=[...events.values()];report.nativeDownloadsPath=downloads;
 }
 try{
  browser=spawn('/snap/bin/chromium',['--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
  browser.stderr.on('data',b=>{log=(log+b.toString()).slice(-6000);});browser.on('error',e=>{launchError=e;});
  const port=await waitFor(async()=>{if(launchError)throw launchError;if(browser.exitCode!==null)throw new Error('Chromium exited '+browser.exitCode);return (await readFile(join(profile,'DevToolsActivePort'),'utf8')).trim().split('\n');},'Chromium startup',450);
  socket=new WebSocket('ws://127.0.0.1:'+port[0]+port[1]);
  socket.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.no(new Error(m.error.message)):p.yes(m.result);}
   else if(m.method==='Runtime.exceptionThrown')report.pageErrors.push({session:m.sessionId,error:m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text});
   else if(m.method==='Network.requestWillBeSent'){const u=m.params.request.url;report.pageRequests.push({session:m.sessionId,url:u,method:m.params.request.method});if(/^https?:/.test(u)&&!u.startsWith(base+'/'))report.externalRequests.push(u);}
   else if(m.method==='Browser.downloadWillBegin'||m.method==='Browser.downloadProgress')events.set(m.params.guid,{...events.get(m.params.guid),...m.params});
  });
  await new Promise((yes,no)=>{socket.addEventListener('open',yes,{once:true});socket.addEventListener('error',no,{once:true});});
  report.browser=await command('Browser.getVersion',{},false);report.browserPid=browser.pid;
  await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath:downloads,eventsEnabled:true},false);
  return {base,command,evaluate,press,enter,chooseFile,newPage,completedDownload,screenshot,close,downloadGuids:()=>new Set(events.keys())};
 }catch(e){await close();throw e;}
}
