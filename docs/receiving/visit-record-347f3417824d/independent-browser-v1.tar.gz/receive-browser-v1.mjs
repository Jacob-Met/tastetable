import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {openBrowser,waitFor,sleep} from './root-cdp-transport-v2.mjs';

const root='/home/jacob/hamon-tastetable-root-browser-347f3417824d';
const source='/dev/shm/tastetable-visit-record-347f3417824d/candidate';
const output='/dev/shm/tastetable-root-browser-347f3417824d/browser-v1';
const sha=b=>createHash('sha256').update(b).digest('hex');
const manifestPath='/dev/shm/tastetable-visit-record-347f3417824d/evidence/source-freeze-v1.json';
const manifestBytes=await readFile(manifestPath);
assert.equal(sha(manifestBytes),'914c46b1fa2f205009fe2bb08ffbb3c1fcdba6a7dfee425af549cfd4207d344d');
const manifest=JSON.parse(manifestBytes);
const oraclesBytes=await readFile(join(root,'browser-oracles-v1.json'));
assert.equal(sha(oraclesBytes),'2b7726d475298cf302a6839b879fd4e510bd50520e6e1174f71ec3058d593af5');
const oracle=JSON.parse(oraclesBytes);
const extra=JSON.parse(await readFile(join(root,'extra-fixture-pins.json')));
const fixtures=[...oracle.fixture_pins,...extra.files];
const transport=join(root,'root-cdp-transport-v2.mjs');
assert.equal(sha(await readFile(transport)),'b4c8b020fa2d04e9b1f4434685c87d7ec98ad39f9e45431d78198a67160ec9e0');
async function unchanged(){for(const f of manifest.files)assert.equal(sha(await readFile(join(source,f.path))),f.sha256,f.path);for(const f of fixtures)assert.equal(sha(await readFile(join(root,f.path))),f.sha256,f.path);}
await unchanged();
await mkdir(output);
const rawSource=await readFile(join(root,'independent-source-week.json'),'utf8');
const literal=JSON.parse(await readFile(join(root,'independent-literal-record.json'),'utf8'));
const expected=structuredClone(literal);
expected.visits[0].outcome='did_not_go';expected.visits[0].date='2023-12-31';
expected.visits[2].note='Independent keyboard note — café 🙂 <b>literal</b>';
expected.visits[1].note='Omitted occurrence kept independently.';
const report={schema:'tastetable.visit_record.root_browser_receipt.v1',startedAt:new Date().toISOString(),status:'running',oracleSha256:sha(oraclesBytes),sourceManifestSha256:sha(manifestBytes),sourceFiles:manifest.files,fixturePins:fixtures,checks:[],artifacts:[],controlledReadCases:[],semanticExpectationChangedAfterCandidateAccess:false,authorBrowserTestRead:false};
let browser;
const esc=JSON.stringify;
async function artifact(name,bytes,kind){const path=join(output,name);await writeFile(path,bytes);const p={name,path,bytes:bytes.length,sha256:sha(bytes),kind};report.artifacts.push(p);return p;}
try{
 browser=await openBrowser({site:source,runName:'tastetable-visit-record-root-347f3417824d-v1',report});
 const {evaluate,command,enter,press,chooseFile}=browser;
 const snapshot=()=>evaluate('({recordHidden:document.querySelector("#record").hidden,previewHidden:document.querySelector("#preview").hidden,preview:document.querySelector("#previewSummary").textContent,status:document.querySelector("#fileStatus").textContent,error:document.querySelector("#fileError").textContent,title:document.querySelector("#recordTitle").textContent,summary:document.querySelector("#recordSummary").textContent,sourceName:document.querySelector("#sourceName").textContent,rows:[...document.querySelectorAll("#visits .visit-card")].map(n=>({key:n.dataset.key,name:n.querySelector("h3").textContent,planned:n.querySelector(".planned").textContent,why:n.querySelector(".why").textContent,outcome:n.querySelector("select").value,date:n.querySelector("input").value,note:n.querySelector("textarea").value,print:n.querySelector(".print-values").textContent})),saveDisabled:document.querySelector("#saveRecord").disabled,printDisabled:document.querySelector("#printRecord").disabled})');
 async function select(input,file){await evaluate('document.querySelector('+esc(input)+').value=""');await chooseFile(input,join(root,file));}
 async function preview(input,file){await select(input,file);await waitFor(()=>evaluate('!document.querySelector("#preview").hidden'),'explicit preview '+file);return snapshot();}
 async function use(){await enter('#useRecord');await waitFor(()=>evaluate('!document.querySelector("#record").hidden && document.querySelector("#preview").hidden'),'Use commits selected file');}
 async function setValue(selector,value,type='input'){await evaluate('(()=>{const n=document.querySelector('+esc(selector)+');n.focus();n.value='+esc(value)+';n.dispatchEvent(new Event('+esc(type)+',{bubbles:true}));})()');}
 async function saved(name){const before=browser.downloadGuids();await enter('#saveRecord');const d=await browser.completedDownload(before);const a=await artifact(name,d.bytes,'completed physical JSON download');a.nativePath=d.path;a.browserEvent=d.event;return {json:JSON.parse(d.bytes),bytes:d.bytes,nativePath:d.path};}
 function assertRecord(actual,want){assert.equal(actual.format,'tastetable.visit-record.v1');assert.deepEqual(actual.source,want.source);assert.deepEqual(actual.visits,want.visits);assert.ok(Number.isFinite(Date.parse(actual.savedAt)));assert.equal(new Date(actual.savedAt).toISOString(),actual.savedAt);}
 async function installObservation(){await evaluate('(()=>{window.__rootStorageWrites=[];const set=Storage.prototype.setItem;Storage.prototype.setItem=function(...a){window.__rootStorageWrites.push(a[0]);return set.apply(this,a);};window.__rootDelayNames=[];window.__rootPending=[];const read=Blob.prototype.arrayBuffer;Blob.prototype.arrayBuffer=function(){const raw=read.call(this);if(!window.__rootDelayNames.includes(this.name))return raw;const item={name:this.name,ready:false};window.__rootPending.push(item);return new Promise((resolve,reject)=>raw.then(bytes=>{item.ready=true;item.release=()=>resolve(bytes);},reject));};window.__rootPrintEvents=[];addEventListener("beforeprint",()=>window.__rootPrintEvents.push("beforeprint"));addEventListener("afterprint",()=>window.__rootPrintEvents.push("afterprint"));})()');}
 async function persistence(){return evaluate('(async()=>({local:localStorage.length,session:sessionStorage.length,cookies:document.cookie,indexed:await indexedDB.databases(),caches:await caches.keys(),workers:(await navigator.serviceWorker.getRegistrations()).length,writes:window.__rootStorageWrites}))()');}
 function noPersistence(p){assert.equal(p.local,0);assert.equal(p.session,0);assert.equal(p.cookies,'');assert.deepEqual(p.indexed,[]);assert.deepEqual(p.caches,[]);assert.equal(p.workers,0);assert.deepEqual(p.writes,[]);}
 await browser.newPage('/static/visit-record.html');
 await waitFor(()=>evaluate('!!document.querySelector("#openWeek")'),'visit record controls ready');
 await installObservation();
 let s=await snapshot();assert.equal(s.recordHidden,true);assert.equal(s.rows.length,0);assert.equal(s.saveDisabled,true);
 s=await preview('#weekFile','independent-source-week.json');
 assert.equal(s.recordHidden,true);assert.equal(s.rows.length,0);assert.match(s.preview,/4 original picks/);
 await use();s=await snapshot();
 assert.deepEqual(s.rows.map(x=>x.key),['pick-0','pick-1','pick-2','pick-3']);
 assert.deepEqual(s.rows.map(x=>x.outcome),['unrecorded','unrecorded','unrecorded','unrecorded']);
 assert.deepEqual(s.rows.map(x=>x.date),['','','','']);
 assert.deepEqual(s.rows.map(x=>x.note),['','','','']);
 assert.equal(s.rows[0].name,'Repeated café <&>');assert.equal(s.rows[2].name,s.rows[0].name);
 assert.deepEqual(s.rows.map(x=>x.planned),['Planned: Thursday, 2024-02-29','Not scheduled in this saved week','Planned: Thursday, 2024-02-29','Planned: Sunday, 2024-03-03']);
 assert.deepEqual(s.rows.map(x=>x.why),['First original occurrence; distinct explanation.','Kept off the arranged week.','Second original occurrence; distinct explanation.','Original cultural suggestion.']);
 assert.equal(await evaluate('document.querySelectorAll("#visits h3 b,#visits h3 script").length'),0);
 report.initialOccurrences=s.rows;
 report.checks.push({id:'explicit-preview-occurrences',status:'passed',physicalInput:true,originalOccurrenceCount:4});

 const beforeLiteral=await snapshot();
 await preview('#recordFile','independent-literal-record.json');
 assert.deepEqual((await snapshot()).rows,beforeLiteral.rows);
 await use();
 s=await snapshot();assert.equal(s.rows[0].date,'9999-12-31');assert.equal(s.rows[0].outcome,'went');
 assert.equal(s.sourceName,literal.source.name);
 assert.equal(s.rows[0].note,literal.visits[0].note.replace(/\r\n?/g,'\n'));
 await evaluate('document.querySelector("#pick-0-outcome").focus()');
 await press('End','End',35);await press('Tab','Tab',9);
 assert.equal((await snapshot()).rows[0].outcome,'did_not_go');
 await setValue('#pick-0-date','2023-12-31');
 await evaluate('document.querySelector("#pick-2-note").focus()');
 await command('Input.insertText',{text:expected.visits[2].note});
 await evaluate('document.querySelector("#pick-1-note").focus()');
 await command('Input.insertText',{text:expected.visits[1].note});
 s=await snapshot();assert.deepEqual(s.rows.map(x=>x.planned),report.initialOccurrences.map(x=>x.planned));assert.deepEqual(s.rows.map(x=>x.why),report.initialOccurrences.map(x=>x.why));
 const first=await saved('literal-edited-record.json');
 assertRecord(first.json,expected);assert.equal(first.json.source.weekText,rawSource);assert.equal(first.json.visits[0].note,literal.visits[0].note);
 report.literalPhysicalDownload={untouchedNoteExact:true,sourceBOM_CRLF_Exact:true,unrelatedFieldEdits:true,actualKeyboardOutcomeAndNotes:true};
 report.checks.push({id:'literal-untouched-note',status:'passed'});

 const preservedRows=(await snapshot()).rows;
 for(const name of ['invalid-json.json','invalid-utf8.json','oversized-record.json','unsupported-record.json']){
  await select('#recordFile',name);
  await waitFor(()=>evaluate('!!document.querySelector("#fileError").textContent'),'refusal '+name);
  s=await snapshot();assert.equal(s.previewHidden,true);assert.deepEqual(s.rows,preservedRows);assert.equal(s.saveDisabled,false);
  (report.refusals??=[]).push({file:name,error:s.error});
 }
 await preview('#weekFile','independent-empty-week.json');assert.deepEqual((await snapshot()).rows,preservedRows);
 await enter('#cancelOpen');s=await snapshot();assert.equal(s.previewHidden,true);assert.deepEqual(s.rows,preservedRows);
 // Each controlled race reads a real selected file; only promise delivery is delayed.
 async function pendingRead(label){await evaluate('window.__rootDelayNames=["independent-source-week.json"];window.__rootPending=[]');await select('#weekFile','independent-source-week.json');await waitFor(()=>evaluate('window.__rootPending.length===1 && window.__rootPending[0].ready'),'controlled pending read '+label);assert.deepEqual((await snapshot()).rows,preservedRows);}
 async function release(){await evaluate('window.__rootPending[0].release();window.__rootDelayNames=[]');await sleep(150);}
 await pendingRead('new-selection');await preview('#weekFile','independent-empty-week.json');const newerPreview=(await snapshot()).preview;
 await release();s=await snapshot();assert.equal(s.preview,newerPreview);assert.equal(s.previewHidden,false);assert.deepEqual(s.rows,preservedRows);await enter('#cancelOpen');
 report.controlledReadCases.push({id:'newer-selection-retires-read',passed:true,control:'Delayed promise delivery of actual selected file bytes; newer physical source preview preserved'});
 await pendingRead('edit');await setValue('#pick-0-date','2023-12-31');await release();s=await snapshot();assert.equal(s.previewHidden,true);assert.deepEqual(s.rows,preservedRows);
 report.controlledReadCases.push({id:'edit-retires-read',passed:true,control:'Existing value explicitly re-entered through actual input event'});
 await pendingRead('cancel');await enter('#cancelOpen');await release();s=await snapshot();assert.equal(s.previewHidden,true);assert.deepEqual(s.rows,preservedRows);
 report.controlledReadCases.push({id:'cancel-retires-read',passed:true});
 const afterRefusal=await saved('after-refusal-and-races.json');assertRecord(afterRefusal.json,expected);
 report.checks.push({id:'refusals-cancel-controlled-races',status:'passed',physicalRefusals:4,controlledReadCases:3});

 await command('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:false});
 const layout=await evaluate('({viewport:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth,controls:[...document.querySelectorAll("#openWeek,#openRecord,#saveRecord,#printRecord,#visits input,#visits select,#visits textarea")].map(n=>{const r=n.getBoundingClientRect();return {id:n.id,left:r.left,right:r.right,width:r.width,height:r.height,disabled:n.disabled}})})');
 assert.ok(layout.document<=391&&layout.body<=391,JSON.stringify(layout));
 assert.ok(layout.controls.every(c=>c.width>0&&c.left>=0&&c.right<=391&&!c.disabled));
 report.narrowLayout=layout;
 await evaluate('document.querySelector("#pick-2-outcome").focus()');
 assert.equal(await evaluate('document.activeElement.id'),'pick-2-outcome');
 await press('Tab','Tab',9);assert.equal(await evaluate('document.activeElement.id'),'pick-2-date');
 await press('Tab','Tab',9);assert.equal(await evaluate('document.activeElement.id'),'pick-2-note');
 await press('End','End',35);await command('Input.insertText',{text:' + keyboard continuation'});expected.visits[2].note+=' + keyboard continuation';
 await evaluate('document.querySelector("#record").scrollIntoView({block:"start"})');await artifact('narrow-record.png',await browser.screenshot(),'native 390px screenshot');
 await evaluate('document.querySelector("[data-key=pick-2].visit-card").scrollIntoView({block:"start"})');await artifact('narrow-occurrence.png',await browser.screenshot(),'native 390px screenshot');
 assert.equal(await evaluate('document.querySelectorAll("#visits script,#visits b").length'),0);
 await enter('#printRecord');
 const pdf=Buffer.from((await command('Page.printToPDF',{printBackground:true,preferCSSPageSize:true,displayHeaderFooter:false})).data,'base64');
 const pdfArtifact=await artifact('visit-record.pdf',pdf,'native Chromium PDF print');
 const extraction=spawnSync('/usr/bin/pdftotext',['-layout',pdfArtifact.path,'-'],{encoding:'utf8',timeout:20000});
 assert.equal(extraction.status,0,extraction.stderr);
 await artifact('visit-record-print.txt',Buffer.from(extraction.stdout),'native PDF extracted text');
 for(const text of ['2024-02-29','2023-12-31','Did not go','Omitted fixture','keyboard continuation','Second original occurrence; distinct explanation.'])assert.ok(extraction.stdout.includes(text),'Printed '+text);
 assert.equal((extraction.stdout.match(/Repeated café <&>/g)||[]).length,2);
 assert.equal((extraction.stdout.match(/No note/g)||[]).length,1);
 assert.equal((await snapshot()).rows[0].note,literal.visits[0].note.replace(/\r\n?/g,'\n'));
 report.printEvents=await evaluate('window.__rootPrintEvents');
 assert.ok(report.printEvents.includes('beforeprint')&&report.printEvents.includes('afterprint'));
 const final=await saved('final-physical-visit-record.json');assertRecord(final.json,expected);
 report.firstPagePersistence=await persistence();noPersistence(report.firstPagePersistence);
 report.checks.push({id:'narrow-keyboard-literal-print',status:'passed',width:390,pdfBytes:pdf.length});

 await browser.newPage('/static/visit-record.html',390,844);
 await installObservation();s=await snapshot();assert.equal(s.recordHidden,true);assert.equal(s.rows.length,0);
 await evaluate('document.querySelector("#recordFile").value=""');
 await chooseFile('#recordFile',final.nativePath);
 await waitFor(()=>evaluate('!document.querySelector("#preview").hidden'),'physical download fresh preview');
 assert.equal((await snapshot()).recordHidden,true);await use();
 s=await snapshot();assert.equal(s.rows.length,4);
 assert.deepEqual(s.rows.map(x=>({key:x.key,outcome:x.outcome,date:x.date||null,note:x.note})),expected.visits.map(x=>({...x,note:x.note.replace(/\r\n?/g,'\n')})));
 const reopened=await saved('fresh-page-reopened-record.json');assertRecord(reopened.json,expected);assert.equal(reopened.json.source.weekText,rawSource);
 await preview('#weekFile','original-physical-saved-week.json');await use();
 s=await snapshot();assert.equal(s.rows.length,5);assert.ok(s.rows.every(x=>x.outcome==='unrecorded'&&x.date===''&&x.note===''));
 const different=await saved('different-source-clean-record.json');
 assert.equal(different.json.source.weekText,await readFile(join(root,'original-physical-saved-week.json'),'utf8'));
 assert.ok(different.json.visits.every(x=>x.outcome==='unrecorded'&&x.date===null&&x.note===''));
 report.secondPagePersistence=await persistence();noPersistence(report.secondPagePersistence);
 report.checks.push({id:'physical-save-fresh-reopen-clean-source',status:'passed',physicalDownloads:report.artifacts.filter(x=>x.kind==='completed physical JSON download').length});
 assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.externalRequests,[]);
 assert.ok(report.pageRequests.every(x=>x.method==='GET'));
 await unchanged();report.sourceAndFixturesUnchanged=true;report.status='accepted';
}catch(error){
 report.status='failed';report.error=error.stack;process.exitCode=1;
 if(browser){try{report.failureDOM=await browser.evaluate('document.body.innerText');await artifact('failure.png',await browser.screenshot(),'native failure screenshot');}catch(e){report.failureCaptureError=String(e);}}
 console.error(error.stack);
}finally{
 if(browser)await browser.close();
 report.finishedAt=new Date().toISOString();report.receiverSha256=sha(await readFile(fileURLToPath(import.meta.url)));report.transportSha256=sha(await readFile(transport));
 await writeFile(join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,checks:report.checks,error:report.error,receiptSha256:sha(await readFile(join(output,'receipt.json'))),receiverSha256:report.receiverSha256,transportSha256:report.transportSha256,browserExited:report.browserExited,ownedProfileRemoved:report.ownedProfileRemoved,artifacts:report.artifacts}));
}
