import assert from "node:assert/strict";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { pathToFileURL } from "node:url";

const args = Object.fromEntries(process.argv.slice(2).map((value, index, all) =>
  value.startsWith("--") ? [value, all[index + 1]?.startsWith("--") ? true : all[index + 1] ?? true] : null).filter(Boolean));
const required = (name) => { assert.equal(typeof args[name], "string", "Required " + name); return path.resolve(args[name]); };
const baseline = required("--baseline");
const oraclePath = required("--oracles");
const output = required("--output");
const baselineOnly = args["--baseline-only"] === true;
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const gitBlob = (bytes) => createHash("sha1").update("blob " + bytes.length + "\0").update(bytes).digest("hex");
const sameBytes = (a, b) => Buffer.from(a).equals(Buffer.from(b));
const baselinePins = {
  "week_file.mjs": "420ddb8f63fca264dcf97be7147801105696155d",
  "week_plan.mjs": "8ed28163e0273c510fdd8e6f7c5d1c8476efb862",
};
const inputPins = [];
async function pin(file, expectedGit = null, expectedSha = null) {
  const bytes = await readFile(file);
  if (expectedGit) assert.equal(gitBlob(bytes), expectedGit, file);
  if (expectedSha) assert.equal(hash(bytes), expectedSha, file);
  inputPins.push({path: file, bytes: bytes.length, sha256: hash(bytes)});
  return bytes;
}
for (const [name, value] of Object.entries(baselinePins)) await pin(path.join(baseline, name), value);
const oracleBytes = await pin(oraclePath);
const oracle = JSON.parse(oracleBytes);
const {readWeekFile} = await import(pathToFileURL(path.join(baseline, "week_file.mjs")));
const original = oracle.sources.primary;
const parsedSource = JSON.parse(original.text.replace(/^\uFEFF/, ""));
const clone = (x) => structuredClone(x);
function countSource(count) {
  const copy = clone(parsedSource);
  copy.response.plan.meals = Array.from({length: count}, (_unused, i) => ({
    ...clone(parsedSource.response.plan.meals[0]), day: "Monday",
    entity_id: "FIX-COUNT-" + i, name: "Counted fixture " + i, why: "Original occurrence " + i,
  }));
  copy.response.plan.outing = null;
  copy.week.assignments = Object.fromEntries(copy.response.plan.meals.map((_pick, i) => ["pick-" + i, "Monday"]));
  const values = copy.response.comparison.grounded;
  for (const key of ["picks", "with_qloo_entity_id", "with_affinity_evidence", "constraint_checked"]) values[key] = count;
  return JSON.stringify(copy);
}
const sources = [
  ["primary", original.text, 4],
  ["empty", oracle.sources.empty.text, 0],
  ["maximum-occurrences", countSource(100), 100],
  ["original-codec-admits-over-new-limit", countSource(101), 101],
];
const originalFacts = [];
for (const [name, text, count] of sources) {
  const value = readWeekFile(text);
  assert.equal(value.state.picks.length, count);
  assert.equal(value.state.weekStart, "2024-02-26");
  originalFacts.push({name, byte_size: Buffer.byteLength(text), sha256: hash(text), occurrences: count});
}
const nativeOriginal = readWeekFile(original.text);
assert.deepEqual(nativeOriginal.state.picks.map((x) => x.key), oracle.expected.keys);
assert.deepEqual(nativeOriginal.state.picks.map((x) => x.originalDay), oracle.expected.originalDays);
assert.deepEqual(oracle.expected.keys.map((key) => nativeOriginal.state.assignments[key]), oracle.expected.plannedDays);
assert.equal(nativeOriginal.state.picks[0].pick.entity_id, nativeOriginal.state.picks[2].pick.entity_id);
assert.notEqual(nativeOriginal.state.picks[0].pick.why, nativeOriginal.state.picks[2].pick.why);
await mkdir(output);
const results = [];
function deepFrozen(value) {
  if (value && typeof value === "object") {
    assert(Object.isFrozen(value), "Returned object must be frozen");
    Object.values(value).forEach(deepFrozen);
  }
}
function rejectsWithoutMutation(input, invoke) {
  const before = clone(input);
  assert.throws(invoke);
  assert.deepEqual(input, before, "Refusal changed its input");
}
async function group(name, run) {
  try { await run(); results.push({name, status: "passed"}); }
  catch (error) { results.push({name, status: "failed", error: error.stack ?? String(error)}); }
}
let api;
let first;
const now = new Date(oracle.expected.saveTime);
if (!baselineOnly) {
  const modulePath = required("--module");
  assert.match(args["--module-sha256"], /^[0-9a-f]{64}$/);
  await pin(modulePath, null, args["--module-sha256"]);
  for (const [name, value] of Object.entries(baselinePins)) await pin(path.join(path.dirname(modulePath), name), value);
  api = await import(pathToFileURL(modulePath));
  for (const name of ["createVisitRecord","updateVisitRecord","visitRecordRows","makeVisitRecordFile","readVisitRecord"]) {
    assert.equal(typeof api[name], "function", name);
  }
  await group("raw source, initial values and original-order projection", () => {
    first = api.createVisitRecord(original.text, original.name);
    assert.deepEqual(Object.keys(first).sort(), ["source","visits"]);
    assert.deepEqual(first.source, {name: original.name, weekText: original.text});
    assert.deepEqual(first.visits, oracle.expected.keys.map((key) => ({key,outcome:"unrecorded",date:null,note:""})));
    const rows = api.visitRecordRows(first);
    assert.deepEqual(rows.map((x) => x.key), oracle.expected.keys);
    assert.deepEqual(rows.map((x) => x.originalDay), oracle.expected.originalDays);
    assert.deepEqual(rows.map((x) => x.plannedDay), oracle.expected.plannedDays);
    assert.deepEqual(rows.map((x) => x.plannedDate), oracle.expected.plannedDates);
    assert.deepEqual(rows.map((x) => x.pick), nativeOriginal.state.picks.map((x) => x.pick));
    for (const row of rows) assert.deepEqual(Object.keys(row).sort(), ["date","key","note","originalDay","outcome","pick","plannedDate","plannedDay"]);
    deepFrozen(first); deepFrozen(rows);
  });
  const fresh = () => api.createVisitRecord(original.text, original.name);
  const file = (record = fresh()) => api.makeVisitRecordFile(record, now);
  await group("repeated venue occurrences and actual versus planned dates", () => {
    const originalRecord = fresh();
    const one = api.updateVisitRecord(originalRecord, "pick-0", {outcome:"went",date:"2024-03-12",note:"  First visit.\r\nKeep this note literal.\rEnd.  "});
    const two = api.updateVisitRecord(one, "pick-2", {outcome:"did_not_go",date:"2024-02-29",note:"Independent decision."});
    const three = api.updateVisitRecord(two, "pick-1", {date:"2000-02-29",note:"Note without an attendance claim."});
    assert.deepEqual(originalRecord.visits, oracle.expected.keys.map((key) => ({key,outcome:"unrecorded",date:null,note:""})));
    assert.deepEqual(three.visits, [
      {key:"pick-0",outcome:"went",date:"2024-03-12",note:"  First visit.\r\nKeep this note literal.\rEnd.  "},
      {key:"pick-1",outcome:"unrecorded",date:"2000-02-29",note:"Note without an attendance claim."},
      {key:"pick-2",outcome:"did_not_go",date:"2024-02-29",note:"Independent decision."},
      {key:"pick-3",outcome:"unrecorded",date:null,note:""},
    ]);
    assert.deepEqual(api.visitRecordRows(three).map((x) => x.plannedDate), oracle.expected.plannedDates);
    assert.deepEqual(three.source, originalRecord.source);
    deepFrozen(one); deepFrozen(two); deepFrozen(three);
  });
  await group("save and reopen retain literal notes and untouched original source", async () => {
    const note = " \tCR\rLF\nCRLF\r\n café e\u0301 🙂 <&> ";
    let record = api.updateVisitRecord(fresh(), "pick-0", {note});
    record = api.updateVisitRecord(record, "pick-0", {outcome:"went"});
    record = api.updateVisitRecord(record, "pick-0", {date:"9999-12-31"});
    const saved = file(record);
    assert.equal(typeof saved.filename, "string");
    assert(saved.filename.endsWith(".json"));
    const envelope = JSON.parse(saved.text);
    assert.deepEqual(Object.keys(envelope).sort(), ["format","savedAt","source","visits"]);
    assert.equal(envelope.format, "tastetable.visit-record.v1");
    assert.equal(envelope.savedAt, oracle.expected.saveTime);
    assert.deepEqual(envelope.source, {name: original.name,weekText: original.text});
    assert.equal(envelope.visits[0].note, note);
    const restored = api.readVisitRecord(saved.text);
    assert.deepEqual(restored, {record,savedAt:oracle.expected.saveTime});
    deepFrozen(restored.record);
    assert(sameBytes(JSON.parse(file(restored.record).text).source.weekText, original.text));
    await writeFile(path.join(output,"literal-record.json"), saved.text, {flag:"wx"});
  });
  await group("reordered input entries retain their keys and canonical source order", () => {
    const record = clone(fresh());
    record.visits[0].note = "first";
    record.visits[2].note = "second";
    record.visits.reverse();
    const before = clone(record);
    assert.deepEqual(api.visitRecordRows(record).map((x) => x.key), oracle.expected.keys);
    const changed = api.updateVisitRecord(record, "pick-2", {outcome:"did_not_go"});
    assert.equal(changed.visits[0].note, "first");
    assert.equal(changed.visits[2].note, "second");
    assert.equal(changed.visits[2].outcome, "did_not_go");
    assert.deepEqual(record, before);
    const envelope = JSON.parse(file(record).text);
    envelope.visits.reverse();
    const restored = api.readVisitRecord(JSON.stringify(envelope)).record;
    assert.deepEqual(restored.visits.map((x) => x.key), oracle.expected.keys);
    assert.equal(restored.visits[0].note, "first");
    assert.equal(restored.visits[2].note, "second");
    deepFrozen(changed); deepFrozen(restored);
  });
  await group("Gregorian boundary dates independent of scheduled week", () => {
    for (const date of oracle.validDates) {
      const value = api.updateVisitRecord(fresh(), "pick-3", {date});
      assert.equal(value.visits[3].date, date);
      assert.equal(value.visits[3].outcome, "unrecorded");
    }
    for (const date of [...oracle.invalidDates, 0, "", undefined, true]) {
      const input = clone(fresh());
      rejectsWithoutMutation(input, () => api.updateVisitRecord(input, "pick-3", {outcome:"went",date}));
    }
  });
  await group("code-point note and source-name limits without normalization", () => {
    const note = "🙂".repeat(4000);
    const value = api.updateVisitRecord(fresh(), "pick-0", {note});
    assert.equal(value.visits[0].note, note);
    assert.equal(api.createVisitRecord(original.text, "🙂".repeat(512)).source.name, "🙂".repeat(512));
    const input = clone(fresh());
    rejectsWithoutMutation(input, () => api.updateVisitRecord(input, "pick-0", {note:note+"a"}));
    assert.throws(() => api.createVisitRecord(original.text, "🙂".repeat(513)));
    for (const name of ["", " \t\r\n ", "bad\u0000name", "bad\tname", "bad\nname", "bad\rname", "bad\u007fname", "\ud800", "\udfff"]) {
      assert.throws(() => api.createVisitRecord(original.text, name));
    }
    const literal = " \tfirst\r\nsecond\rlast\n ";
    assert.equal(api.updateVisitRecord(fresh(), "pick-0", {note:literal}).visits[0].note, literal);
  });
  await group("owned Unicode and control characters refuse atomically", () => {
    const controls = Array.from({length:32}, (_unused,i) => i).filter((i) => ![9,10,13].includes(i)).concat(127);
    for (const n of controls) {
      const input = clone(fresh());
      rejectsWithoutMutation(input, () => api.updateVisitRecord(input, "pick-0", {outcome:"went",note:"x"+String.fromCharCode(n)+"y"}));
    }
    for (const note of ["\ud800","\udfff"]) {
      const input = clone(fresh());
      rejectsWithoutMutation(input, () => api.updateVisitRecord(input, "pick-0", {note}));
      const envelope = JSON.parse(file().text); envelope.visits[0].note = note;
      assert.throws(() => api.readVisitRecord(JSON.stringify(envelope)));
    }
    assert.throws(() => api.createVisitRecord(original.text.replace("source-only","\ud800"), original.name));
  });
  await group("full-record schema and every-occurrence admission on all public consumers", () => {
    const corruptions = [
      (x) => { x.extra = true; },
      (x) => { x.source.extra = true; },
      (x) => { x.visits[0].extra = true; },
      (x) => { x.visits[1].key = x.visits[0].key; },
      (x) => { x.visits.pop(); },
      (x) => { x.visits[0].key = "pick-999"; },
      (x) => { x.visits[0].outcome = "attended"; },
      (x) => { delete x.visits[0].date; },
      (x) => { x.visits[0].note = 1; },
      (x) => { x.source.weekText = "{}"; },
    ];
    for (const corrupt of corruptions) for (const consumer of [
      (x) => api.visitRecordRows(x), (x) => api.updateVisitRecord(x,"pick-0",{}), (x) => api.makeVisitRecordFile(x,now),
    ]) {
      const input = clone(fresh()); corrupt(input);
      rejectsWithoutMutation(input, () => consumer(input));
    }
  });
  await group("patch refusals are atomic and empty patch is a value no-op", () => {
    const patches = [{extra:true},{outcome:"went",date:"2023-02-29"},{outcome:"scheduled"},{note:null},{date:undefined},{note:undefined}];
    for (const patch of patches) {
      const input = clone(fresh());
      rejectsWithoutMutation(input, () => api.updateVisitRecord(input,"pick-0",patch));
    }
    const input = clone(fresh());
    rejectsWithoutMutation(input, () => api.updateVisitRecord(input,"pick-999",{outcome:"went"}));
    const result = api.updateVisitRecord(input,"pick-0",{});
    assert.deepEqual(result,input);
    deepFrozen(result);
  });
  await group("record envelope and finite canonical save time", () => {
    const corruptions = [
      (x) => {x.extra=true;}, (x) => {delete x.savedAt;}, (x) => {x.format="tastetable.visit-record.v2";},
      (x) => {x.savedAt="2030-07-01T02:03:04Z";}, (x) => {x.savedAt="not-a-date";},
      (x) => {x.visits[0].date="1900-02-29";}, (x) => {x.visits.push(clone(x.visits[0]));},
    ];
    for (const corrupt of corruptions) {
      const envelope=JSON.parse(file().text);corrupt(envelope);
      assert.throws(() => api.readVisitRecord(JSON.stringify(envelope)));
    }
    for (const text of ["", "{", "null", "[]"]) assert.throws(() => api.readVisitRecord(text));
    assert.throws(() => api.makeVisitRecordFile(fresh(),new Date(NaN)));
    assert.throws(() => api.makeVisitRecordFile(fresh(),oracle.expected.saveTime));
  });
  await group("empty source and occurrence-count boundary", () => {
    const empty = api.createVisitRecord(oracle.sources.empty.text, oracle.sources.empty.name);
    assert.deepEqual(empty.visits,[]);
    assert.deepEqual(api.visitRecordRows(empty),[]);
    assert.deepEqual(api.readVisitRecord(file(empty).text).record,empty);
    assert.equal(api.createVisitRecord(countSource(100),"hundred.json").visits.length,100);
    assert.throws(() => api.createVisitRecord(countSource(101),"hundred-one.json"));
    deepFrozen(empty);
  });
  await group("actual UTF-8 source and whole-record byte limits", () => {
    const sourceAtLimit = original.text + " ".repeat(2*1024*1024-Buffer.byteLength(original.text));
    assert.equal(Buffer.byteLength(sourceAtLimit),2*1024*1024);
    assert.equal(api.createVisitRecord(sourceAtLimit,original.name).source.weekText,sourceAtLimit);
    assert.throws(() => api.createVisitRecord(sourceAtLimit+" ",original.name));
    const saved=file().text;
    const recordAtLimit=saved+" ".repeat(8*1024*1024-Buffer.byteLength(saved));
    assert.equal(Buffer.byteLength(recordAtLimit),8*1024*1024);
    assert.deepEqual(api.readVisitRecord(recordAtLimit).record,fresh());
    assert.throws(() => api.readVisitRecord(recordAtLimit+" "));
  });
}
for (const input of inputPins) {
  const after = await readFile(input.path);
  assert.equal(after.length,input.bytes,input.path);
  assert.equal(hash(after),input.sha256,input.path);
}
const receipt = {
  schema:"tastetable.visit_record.independent_receiving.v1",
  mode:baselineOnly?"original-codec-only":"frozen-candidate-api",
  node:process.version,oracle_sha256:hash(oracleBytes),original_codec_sources:originalFacts,
  groups:results,passed:results.filter((x)=>x.status==="passed").length,failed:results.filter((x)=>x.status==="failed").length,
  input_hashes:inputPins,all_inputs_unchanged:true,
  synthetic_only:true,browser_execution:false,
  qualification_limit:"Original saved-week admission and pure public visit-record API. Native browser file/preview/edit/download behavior is a separate gate.",
};
const receiptBytes=JSON.stringify(receipt,null,2)+"\n";
await writeFile(path.join(output,"receipt.json"),receiptBytes,{flag:"wx"});
console.log(JSON.stringify({mode:receipt.mode,passed:receipt.passed,failed:receipt.failed,original_sources:originalFacts.length,all_inputs_unchanged:true,receipt:path.join(output,"receipt.json"),receipt_sha256:hash(receiptBytes)}));
if(receipt.failed)process.exitCode=1;
