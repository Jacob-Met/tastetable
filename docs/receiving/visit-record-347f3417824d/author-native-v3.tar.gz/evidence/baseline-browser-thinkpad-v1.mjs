#!/usr/bin/env node
import assert from 'node:assert/strict';
import { readFile,writeFile,mkdir,mkdtemp,rm,statfs } from 'node:fs/promises';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join,resolve,extname,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readWeekFile } from '../base/static/week_file.mjs';
import { readOfflineWeek,inputsForRecord } from '../base/web-demo-offline/saved_week.mjs';
import { validateCatalogue } from '../base/web-demo-offline/catalogue.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),project=join(root,'base'),site=join(project,'web-demo-offline');
const output=join(root,'evidence/browser-baseline-v1'),browserExecutable='/snap/bin/chromium';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex'),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const sourceBytes=await readFile(join(root,'evidence/baseline-source-manifest.json'));
assert.equal(sha(sourceBytes),'b4accf90f8e1bc2e516e6ee2b1b32b7c4e0d90b3a6d5e4c1ae0df42b3dd94494');
const source=JSON.parse(sourceBytes),report={schema:'tastetable.visit_record.browser_baseline.v1',startedAt:new Date().toISOString(),status:'running',base:source.base,tree:source.tree,sourceManifestSha256:sha(sourceBytes),checks:[],pageErrors:[],externalRequests:[],sourceFiles:source.files};
async function sourcesUnchanged(){for(const file of source.files)assert.equal(sha(await readFile(join(project,file.path))),file.sha256,file.path);}
await sourcesUnchanged();
const space=await statfs(root);report.preflightFreeBytes=space.bavail*space.bsize;
assert.ok(report.preflightFreeBytes>=200*1024*1024,'Not enough current space for one bounded browser session.');
await mkdir(output);
const browserRoot='/home/jacob/snap/chromium/common/tastetable-visit-record-347f3417824d-baseline';await mkdir(browserRoot);const profile=await mkdtemp(join(browserRoot,'owned-chrome-')),downloads=join(browserRoot,'downloads');await mkdir(downloads);
const server=createServer(async(req,res)=>{try{
 const url=new URL(req.url,'http://127.0.0.1'),path=resolve(site,'.'+(url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname)));
 if(!path.startsWith(site+'/')){res.writeHead(403).end();return;}
 const bytes=await readFile(path);res.writeHead(200,{'Content-Type':({'.html':'text/html','.css':'text/css','.mjs':'text/javascript','.json':'application/json'}[extname(path)]||'application/octet-stream')+';charset=utf-8'}).end(bytes);
}catch{res.writeHead(404).end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
let browser,socket,sessionId,nextId=0,browserLog='';
const pending=new Map(),downloadEvents=new Map();
async function waitFor(fn,label){let last;for(let i=0;i<120;i++){try{const value=await fn();if(value)return value;}catch(e){last=e;}await sleep(100);}throw new Error('Timed out: '+label+(last?' '+last.message:''));}
function command(method,params={},scoped=true){const id=++nextId;return new Promise((yes,no)=>{const timer=setTimeout(()=>{pending.delete(id);no(new Error('CDP timeout '+method));},10000);pending.set(id,{yes,no,timer});socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));});}
async function evaluate(expression){const r=await command('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value;}
async function enter(selector){await evaluate('document.querySelector('+JSON.stringify(selector)+').focus()');for(const type of ['keyDown','keyUp'])await command('Input.dispatchKeyEvent',{type,key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13,...(type==='keyDown'?{text:'\r',unmodifiedText:'\r'}:{})});}
try{
 browser=spawn(browserExecutable,['--headless=new','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--no-default-browser-check','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
 browser.stderr.on('data',b=>{browserLog=(browserLog+b.toString()).slice(-6000);});let launchError;browser.on('error',e=>{launchError=e;});
 const port=await waitFor(async()=>{if(launchError)throw launchError;if(browser.exitCode!==null)throw new Error('Chrome exited '+browser.exitCode);return (await readFile(join(profile,'DevToolsActivePort'),'utf8')).trim().split('\n');},'Chrome startup');
 socket=new WebSocket('ws://127.0.0.1:'+port[0]+port[1]);
 socket.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.no(new Error(m.error.message)):p.yes(m.result);}
 else if(m.method==='Runtime.exceptionThrown')report.pageErrors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);
 else if(m.method==='Network.requestWillBeSent'){const u=m.params.request.url;if(/^https?:/.test(u)&&!u.startsWith(base+'/'))report.externalRequests.push(u);}
 else if(m.method==='Browser.downloadWillBegin'||m.method==='Browser.downloadProgress')downloadEvents.set(m.params.guid,{...downloadEvents.get(m.params.guid),...m.params});});
 await new Promise((yes,no)=>{socket.addEventListener('open',yes,{once:true});socket.addEventListener('error',no,{once:true});});
 report.browser=await command('Browser.getVersion',{},false);report.browserPid=browser.pid;
 const {targetId}=await command('Target.createTarget',{url:'about:blank'},false);({sessionId}=await command('Target.attachToTarget',{targetId,flatten:true},false));
 for(const method of ['Page.enable','Runtime.enable','Network.enable','DOM.enable'])await command(method);
 await command('Browser.setDownloadBehavior',{behavior:'allowAndName',downloadPath:downloads,eventsEnabled:true},false);
 await command('Emulation.setDeviceMetricsOverride',{width:1280,height:1000,deviceScaleFactor:1,mobile:false});
 await command('Page.navigate',{url:base+'/'});
 await waitFor(()=>evaluate('document.readyState==="complete" && document.querySelector("#results") && !document.querySelector("#results").hidden && !document.querySelector("#saveWeek").disabled'),'original studio ready');
 report.initial=await evaluate('({recordKey:document.querySelector("#results").dataset.recordKey,source:document.querySelector("#weekSource").textContent,summary:document.querySelector("#weekSummary").textContent,controls:[...document.querySelectorAll("#results button,#results select,#results textarea,#results input,#results a")].map(n=>({tag:n.tagName,id:n.id,type:n.type||null,label:n.getAttribute("aria-label")||n.textContent.trim(),pickKey:n.dataset.pickKey||null}))})');
 assert.ok(report.initial.recordKey&&report.initial.source.includes('Demo plan'));
 await evaluate('document.querySelector("#weekDate").value="2026-10-12";document.querySelector("#weekDate").dispatchEvent(new Event("input",{bubbles:true}))');
 await evaluate('(()=>{const s=document.querySelector("select[data-pick-key=pick-0]");s.value="Sunday";s.dispatchEvent(new Event("change",{bubbles:true}));})()');
 await evaluate('(()=>{const s=document.querySelector("select[data-pick-key=pick-1]");s.value="";s.dispatchEvent(new Event("change",{bubbles:true}));})()');
 report.arranged=await evaluate('({date:document.querySelector("#weekDate").value,summary:document.querySelector("#weekSummary").textContent,first:document.querySelector("select[data-pick-key=pick-0]").value,second:document.querySelector("select[data-pick-key=pick-1]").value})');
 assert.equal(report.arranged.first,'Sunday');assert.equal(report.arranged.second,'');assert.equal(report.arranged.date,'2026-10-12');
 await enter('#saveWeek');
 const event=await waitFor(()=>[...downloadEvents.values()].find(x=>x.state==='completed'),'physical saved-week completion');
 const filePath=join(downloads,event.guid),bytes=await readFile(filePath);assert.ok(bytes.length>100);await writeFile(join(output,'original-saved-week.json'),bytes);
 const snapshot=readWeekFile(bytes.toString('utf8')),catalogue=validateCatalogue(JSON.parse(await readFile(join(site,'data/catalogue.json'),'utf8')));
 const offline=readOfflineWeek(bytes.toString('utf8'),catalogue),record=catalogue.records.find(x=>x.key===report.initial.recordKey);
 assert.equal(snapshot.state.weekStart,'2026-10-12');assert.equal(snapshot.state.assignments['pick-0'],'Sunday');assert.equal(snapshot.state.assignments['pick-1'],null);
 assert.deepEqual(snapshot.response,record.response);assert.deepEqual(snapshot.inputs,inputsForRecord(catalogue,record));assert.equal(offline.record.key,record.key);
 report.savedWeek={path:filePath,evidenceCopy:join(output,'original-saved-week.json'),suggestedFilename:event.suggestedFilename,byteSize:bytes.length,sha256:sha(bytes),completeBrowserDownload:true,sourceRecord:record.key,weekStart:snapshot.state.weekStart,assignments:snapshot.state.assignments,fullOriginalResponseAndInputsRetained:true,sharedCodecAccepted:true,offlineExactSourceCodecAccepted:true};
 report.checks.push({name:'ordinary arrangement and physical Save week',status:'passed'});
 report.checks.push({name:'actual downloaded file admitted by both unchanged native codecs',status:'passed'});
 const controls=report.initial.controls;
 const outcomeControls=controls.filter(x=>/visit (?:status|date)|record (?:a |the )?visit|not visited|visit notes|experience notes|outcome/i.test(x.label+' '+x.id));
 report.missingCapability={expectedWorkflow:'Record a planned occurrence as visited/not visited with its actual date and caregiver note, then save/reopen that record',actualOutcomeControls:outcomeControls,observedTextareaCount:controls.filter(x=>x.tag==='TEXTAREA').length,existingFormat:JSON.parse(bytes).format,interpretation:'Missing current workflow; no regression or defect is attributed to the existing planner or saved-week format.'};
 assert.deepEqual(outcomeControls,[],'A current outcome workflow already exists; do not claim competing work.');
 report.checks.push({name:'current studio exposes arrangement controls but no visit-record workflow',status:'observed-missing'});
 await evaluate('document.querySelector("#weekOrganizer").scrollIntoView({block:"start"})');
 await command('Page.bringToFront');await evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');await sleep(150);
 const png=Buffer.from((await command('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64');
 await writeFile(join(output,'original-arranged-week.png'),png);report.screenshot={path:join(output,'original-arranged-week.png'),byteSize:png.length,sha256:sha(png)};
 assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.externalRequests,[]);
 await sourcesUnchanged();report.sourceFilesUnchanged=true;report.status='baseline-established';
}catch(error){report.status='failed';report.error=error.stack;report.browserLog=browserLog;console.error(error.stack);process.exitCode=1;}
finally{
 if(socket?.readyState===WebSocket.OPEN){try{await command('Browser.close',{},false);}catch{}}
 socket?.close();for(const p of pending.values())clearTimeout(p.timer);
 if(browser&&browser.exitCode===null&&browser.signalCode===null)browser.kill('SIGTERM');
 for(let i=0;browser&&browser.exitCode===null&&browser.signalCode===null&&i<30;i++)await sleep(100);
 report.browserExited=!browser||browser.exitCode!==null||browser.signalCode!==null;
 if(report.browserExited){await rm(profile,{recursive:true,force:true});report.ownedProfileRemoved=true;}
 else{report.cleanupError='Owned browser still running; profile preserved.';process.exitCode=1;}
 server.closeAllConnections();await new Promise(r=>server.close(r));report.serverClosed=true;
 report.finishedAt=new Date().toISOString();report.receiverSha256=sha(await readFile(fileURLToPath(import.meta.url)));
 await writeFile(join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,checks:report.checks,receiptSha256:sha(await readFile(join(output,'receipt.json'))),savedWeek:report.savedWeek,browserExited:report.browserExited,ownedProfileRemoved:report.ownedProfileRemoved,receiverSha256:report.receiverSha256}));
}
