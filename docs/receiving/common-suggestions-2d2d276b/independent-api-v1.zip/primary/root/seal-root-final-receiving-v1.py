from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, zipfile, traceback

R=Path(r"D:\hamon-ultra-2d2d276b-taste-common-independent")
A=Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions")
W=Path(r"D:\ttc2d26")
OUT=R/"root-final-receiving-v1"
CAP=R/"root-api-seal-v1"
PRODUCT="42bc23f796870b3b60ef15033d00d53628e27d59"
BASE="145d27981b3c5fe6afa72e205b42582fd72c7734"
TREE="6a5c7432d5d05dc902db38971a17a9ac32635f17"
def now(): return datetime.now(timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
    p=Path(p)
    assert p.is_file() and not p.is_symlink(),str(p)
    b=p.read_bytes()
    return {"path":str(p),"bytes":len(b),"sha256":sha(b)}
def checked(p,n,h):
    q=pin(p)
    assert q["bytes"]==n and q["sha256"]==h,{"pin_mismatch":q,"expected_bytes":n,"expected_sha256":h}
    return q
def load(p): return json.loads(Path(p).read_bytes())
def write_new(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    b=(json.dumps(obj,indent=2,ensure_ascii=False)+"\n").encode("utf-8")
    with p.open("xb") as f: f.write(b)
    assert p.read_bytes()==b
    return pin(p)
assert not OUT.exists() and not CAP.exists(),"First execution only; retain any earlier attempt."
OUT.mkdir();CAP.mkdir()
started=now()
try:
    known=[
      (R/"PUBLIC-INTAKE-v1.json",9914,"3831b1a77c14628bbc0c4f461794952d4a019bac6f0676b95f7e90ed9af71f23"),
      (R/"public/PUBLIC-CONTRACT-v1.md",10648,"32c9062e8085a73ec18af5fe909bdfd95c9829153441a0bc272c96231e65a433"),
      (R/"ORACLE-FROZEN-v1.json",4242,"fc2ee8476a5c73102fd6db45f42148d4d6c65e70f6df78e5a67f9d25eeb8c875"),
      (R/"CANDIDATE-INTAKE-v1.json",7359,"bc87375eb44bab82709c53cae6a74eeda2526333d9e078cc741d15fd1c671211"),
      (R/"candidate-v1/MANIFEST.json",4442,"95cceb5a59cb65807388bca0e6385b28ac3ab54cb8b2a3a7f67c0cda149fc94b"),
      (R/"candidate-v1/SEALED.json",1289,"26a26ce89fd75d8f828f33f06314b895dbb6f495cd534a62174d1d286ded108a"),
      (R/"api-receiving-v1/receipt.json",22778,"065033ac6db1cf36a7d916035f8b3810af2831e7dc8ef1004707442cfadc5813"),
      (R/"complete-source-binding-v1/receipt.json",13980,"0730d7879350968ed089ed2e9004e82d149648bff0c0a0fcfb16102e0b28a09f"),
      (R/"complete-source-binding-v1/SEALED.json",1759,"7577116d28c505cf0ec7765b0dce8f8d68e43c1ba7af25f3c19050d098b8bbba"),
      (R/"browser-receiving-v1/FINAL-BROWSER-REVIEW-v1.json",20568,"8e0ec7d904ea33e6d7ab2ae9a9828c40439d4fc644f31e0d78ce0a452706a35a"),
      (R/"browser-receiving-v1/BROWSER-FROZEN-v1.json",5869,"9ca7759c706a00d8ee511bd808e52c061ec1fd743cf96771f5c12ffc6ec506b1"),
      (R/"browser-receiving-v1/receiving-r1/receipt.json",134357,"f4d7676efc995502410ad35e92ee26763e05c492fa33c4805c1ac24cfe8ce3a8"),
      (R/"browser-receiving-v1/final-browser-seal-v1/taste-common-native-browser-v1.zip",744324,"0c4b570e331830584e1abab410eee55363185d83dd79b22f7a4794242ac3ac57"),
      (R/"browser-receiving-v1/final-browser-seal-v1/MANIFEST.json",35629,"5e4c88a3b34db7798f889b5b85409798bc9bd56b581eb00b80992070d4742e34"),
      (R/"browser-receiving-v1/final-browser-seal-v1/SEALED.json",1106,"8d15327ec699dd79be17ec72d3ff24b58c7f79e20abf71432517467298f5b335"),
      (A/"author-native-v1/controller-console-boundary.json",907,"117570fd21aee63b98672385b9d5abbc38416288a0de84b790c089c96c215716"),
      (A/"author-evidence-seal-v1/tastetable-common-author-native-v1.zip",647131,"569de85ed1b576d53e6838473ae5673da5051755f9e52ae4d4713f4798d7de67")
    ]
    references=[checked(*v) for v in known]
    freeze=load(R/"ORACLE-FROZEN-v1.json")
    pub=load(R/"public/MANIFEST.json")
    candidate=load(R/"candidate-v1/MANIFEST.json")
    intake=load(R/"CANDIDATE-INTAKE-v1.json")
    api=load(R/"api-receiving-v1/receipt.json")
    custody=load(R/"complete-source-binding-v1/receipt.json")
    browser=load(R/"browser-receiving-v1/FINAL-BROWSER-REVIEW-v1.json")
    assert freeze["candidateExposed"] is False and freeze["baseline"]==BASE
    assert (freeze["accepted"],freeze["refused"],freeze["browserGroups"])==(25,36,7)
    assert freeze["sealedAt"]<candidate["utc"]<intake["at"]<api["startedAt"]
    assert (api["accepted"],api["refused"],api["passed"],api["failed"])==(25,36,61,0)
    assert len(api["results"])==61 and all(x["pass"] is True for x in api["results"])
    assert (custody["product"],custody["tree"],custody["parent"])==(PRODUCT,TREE,BASE)
    assert (custody["baseline_leaves"],custody["product_leaves"],custody["unchanged_baseline_leaves"])==(818,824,816)
    assert custody["status"]=="full_source_custody_accepted"
    for k in ("all_824_physical_bytes_exact","no_newline_conversion_needed_or_performed","all_index_modes_and_blobs_exact","metadata_before_after_identical","no_source_index_config_hooks_refs_mutation"):
        assert custody[k] is True,k
    assert custody["behavior_or_author_test_executed"] is False
    assert browser["candidate"]["product_commit"]==PRODUCT
    first=browser["first_run"]
    assert len(first["groups"])==7 and first["checks"]==77 and first["all_passed"] is True
    assert all(x["status"]=="passed" for x in first["groups"])
    for x in pub["files"]: checked(R/"public"/x["path"],x["bytes"],x["sha256"])
    for x in freeze["files"]: checked(x["path"],x["bytes"],x["sha256"])
    for k in ("generator","apiController"):
        x=freeze[k];checked(x["path"],x["bytes"],x["sha256"])
    for x in candidate["files"]:
        p=R/"candidate-v1"/x["path"];checked(p,x["bytes"],x["sha256"])
        b=p.read_bytes()
        assert hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==x["blob"]
    raw=load(R/"complete-source-binding-v1/product-raw-manifest.json")
    assert len(raw)==824
    raw_by_path={x["path"]:x for x in raw}
    late_test=raw_by_path["tests/test_common_suggestions.mjs"]
    checked(W/late_test["path"],late_test["bytes"],late_test["sha256"])
    index=(R/"candidate-v1/source/static/index.html").read_bytes()
    original_index=(R/"public/baseline/static/index.html").read_bytes()
    anchor=b'    <a href="/static/common-suggestions.html" target="_blank" rel="noopener">Common saved suggestions (new tab)</a>\n'
    assert index.count(anchor)==1
    assert index.replace(anchor,b"",1)==original_index
    assert len(anchor)==116
    readme=(R/"candidate-v1/source/README.md").read_bytes()
    original_readme=(R/"public/baseline/README.md").read_bytes()
    assert readme.startswith(original_readme) and len(readme)-len(original_readme)==464
    assert sha(readme[len(original_readme):])=="b16e542dbe7647bbd9c92e7b7dacaa83d6415922fee8c3db5aabe6d747879550"
    reviewed_paths=custody["exact_eight_path_delta"]+["static/week_file.mjs","static/week_plan.mjs","static/week_compare.mjs"]
    review={
      "schema":"hamon.tastetable.common-suggestions.root-source-acceptance/v1",
      "started_at":started,"accepted_at":now(),"actor":"chatgpt:2d2d276bbccc:root",
      "status":"exact_product_source_and_independent_behavior_accepted_for_native_delivery",
      "source":{"repository":"Jacob-Met/tastetable","issue":72,"product":PRODUCT,"tree":TREE,"direct_parent":BASE,"baseline_tree":"71f2c5b144e2a54787cb92b37d6e639bbfef6ba6","baseline_leaves":818,"product_leaves":824,"unrelated_baseline_leaves_preserved":816,"changed_paths":custody["exact_eight_path_delta"],"evidence_only_prefix":"docs/receiving/common-suggestions-2d2d276b/"},
      "root_semantic_review":{
        "complete_new_module_ui_html_css_test_guide_read":True,
        "readme_append_and_complete_actual_index_anchor_read":True,
        "three_original_modules_read_and_byte_unchanged":True,
        "reviewed_source_pins":[raw_by_path[x] for x in reviewed_paths],
        "index_exact_complete_anchor":anchor.decode(),
        "index_receipt_fragment_explanation":"The earlier inverse insertion receipt used longest common prefix/suffix inside repeated link text. Root directly read the actual complete valid anchor and independently removed exactly its 116 bytes to recover the original index; no product defect or repair.",
        "findings":[
          "API admits exactly two through six dense own-indexed sources; string labels are bounded by UTF-8 bytes and saved text by two MiB before unchanged readWeekFile validation and the 500-pick consumer limit.",
          "JSON string encoding of the kind/id pair gives exact injective string identity. The first source determines group order; all matching duplicate occurrences retain source-index/native order with full snapshots and saved records.",
          "No trimming, case folding, Unicode normalization, name matching, inferred suitability, refreshed venue checking or shared-availability computation is introduced.",
          "The new API has no filesystem, network, storage, clock-now or random calls. Explicit saved-date parsing remains in the unchanged original modules. Full-value receiving separately checks frozen inputs, mutation and distinct result object graphs.",
          "UI selection/Clear/Remove generations retire stale results and invalidate late reads; a cancelled chooser is a no-op and a refused replacement preserves the previous accepted source. Pending reads disable comparison.",
          "Browser file size is checked before and after arrayBuffer; fatal UTF-8 decoding with ignoreBOM true preserves one BOM for original codec handling. Malformed/invalid/oversized input is refused through current status.",
          "File-derived display content uses textContent. Source cards and occurrence rows keep saved facts, source mode/week/notes/model messages, duplicates, dates and off-week state visible.",
          "Export is guarded by the current result and uses a fixed basename with UTF-8 JSON, two-space formatting and a final LF. Object URL failure leaves the current result available; temporary link and object URL cleanup is explicit.",
          "Print is guarded by the current result and invokes the existing browser print capability. CSS hides interactive controls and keeps source/result content; narrow layout uses wrapping and visible keyboard focus.",
          "The separate page and guide accurately explain local static serving, limits, saved-data review and absent guarantees. The only existing-file changes are the 464-byte README append and 116-byte anchor insertion."
        ]
      },
      "independent_api":{"freeze":references[2],"candidate_intake":references[3],"receipt":references[6],"accepted_full_value_cases":25,"refusal_cases":36,"passed":61,"failed":0,"candidate_exposed_before_freeze":False,"first_run_only":True,"pure_guard_scope":"Date without arguments/Date.now, Math.random, fetch and storage during calls; explicit original date parsing allowed. Filesystem and alternate effects assessed by source review, not claimed as dynamically intercepted."},
      "independent_browser":{"review":references[9],"freeze":references[10],"first_receipt":references[11],"capsule":references[12],"groups":7,"checks":77,"all_passed":True,"review_attribution":"production_custody executed the frozen native run, directly viewed ten first-run screenshots and the separate focused 390px screenshot; root read the full final browser review and complete receipt references.","physical_downloads":3,"pdf_scope":"Seven generated PDF pages were text-read; direct PDF pixel review and physical printer/dialog completion were not claimed.","controlled_boundaries":"Object URL throw, File.arrayBuffer rejection after actual read and delayed actual original bytes were explicit controlled injections, not OS permission failures or natural race occurrence.","focus_supplement_scope":"Separate empty-page narrow keyboard-focus visual receiving; no file selection, comparison, export or print success replay.","own_browser_and_server_cleanup_reported":True},
      "complete_source_custody":{"receipt":references[7],"seal":references[8],"all_824_physical_raw_git_bytes_exact":True,"all_index_blobs_and_modes_exact":True,"unique_git_blobs_independently_hashed":726,"metadata_before_after_identical":True,"root_reexecution":False},
      "author_evidence":{"capsule":references[16],"console_boundary":references[15],"reported_native_api_tests":12,"reported_native_test_failures":0,"ui_syntax_exit":0,"boundary":"Outer console echo raised cp1252 UnicodeEncodeError after durable native exit-zero test/syntax evidence. Boundary preserved, no success replay or product failure relabel. Earlier ordinary private-index restage/native Git transport boundaries remain in author capsule."},
      "first_failures_and_limits":["Initial controller write addressed nonexistent D:\\rootcheckpoints and returned ENOENT before any write or process. The verified estate-native root-checkpoints directory was then used; no source or behavior effect.","No independent API behavioral failure was observed in the first 61 cases.","The browser native command-quoting boundary occurred before Node began and is preserved in the separate browser capsule.","Read-only wrong public path observation is preserved in the browser review; no source conclusion was taken from it.","This acceptance seals prior behavior and current evidence bytes. It runs no candidate/author tests or browser behavior."],
      "receiving_effects":{"git_commands":0,"product_source_writes":0,"metadata_or_policy_changes":0,"behavior_replays":0,"service_launches":0,"thinkpad_writes":0,"github_actions_calls":0,"source_publications":0},
      "delivery_state":"Qualified for an evidence-only child preserving every product leaf and a usable native recipient package. No native recipient delivery, main adoption, hosted publication, PR or deployment is asserted by this receipt.",
      "references":references
    }
    acceptance=write_new(OUT/"ROOT-SOURCE-ACCEPTANCE.json",review)
    sources={}
    def add(p,rel):
        p=Path(p);assert rel not in sources and ".." not in Path(rel).parts
        sources[rel]=p
    for rel in ("PUBLIC-INTAKE-v1.json","ORACLE-FROZEN-v1.json","freeze-oracle-v1.mjs","receive-api-v1.mjs","CANDIDATE-INTAKE-v1.json","api-receiving-v1/receipt.json"):
        add(R/rel,"primary/independent/"+rel)
    for dirname in ("public","oracle-v1","candidate-v1","complete-source-binding-v1"):
        for p in sorted((R/dirname).rglob("*")):
            if p.is_file(): add(p,"primary/independent/"+p.relative_to(R).as_posix())
    for rel in ("FINAL-BROWSER-REVIEW-v1.json","BROWSER-FROZEN-v1.json","final-browser-seal-v1/MANIFEST.json","final-browser-seal-v1/SEALED.json"):
        add(R/"browser-receiving-v1"/rel,"primary/independent/browser-receiving-v1/"+rel)
    for rel in ("author-native-v1/controller-console-boundary.json","native-git-boundary-r1/receipt.json","worktree-index-r3/receipt.json"):
        add(A/rel,"primary/author-boundaries/"+rel)
    add(W/"tests/test_common_suggestions.mjs","primary/late-semantic-source/tests/test_common_suggestions.mjs")
    add(OUT/"ROOT-SOURCE-ACCEPTANCE.json","primary/root/ROOT-SOURCE-ACCEPTANCE.json")
    add(Path(__file__),"primary/root/seal-root-final-receiving-v1.py")
    entries=[]
    for rel,p in sorted(sources.items()):
        q=pin(p);entries.append({"path":rel,"native_source":str(p),"bytes":q["bytes"],"sha256":q["sha256"]})
    manifest={"schema":"hamon.tastetable.common-suggestions.root-api-primary-manifest/v1","at":now(),"product":PRODUCT,"purpose":"Root API, public/blindness and semantic/source acceptance primaries; the independently sealed browser and author capsules are separate companions.","private_oracle_custody":"Author may verify archive member names, lengths and hashes without semantically inspecting private expected-value content.","files":entries}
    manifest_pin=write_new(CAP/"MANIFEST.json",manifest)
    zip_path=CAP/"tastetable-common-root-api-v1.zip"
    with zipfile.ZipFile(zip_path,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for x in entries:
            b=sources[x["path"]].read_bytes()
            assert len(b)==x["bytes"] and sha(b)==x["sha256"]
            z.writestr(x["path"],b)
        z.write(CAP/"MANIFEST.json","MANIFEST.json")
    with zipfile.ZipFile(zip_path) as z:
        assert z.testzip() is None
        names=z.namelist()
        assert len(names)==len(set(names))==len(entries)+1
        assert set(names)==set(sources)|{"MANIFEST.json"}
        for x in entries:
            b=z.read(x["path"])
            assert len(b)==x["bytes"] and sha(b)==x["sha256"]
            assert b==sources[x["path"]].read_bytes()
        assert z.read("MANIFEST.json")==(CAP/"MANIFEST.json").read_bytes()
    for v in known: checked(*v)
    sealed=write_new(CAP/"SEALED.json",{"schema":"hamon.tastetable.common-suggestions.root-api-primary-sealed/v1","sealed_at":now(),"acceptance":acceptance,"manifest":manifest_pin,"capsule":pin(zip_path),"members":len(entries)+1,"primaries":len(entries),"primary_bytes":sum(x["bytes"] for x in entries),"all_member_bytes_match_manifest_and_native":True,"source_and_behavior_effects":review["receiving_effects"],"prior_evidence_byte_stable":True})
    print(json.dumps({"status":"sealed_and_accepted","acceptance":acceptance,"capsule":pin(zip_path),"manifest":manifest_pin,"seal":sealed,"members":len(entries)+1,"primaries":len(entries),"primary_bytes":sum(x["bytes"] for x in entries)},ensure_ascii=True))
except Exception as e:
    write_new(OUT/"first-boundary.json",{"at":now(),"started_at":started,"error":repr(e),"traceback":traceback.format_exc(),"effect_scope":"Native evidence receipt/capsule preparation only; no product, Git, behavior, service, central or publication calls."})
    raise
