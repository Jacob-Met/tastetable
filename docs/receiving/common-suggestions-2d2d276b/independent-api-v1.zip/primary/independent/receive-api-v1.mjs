import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import {fileURLToPath,pathToFileURL} from "node:url";
const root=path.dirname(fileURLToPath(import.meta.url)),out=path.join(root,"api-receiving-v1");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const pin=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
assert(!fs.existsSync(out),"Receiving destination exists: reconcile instead of replay.");fs.mkdirSync(out);
const write=(name,value)=>{const p=path.join(out,name);fs.writeFileSync(p,JSON.stringify(value,null,2)+"\n",{flag:"wx"});return pin(p);};
const startedAt=new Date().toISOString(),results=[];
const RealDate=Date,realRandom=Math.random,descriptors=new Map();
function freeze(v){if(v&&typeof v==="object"&&!Object.isFrozen(v)){Object.values(v).forEach(freeze);Object.freeze(v);}return v;}
function graph(v,set=new Set()){if(v&&typeof v==="object"&&!set.has(v)){set.add(v);Object.values(v).forEach(x=>graph(x,set));}return set;}
function deny(name){return ()=>{throw new Error("Forbidden effect during pure API: "+name);};}
function installPurity(){
 class ExplicitDate extends RealDate{constructor(...args){if(!args.length)throw new Error("Forbidden implicit clock");super(...args);}static now(){throw new Error("Forbidden Date.now");}}
 for(const [name,value] of [["Date",ExplicitDate],["fetch",deny("fetch")],["localStorage",new Proxy({}, {get:deny("localStorage"),set:deny("localStorage")})],["sessionStorage",new Proxy({}, {get:deny("sessionStorage"),set:deny("sessionStorage")})]]){
  descriptors.set(name,Object.getOwnPropertyDescriptor(globalThis,name));Object.defineProperty(globalThis,name,{configurable:true,writable:true,value});
 }Math.random=deny("Math.random");
}
function restorePurity(){Math.random=realRandom;for(const [name,d] of descriptors){if(d)Object.defineProperty(globalThis,name,d);else delete globalThis[name];}descriptors.clear();}
try{
 const freezePath=path.join(root,"ORACLE-FROZEN-v1.json"),frozen=JSON.parse(fs.readFileSync(freezePath,"utf8"));
 for(const f of [...frozen.files,frozen.generator,frozen.apiController,frozen.publicIntake,frozen.publicContract])assert.deepEqual(pin(f.path),f);
 const candidate=path.resolve(process.argv[2]),intake=path.join(root,"CANDIDATE-INTAKE-v1.json");
 const intakePin=pin(intake),candidatePin=pin(candidate);
 const accepted=JSON.parse(fs.readFileSync(path.join(root,"oracle-v1/accepted-cases.json"),"utf8"));
 const refused=JSON.parse(fs.readFileSync(path.join(root,"oracle-v1/refusal-cases.json"),"utf8"));
 const module=await import(pathToFileURL(candidate).href);assert.equal(typeof module.compareSavedSuggestions,"function");
 const compare=module.compareSavedSuggestions;
 for(const c of accepted){
  const input=structuredClone(c.entries),before=JSON.stringify(input);freeze(input);let actual,again,error;
  try{installPurity();actual=compare(input);again=compare(input);assert.deepEqual(actual,c.expected);assert.deepEqual(again,c.expected);assert.equal(JSON.stringify(input),before);const first=graph(actual);for(const obj of graph(again))assert(!first.has(obj),"Two API calls share an object reference");}
  catch(e){error={name:e.name,message:String(e.message).slice(0,6000),stack:String(e.stack).slice(0,12000)};}
  finally{restorePurity();}
  const row={id:c.id,group:"accepted-full-value-purity-independent-graphs",pass:!error,inputSha256:sha(Buffer.from(before)),expectedSha256:sha(Buffer.from(JSON.stringify(c.expected))),error:error??null};
  if(error&&actual!==undefined)row.actual=write("failed-"+results.length+"-actual.json",actual);
  if(!error)row.actualSha256=sha(Buffer.from(JSON.stringify(actual)));
  results.push(row);
 }
 for(const c of refused){
  let input;if(c.input.kind==="sparse"){input=Array(c.input.length);for(const [k,v] of Object.entries(c.input.entries))input[Number(k)]=structuredClone(v);}else input=structuredClone(c.input.value);
  freeze(input);let returned=false,error;
  try{installPurity();compare(input);returned=true;}catch(e){error={name:e.name,message:String(e.message).slice(0,6000)};}finally{restorePurity();}
  results.push({id:c.id,group:"refusal",pass:!returned&&!!error&&c.expectedErrorTypes.includes(error.name),returned,error:error??null,reason:c.reason});
 }
 const receipt={schema:"hamon.tastetable.common-suggestions.api-receiving/v1",startedAt,finishedAt:new Date().toISOString(),nativeNode:process.version,controller:pin(fileURLToPath(import.meta.url)),freeze:pin(freezePath),intake:intakePin,candidate:candidatePin,accepted:accepted.length,refused:refused.length,passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,results,limits:"Explicit Date parsing remains allowed for unchanged originals. Dynamic effect guards cover implicit Date/Date.now/Math.random/fetch/storage; complete source review separately assesses filesystem, alternate network and import effects. Object member order is immaterial; full values/types/array order and separate graphs are exact."};
 console.log(JSON.stringify({state:receipt.failed?"failed":"passed",receipt:write("receipt.json",receipt),passed:receipt.passed,failed:receipt.failed}));process.exitCode=receipt.failed?1:0;
}catch(error){restorePurity();write("first-boundary.json",{at:new Date().toISOString(),startedAt,name:error.name,message:error.message,stack:error.stack,results});throw error;}
