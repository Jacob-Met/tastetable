import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import {fileURLToPath} from "node:url";
import {readWeekFile,makeWeekFile} from "./public/baseline/static/week_file.mjs";
import {createWeekPlan,setPickDay} from "./public/baseline/static/week_plan.mjs";
import {savedWeekVisits} from "./public/baseline/static/week_compare.mjs";
const root=path.dirname(fileURLToPath(import.meta.url)), out=path.join(root,"oracle-v1");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const pin=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
const write=(name,value)=>{const p=path.join(out,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof value==="string"||Buffer.isBuffer(value)?value:JSON.stringify(value,null,2)+"\n",{flag:"wx"});return pin(p);};
assert(!fs.existsSync(out),"Oracle destination already exists: reconcile instead of replay.");
fs.mkdirSync(out);
const startedAt=new Date().toISOString(), MAX=2*1024*1024, encoder=new TextEncoder();
try {
 const manifest=JSON.parse(fs.readFileSync(path.join(root,"public","MANIFEST.json"),"utf8"));
 for(const f of manifest.files){const p=path.join(root,"public",...f.path.split("/"));const b=fs.readFileSync(p);assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);if(f.git_blob)assert.equal(crypto.createHash("sha1").update(Buffer.concat([Buffer.from("blob "+b.length+"\0"),b])).digest("hex"),f.git_blob);}
 const literal='<img src=x onerror="globalThis.__fileMarkupExecuted=1"> café & 梅';
 const counts={picks:17,with_qloo_entity_id:4,with_affinity_evidence:3,constraint_checked:2,unsafe_candidates_rejected:9};
 const pick=(id,day="Monday",kind="restaurant",extra={})=>({kind,entity_id:id,day,name:"Recorded "+id+" "+literal,why:"Original reason "+id+" "+literal,affinity:null,fallback:false,extra:{nested:[null,"kept",7]},...extra});
 function response(meals=[],outing=null,mode=true,tag="A"){
  return {plan:{meals,outing,notes:["Plan note "+tag+" "+literal],rejected:[{name:"Rejected "+literal,failed:[{constraint:"literal-check",status:"recorded",reason:"Not rerun "+literal}]}]},llm_only:{meals:[],outing:{name:"Unchecked "+literal,why:"Original text",day:"Sunday"}},comparison:{grounded:{...counts},llm_only:{...counts},constraints:["wheelchair","recorded-only "+literal]},trace:[{tool:"original_tool",result_summary:"literal "+tag,args:null},{tool:"scalar",result_summary:"retained",args:7},{tool:"array",result_summary:"retained",args:["x",null]}],mock:mode,model_message:"Recorded model message "+tag+" "+literal,unrelated_response_field:{tag,deep:[1,null,{"__literal":"unchanged"}]}};
 }
 function week({meals=[],outing=null,mode=true,tag="A",start="2026-10-05",days={},rawResponse=null,calendarId=null}={}){
  const resp=rawResponse===null?response(meals,outing,mode,tag):structuredClone(rawResponse);
  let state=createWeekPlan(resp,start);
  for(const [key,day] of Object.entries(days))state=setPickDay(state,key,day);
  const inputs={cuisines:["Cuban","literal "+literal],music:["jazz"],films:[],constraints:structuredClone(resp.comparison?.constraints??[]),city:"San José & 梅",extra_inputs:{tag,preserved:true}};
  return makeWeekFile({response:resp,inputs,state,receivedAt:"2026-10-05T08:00:00.000Z",calendarId},new Date("2026-10-06T09:10:11.000Z")).text;
 }
 const A=week({tag:"A",meals:[pick("B","Wednesday","restaurant",{affinity:0.25,fallback:true}),pick("A"),pick("B","Tuesday"),pick("only-A","Friday")],outing:pick("same-out","Sunday","outing"),days:{"pick-0":"Saturday","pick-2":null}});
 const B=week({tag:"B",mode:false,start:"2026-10-12",calendarId:"0123456789abcdef0123456789abcdef",meals:[pick("A","Thursday","restaurant",{name:"B's distinct A name "+literal,affinity:0}),pick("B","Monday","restaurant",{name:"B first occurrence",why:"Distinct B explanation",affinity:0.9}),pick("B","Friday","restaurant",{name:"B second occurrence",fallback:true}),pick("only-B","Wednesday")],outing:pick("same-out","Sunday","outing"),days:{"pick-0":"Tuesday","pick-4":null}});
 const empty=week({tag:"empty",mode:"unknown"});
 const pair=(text1,text2,label1="First & 梅.json",label2="Second café.json")=>[{label:label1,text:text1,ignored:{deep:[1,2]}},{label:label2,text:text2}];
 function expected(entries){
  const sources=entries.map(({label,text},index)=>({index,label,snapshot:readWeekFile(text)}));
  const visits=sources.map(s=>savedWeekVisits(s.snapshot)), seen=[], matches=[];
  for(const first of visits[0]){
   const kind=first.pick.kind, entityId=first.pick.entity_id;
   if(seen.some(k=>k[0]===kind&&k[1]===entityId))continue;
   seen.push([kind,entityId]);
   if(!visits.every(rows=>rows.some(v=>v.pick.kind===kind&&v.pick.entity_id===entityId)))continue;
   const occurrences=[];
   visits.forEach((rows,sourceIndex)=>rows.forEach(v=>{if(v.pick.kind===kind&&v.pick.entity_id===entityId)occurrences.push({sourceIndex,key:v.key,originalDay:v.originalDay,day:v.day,date:v.date,pick:v.pick});}));
   matches.push({kind,entityId,occurrences});
  }
  return {format:"tastetable.common-suggestions.v1",sources,matches,counts:{sources:sources.length,commonIdentities:matches.length,occurrences:matches.reduce((n,m)=>n+m.occurrences.length,0)}};
 }
 const accepted=[];
 function accept(id,entries){for(const e of entries){assert(encoder.encode(e.label).length<=1024);assert(encoder.encode(e.text).length<=MAX);assert(readWeekFile(e.text).state.picks.length<=500);}const want=expected(entries);accepted.push({id,entries,expected:want});return want;}
 const rich=accept("rich-duplicates-mixed-modes-weeks-offweek",pair(A,B));
 assert.deepEqual(rich.matches.map(m=>[m.kind,m.entityId,m.occurrences.length]),[["restaurant","B",4],["restaurant","A",2],["outing","same-out",2]]);
 assert.deepEqual(rich.counts,{sources:2,commonIdentities:3,occurrences:8});
 assert.deepEqual(rich.matches[0].occurrences.map(v=>[v.sourceIndex,v.key,v.day,v.date]),[[0,"pick-0","Saturday","2026-10-10"],[0,"pick-2",null,null],[1,"pick-1","Monday","2026-10-12"],[1,"pick-2","Friday","2026-10-16"]]);
 accept("reversed-first-source-order",pair(B,A));
 const just=(ids,extra={})=>week({meals:ids.map((id,i)=>pick(id,i%2?"Tuesday":"Monday")), ...extra});
 accept("same-id-different-kind-excluded",pair(just(["same"]),week({outing:pick("same","Sunday","outing")})));
 accept("same-id-both-kinds-distinct",pair(week({meals:[pick("same")],outing:pick("same","Sunday","outing")}),week({meals:[pick("same","Friday")],outing:pick("same","Tuesday","outing"),mode:false})));
 accept("case-space-and-unicode-exact",pair(just(["a","A"," a ","é","e\u0301","both"]),just(["A","a ","é","e\u0301","both"])));
 accept("no-unicode-normalization",pair(just(["é"]),just(["e\u0301"])));
 accept("no-trim-case-fold",pair(just(["Exact"," exact ","EXACT"]),just(["exact"])));
 accept("prototype-names-and-nul-identity",pair(just(["__proto__","constructor","hasOwnProperty","nul\u0000key"]),just(["nul\u0000key","hasOwnProperty","constructor","__proto__"])));
 accept("all-common-off-week",pair(week({meals:[pick("off")],days:{"pick-0":null}}),week({meals:[pick("off","Friday")],days:{"pick-0":null},start:"2026-10-12"})));
 accept("empty-versus-nonempty",pair(empty,A));
 accept("two-empty-success",pair(empty,empty));
 accept("duplicates-labels-are-positions",pair(A,A,"same.json","same.json"));
 accept("empty-labels",pair(A,B,"",""));
 accept("ascii-label-inclusive-1024",pair(A,B,"x".repeat(1024),"ok"));
 accept("utf8-label-inclusive-1024",pair(A,B,"é".repeat(512),"ok"));
 accept("label-ordinary-textencoder-surrogate",pair(A,B,"\ud800",""));
 accept("six-sources-all-common",Array.from({length:6},(_,i)=>({label:"slot "+i,text:just(["shared","local-"+i],{tag:"source-"+i,mode:i%3===0?true:i%3===1?false:"unknown"})})));
 accept("six-sources-one-empty",Array.from({length:6},(_,i)=>({label:"slot "+i,text:i===4?empty:just(["shared"])})));
 accept("five-sources-preserve-all-duplicates",Array.from({length:5},(_,i)=>({label:"dup",text:just(["dup","dup","own-"+i])})));
 accept("single-leading-bom",pair("\uFEFF"+A,B));
 const exact=A+" ".repeat(MAX-encoder.encode(A).length);
 accept("text-inclusive-two-mib",pair(exact,B));
 const many=week({tag:"500",meals:Array.from({length:499},(_,i)=>pick("many","Monday","restaurant",{name:"Original "+i})),outing:pick("many-out","Sunday","outing")});
 assert.equal(readWeekFile(many).state.picks.length,500);
 const manyWant=accept("pick-count-inclusive-500-with-outing",pair(many,many));assert.equal(manyWant.counts.occurrences,1000);
 const nativeResponse=JSON.parse(fs.readFileSync(path.join(root,"public/baseline/tests/fixtures/saved-week-response.json"),"utf8"));
 const nativeWeek=week({rawResponse:nativeResponse,tag:"native-original"});
 accept("complete-original-response-preserved",pair(nativeWeek,nativeWeek));
 const recover=JSON.parse(fs.readFileSync(path.join(root,"public/baseline/tests/fixtures/saved-week-recovery.json"),"utf8"));
 const nativeRecovery=[];
 for(const item of recover.cases){const text=week({rawResponse:item.response,tag:"native-recovery"});accept("original-recovery-"+item.case,pair(text,text));nativeRecovery.push({case:item.case,model_message:item.response.model_message??null,traceArgs:item.response.trace.map(v=>v.args),snapshotSha256:sha(Buffer.from(JSON.stringify(readWeekFile(text))))});}
 const refused=[];
 const reject=(id,input,reason)=>refused.push({id,input,reason,expectedErrorTypes:["TypeError","RangeError"]});
 reject("input-null",{kind:"literal",value:null},"dense Array required");
 reject("input-object",{kind:"literal",value:{}},"dense Array required");
 reject("input-string",{kind:"literal",value:"[]"},"dense Array required");
 for(const n of [0,1,7])reject("source-count-"+n,{kind:"literal",value:Array.from({length:n},()=>({label:"x",text:A}))},"2 through 6 required");
 reject("sparse-array",{kind:"sparse",length:2,entries:{"0":{label:"x",text:A}}},"every position must exist");
 for(const value of [null,0,"source",[]])reject("bad-entry-"+(value===null?"null":typeof value==="object"?"array":typeof value),{kind:"literal",value:[value,{label:"B",text:B}]},"entry objects with string fields");
 reject("missing-label",{kind:"literal",value:[{text:A},{label:"B",text:B}]},"label string required");
 reject("number-label",{kind:"literal",value:[{label:0,text:A},{label:"B",text:B}]},"label string required");
 reject("missing-text",{kind:"literal",value:[{label:"A"},{label:"B",text:B}]},"text string required");
 reject("object-text",{kind:"literal",value:[{label:"A",text:{}},{label:"B",text:B}]},"text string required");
 reject("ascii-label-over-1024",{kind:"literal",value:pair(A,B,"x".repeat(1025),"B")},"label UTF8 bound");
 reject("utf8-label-over-1024",{kind:"literal",value:pair(A,B,"é".repeat(513),"B")},"label UTF8 bound");
 reject("text-over-two-mib",{kind:"literal",value:pair(exact+" ",B)},"text UTF8 bound");
 const tooMany=week({meals:Array.from({length:500},()=>pick("many")),outing:pick("out","Sunday","outing")});
 assert.equal(readWeekFile(tooMany).state.picks.length,501);
 reject("pick-count-501-with-outing",{kind:"literal",value:pair(tooMany,B)},"new consumer pick bound; original codec admits 501");
 const originalRefusals=[];
 const envelope=JSON.parse(A);
 const mutate=(fn)=>{const v=structuredClone(envelope);fn(v);return JSON.stringify(v);};
 const badTexts=[
  ["invalid-json","{"],["wrong-format",mutate(v=>v.format="other")],
  ["noncanonical-timestamp",mutate(v=>v.savedAt="2026-10-06T09:10:11Z")],
  ["calendar-id",mutate(v=>v.calendarId="ABC")],["non-monday-week",mutate(v=>v.week.start="2026-10-06")],
  ["missing-assignment",mutate(v=>delete v.week.assignments["pick-0"])],
  ["extra-assignment",mutate(v=>v.week.assignments["pick-999"]="Monday")],
  ["assignment-day",mutate(v=>v.week.assignments["pick-0"]="monday")],
  ["pick-kind",mutate(v=>v.response.plan.meals[0].kind="venue")],
  ["blank-identity",mutate(v=>v.response.plan.meals[0].entity_id=" \t")],
  ["fallback-not-boolean",mutate(v=>v.response.plan.meals[0].fallback=0)],
  ["nonfinite-affinity",mutate(v=>v.response.plan.meals[0].affinity="REPLACE_NONFINITE").replace('"REPLACE_NONFINITE"',"1e400")],
  ["constraints-mismatch",mutate(v=>v.inputs.constraints.push("changed"))],
  ["missing-trace-args",mutate(v=>delete v.response.trace[0].args)],
  ["invalid-comparison-count",mutate(v=>v.response.comparison.grounded.picks=-1)],
  ["missing-llm-outing",mutate(v=>delete v.response.llm_only.outing)],
  ["two-boms","\uFEFF\uFEFF"+A]
 ];
 for(const [name,text] of badTexts){let error;try{readWeekFile(text);}catch(e){error={name:e.name,message:e.message};}assert(error,"Original unexpectedly admitted "+name);assert(["TypeError","RangeError"].includes(error.name));originalRefusals.push({id:name,error,textSha256:sha(Buffer.from(text))});reject("original-"+name,{kind:"literal",value:pair(A,text)},"unchanged codec refusal: "+error.name);}
 const browserFixtures=[
 ["First & 梅.json",A],["Second café.json",B],["Third unknown.json",just(["B","A","same-out"],{mode:"unknown"})],
 ["Empty source.json",empty],["Malformed replacement.json","{"],["Invalid UTF8.json",Buffer.from([0xff,0xfe,0x00,0x80])],
 ["Oversized replacement.json",exact+" "],["Exact two MiB.json",exact],["BOM source.json","\uFEFF"+A]
 ].map(([name,value])=>write("browser-inputs/"+name,value));
 write("accepted-cases.json",accepted);write("refusal-cases.json",refused);write("native-original-observations.json",{at:new Date().toISOString(),nativeNode:process.version,publicManifest:pin(path.join(root,"public/MANIFEST.json")),publicFilesVerified:manifest.files.length,originalModulesOnly:true,candidateExposed:false,richHandWitness:{counts:rich.counts,identities:rich.matches.map(m=>({kind:m.kind,entityId:m.entityId,occurrences:m.occurrences.length}))},nativeRecovery,originalRefusals,pickBound:{admittedByOriginal500:true,admittedByOriginal501:true,consumerRefuses501:true},browserFixtures});
 const protocol={
  schema:"hamon.tastetable.common-suggestions-independent-protocol/v1",frozenBeforeCandidate:true,
  derivation:"All expected snapshots are actual unchanged readWeekFile outputs and visits are actual unchanged savedWeekVisits outputs. Shared identities are independently derived by nested exact pair comparisons in first-source original order. A rich witness is hand-asserted. No author candidate, author's new fixtures or author's controls are oracle inputs.",
  acceptedCount:accepted.length,refusalCount:refused.length,
  api:["Load only received exact candidate closure after this seal. Every accepted case must deep-equal the complete frozen expected object: exact value types and arrays, with object key ordering immaterial. No dropped source fields or numeric tolerance.",
   "All refused descriptors must throw TypeError or RangeError and return no partial result. Keep original codec refusal observations separate from new consumer-bound refusals.",
   "Deep-freeze input entries and ignored extra objects; compare before/after. Deny clock-without-arguments, Date.now, Math.random, fetch and browser storage during API calls; explicit dates used by unchanged original codec remain allowed.",
   "Two calls on the same inputs must return fully independent object graphs. Original native state/picks may be frozen. Do not demand mutability. Full snapshot/occurrence values remain exact."],
  browserGroups:[
   {id:"initial-and-physical-intake",requirements:["Actual installed Chrome with new private profile and owned localhost listener.","Initial two numbered slots, labelled native file choosers/status/Clear, Add bound6 Remove minimum2, disabled Compare/download/print.","Set actual physical filenames/bytes, read status then Compare only all slots accepted with no pending read."]},
   {id:"rich-literal-result",requirements:["Compare physical First & 梅.json and Second café.json against exact frozen first rich case.","Counts2 sources3 identities8 occurrences, first appearance B,A,same-out; full distinct occurrences with dates/offweek, original days, affinity/fallback.","Expose source filename/position/week/timestamps/mock-live-unknown/original inputs and constraints/plan notes/nonempty model_message.","File-authored markup remains literal text. No authored DOM nodes, script execution or external requests; unsigned/heuristic/current suitability/availability/booking/advice context explicit."]},
   {id:"native-keyboard-export-print",requirements:["Actual Tab and Enter or Space activate primary controls with visible focus.","Physical downloaded JSON has fixed filename tastetable-common-suggestions.json, fatal-decodable UTF8, no BOM, exact JSON.stringify(parsed,null,2)+LF byte formatting; parsed value deep-equals frozen expected. JSON object member order itself is not contractually fixed.","One injected export preparation failure preserves current result and enables a successful retry; original and failed-attempt evidence both retained.","Current Print button invokes window.print exactly once under a receiving intercept; retired result cannot invoke it. Inspect print-media rendering with source disclosures complete and input controls hidden. No printer or dialog-completion claim."]},
   {id:"replacement-refusals-and-cancel",requirements:["Malformed JSON, invalid UTF8 and oversized physical replacements preserve prior accepted slot, show literal accessible error, and retire old comparison/download immediately.","Inject actual File/Blob read rejection for an unreadable selection; distinguish this controlled boundary from a filesystem permission failure. Preserve old accepted slot and retired result.","A canceled chooser change with empty FileList is a no-op. No new comparison is inferred without explicit Compare."]},
   {id:"source-lifecycle",requirements:["Clear removes accepted input and retires result; add/remove retires result; total slots stays2 through6.","Repeated physical file labels/contents remain separate source positions; successful empty intersection distinct from missing input.","Compare and export always refer to current accepted slot order; mixed unknown mode is displayed without promotion."]},
   {id:"asynchronous-retirement",requirements:["After candidate intake, adapt a receiving-only hook to delay the actual chosen physical bytes at the File/Blob/FileReader read boundary; do not alter file data or API result.","An older slow read cannot replace a newer accepted selection; Clear and Remove invalidate older reads; pending disables Compare. Release all controlled promises and verify no stale state revival.","Preserve exact adapter source and first failure; injected timing is not claimed as a naturally occurring OS race."]},
   {id:"narrow-print-and-cleanup",requirements:["Directly inspect390px screenshot: no page-level horizontal overflow, literal long IDs/text readable, native focus visible.","Capture and inspect print-media evidence showing complete sources and matches with file inputs hidden.","Retain runtime errors/network requests/storage observations; no external requests or automatic storage.","Terminate only owned Chrome/profile/listener resources and verify cleanup."]}
  ],
  selectionPolicy:"Use the smallest meaningful browser cases for each distinct boundary. Never rerun unaffected API/browser groups to cosmetically replace evidence. First failures remain primary; fixes get narrow successor receipts.",
  limits:"These are unsigned saved suggestion identities. The receiving does not rerun recommendations, provider checks, infer real venue identity, shared availability, completion, clinical suitability or main adoption."
 };
 write("PROTOCOL.json",protocol);
 const files=[];function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,entry.name);if(entry.isDirectory())walk(p);else files.push(pin(p));}}walk(out);
 const frozen={schema:"hamon.tastetable.common-suggestions.oracle-frozen/v1",startedAt,sealedAt:new Date().toISOString(),actor:"chatgpt:2d2d276bbccc:root",root,candidateExposed:false,baseline:"145d27981b3c5fe6afa72e205b42582fd72c7734",publicIntake:pin(path.join(root,"PUBLIC-INTAKE-v1.json")),publicContract:pin(path.join(root,"public/PUBLIC-CONTRACT-v1.md")),generator:pin(fileURLToPath(import.meta.url)),apiController:pin(path.join(root,"receive-api-v1.mjs")),accepted:accepted.length,refused:refused.length,browserGroups:protocol.browserGroups.length,files};
 fs.writeFileSync(path.join(root,"ORACLE-FROZEN-v1.json"),JSON.stringify(frozen,null,2)+"\n",{flag:"wx"});
 console.log(JSON.stringify({state:"frozen_before_candidate",receipt:pin(path.join(root,"ORACLE-FROZEN-v1.json")),accepted:accepted.length,refused:refused.length,browserGroups:protocol.browserGroups.length,files:files.length}));
} catch(error){write("first-boundary.json",{at:new Date().toISOString(),startedAt,name:error.name,message:error.message,stack:error.stack,candidateExposed:false,sealWritten:false});throw error;}
