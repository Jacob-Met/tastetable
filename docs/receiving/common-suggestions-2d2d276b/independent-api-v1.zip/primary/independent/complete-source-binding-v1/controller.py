import pathlib,json,hashlib,subprocess,datetime,os,zipfile,difflib,shutil
A=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-suggestions');R=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-independent');O=R/'complete-source-binding-v1';W=pathlib.Path(r'D:\ttc2d26');G=A/'canonical-source.git';EXE=r'C:\Program Files\Git\cmd\git.exe'
BASE='145d27981b3c5fe6afa72e205b42582fd72c7734';PROD='42bc23f796870b3b60ef15033d00d53628e27d59'
assert not O.exists();O.mkdir()
ENV=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='never')
commands=[];receipt={'utc_started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'behavior_or_author_test_executed':False}
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def js(p):return json.loads(p.read_bytes())
def save(name,obj):
 p=O/name
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
 return pin(p)
def git(args,work=False,data=None):
 argv=[EXE]+(['-C',str(W)] if work else ['--git-dir='+str(G)])+args
 r=subprocess.run(argv,input=data,capture_output=True,env=ENV)
 commands.append({'argv':argv,'exit':r.returncode,'stdout_bytes':len(r.stdout),'stdout_sha256':sha(r.stdout),'stderr':r.stderr.decode('utf-8','replace')})
 assert r.returncode==0,(args,r.returncode,r.stderr)
 return r.stdout
def tree(commit):
 out={}
 for row in git(['ls-tree','-rz','--full-tree',commit]).split(b'\0'):
  if not row:continue
  meta,p=row.split(b'\t',1);mode,kind,oid=meta.decode().split();assert kind=='blob'
  out[p.decode('utf-8')]={'path':p.decode('utf-8'),'mode':mode,'blob':oid}
 return out
def gitmeta():
 paths=[W/'.git',G/'config',G/'HEAD',G/'packed-refs',pathlib.Path.home()/'.gitconfig',pathlib.Path(r'C:\ProgramData\Git\config'),pathlib.Path(r'C:\Program Files\Git\etc\gitconfig')]
 wd=pathlib.Path(git(['rev-parse','--absolute-git-dir'],True).decode().strip())
 for p in [wd/'index',wd/'HEAD',wd/'config.worktree',wd/'commondir',wd/'gitdir']:paths.append(p)
 for dr in [G/'refs',G/'logs',wd/'logs',G/'hooks',pathlib.Path(r'C:\Users\jacob\.config\git\hooks')]:
  if dr.exists():
   for q in dr.rglob('*'):
    if q.is_file():paths.append(q)
 return {str(p):pin(p) if p.exists() and p.is_file() else {'path':str(p),'absent':True} for p in sorted(set(paths),key=str)}
try:
 assert subprocess.check_output(['hostname'],text=True).strip().upper()=='MSI'
 assert subprocess.check_output(['whoami'],text=True).strip().lower()=='msi\\jacob'
 assert pin(A/'product-custody-v1/receipt.json')['sha256']=='12730cf539f2412601e8a149f1d8f717c450c774ed60c66e30553d2dd5581f72'
 before=gitmeta();save('metadata-before.json',before)
 assert git(['rev-parse','refs/heads/work/2d2d276b-common-suggestions']).decode().strip()==PROD
 assert git(['rev-parse','HEAD'],True).decode().strip()==PROD
 assert git(['rev-parse',PROD+'^{tree}']).decode().strip()=='6a5c7432d5d05dc902db38971a17a9ac32635f17'
 assert git(['rev-parse',BASE+'^{tree}']).decode().strip()=='71f2c5b144e2a54787cb92b37d6e639bbfef6ba6'
 assert git(['show','-s','--format=%P',PROD]).decode().strip()==BASE
 base=tree(BASE);prod=tree(PROD);assert len(base)==818 and len(prod)==824
 changed=sorted(p for p in set(base)|set(prod) if base.get(p)!=prod.get(p))
 owned=sorted(['static/common_suggestions.mjs','static/common_suggestions_ui.mjs','static/common-suggestions.html','static/common_suggestions.css','tests/test_common_suggestions.mjs','docs/COMMON_SUGGESTIONS.md','static/index.html','README.md'])
 assert changed==owned,changed
 preserved=[p for p in base if p in prod and base[p]==prod[p]];assert len(preserved)==816
 ids=sorted({x['blob'] for x in [*base.values(),*prod.values()]});raw=git(['cat-file','--batch'],data=('\n'.join(ids)+'\n').encode())
 blobs={};at=0
 for oid in ids:
  end=raw.index(b'\n',at);got,kind,size=raw[at:end].decode().split();size=int(size);assert got==oid and kind=='blob'
  b=raw[end+1:end+1+size];assert len(b)==size and raw[end+1+size:end+2+size]==b'\n'
  assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
  blobs[oid]=b;at=end+size+2
 assert at==len(raw)
 def complete(t):
  return [dict(x,bytes=len(blobs[x['blob']]),sha256=sha(blobs[x['blob']])) for p,x in sorted(t.items())]
 bm=save('baseline-raw-manifest.json',complete(base));pm=save('product-raw-manifest.json',complete(prod))
 physical=[];links=[];mismatch=None
 for p,x in sorted(prod.items()):
  q=W/p;b=blobs[x['blob']]
  if x['mode']=='120000':
   target=b.decode('utf-8');literal=os.readlink(q) if q.is_symlink() else q.read_text(encoding='utf-8')
   links.append({'path':p,'git_target':target,'physical_literal':literal,'is_native_symlink':q.is_symlink(),'followed':False});assert literal==target
   data=literal.encode('utf-8')
  else:
   assert q.is_file() and not q.is_symlink(),p;data=q.read_bytes()
  if data!=b:
   mismatch={'path':p,'mode':x['mode'],'git_bytes':len(b),'git_sha256':sha(b),'physical_bytes':len(data),'physical_sha256':sha(data),'physical_crlf_count':data.count(b'\r\n'),'only_crlf_to_lf_equals_git':data.replace(b'\r\n',b'\n')==b};save('first-physical-mismatch.json',mismatch);raise AssertionError('physical raw Git mismatch '+p)
  physical.append(dict(x,bytes=len(data),sha256=sha(data)))
 physicalpin=save('physical-source-manifest.json',physical)
 idx={}
 for row in git(['ls-files','--stage','-z'],True).split(b'\0'):
  if not row:continue
  meta,p=row.split(b'\t',1);mode,oid,stage=meta.decode().split();assert stage=='0'
  idx[p.decode()]={'path':p.decode(),'mode':mode,'blob':oid}
 assert idx==prod,'index differs from complete product tree'
 old=blobs[base['README.md']['blob']];new=blobs[prod['README.md']['blob']]
 assert len(old)==20212 and new.startswith(old) and len(new)-len(old)==464
 readme={'original_bytes':len(old),'suffix_bytes':464,'suffix_sha256':sha(new[len(old):]),'suffix_utf8':new[len(old):].decode()}
 oldi=blobs[base['static/index.html']['blob']];newi=blobs[prod['static/index.html']['blob']]
 diffs=[op for op in difflib.SequenceMatcher(None,oldi,newi,autojunk=False).get_opcodes() if op[0]!='equal']
 assert len(diffs)==1 and diffs[0][0]=='insert',diffs
 _,i,j,k,l=diffs[0];insert=newi[k:l];assert len(insert)==116 and newi[:k]+newi[l:]==oldi
 index={'baseline_bytes':len(oldi),'insertion_offset':k,'insertion_bytes':116,'insertion_sha256':sha(insert),'insertion_utf8':insert.decode()}
 pub=js(R/'PUBLIC-INTAKE-v1.json');public=[]
 for p in ['README.md','static/index.html','static/week_file.mjs','static/week_plan.mjs','static/week_compare.mjs']:
  entry=next(x for x in pub['files'] if x['path']=='baseline/'+p);q=pathlib.Path(entry['received']['path']);data=q.read_bytes()
  assert data==blobs[base[p]['blob']] and sha(data)==entry['sha256'] and base[p]['mode']==entry['mode']
  if p not in ['README.md','static/index.html']:assert prod[p]==base[p]
  public.append({'git_path':p,'public':pin(q),'base':base[p],'product':prod[p]})
 packet=js(A/'candidate-source-v1/MANIFEST.json')
 for x in packet['files']:
  data=(A/'candidate-source-v1'/x['path']).read_bytes();assert data==blobs[prod[x['git_path']]['blob']]
  assert x['mode']==prod[x['git_path']]['mode'] and x['blob']==prod[x['git_path']]['blob'] and sha(data)==x['sha256']
  received=R/'browser-receiving-v1/candidate-source-v1'/x['path'];assert received.read_bytes()==data
 rawm=js(A/'product-custody-v1/RAW-SOURCE-MANIFEST.json');assert rawm==complete(prod),'author raw manifest exact'
 sourcezip=A/'product-custody-v1/complete-product-source-raw.zip';assert pin(sourcezip)['sha256']=='1323805579751f27df5b2413909ca31dd5b891208959837bc2fd22238628b9f6'
 with zipfile.ZipFile(sourcezip) as z:
  names=z.namelist();assert len(names)==len(set(names))==824
  if set(names)==set(prod):prefix=''
  elif set(names)=={'source/'+p for p in prod}:prefix='source/'
  else:raise AssertionError(('unexpected source ZIP paths',names[:8],len(names)))
  zipmodes={}
  for p,x in prod.items():
   data=z.read(prefix+p);assert data==blobs[x['blob']]
   info=z.getinfo(prefix+p);zipmodes[p]=oct((info.external_attr>>16)&0xffff)
 arch=A/'author-evidence-seal-v1/tastetable-common-author-native-v1.zip';assert pin(arch)['sha256']=='569de85ed1b576d53e6838473ae5673da5051755f9e52ae4d4713f4798d7de67'
 ampath=A/'author-evidence-seal-v1/MANIFEST.json';am=js(ampath);assert len(am['files'])==149
 boundaries=[]
 with zipfile.ZipFile(arch) as z:
  names=z.namelist();assert len(names)==len(set(names))==150;assert z.read('MANIFEST.json')==ampath.read_bytes()
  for x in am['files']:
   data=z.read(x['path']);assert len(data)==x['bytes'] and sha(data)==x['sha256'];assert (A/x['path']).read_bytes()==data
   if 'boundary' in x['path'].lower() or 'index' in x['path'].lower():boundaries.append(x)
 assert any('console-boundary' in x['path'] for x in boundaries),'cp1252 boundary missing'
 after=gitmeta();save('metadata-after.json',after);assert before==after,'native metadata changed during read'
 receipt.update({'status':'full_source_custody_accepted','product':PROD,'tree':'6a5c7432d5d05dc902db38971a17a9ac32635f17','parent':BASE,'baseline_tree':'71f2c5b144e2a54787cb92b37d6e639bbfef6ba6','baseline_leaves':818,'product_leaves':824,'unchanged_baseline_leaves':816,'exact_eight_path_delta':changed,'raw_git_blobs_independently_hashed':len(ids),'all_824_physical_bytes_exact':True,'no_newline_conversion_needed_or_performed':True,'all_index_modes_and_blobs_exact':True,'source_mode_scope':'Git tree and index modes are exact; no POSIX executable-bit interpretation is imposed on NTFS. Any symlink is compared as literal target without following.','literal_links':links,'readme':readme,'index':index,'public_original_binding':public,'candidate_packet_files':10,'author_raw_manifest':pin(A/'product-custody-v1/RAW-SOURCE-MANIFEST.json'),'complete_source_archive':dict(pin(sourcezip),members=824,all_bytes_exact=True),'author_capsule':dict(pin(arch),members=150,primaries=149,all_bytes_match_manifest_and_native=True),'author_boundary_records_preserved':boundaries,'metadata_before_after_identical':True,'manifests':[bm,pm,physicalpin],'author_receipt':pin(A/'product-custody-v1/receipt.json'),'browser_receipt':pin(R/'browser-receiving-v1/FINAL-BROWSER-REVIEW-v1.json'),'no_source_index_config_hooks_refs_mutation':True,'semantics_and_API_owned_by_root':True})
except Exception as e:
 receipt.update({'status':'stopped_with_boundary','error':repr(e)})
finally:
 receipt['utc_finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['commands']=commands
 shutil.copyfile(__file__,O/'controller.py')
 rp=save('receipt.json',receipt)
 sp=save('SEALED.json',{'utc':receipt['utc_finished'],'status':receipt['status'],'files':[pin(p) for p in sorted(O.iterdir()) if p.is_file()]})
 print(json.dumps({'receipt':rp,'seal':sp,'status':receipt['status'],'error':receipt.get('error')}))
 if receipt['status']!='full_source_custody_accepted':raise SystemExit(1)
