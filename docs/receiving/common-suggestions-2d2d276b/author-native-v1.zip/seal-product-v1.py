import os,sys,json,hashlib,subprocess,datetime,socket,zipfile
from pathlib import Path
ROOT=Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions")
WT=Path(r"D:\ttc2d26")
GIT=r"C:\Program Files\Git\cmd\git.exe"
BASE="145d27981b3c5fe6afa72e205b42582fd72c7734"
REF="refs/heads/work/2d2d276b-common-suggestions"
OUT=ROOT/"product-custody-v1"
PACKET=ROOT/"candidate-source-v1"
assert socket.gethostname().lower()=="msi"
assert subprocess.check_output(["whoami"],text=True).strip().lower()==r"msi\jacob"
assert not OUT.exists() and not PACKET.exists()
OUT.mkdir();PACKET.mkdir()
env=os.environ.copy();env.update(GIT_TERMINAL_PROMPT="0",GCM_INTERACTIVE="never",GIT_OPTIONAL_LOCKS="0")
def pin(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def git(*args,log=None):
 p=subprocess.run([GIT,"-C",str(WT),*args],capture_output=True,env=env)
 if log:
  (OUT/(log+".stdout")).write_bytes(p.stdout);(OUT/(log+".stderr")).write_bytes(p.stderr)
 assert p.returncode==0,(args,p.stderr.decode(errors="replace"))
 return p.stdout
def tree(ref):
 result={}
 for line in git("ls-tree","-r","-z",ref).split(b"\0"):
  if not line:continue
  meta,path=line.split(b"\t",1);mode,kind,sha=meta.decode().split()
  assert kind=="blob"
  result[path.decode()]={"mode":mode,"blob":sha}
 return result
def rawblob(sha):return git("cat-file","blob",sha)
gate=json.loads((ROOT/"author-native-v1/receipt.json").read_text(encoding="utf-8"))
assert gate["source_unchanged"] and all(r["exit"]==0 for r in gate["runs"])
outtext=(ROOT/"author-native-v1/api-tests.stdout").read_text(encoding="utf-8")
assert "\u2139 pass 12" in outtext and "\u2139 fail 0" in outtext and "\u2139 skipped 0" in outtext
boundary={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"observed_outer_pid":13232,
"boundary":"Author controller failed only while echoing already-persisted Unicode Node test stdout to cp1252 console.",
"error":"UnicodeEncodeError: 'charmap' codec can't encode character '\\u2714' in position 0: character maps to <undefined>",
"native_node_commands":[{"name":r["name"],"exit":r["exit"]} for r in gate["runs"]],
"preserved_receipt":pin(ROOT/"author-native-v1/receipt.json"),
"preserved_stdout":pin(ROOT/"author-native-v1/api-tests.stdout"),
"direct_receiving":"Original output physically read: 12 tests passed, zero failures/skips. Original source-before/source-after pins equal.",
"behavior_replayed":False}
(ROOT/"author-native-v1/controller-console-boundary.json").write_bytes((json.dumps(boundary,indent=2)+"\n").encode())
payload=json.loads((ROOT/"implementation-payload-v1.json").read_text(encoding="utf-8"))
owned=list(payload["files"])+["static/index.html","README.md"]
base=tree(BASE)
assert len(base)==818
assert git("rev-parse","HEAD").decode().strip()==BASE
for path,meta in base.items():
 if path not in owned:assert blob((WT/path).read_bytes())==meta["blob"],path
for path,p in gate["source_after"].items():assert pin(WT/path)==p,path
git("add","--",*owned,log="git-add")
staged=tree(git("write-tree").decode().strip())
changed={p for p in set(base)|set(staged) if base.get(p)!=staged.get(p)}
assert changed==set(owned),(changed,owned)
assert len(staged)==824
for p in owned:assert blob((WT/p).read_bytes())==staged[p]["blob"],p
msg=OUT/"commit-message.txt"
msg.write_bytes(b"Add common saved-suggestion comparison for multiple weeks\n\nImplement the frozen issue #72 consumer contract with unchanged saved-week\nadmission and date projection. Retain literal identities, duplicate occurrences,\nsource provenance and explicit file/result lifecycle.\n\nImplemented with ChatGPT assistance under Jacob Metoyer's standing estate\nproduct mandate. Native author API checks are separate from independent\nreceiving; browser acceptance and hosted publication are not claimed here.\n")
git("-c","user.name=Jacob Metoyer","-c","user.email=150724801+Jacob-Met@users.noreply.github.com",
    "commit","-F",str(msg),log="git-commit")
head=git("rev-parse","HEAD").decode().strip()
assert git("rev-parse",REF).decode().strip()==head
assert git("rev-parse","HEAD^").decode().strip()==BASE
assert git("status","--porcelain=v1","--untracked-files=all")==b""
full=tree(head);assert full==staged
for path,meta in full.items():assert blob((WT/path).read_bytes())==meta["blob"],path
readme_before=rawblob(base["README.md"]["blob"])
index_before=rawblob(base["static/index.html"]["blob"])
assert (WT/"README.md").read_bytes()==readme_before+payload["readmeAppend"].encode()
assert (WT/"static/index.html").read_bytes().replace(payload["indexAddition"].encode(),b"",1)==index_before
runtime=["static/common_suggestions.mjs","static/common_suggestions_ui.mjs","static/common-suggestions.html",
"static/common_suggestions.css","docs/COMMON_SUGGESTIONS.md","README.md","static/index.html",
"static/week_file.mjs","static/week_plan.mjs","static/week_compare.mjs"]
packetfiles=[]
for path in runtime:
 b=(WT/path).read_bytes();p=PACKET/"source"/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 packetfiles.append({"path":"source/"+path,"git_path":path,**full[path],**pin(p)})
metadata={"product_commit":head,"tree":git("rev-parse","HEAD^{tree}").decode().strip(),"parent":BASE,"ref":REF,
"canonical_bare":str(ROOT/"canonical-source.git"),"native_worktree":str(WT),
"baseline_leaves":818,"product_leaves":824,"unchanged_baseline_leaves":816,"owned_paths":owned,
"original_readme_bytes":len(readme_before),"readme_append_bytes":len(payload["readmeAppend"].encode()),
"index_addition_bytes":len(payload["indexAddition"].encode()),
"candidate_tests_fixtures_results_in_packet":False,"full_custody_is_separate":True}
(PACKET/"SOURCE.json").write_bytes((json.dumps(metadata,indent=2)+"\n").encode())
manifest={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":metadata,"files":packetfiles,
"source_metadata":pin(PACKET/"SOURCE.json"),
"public_contract":pin(ROOT/"public-v1/PUBLIC-CONTRACT-v1.md"),
"receiver_freeze":{"path":r"D:\hamon-ultra-2d2d276b-taste-common-independent\ORACLE-FROZEN-v1.json",
"sha256":"fc2ee8476a5c73102fd6db45f42148d4d6c65e70f6df78e5a67f9d25eeb8c875"}}
(PACKET/"MANIFEST.json").write_bytes((json.dumps(manifest,indent=2)+"\n").encode())
# Exact raw Git export. No checkout or git-archive text conversion.
paths=list(full);data=b"".join((full[path]["blob"]+"\n").encode() for path in paths)
proc=subprocess.run([GIT,"-C",str(WT),"cat-file","--batch"],input=data,capture_output=True,env=env)
assert proc.returncode==0,proc.stderr
raw=proc.stdout;cursor=0;rawmanifest=[]
with zipfile.ZipFile(OUT/"complete-product-source-raw.zip","x",zipfile.ZIP_DEFLATED) as archive:
 for path in paths:
  end=raw.index(b"\n",cursor);sha,kind,size=raw[cursor:end].decode().split();size=int(size)
  cursor=end+1;b=raw[cursor:cursor+size];cursor+=size
  assert raw[cursor:cursor+1]==b"\n";cursor+=1
  assert kind=="blob" and sha==full[path]["blob"] and blob(b)==sha
  info=zipfile.ZipInfo(path,(2026,10,9,7,30,0));info.compress_type=zipfile.ZIP_DEFLATED
  info.external_attr=(int(full[path]["mode"],8)<<16)
  archive.writestr(info,b)
  rawmanifest.append({"path":path,**full[path],"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
assert cursor==len(raw)
with zipfile.ZipFile(OUT/"complete-product-source-raw.zip") as archive:
 assert archive.namelist()==paths
 for row in rawmanifest:
  b=archive.read(row["path"]);assert len(b)==row["bytes"] and hashlib.sha256(b).hexdigest()==row["sha256"]
  assert (archive.getinfo(row["path"]).external_attr>>16)==int(row["mode"],8)
(OUT/"RAW-SOURCE-MANIFEST.json").write_bytes((json.dumps(rawmanifest,indent=2)+"\n").encode())
(OUT/"product.diff").write_bytes(git("diff","--binary",BASE,head,"--",*owned))
(OUT/"product-tree.json").write_bytes((json.dumps(full,indent=2)+"\n").encode())
git("bundle","create",str(OUT/"tastetable-common-suggestions.bundle"),REF,"^"+BASE,log="bundle-create")
git("bundle","verify",str(OUT/"tastetable-common-suggestions.bundle"),log="bundle-verify")
receipt={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source":metadata,
"all_824_worktree_files_are_raw_git":True,"full_raw_export_checked":824,
"packet_files":len(packetfiles),"packet_bytes":sum(x["bytes"] for x in packetfiles),
"manifest":pin(PACKET/"MANIFEST.json"),"source_archive":pin(OUT/"complete-product-source-raw.zip"),
"raw_source_manifest":pin(OUT/"RAW-SOURCE-MANIFEST.json"),"bundle":pin(OUT/"tastetable-common-suggestions.bundle"),
"diff":pin(OUT/"product.diff"),"author_gate":pin(ROOT/"author-native-v1/receipt.json"),
"author_console_boundary":pin(ROOT/"author-native-v1/controller-console-boundary.json"),
"controller":pin(Path(__file__)),"hosted_source_effect":False,"browser_run":False}
(OUT/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
seal={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"manifest":pin(PACKET/"MANIFEST.json"),
"source":metadata,"custody_receipt":pin(OUT/"receipt.json")}
(PACKET/"SEALED.json").write_bytes((json.dumps(seal,indent=2)+"\n").encode())
print(json.dumps({"head":head,"tree":metadata["tree"],"packet":str(PACKET),
"manifest":pin(PACKET/"MANIFEST.json"),"seal":pin(PACKET/"SEALED.json"),
"custody":str(OUT/"receipt.json"),"receipt":pin(OUT/"receipt.json"),
"raw_source":pin(OUT/"complete-product-source-raw.zip")},indent=2))
