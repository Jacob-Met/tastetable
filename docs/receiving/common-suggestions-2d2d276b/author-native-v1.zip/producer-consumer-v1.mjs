import {readFileSync,writeFileSync} from "node:fs";
import {pathToFileURL} from "node:url";
import assert from "node:assert/strict";
const root="D:/hamon-ultra-2d2d276b-taste-common-suggestions";
const {compareSavedSuggestions}=await import(pathToFileURL("D:/ttc2d26/static/common_suggestions.mjs"));
const {readWeekFile}=await import(pathToFileURL("D:/ttc2d26/static/week_file.mjs"));
const entries=[1,2].map(index=>({label:"Original native mock plan "+index,
 text:readFileSync(root+"/original-producer-r1/"+index+"/saved-week.json","utf8")}));
const before=JSON.stringify(entries), result=compareSavedSuggestions(entries);
assert.equal(JSON.stringify(entries),before);
for(let index=0;index<2;index++)assert.deepEqual(result.sources[index].snapshot,readWeekFile(entries[index].text));
assert.deepEqual(result.sources.map(source=>source.snapshot.state.sourceMode),["mock","mock"]);
assert.ok(result.matches.length>0,"Actual original producer pair must offer at least one shared recorded identity.");
const ownIdentities=entries.map(entry=>new Set(readWeekFile(entry.text).state.picks.map(({pick})=>JSON.stringify([pick.kind,pick.entity_id]))));
for(const match of result.matches) assert.ok(ownIdentities.every(ids=>ids.has(JSON.stringify([match.kind,match.entityId]))));
const output=JSON.stringify(result,null,2)+"\n";
writeFileSync(root+"/producer-consumer-v1/tastetable-common-suggestions.json",output,"utf8");
console.log(JSON.stringify({status:"passed",counts:result.counts,
inputBytes:entries.map(entry=>Buffer.byteLength(entry.text)),outputBytes:Buffer.byteLength(output),
modes:result.sources.map(source=>source.snapshot.state.sourceMode),
noNewProducerRun:true,noBrowserExecuted:true}));
