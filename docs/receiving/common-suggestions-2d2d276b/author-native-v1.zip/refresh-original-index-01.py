import pathlib,subprocess,json,hashlib,datetime,socket
assert socket.gethostname()=="MSI";r=pathlib.Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions");o=r/'worktree-index-r3';o.mkdir(exist_ok=False);w=pathlib.Path(r'D:\ttc2d26');g=r'C:\Program Files\Git\cmd\git.exe';ls=json.loads((r/'native-source-r1/UPSTREAM-TREE.json').read_text())
for x in ls:
 b=(w/x['path']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha']
assert not (w/'static/common_suggestions.mjs').exists()
def run(args,name):
 p=subprocess.run([g,'-C',str(w),*args],capture_output=True,timeout=40);(o/(name+'.stdout')).write_bytes(p.stdout);(o/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr);return p.stdout
run(['add','--all'],'restage-original');tree=run(['write-tree'],'tree').decode().strip();assert tree=='71f2c5b144e2a54787cb92b37d6e639bbfef6ba6';status=run(['status','--porcelain'],'status');assert not status
for x in ls:
 b=(w/x['path']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha']
a={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'Original raw 818 files and canonical tree exact; ordinary own-index staging refresh clears prior status entries','tree':tree,'raw_files':818,'clean':True,'source_edits':0,'candidate_exists':False,'global_or_repo_config_changes':0,'original_failure_retained':True};f=o/'receipt.json';f.write_bytes((json.dumps(a,indent=2)+'\n').encode());print(json.dumps({'receipt':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),**a}))
