import os,json,hashlib,subprocess,datetime,socket
from pathlib import Path
ROOT=Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions")
OUT=ROOT/"producer-consumer-v1"
assert socket.gethostname().lower()=="msi"
assert subprocess.check_output(["whoami"],text=True).strip().lower()==r"msi\jacob"
assert not OUT.exists();OUT.mkdir()
def pin(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
files=[ROOT/"original-producer-r1"/str(i)/"saved-week.json" for i in (1,2)]
sources=[Path(r"D:\ttc2d26")/"static"/name for name in ("common_suggestions.mjs","week_file.mjs","week_plan.mjs","week_compare.mjs")]
before={str(p):pin(p) for p in files+sources}
p=subprocess.run([r"C:\Program Files\nodejs\node.exe",str(ROOT/"producer-consumer-v1.mjs")],capture_output=True,timeout=30)
(OUT/"stdout.json").write_bytes(p.stdout);(OUT/"stderr.txt").write_bytes(p.stderr)
after={str(p):pin(p) for p in files+sources}
receipt={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host":socket.gethostname(),
"candidate":"42bc23f796870b3b60ef15033d00d53628e27d59","original_native_producer_receipt":pin(ROOT/"original-producer-r1/receipt.json"),
"scope":"One new consumer invocation of two already-created original CLI-to-saved-week mock outputs; no generator rerun.",
"exit":p.returncode,"inputs_sources_before":before,"inputs_sources_after":after,"unchanged":before==after,
"stdout":pin(OUT/"stdout.json"),"stderr":pin(OUT/"stderr.txt"),
"script":pin(ROOT/"producer-consumer-v1.mjs")}
if (OUT/"tastetable-common-suggestions.json").exists():receipt["report"]=pin(OUT/"tastetable-common-suggestions.json")
(OUT/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps({"receipt":str(OUT/"receipt.json"),**pin(OUT/"receipt.json"),"exit":p.returncode,
"result":p.stdout.decode(errors="replace"),"stderr":p.stderr.decode(errors="replace")},indent=2))
assert p.returncode==0 and before==after
