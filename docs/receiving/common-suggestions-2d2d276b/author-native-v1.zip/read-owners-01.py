import pathlib,subprocess,json,hashlib,datetime,shlex,socket
r=pathlib.Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions");o=r/"owner-read-r1";o.mkdir(exist_ok=False)
remote="import pathlib,json,socket,hashlib,sqlite3\nassert socket.gethostname()==\"hamon-thinkpad\"\nseen=0;omitted=[];hits=[];failed=[]\nfor p in pathlib.Path(\"/srv/hamon-estate/coord\").iterdir():\n if not p.is_file():continue\n try:\n  if p.stat().st_size>131072:omitted.append(str(p));continue\n  raw=p.read_bytes();seen+=1\n  if any(t in raw.lower() for t in (b\"tastetable\",b\"shared venue\",b\"common suggestion\",b\"common venue\")):hits.append({\"path\":str(p),\"bytes\":len(raw),\"sha256\":hashlib.sha256(raw).hexdigest(),\"content\":raw.decode(\"utf-8\")})\n except Exception as e:failed.append({\"path\":str(p),\"error\":str(e)})\ndb=sqlite3.connect(\"file:/var/lib/hamon/conscience.sqlite3?mode=ro\",uri=True);db.row_factory=sqlite3.Row;tip=db.execute(\"SELECT MAX(seq) FROM conscience_events\").fetchone()[0]\nevents=[dict(x) for x in db.execute(\"SELECT seq,actor,event_id,payload_ref,payload_sha256,event_hash,created_at FROM conscience_events WHERE seq>? AND (payload_ref LIKE ? OR payload_ref LIKE ? OR payload_ref LIKE ?) ORDER BY seq DESC LIMIT 80\",(max(0,tip-2000),\"%tastetable%\",\"%shared-venue%\",\"%common-suggestion%\"))];db.close()\nprint(json.dumps({\"host\":socket.gethostname(),\"records\":seen,\"omitted\":omitted,\"failed\":failed,\"hits\":hits,\"tip\":tip,\"events\":events,\"writes\":0}))"
assert socket.gethostname()=="MSI"
p=subprocess.run([r"C:\Program Files\Git\usr\bin\ssh.exe","-n","-T","-o","BatchMode=yes","-o","ConnectTimeout=8","-o","StrictHostKeyChecking=yes","thinkpad","sudo -n python3 -B -c "+shlex.quote(remote)],capture_output=True,timeout=35)
(o/"response.json").write_bytes(p.stdout);(o/"stderr.txt").write_bytes(p.stderr);assert p.returncode==0,p.stderr
j=json.loads(p.stdout);scopes=[]
for h in j["hits"]:
 try:obj=json.loads(h["content"])
 except ValueError:obj=None
 found=[]
 def walk(v):
  if isinstance(v,dict):
   desc=" ".join(str(v.get(k,"")) for k in ("repository","project","area","objective"))
   if "tastetable" in desc.lower():found.append({k:v[k] for k in ("worker_id","owner","repository","project","area","objective","scope","paths","state") if k in v})
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(obj)
 matching=[x.strip()[:1000] for x in h["content"].splitlines() if any(t in x.lower() for t in ("shared venue","common suggestion","common venue","group outing","several people"))]
 if found or matching:scopes.append({"path":h["path"],"scopes":found[:10],"matching":matching[:8]})
receipt={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"records":j["records"],"omitted":j["omitted"],"failed":j["failed"],"tip":j["tip"],"events":len(j["events"]),"response_bytes":len(p.stdout),"response_sha256":hashlib.sha256(p.stdout).hexdigest(),"remote_writes":0}
f=o/"receipt.json";f.write_bytes((json.dumps(receipt,indent=2)+"\n").encode());(o/"bounded-scopes.json").write_bytes((json.dumps(scopes,indent=2)+"\n").encode())
print(json.dumps({"receipt":str(f),"sha256":hashlib.sha256(f.read_bytes()).hexdigest(),**receipt,"scopes":scopes,"events":[{"seq":e["seq"],"actor":e["actor"],"payload":e["payload_ref"][:700]} for e in j["events"]]},ensure_ascii=True))
