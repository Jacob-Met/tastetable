import os,sys,json,hashlib,subprocess,datetime,socket,shutil
from pathlib import Path
ROOT=Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions")
WT=Path(r"D:\ttc2d26")
GIT=r"C:\Program Files\Git\cmd\git.exe"
BASE="145d27981b3c5fe6afa72e205b42582fd72c7734"
OUT=ROOT/"implementation-native-v1"
assert socket.gethostname().lower()=="msi"
assert subprocess.check_output(["whoami"],text=True).strip().lower()==r"msi\jacob"
assert not OUT.exists()
OUT.mkdir()
env=os.environ.copy()
env.update(GIT_TERMINAL_PROMPT="0",GCM_INTERACTIVE="never",GIT_OPTIONAL_LOCKS="0")
def git(*args):
 p=subprocess.run([GIT,"-C",str(WT),*args],capture_output=True,env=env)
 assert p.returncode==0,(args,p.stderr.decode(errors="replace"))
 return p.stdout
def pin(p):
 b=p.read_bytes()
 return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def blob(b):return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
assert git("rev-parse","HEAD").decode().strip()==BASE
assert git("status","--porcelain=v1","--untracked-files=all")==b""
records=[]
for rec in git("ls-tree","-r","-z",BASE).split(b"\0"):
 if not rec:continue
 meta,path=rec.split(b"\t",1);mode,typ,sha=meta.decode().split()
 records.append({"path":path.decode(),"mode":mode,"type":typ,"sha":sha})
assert len(records)==818
for item in records:assert blob((WT/item["path"]).read_bytes())==item["sha"],item["path"]
payload=json.loads((ROOT/"implementation-payload-v1.json").read_text(encoding="utf-8"))
assert len(payload["files"])==6
assert shutil.disk_usage(WT).free>100_000_000
for name in payload["files"]:assert not (WT/name).exists(),name
index=WT/"static/index.html"; ib=index.read_bytes()
anchor=payload["indexAnchor"].encode();addition=payload["indexAddition"].encode()
assert ib.count(anchor)==1
readme=WT/"README.md"; rb=readme.read_bytes()
for name,content in payload["files"].items():
 p=WT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content.encode("utf-8"))
index.write_bytes(ib.replace(anchor,anchor+addition))
readme.write_bytes(rb+payload["readmeAppend"].encode())
for item in records:
 if item["path"] not in ["static/index.html","README.md"]:
  assert blob((WT/item["path"]).read_bytes())==item["sha"],item["path"]
assert index.read_bytes().replace(addition,b"",1)==ib
assert readme.read_bytes()[:len(rb)]==rb
owned=list(payload["files"])+["static/index.html","README.md"]
receipt={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host":socket.gethostname(),"base":BASE,
"unchanged_baseline_leaves":816,"new_paths":6,"existing_additive_paths":2,
"source_files":{name:pin(WT/name) for name in owned},
"payload":pin(ROOT/"implementation-payload-v1.json"),
"original_readme_bytes":len(rb),"readme_append_bytes":len(payload["readmeAppend"].encode()),
"index_addition_bytes":len(addition),"controller":pin(Path(__file__)),"status":"written; not yet qualified"}
(OUT/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
(OUT/"git-status.txt").write_bytes(git("status","--porcelain=v1","--untracked-files=all"))
print(json.dumps({"receipt":str(OUT/"receipt.json"),**pin(OUT/"receipt.json"),"owned":owned},indent=2))
