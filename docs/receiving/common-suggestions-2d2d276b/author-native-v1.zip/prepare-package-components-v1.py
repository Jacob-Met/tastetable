import os,json,hashlib,socket,subprocess,datetime
from pathlib import Path
ROOT=Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions")
PACK=ROOT/"candidate-source-v1"
OUT=ROOT/"package-components-v1"
assert socket.gethostname().lower()=="msi"
assert subprocess.check_output(["whoami"],text=True).strip().lower()==r"msi\jacob"
assert not OUT.exists();OUT.mkdir()
def pin(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def cp(source,dest):
 assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True)
 dest.write_bytes(source.read_bytes());assert pin(source)==pin(dest)
manifest=json.loads((PACK/"MANIFEST.json").read_text(encoding="utf-8"))
runtime=[r for r in manifest["files"] if r["git_path"].startswith("static/") and r["git_path"]!="static/index.html"]
assert len(runtime)==7
for row in runtime:
 source=PACK/row["path"];assert pin(source)=={"bytes":row["bytes"],"sha256":row["sha256"]}
 cp(source,OUT/"app"/row["git_path"])
cp(PACK/"source/docs/COMMON_SUGGESTIONS.md",OUT/"COMMON_SUGGESTIONS.md")
cp(ROOT/"native-package-readme-draft.md",OUT/"README.md")
for i in (1,2):cp(ROOT/"original-producer-r1"/str(i)/"saved-week.json",OUT/"examples"/("original-native-mock-plan-"+str(i)+".json"))
cp(ROOT/"producer-consumer-v1/tastetable-common-suggestions.json",OUT/"examples/authored-comparison-report.json")
meta={"status":"private package components; independent receiving pending; not delivered or launched",
"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"product":manifest["source"],
"runtime_files":7,"examples":"Two original fixture-backed native CLI/saved-week outputs; no live-provider or receiving-input claim.",
"original_producer_receipt":pin(ROOT/"original-producer-r1/receipt.json"),
"authored_consumer_receipt":pin(ROOT/"producer-consumer-v1/receipt.json"),
"receiver_pass_claimed":False,"service_started":False,"downloads_copy_performed":False}
(OUT/"PREPARATION.json").write_bytes((json.dumps(meta,indent=2)+"\n").encode())
rows=[{"path":p.relative_to(OUT).as_posix(),**pin(p)} for p in sorted(OUT.rglob("*")) if p.is_file()]
(OUT/"MANIFEST.json").write_bytes((json.dumps(rows,indent=2)+"\n").encode())
print(json.dumps({"root":str(OUT),"files":len(rows),"bytes":sum(r["bytes"] for r in rows),"manifest":pin(OUT/"MANIFEST.json")},indent=2))
