import pathlib,subprocess,json,hashlib,datetime,socket,os
assert socket.gethostname()=="MSI";r=pathlib.Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions");o=r/'native-git-boundary-r1';o.mkdir(exist_ok=False);w=pathlib.Path(r'D:\ttc2d26');g=r'C:\Program Files\Git\cmd\git.exe';cfg={}
for key in ('core.hooksPath','core.autocrlf','commit.gpgsign'):
 q=subprocess.run([g,'-C',str(w),'config','--show-origin','--get',key],capture_output=True,timeout=10);assert q.returncode in (0,1);cfg[key]={'exit':q.returncode,'value':q.stdout.decode().strip()}
h=pathlib.Path(r'C:\Users\jacob\.config\git\hooks');items=[]
for f in h.iterdir():
 if f.is_file():
  b=f.read_bytes();(o/f.name).write_bytes(b);items.append({'name':f.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert [x['name'] for x in items]==['commit-msg'];a={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'effective_config':cfg,'hooks':items,'hook_review':'17-line commit-msg only validates attribution and conditionally invokes local git interpret-trailers. No pre/post commit or push hook present.','attribution_env_present':{k:bool(os.environ.get(k)) for k in ('HAMON_ZA_ID','HAMON_ZA','HAMON_GOAL_ID','HAMON_GOAL')},'mutation':'own evidence files only; no Git config or hook changes','actions':0};f=o/'receipt.json';f.write_bytes((json.dumps(a,indent=2)+'\n').encode());print(json.dumps({'receipt':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),**a}))
