import os,json,hashlib,subprocess,socket,datetime
from pathlib import Path
ROOT=Path(r"D:\hamon-ultra-2d2d276b-taste-common-suggestions")
WT=Path(r"D:\ttc2d26")
NODE=r"C:\Program Files\nodejs\node.exe"
OUT=ROOT/"author-native-v1"
assert socket.gethostname().lower()=="msi"
assert subprocess.check_output(["whoami"],text=True).strip().lower()==r"msi\jacob"
assert not OUT.exists();OUT.mkdir()
def pin(p):
 b=p.read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
files=list(json.loads((ROOT/"implementation-payload-v1.json").read_text(encoding="utf-8"))["files"])+["static/index.html","README.md","static/week_file.mjs","static/week_plan.mjs","static/week_compare.mjs"]
before={x:pin(WT/x) for x in files}
runs=[]
for name,args in [
 ("api-tests",[NODE,"--test","--test-concurrency=1","tests/test_common_suggestions.mjs"]),
 ("ui-syntax",[NODE,"--check","static/common_suggestions_ui.mjs"]),
]:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(args,cwd=WT,capture_output=True,timeout=90)
 (OUT/(name+".stdout")).write_bytes(p.stdout);(OUT/(name+".stderr")).write_bytes(p.stderr)
 runs.append({"name":name,"argv":args,"start":start,"exit":p.returncode,"stdout":pin(OUT/(name+".stdout")),"stderr":pin(OUT/(name+".stderr"))})
after={x:pin(WT/x) for x in files}
receipt={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"host":socket.gethostname(),
"node":subprocess.check_output([NODE,"--version"],text=True).strip(),
"source_before":before,"source_after":after,"source_unchanged":before==after,"runs":runs,
"browser_executed":False,"existing_suite_replayed":False}
(OUT/"receipt.json").write_bytes((json.dumps(receipt,indent=2)+"\n").encode())
print(json.dumps({"receipt":str(OUT/"receipt.json"),**pin(OUT/"receipt.json"),"runs":runs},indent=2))
print((OUT/"api-tests.stdout").read_text(encoding="utf-8"))
assert before==after
assert all(r["exit"]==0 for r in runs)
