import pathlib,json,subprocess,datetime
r=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-independent/browser-receiving-v1')
assert not (r/'receiving-r1').exists()
args=[r'C:\Program Files\nodejs\node.EXE',str(r/'browser-controller-v1.mjs')]
with (r/'browser-run-r1.stdout').open('xb') as so,(r/'browser-run-r1.stderr').open('xb') as se:
 p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 with (r/'browser-run-r1-STARTED.json').open('x',encoding='utf-8') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'argv':args},f,indent=2)
 print(json.dumps({'pid':p.pid,'started':True}),flush=True)
 code=p.wait()
print((r/'browser-run-r1.stdout').read_text(encoding='utf-8'))
print((r/'browser-run-r1.stderr').read_text(encoding='utf-8'))
print('EXIT',code)
