import pathlib,json,hashlib,zipfile,datetime,shutil,os
ROOT=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-independent')
H=ROOT/'browser-receiving-v1';S=H/'final-browser-seal-v1';assert not S.exists()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p,sha=None):
 if sha:assert pin(p)['sha256']==sha,str(p)
 return json.loads(p.read_bytes())
r=read(H/'receiving-r1/receipt.json','f4d7676efc995502410ad35e92ee26763e05c492fa33c4805c1ac24cfe8ce3a8')
f=read(H/'focus-visual-supplement-v1/receipt.json','53fb1cdfc83a8af83f30224210dbd0f6a2aa498d5507029bc75bc929b2cb89b8')
assert r['passed']==7 and r['failed']==0 and r['clean'] and not r.get('failure')
assert len(r['groups'])==7 and all(g['status']=='passed' for g in r['groups']) and all(c['pass'] for c in r['checks'])
assert f['passed'] and f['clean'] and f['initial']['files']==[0,0] and f['initial']['compareDisabled'] and f['initial']['resultHidden']
assert not r['network']['external'] and not r['network']['exceptions'] and not r['storage']
intake=read(H/'CANDIDATE-INTAKE-v1.json','a49dc3aeaf3570734ea42c0afccd6f48eac59204b7a305ffa46790e3711de260')
for x in intake['files']:
 p=pathlib.Path(x['received_path']);b=p.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['blob']
 author=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-suggestions/candidate-source-v1')/x['path'];assert author.read_bytes()==b
 if 'unchanged_original' in x:assert pin(pathlib.Path(x['unchanged_original']['path']))['sha256']==x['sha256']
expected=read(H/'UI-EXPECTED-v1.json','94d49556c441b73f087ef8588f1b7f620b7c0a8430d86a23931109781327139e')
for d,key in zip(r['downloads'],['rich','repeat','unknown']):
 p=pathlib.Path(d['file']['path']);assert pin(p)==d['file'];assert json.loads(p.read_bytes())==expected[key]
screens=r['screenshots']+[f['screenshot']]
assert len(screens)==10
for p in screens+[r['printPDF']]:assert pin(pathlib.Path(p['path']))==p
S.mkdir()
review={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actor':'chatgpt:2d2d276bbccc:production_custody','status':'exact_source_native_browser_receiving_accepted','candidate':intake['product'],'scope':'Independent browser receiving only; root owns API and full semantic/source acceptance. No delivery or publication is claimed.',
'root_oracle':pin(ROOT/'ORACLE-FROZEN-v1.json'),'controller_freeze':pin(H/'BROWSER-FROZEN-v1.json'),'source_intake':pin(H/'CANDIDATE-INTAKE-v1.json'),'source_final_readback':{'files':10,'candidate_unchanged':True,'three_original_runtime_modules_unchanged':True,'author_tests_fixtures_results_received':False},
'first_run':{'receipt':pin(H/'receiving-r1/receipt.json'),'groups':r['groups'],'checks':len(r['checks']),'all_passed':True,'browser':pin(H/'receiving-r1/browser/identity.json'),'server':pin(H/'receiving-r1/server-identity.json'),'all_successful_groups_executed_once':True},
'physical_downloads':r['downloads'],'download_review':'All three actual physical files have fixed suggested/native basename tastetable-common-suggestions.json in separate receiving directories. Fatal UTF8, no BOM and JSON.stringify(parsed,null,2)+LF byte contract were checked in the native browser controller. Complete parsed values equal original-derived expected rich, duplicate-position and current unknown-source results; exact size/SHA read back again during sealing.',
'controlled_boundaries':r['controlledBoundaries'],'visual_review':{'directly_viewed':screens,'observations':['Desktop physical inputs show accepted literal Unicode filenames with explicit mock/live week labels.','Rich source cards and all occurrence DOM values match frozen original-derived snapshots, retaining duplicate, off-week, nullable affinity and fallback values.','390px cards/controls/long literal markup wrap inside the viewport; source/match text remains readable; no authored image node or execution occurred.','Original narrow focus screenshot includes the focus ring at its lower viewport edge. The separate empty-page supplement centers the entire focused Add source button, preserving the original image.','Print-media screenshots expose source details, notes and model message as literal text.'],
'focus_only_supplement':pin(H/'focus-visual-supplement-v1/receipt.json'),'supplement_boundary':'Only empty-page native Tab and centered screenshot; no physical input, comparison, export or print replay. Original group outcomes untouched.'},
'print_review':{'pdf':r['printPDF'],'read_all_seven_pdf_pages':True,'pdf_text_content':'Both full source disclosures, three identities and all eight occurrences with original/current date, affinity/fallback and contextual limits were present. Input controls absent.','direct_pdf_pixel_review':False,'physical_printer_or_dialog_completion_claim':False},
'cleanup':{'first_run':r['cleanup'],'first_server':r['serverCleanup'],'focus_run':f['cleanup'],'focus_server':f['serverCleanup']},
'retained_boundaries':[{'type':'native command quoting','receipt':pin(H/'native-launch-boundary-v1.json'),'effect':'Initial cmd wrapper stopped before Node sealer began; Python argv transport corrected; no candidate behavior or expectation change.'},{'type':'read-only public path guess','path':str(ROOT/'public/static/week_compare.mjs'),'effect':'ENOENT only; subsequent reads used exact original path from verified intake. No file written or source conclusion from guessed path.'}],
'exclusions':['Private Chrome profiles/cache remain native in place and are excluded from capsule.','No author tests/fixtures/results, remote request, external service, ThinkPad write, LA7 effect, GitHub Actions or browser-success replay.']}
p=H/'FINAL-BROWSER-REVIEW-v1.json'
with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(review,out,ensure_ascii=False,indent=2);out.write('\n')
orig=S/'oracle-origin';orig.mkdir()
for rel in ['ORACLE-FROZEN-v1.json','PUBLIC-INTAKE-v1.json','oracle-v1/PROTOCOL.json','oracle-v1/accepted-cases.json']:
 src=ROOT/rel;dst=orig/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert src.read_bytes()==dst.read_bytes()
for src in (ROOT/'oracle-v1/browser-inputs').iterdir():
 if src.is_file():
  dst=orig/'oracle-v1/browser-inputs'/src.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert src.read_bytes()==dst.read_bytes()
for x in intake['files']:
 if 'unchanged_original' in x:
  src=pathlib.Path(x['unchanged_original']['path']);dst=orig/'unchanged-original'/src.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert src.read_bytes()==dst.read_bytes()
scripts=S/'native-launch-controllers';scripts.mkdir()
for n in ['taste-browser-intake-2d2d-v1.py','taste-browser-mechanics-2d2d-v1.py','taste-browser-seal-launch.py','taste-browser-run-r1.py','taste-focus-visual-v1.py','taste-browser-final-seal-v1.py']:
 src=pathlib.Path(r'C:\Users\jacob\AppData\Local\Temp')/n
 if src.exists():shutil.copyfile(src,scripts/n)
records=[];payload=[]
for root,dirs,files in os.walk(H,followlinks=False):
 dirs[:]=[d for d in dirs if d not in ['profile','final-browser-seal-v1']]
 for name in files:
  q=pathlib.Path(root)/name;assert not q.is_symlink();rel='browser/'+q.relative_to(H).as_posix();payload.append((rel,q))
for root,dirs,files in os.walk(S,followlinks=False):
 for name in files:
  q=pathlib.Path(root)/name;rel=q.relative_to(S).as_posix();payload.append((rel,q))
for rel,q in sorted(payload):
 x=pin(q);records.append({'path':rel,'native_path':str(q),'bytes':x['bytes'],'sha256':x['sha256']})
assert len({x['path'] for x in records})==len(records)
m={'schema':'hamon.taste.browser.capsule.v1','utc':review['utc'],'files':records,'members':len(records),'primary_bytes':sum(x['bytes'] for x in records),'profile_excluded':True,'source_product':'42bc23f796870b3b60ef15033d00d53628e27d59'}
mp=S/'MANIFEST.json';mp.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
zp=S/'taste-common-native-browser-v1.zip'
with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel,q in sorted(payload):z.write(q,rel)
 z.write(mp,'MANIFEST.json')
with zipfile.ZipFile(zp) as z:
 names=z.namelist();assert len(names)==len(set(names))==len(records)+1
 assert z.read('MANIFEST.json')==mp.read_bytes()
 for x in records:
  b=z.read(x['path']);assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
seal={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review':pin(p),'archive':pin(zp),'manifest':pin(mp),'members':len(records)+1,'all_members_verified':True,'primary_bytes':m['primary_bytes'],'seven_groups_passed_once':True,'checks':len(r['checks']),'physical_downloads':3,'screenshots_directly_viewed':10,'focus_supplement_separate':True,'all_owned_processes_listeners_clean':True}
sp=S/'SEALED.json';sp.write_text(json.dumps(seal,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'review':pin(p),'archive':pin(zp),'manifest':pin(mp),'seal':pin(sp),'members':len(records)+1,'checks':len(r['checks'])}))
