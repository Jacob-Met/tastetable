import pathlib,json,subprocess,hashlib,datetime
r=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-independent/browser-receiving-v1')
assert not (r/'BROWSER-FROZEN-v1.json').exists()
p=r/'native-launch-boundary-v1.json'
with p.open('x',encoding='utf-8') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior_outer_pid':82756,'boundary':'cmd wrapper stripped leading executable quotation; C:\\Program not recognized; Node sealer never started','candidate_behavior_executed':False,'correction':'Python subprocess argv with native exact executable; no source or predicate change'},f,indent=2)
args=[r'C:\Program Files\nodejs\node.EXE',str(r/'seal-browser-v1.mjs')]
c=subprocess.run(args,capture_output=True)
(r/'seal-browser-launch.stdout').write_bytes(c.stdout);(r/'seal-browser-launch.stderr').write_bytes(c.stderr)
print(c.stdout.decode('utf-8',errors='replace'));print(c.stderr.decode('utf-8',errors='replace'));print('EXIT',c.returncode)
