import pathlib,json,subprocess,datetime,hashlib
r=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-independent/browser-receiving-v1')
assert not (r/'focus-visual-supplement-v1').exists()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert pin(r/'receiving-r1/receipt.json')['sha256']=='f4d7676efc995502410ad35e92ee26763e05c492fa33c4805c1ac24cfe8ce3a8'
args=[r'C:\Program Files\nodejs\node.EXE',str(r/'focus-visual-v1.mjs')]
syntax=subprocess.run([args[0],'--check',args[1]],capture_output=True);assert syntax.returncode==0,syntax.stderr
with (r/'FOCUS-VISUAL-FROZEN-v1.json').open('x',encoding='utf-8') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script':pin(r/'focus-visual-v1.mjs'),'driver':pin(r/'native-http-browser-driver-v1.mjs'),'mechanics':pin(r/'browser-mechanics-v1.mjs'),'prior':pin(r/'receiving-r1/receipt.json'),'predicate':'Centered full button and keyboard outline in 390px empty initial page; no input/compare/download/print action'},f,indent=2)
with (r/'focus-visual.stdout').open('xb') as so,(r/'focus-visual.stderr').open('xb') as se:
 p=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=so,stderr=se);print(json.dumps({'pid':p.pid}),flush=True);code=p.wait()
print((r/'focus-visual.stdout').read_text());print((r/'focus-visual.stderr').read_text());print('EXIT',code)
