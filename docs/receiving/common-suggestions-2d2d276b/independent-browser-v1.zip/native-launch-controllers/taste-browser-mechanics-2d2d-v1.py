import json,hashlib,subprocess,socket,shutil
from pathlib import Path
R=Path(r"D:\hamon-ultra-2d2d276b-taste-common-independent")
O=R/"browser-receiving-v1"
assert socket.gethostname().upper()=="MSI"
assert subprocess.check_output(["whoami"],text=True).strip().lower()==r"msi\jacob"
O.mkdir(exist_ok=False)
f=R/"ORACLE-FROZEN-v1.json";assert hashlib.sha256(f.read_bytes()).hexdigest()=="fc2ee8476a5c73102fd6db45f42148d4d6c65e70f6df78e5a67f9d25eeb8c875"
freeze=json.loads(f.read_bytes())
for x in freeze["files"]:
 p=Path(x["path"]);b=p.read_bytes();assert len(b)==x["bytes"] and hashlib.sha256(b).hexdigest()==x["sha256"]
src=Path(r"D:\hamon-ultra-2d2d276b-uci-joint-coverage-independent\native-file-browser-driver-v2.mjs")
b=src.read_bytes();assert hashlib.sha256(b).hexdigest()=="63570fa93e6757f5de3d60639ccf50899d16ed8aa8627b086da565f077e272f9"
(O/"inherited-native-file-driver-v2.mjs").write_bytes(b)
t=b.decode()
pairs=[
("startNative({root,out,allowedFileRoot})","startNative({root,out,allowedOrigin})"),
("const allowedURL=pathToFileURL(path.resolve(allowedFileRoot)+path.sep).href;","const allowedURL=allowedOrigin+'/';need(/^http:\\/\\/127\\.0\\.0\\.1:\\d+$/.test(allowedOrigin),'owned local origin');"),
("noStaticServerAllocated:true","staticServerOwnedByController:true"),
("allowedFileRoot,allowedURL","allowedOrigin,allowedURL"),
("async openFile(file){need(pathToFileURL(file).href.startsWith(allowedURL),'outside owned report root');await page.send('Page.navigate',{url:pathToFileURL(file).href});const until=Date.now()+15000;while(!(await page.evaluate(\"document.readyState==='complete'&&location.href===\"+JSON.stringify(pathToFileURL(file).href)))){need(Date.now()<until,'direct file load');await delay(100);}}",
"async openURL(url){need(new URL(url).origin===allowedOrigin,'outside owned local origin');await page.send('Page.navigate',{url});const until=Date.now()+15000;while(!(await page.evaluate(\"document.readyState==='complete'&&location.href===\"+JSON.stringify(url)))){need(Date.now()<until,'owned local page load');await delay(100);}}")
]
for a,c in pairs:assert t.count(a)==1,a;t=t.replace(a,c)
(O/"native-http-browser-driver-v1.mjs").write_text(t,encoding="utf-8",newline="\n")
(O/"PROTOCOL-v1.json").write_bytes((R/"oracle-v1/PROTOCOL.json").read_bytes())
plan={"parentFreeze":str(f),"parentFreezeSHA256":hashlib.sha256(f.read_bytes()).hexdigest(),"candidateSourceSeen":False,"browserGroups":freeze["browserGroups"],"completeRootOracleFilesVerified":len(freeze["files"]),"staticServer":"Loopback127.0.0.1 ephemeral port, allowlisted exact candidate source closure only; no bind before candidate/controller seal.","Chrome":"Private profile within new receiving-r1 only; exact executable/profile/native identity and listener PID observations; no browser launched in preparation.","readHooks":"Receiver-only File/Blob promise rejection and controlled delay adapter, retaining actual physical input bytes. Candidate read boundary will be bound after source read and before execution.","expectedValues":"Root frozen accepted-cases.json only. No candidate result or author fixture is used to derive expected results.","readiness":"mechanics_preparation_only","node":shutil.which("node"),"preparationPID":__import__("os").getpid()}
(O/"PREPARATION-v1.json").write_text(json.dumps(plan,indent=2)+"\n",encoding="utf-8")
print(json.dumps(plan))
