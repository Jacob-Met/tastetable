import pathlib,json,hashlib,subprocess,datetime
R=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-independent')
D=R/'browser-receiving-v1'
A=pathlib.Path(r'D:\hamon-ultra-2d2d276b-taste-common-suggestions/candidate-source-v1')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert subprocess.check_output(['hostname'],text=True).strip().upper()=='MSI'
assert subprocess.check_output(['whoami'],text=True).strip().lower()=='msi\\jacob'
assert pin(A/'MANIFEST.json')['sha256']=='95cceb5a59cb65807388bca0e6385b28ac3ab54cb8b2a3a7f67c0cda149fc94b'
assert pin(A/'SEALED.json')['sha256']=='26a26ce89fd75d8f828f33f06314b895dbb6f495cd534a62174d1d286ded108a'
m=json.loads((A/'MANIFEST.json').read_bytes());o=D/'candidate-source-v1';assert not o.exists();o.mkdir()
orig={}
for p in (R/'public').rglob('*'):
 if p.is_file():orig.setdefault(p.name,[]).append(p)
rows=[]
for x in m['files']:
 b=(A/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['blob']
 p=o/x['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.read_bytes()==b
 row=dict(x,received_path=str(p))
 if p.name in ('week_file.mjs','week_plan.mjs','week_compare.mjs'):
  matches=[q for q in orig.get(p.name,[]) if q.read_bytes()==b];assert matches,(p,orig.keys());row['unchanged_original']=pin(matches[0])
 rows.append(row)
for f in ('MANIFEST.json','SEALED.json'):
 (o/f).write_bytes((A/f).read_bytes())
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'product':m['source'],'frozen_oracle':pin(R/'ORACLE-FROZEN-v1.json'),'files':rows,'original_runtime_count':3,'author_tests_fixtures_results_received':False,'behavior_executed':False}
p=D/'CANDIDATE-INTAKE-v1.json';p.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(pin(p)))
cases=json.loads((R/'oracle-v1/accepted-cases.json').read_bytes())
print(json.dumps([{'id':c['id'],'labels':[e['label'] for e in c['entries']],'counts':c['expected']['counts']} for c in cases],ensure_ascii=True))
