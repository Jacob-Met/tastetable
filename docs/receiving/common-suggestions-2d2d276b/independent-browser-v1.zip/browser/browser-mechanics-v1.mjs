import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {spawnSync} from 'node:child_process';
import {need,delay,pin,write,sha} from './native-http-browser-driver-v1.mjs';
export async function startServer({source,out,manifest}) {
 const files=new Map(manifest.files.filter(x=>x.git_path.startsWith('static/')).map(x=>['/'+x.git_path,{...x,file:path.join(source,x.git_path)}]));
 const requests=[];let port;
 const server=http.createServer((req,res)=>{
  const u=new URL(req.url,'http://127.0.0.1');const row=files.get(u.pathname);
  if(u.pathname==='/favicon.ico'){requests.push({path:u.pathname,status:204});res.writeHead(204);res.end();return;}
  if(!row||req.method!=='GET'){requests.push({path:u.pathname,status:404});res.writeHead(404);res.end();return;}
  const b=fs.readFileSync(row.file);need(sha(b)===row.sha256,'served candidate bytes changed '+row.git_path);
  requests.push({path:u.pathname,bytes:b.length,sha256:sha(b),status:200});
  res.writeHead(200,{'Content-Type':row.file.endsWith('.mjs')?'text/javascript;charset=utf-8':row.file.endsWith('.css')?'text/css;charset=utf-8':'text/html;charset=utf-8','Cache-Control':'no-store'});res.end(b);
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
 port=server.address().port;
 const observe=()=>spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command','@(Get-NetTCPConnection -State Listen -LocalPort '+port+' -ErrorAction SilentlyContinue)|Select-Object LocalAddress,LocalPort,OwningProcess|ConvertTo-Json -Compress'],{encoding:'utf8',timeout:15000});
 const p=observe();const listeners=p.stdout.trim()?JSON.parse(p.stdout):null;const list=Array.isArray(listeners)?listeners:[listeners];
 need(p.status===0&&list.some(x=>x?.OwningProcess===process.pid&&x.LocalAddress==='127.0.0.1'),'owned static listener identity');
 const identity={at:new Date().toISOString(),pid:process.pid,port,origin:'http://127.0.0.1:'+port,source,allowed:[...files.keys()],nativeListeners:listeners};
 write(path.join(out,'server-identity.json'),JSON.stringify(identity,null,2)+'\n');
 return {origin:identity.origin,identity,requests,async close(){await new Promise(resolve=>server.close(resolve));const p=observe();const remaining=p.stdout.trim()?JSON.parse(p.stdout):null;const result={at:new Date().toISOString(),pid:process.pid,port,remaining,observationExit:p.status,requests};write(path.join(out,'server-cleanup.json'),JSON.stringify(result,null,2)+'\n');return result;}};
}
export const hookSource=String.raw`(()=>{
 const r=window.__receiving={printCalls:0,readStarts:[],held:[],holdName:null,failReadName:null,failExport:false,exports:[],released:[]};
 window.print=()=>{r.printCalls++;};
 const original=File.prototype.arrayBuffer;
 File.prototype.arrayBuffer=function(...args){
  const name=this.name,hold=name===r.holdName,fail=name===r.failReadName;
  if(hold)r.holdName=null;if(fail)r.failReadName=null;
  r.readStarts.push({name,size:this.size,hold,fail});
  const p=original.apply(this,args);
  if(fail)return p.then(()=>{throw new Error('Independent controlled File.arrayBuffer rejection');});
  if(hold)return p.then(bytes=>new Promise(resolve=>{r.held.push({name,bytes:bytes.byteLength,release:()=>{r.released.push({name,bytes:bytes.byteLength});resolve(bytes);}});}));
  return p;
 };
 r.release=()=>{for(const item of r.held.splice(0))item.release();};
 const create=URL.createObjectURL.bind(URL);
 URL.createObjectURL=function(blob){
  if(r.failExport){r.failExport=false;throw new Error('Independent controlled export preparation refusal');}
  const item={type:blob.type,size:blob.size,text:null};r.exports.push(item);blob.text().then(s=>item.text=s);return create(blob);
 };
})();`;
export async function wait(page,expr,label,ms=12000){const end=Date.now()+ms;while(true){if(await page.evaluate(expr))return;need(Date.now()<end,'wait failed: '+label);await delay(80);}}
export async function click(b,selector){const rect=await b.page.evaluate('(()=>{const n=document.querySelector('+JSON.stringify(selector)+');if(!n)throw new Error("missing control");n.scrollIntoView({block:"center"});const r=n.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2,disabled:!!n.disabled};})()');need(!rect.disabled,'cannot activate disabled '+selector);await b.page.send('Input.dispatchMouseEvent',{type:'mousePressed',x:rect.x,y:rect.y,button:'left',clickCount:1});await b.page.send('Input.dispatchMouseEvent',{type:'mouseReleased',x:rect.x,y:rect.y,button:'left',clickCount:1});}
export async function physical(b,index,file){
 const r=await b.page.send('Runtime.evaluate',{expression:'document.querySelectorAll("#source-slots input[type=file]")['+index+']'});
 need(r.result.objectId,'native file input index '+index);
 await b.page.send('DOM.setFileInputFiles',{objectId:r.result.objectId,files:file?[file]:[]});
 await b.page.send('Runtime.releaseObject',{objectId:r.result.objectId});
}
export async function tabTo(b,selector){
 for(let n=0;n<40;n++){await b.key('Tab');if(await b.page.evaluate('document.activeElement===document.querySelector('+JSON.stringify(selector)+')')){
  return await b.page.evaluate('(()=>{const n=document.activeElement,r=getComputedStyle(n);return {id:n.id,text:n.textContent,focusVisible:n.matches(":focus-visible"),outline:r.outline,outlineWidth:r.outlineWidth};})()');
 }}throw new Error('Tab did not reach '+selector);
}
export async function downloaded(b,out,label,activate){
 const dir=path.join(out,'physical-'+label);fs.mkdirSync(dir);const count=b.downloads.length;
 await b.browser.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:dir,eventsEnabled:true});
 await activate();
 const end=Date.now()+15000;let event;
 while(true){event=b.downloads.slice(count).find(x=>x.suggestedFilename==='tastetable-common-suggestions.json');if(event&&b.progress.some(x=>x.guid===event.guid&&x.state==='completed')&&fs.existsSync(path.join(dir,event.suggestedFilename)))break;need(Date.now()<end,'physical current download '+label);await delay(80);}
 const file=pin(path.join(dir,event.suggestedFilename));const bytes=fs.readFileSync(file.path),text=new TextDecoder('utf-8',{fatal:true}).decode(bytes),parsed=JSON.parse(text);
 need(!(bytes[0]===239&&bytes[1]===187&&bytes[2]===191),'download BOM');need(text===JSON.stringify(parsed,null,2)+'\n','download pretty JSON and final LF');
 return {file,event,progress:b.progress.filter(x=>x.guid===event.guid),parsed};
}
