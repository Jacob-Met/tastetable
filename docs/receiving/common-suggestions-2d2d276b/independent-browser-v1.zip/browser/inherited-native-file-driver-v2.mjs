import fs from 'node:fs';
import path from 'node:path';
import {spawn,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
export const delay=ms=>new Promise(r=>setTimeout(r,ms));
export const need=(v,m)=>{if(!v)throw new Error(m);};
export const sha=b=>createHash('sha256').update(b).digest('hex');
export const pin=p=>{const b=fs.readFileSync(p);return {path:p,bytes:b.length,sha256:sha(b)};};
export const write=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'});};
export class CDP{
 constructor(ws){this.ws=ws;this.id=0;this.pending=new Map;this.handlers=new Map;ws.addEventListener('message',event=>{const m=JSON.parse(String(event.data));if(m.id){const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}}else{for(const f of this.handlers.get(m.method)||[])f(m.params);}});}
 static async open(url){const ws=new WebSocket(url);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});return new CDP(ws);}
 on(method,fn){const list=this.handlers.get(method)||[];list.push(fn);this.handlers.set(method,list);}
 send(method,params={}){const id=++this.id;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('CDP timeout '+method));},15000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params}));});}
 async evaluate(expression){const r=await this.send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true,userGesture:true});if(r.exceptionDetails)throw new Error('page evaluation '+JSON.stringify(r.exceptionDetails));return r.result.value;}
 close(){this.ws.close();}
}
export async function startNative({root,out,allowedFileRoot}){
 need(!fs.existsSync(out),'existing browser receiving directory; reconcile first');fs.mkdirSync(out,{recursive:true});
 const host=spawnSync('hostname',[],{encoding:'utf8'}).stdout.trim();const user=spawnSync('whoami',[],{encoding:'utf8'}).stdout.trim().toLowerCase();need(host.toUpperCase()==='MSI'&&user==='msi\\jacob','native host identity');
 need(sha(fs.readFileSync('D:\\hamon-ultra-2d2d276b-longwater\\raider-downloads-delivery-401707f2.json'))==='0bb201350ad2f02a17743f572e360c5753117cc10d0becf53ee86b3a9ed24a1c','native custody anchor');
 const requests=[],external=[],exceptions=[],transportErrors=[],downloads=[],progress=[];
 const profile=path.join(out,'profile'),downloadPath=path.join(out,'downloads'),chrome='C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
 fs.mkdirSync(downloadPath);const allowedURL=pathToFileURL(path.resolve(allowedFileRoot)+path.sep).href;
 const args=['--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-extensions','--disable-component-update','--disable-sync','--disable-background-networking','--metrics-recording-only','--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'];
 const child=spawn(chrome,args,{stdio:['ignore','pipe','pipe'],windowsHide:true});
 const stdout=[],stderr=[];child.stdout.on('data',b=>stdout.push(b));child.stderr.on('data',b=>stderr.push(b));
 let browser,page,actualPID,identity,devport;
 const observeCommand=pid=>'Get-CimInstance Win32_Process -Filter "ProcessId='+pid+'"|Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine|ConvertTo-Json -Compress';
 const close=async()=>{
  const errors=[];try{if(browser)await browser.send('Browser.close');}catch(e){errors.push(String(e));}
  await delay(500);page?.close();browser?.close();
  write(path.join(out,'chrome.stdout'),Buffer.concat(stdout));write(path.join(out,'chrome.stderr'),Buffer.concat(stderr));
  let remaining=null;
  if(actualPID){const ps=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',observeCommand(actualPID)],{encoding:'utf8',timeout:15000});need(ps.status===0,'cleanup observation failed');remaining=ps.stdout.trim()?JSON.parse(ps.stdout.trim()):null;}
  const listener=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command','@(Get-NetTCPConnection -State Listen -LocalPort '+devport+' -ErrorAction SilentlyContinue)|Select-Object LocalAddress,LocalPort,OwningProcess|ConvertTo-Json -Compress'],{encoding:'utf8',timeout:15000});
  const cleanup={at:new Date().toISOString(),browserPID:actualPID,launcherPID:child.pid,remainingBrowserProcess:remaining,debugPort:devport,debugListener:listener.stdout.trim()?JSON.parse(listener.stdout.trim()):null,listenerObservationExit:listener.status,browserCloseErrors:errors,profilePreserved:true,noStaticServerAllocated:true};write(path.join(out,'cleanup.json'),JSON.stringify(cleanup,null,2)+'\n');return cleanup;
 };
 try{
  const active=path.join(profile,'DevToolsActivePort');const until=Date.now()+15000;
  while(!fs.existsSync(active)){need(Date.now()<until,'Chrome debug endpoint did not arrive');await delay(100);}
  const lines=fs.readFileSync(active,'utf8').trim().split(/\r?\n/);devport=Number(lines[0]);
  browser=await CDP.open('ws://127.0.0.1:'+devport+lines[1]);
  const info=await browser.send('SystemInfo.getProcessInfo');actualPID=info.processInfo.find(x=>x.type==='browser').id;
  need(Number.isInteger(actualPID)&&actualPID>0,'browser PID');
  const ps=spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',observeCommand(actualPID)],{encoding:'utf8',timeout:15000});need(ps.status===0,'browser identity observation');
  identity=JSON.parse(ps.stdout);need(identity.ExecutablePath.toLowerCase()===chrome.toLowerCase()&&identity.CommandLine.includes(profile),'actual browser executable/profile binding');
  browser.on('Browser.downloadWillBegin',p=>downloads.push(p));browser.on('Browser.downloadProgress',p=>progress.push(p));
  await browser.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath,eventsEnabled:true});
  const target=await browser.send('Target.createTarget',{url:'about:blank'});
  const list=await (await fetch('http://127.0.0.1:'+devport+'/json/list')).json();const t=list.find(t=>t.id===target.targetId);need(t,'target binding');
  page=await CDP.open(t.webSocketDebuggerUrl);
  page.on('Network.requestWillBeSent',p=>requests.push({url:p.request.url,method:p.request.method,type:p.type}));
  page.on('Runtime.exceptionThrown',p=>exceptions.push(p));
  page.on('Fetch.requestPaused',p=>{if(p.request.url.startsWith(allowedURL)||p.request.url.startsWith('data:')||p.request.url==='about:blank')void page.send('Fetch.continueRequest',{requestId:p.requestId}).catch(e=>transportErrors.push(String(e)));else{external.push(p.request.url);void page.send('Fetch.failRequest',{requestId:p.requestId,errorReason:'BlockedByClient'}).catch(e=>transportErrors.push(String(e)));}});
  await page.send('Page.enable');await page.send('Runtime.enable');await page.send('Network.enable');await page.send('Fetch.enable',{patterns:[{urlPattern:'*'}]});
  await page.send('Page.addScriptToEvaluateOnNewDocument',{source:"window.__independentStorage=[];for(const k of ['getItem','setItem','removeItem','clear']){const old=Storage.prototype[k];Storage.prototype[k]=function(...a){window.__independentStorage.push(k);return old.apply(this,a);};}if(window.indexedDB){const old=indexedDB.open.bind(indexedDB);indexedDB.open=(...a)=>{window.__independentStorage.push('indexedDB.open');return old(...a);};}if(navigator.serviceWorker){const old=navigator.serviceWorker.register.bind(navigator.serviceWorker);navigator.serviceWorker.register=(...a)=>{window.__independentStorage.push('serviceWorker.register');return old(...a);};}"});
  const version=await browser.send('Browser.getVersion');write(path.join(out,'identity.json'),JSON.stringify({at:new Date().toISOString(),host,user,launcherPID:child.pid,actualBrowser:identity,version,profile,debugPort:devport,allowedFileRoot,allowedURL,downloadPath},null,2)+'\n');
  return {page,browser,requests,external,exceptions,transportErrors,downloads,progress,downloadPath,identity,close,out,async openFile(file){need(pathToFileURL(file).href.startsWith(allowedURL),'outside owned report root');await page.send('Page.navigate',{url:pathToFileURL(file).href});const until=Date.now()+15000;while(!(await page.evaluate("document.readyState==='complete'&&location.href==="+JSON.stringify(pathToFileURL(file).href)))){need(Date.now()<until,'direct file load');await delay(100);}},async screenshot(name){const r=await page.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const p=path.join(out,name);write(p,Buffer.from(r.data,'base64'));return pin(p);},async viewport(width,height=900){await page.send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false});},async key(key,code=key){await page.send('Input.dispatchKeyEvent',{type:'keyDown',key,code,windowsVirtualKeyCode:key==='Enter'?13:key==='Tab'?9:32});if(key==='Enter'||key===' ')await page.send('Input.dispatchKeyEvent',{type:'char',text:key==='Enter'?'\r':' ',unmodifiedText:key==='Enter'?'\r':' '});await page.send('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:key==='Enter'?13:key==='Tab'?9:32});},async waitDownload(filename){const until=Date.now()+15000;while(true){const begun=downloads.find(d=>d.suggestedFilename===filename);const p=path.join(downloadPath,filename);if(begun&&progress.some(x=>x.guid===begun.guid&&x.state==='completed')&&fs.existsSync(p))return {event:begun,progress:progress.filter(x=>x.guid===begun.guid),file:pin(p)};need(Date.now()<until,'native physical download not complete '+filename);await delay(100);}}};
 }catch(e){write(path.join(out,'startup-error.json'),JSON.stringify({at:new Date().toISOString(),error:String(e.stack||e)},null,2)+'\n');await close();throw e;}
}
