import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {isDeepStrictEqual} from 'node:util';
import {need,pin,write} from './native-http-browser-driver-v1.mjs';
const ROOT=String.raw`D:\hamon-ultra-2d2d276b-taste-common-independent`,HOME=path.join(ROOT,'browser-receiving-v1');
need(!fs.existsSync(path.join(HOME,'BROWSER-FROZEN-v1.json')),'already frozen');
const original=JSON.parse(fs.readFileSync(path.join(ROOT,'ORACLE-FROZEN-v1.json')));
need(pin(path.join(ROOT,'ORACLE-FROZEN-v1.json')).sha256==='fc2ee8476a5c73102fd6db45f42148d4d6c65e70f6df78e5a67f9d25eeb8c875','root freeze pin');
const intake=JSON.parse(fs.readFileSync(path.join(HOME,'CANDIDATE-INTAKE-v1.json')));
for(const f of intake.files)need(pin(f.received_path).sha256===f.sha256,'candidate pin');
const wf=intake.files.find(x=>x.git_path==='static/week_file.mjs'),wc=intake.files.find(x=>x.git_path==='static/week_compare.mjs');
for(const f of [wf,wc])need(pin(f.unchanged_original.path).sha256===f.sha256,'exact original');
const {readWeekFile}=await import(pathToFileURL(wf.unchanged_original.path).href);
const {savedWeekVisits}=await import(pathToFileURL(wc.unchanged_original.path).href);
const input=path.join(ROOT,'oracle-v1','browser-inputs');
const expected=names=>{
 const sources=names.map((label,index)=>({index,label,snapshot:readWeekFile(fs.readFileSync(path.join(input,label),'utf8'))}));
 const visits=sources.map(s=>savedWeekVisits(s.snapshot));const matches=[];
 for(const v of visits[0]){
  const kind=v.pick.kind,entityId=v.pick.entity_id;
  if(matches.some(m=>m.kind===kind&&m.entityId===entityId))continue;
  if(!visits.every(list=>list.some(x=>x.pick.kind===kind&&x.pick.entity_id===entityId)))continue;
  const occurrences=[];
  visits.forEach((list,sourceIndex)=>list.forEach(x=>{if(x.pick.kind===kind&&x.pick.entity_id===entityId)occurrences.push({sourceIndex,key:x.key,originalDay:x.originalDay,day:x.day,date:x.date,pick:x.pick});}));
  matches.push({kind,entityId,occurrences});
 }
 return {format:'tastetable.common-suggestions.v1',sources,matches,counts:{sources:sources.length,commonIdentities:matches.length,occurrences:matches.reduce((s,m)=>s+m.occurrences.length,0)}};
};
const a='First & 梅.json',b='Second café.json',rich=expected([a,b]);
const cases=JSON.parse(fs.readFileSync(path.join(ROOT,'oracle-v1','accepted-cases.json')));
need(isDeepStrictEqual(rich,cases[0].expected),'independent mechanical expansion must reproduce exact root-frozen rich oracle');
const e={rich,repeat:expected([a,a]),empty:expected([a,'Empty source.json']),unknown:expected([a,'Third unknown.json'])};
write(path.join(HOME,'UI-EXPECTED-v1.json'),JSON.stringify(e,null,2)+'\n');
const syntax=[];
for(const name of ['native-http-browser-driver-v1.mjs','browser-mechanics-v1.mjs','browser-controller-v1.mjs']){
 const p=path.join(HOME,name),r=spawnSync(process.execPath,['--check',p],{encoding:'utf8'});syntax.push({file:pin(p),exit:r.status,stdout:r.stdout,stderr:r.stderr});need(r.status===0,'controller syntax '+name);
}
const files=['native-http-browser-driver-v1.mjs','browser-mechanics-v1.mjs','browser-controller-v1.mjs','seal-browser-v1.mjs','UI-EXPECTED-v1.json','PROTOCOL-v1.json','CANDIDATE-INTAKE-v1.json'].map(n=>pin(path.join(HOME,n)));
files.push(pin(path.join(ROOT,'ORACLE-FROZEN-v1.json')));
for(const n of ['First & 梅.json','Second café.json','Third unknown.json','Empty source.json','Malformed replacement.json','Invalid UTF8.json','Oversized replacement.json'])files.push(pin(path.join(input,n)));
const freeze={at:new Date().toISOString(),actor:'chatgpt:2d2d276bbccc:production_custody',rootFreeze:pin(path.join(ROOT,'ORACLE-FROZEN-v1.json')),protocol:pin(path.join(HOME,'PROTOCOL-v1.json')),candidate:'42bc23f796870b3b60ef15033d00d53628e27d59',sourceOnlyIntake:pin(path.join(HOME,'CANDIDATE-INTAKE-v1.json')),sevenGroupsUnchanged:true,oracleChange:false,uiExpectationExpansion:'Only existing frozen physical files, exact unchanged original readWeekFile/savedWeekVisits and independent ordered pair equality. Rich expansion deep-equals root original frozen case. No candidate API output or author fixture used.',mechanicalAdaptation:'Exact DOM selectors plus physical File.arrayBuffer delay/reject, URL.createObjectURL preparation refusal, intercepted print, private CDP and own allowlisted localhost. Original file bytes unaltered.',noBehaviorBeforeThisSeal:true,syntax,files};
write(path.join(HOME,'BROWSER-FROZEN-v1.json'),JSON.stringify(freeze,null,2)+'\n');
console.log(JSON.stringify({freeze:pin(path.join(HOME,'BROWSER-FROZEN-v1.json')),expected:pin(path.join(HOME,'UI-EXPECTED-v1.json')),syntax:syntax.map(x=>({name:path.basename(x.file.path),exit:x.exit})),browserAllocated:false}));
