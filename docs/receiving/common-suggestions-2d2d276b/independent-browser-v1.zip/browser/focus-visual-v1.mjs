import fs from 'node:fs';import path from 'node:path';
import {startNative,need,pin,write} from './native-http-browser-driver-v1.mjs';
import {startServer,tabTo,wait} from './browser-mechanics-v1.mjs';
const HOME=String.raw`D:\hamon-ultra-2d2d276b-taste-common-independent\browser-receiving-v1`,OUT=path.join(HOME,'focus-visual-supplement-v1');
need(!fs.existsSync(OUT),'existing focus observation');fs.mkdirSync(OUT);
const manifest=JSON.parse(fs.readFileSync(path.join(HOME,'candidate-source-v1/MANIFEST.json'))),source=path.join(HOME,'candidate-source-v1/source');
const r={started:new Date().toISOString(),purpose:'Only centered native keyboard focus framing on an empty initial page. Original seven-group pass retained; no physical input, comparison, download or print repeated.',prior:pin(path.join(HOME,'receiving-r1/receipt.json'))};
let server,b;
try{
 server=await startServer({source,out:OUT,manifest});b=await startNative({root:HOME,out:path.join(OUT,'browser'),allowedOrigin:server.origin});
 await b.viewport(390,844);await b.openURL(server.origin+'/static/common-suggestions.html');await wait(b.page,'document.querySelectorAll("#source-slots fieldset").length===2','initial module');
 r.focus=await tabTo(b,'#add-source');await b.page.evaluate('document.activeElement.scrollIntoView({block:"center"})');
 r.geometry=await b.page.evaluate('(()=>{const n=document.activeElement,r=n.getBoundingClientRect();return {id:n.id,x:r.x,y:r.y,width:r.width,height:r.height,inner:innerWidth,viewport:innerHeight,scroll:document.documentElement.scrollWidth};})()');
 need(r.focus.focusVisible&&parseFloat(r.focus.outlineWidth)>=1,'visible keyboard focus');need(r.geometry.x>=3&&r.geometry.y>=3&&r.geometry.x+r.geometry.width<=390-3&&r.geometry.y+r.geometry.height<=844-3,'complete focus frame');
 r.screenshot=await b.screenshot('centered-390px-native-focus.png');
 r.initial=await b.page.evaluate('({files:[...document.querySelectorAll("input[type=file]")].map(n=>n.files.length),compareDisabled:document.querySelector("#compare-sources").disabled,resultHidden:document.querySelector("#comparison-result").hidden,storage:window.__independentStorage})');
 need(r.initial.files.every(n=>n===0)&&r.initial.compareDisabled&&r.initial.resultHidden,'no file/comparison prerequisite replay');
 r.network={requests:b.requests,external:b.external,exceptions:b.exceptions};need(!b.external.length&&!b.exceptions.length&&!r.initial.storage.length,'clean observation');r.passed=true;
}catch(e){r.failure=String(e.stack||e);r.passed=false;}
finally{if(b)r.cleanup=await b.close();if(server)r.serverCleanup=await server.close();r.finished=new Date().toISOString();r.clean=!!r.cleanup&&!r.cleanup.remainingBrowserProcess&&!r.cleanup.debugListener&&!!r.serverCleanup&&!r.serverCleanup.remaining;write(path.join(OUT,'receipt.json'),JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify({receipt:pin(path.join(OUT,'receipt.json')),passed:r.passed,clean:r.clean}));if(!r.passed||!r.clean)process.exitCode=1;}
