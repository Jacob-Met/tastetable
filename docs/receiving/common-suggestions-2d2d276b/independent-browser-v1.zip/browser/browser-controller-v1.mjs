import fs from 'node:fs';
import path from 'node:path';
import {isDeepStrictEqual} from 'node:util';
import {startNative,need,delay,pin,write,sha} from './native-http-browser-driver-v1.mjs';
import {startServer,hookSource,wait,click,physical,tabTo,downloaded} from './browser-mechanics-v1.mjs';
const ROOT=String.raw`D:\hamon-ultra-2d2d276b-taste-common-independent`;
const HOME=path.join(ROOT,'browser-receiving-v1'),OUT=path.join(HOME,'receiving-r1'),INPUT=path.join(ROOT,'oracle-v1','browser-inputs');
const manifest=JSON.parse(fs.readFileSync(path.join(HOME,'candidate-source-v1','MANIFEST.json')));
const source=path.join(HOME,'candidate-source-v1','source');
const freeze=JSON.parse(fs.readFileSync(path.join(HOME,'BROWSER-FROZEN-v1.json')));
for(const item of freeze.files)need(pin(item.path).sha256===item.sha256,'frozen input changed '+item.path);
for(const item of manifest.files)need(pin(path.join(HOME,'candidate-source-v1',item.path)).sha256===item.sha256,'candidate source changed');
need(!fs.existsSync(OUT),'existing run; reconcile rather than replay');fs.mkdirSync(OUT);
const expected=JSON.parse(fs.readFileSync(path.join(HOME,'UI-EXPECTED-v1.json')));
const first='First & 梅.json',second='Second café.json',third='Third unknown.json';
const result={started:new Date().toISOString(),candidate:manifest.source,freeze:pin(path.join(HOME,'BROWSER-FROZEN-v1.json')),groups:[],checks:[],screenshots:[],downloads:[],controlledBoundaries:[],cleanup:null};
let b,server,page,activeGroup;
const check=(id,value,details)=>{result.checks.push({group:activeGroup,id,pass:!!value,...(details===undefined?{}:{details})});need(value,id);};
const equal=(id,a,e)=>check(id,isDeepStrictEqual(a,e),isDeepStrictEqual(a,e)?undefined:{actual:a,expected:e});
const state=()=>page.evaluate(String.raw`(()=>({slots:[...document.querySelectorAll('#source-slots fieldset')].map(n=>({legend:n.querySelector('legend').textContent,label:n.querySelector('label').textContent,input:n.querySelector('input').id,labelFor:n.querySelector('label').htmlFor,accepted:n.querySelector('.accepted-file').textContent,status:n.querySelector('.slot-state').textContent,role:n.querySelector('.slot-state').getAttribute('role'),live:n.querySelector('.slot-state').getAttribute('aria-live'),error:n.querySelector('.slot-state').classList.contains('error'),clearDisabled:n.querySelector('button').disabled,removeDisabled:n.querySelectorAll('button')[1].disabled})),addDisabled:document.querySelector('#add-source').disabled,compareDisabled:document.querySelector('#compare-sources').disabled,downloadDisabled:document.querySelector('#download-comparison').disabled,printDisabled:document.querySelector('#print-comparison').disabled,resultHidden:document.querySelector('#comparison-result').hidden,summary:document.querySelector('#result-summary').textContent,status:document.querySelector('#comparison-status').textContent,exportStatus:document.querySelector('#export-status').textContent,printCalls:window.__receiving.printCalls}))()`);
const file=async(index,name)=>{await physical(b,index,path.join(INPUT,name));await wait(page,'!document.querySelectorAll("#source-slots .slot-state")['+index+'].textContent.startsWith("Reading")','physical file settled '+name);};
const accepted=(s,i,name)=>s.slots[i].accepted==='Accepted file: '+name;
const retired=s=>s.resultHidden&&s.downloadDisabled&&s.printDisabled&&s.summary==='';
const compareNow=async()=>{await click(b,'#compare-sources');await wait(page,'!document.querySelector("#comparison-result").hidden','explicit comparison ready');};
const snapshot=async(label)=>{const p=path.join(OUT,label+'.json');const s=await state();write(p,JSON.stringify(s,null,2)+'\n');return s;};
const shot=async(name,selector)=>{if(selector)await page.evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');await delay(60);const p=await b.screenshot(name);result.screenshots.push(p);return p;};
async function domResult(label,e) {
 const actual=await page.evaluate(String.raw`(()=>{const dl=n=>Object.fromEntries([...n.querySelectorAll('dt')].map(x=>[x.textContent,x.nextElementSibling.textContent]));return {summary:document.querySelector('#result-summary').textContent,sources:[...document.querySelectorAll('.source-card')].map(n=>({heading:n.querySelector('h4').textContent,facts:dl(n),inputs:n.querySelector('pre').textContent,notes:[...n.querySelectorAll('.notes li')].map(n=>n.textContent),model:[...n.querySelectorAll('h4')].find(n=>n.textContent==='Recorded model message')?.nextElementSibling.textContent??null})),matches:[...document.querySelectorAll('.match-card')].map(n=>({kind:n.querySelector('h4').textContent,identity:n.querySelector('.identity').textContent,occurrences:[...n.querySelectorAll('.occurrences > li')].map(i=>({heading:i.querySelector('h4').textContent,label:i.querySelector('.context').textContent,facts:dl(i)}))})),notice:document.querySelector('.notice').textContent,empty:document.querySelector('.empty-result')?.textContent??null,authoredImages:document.querySelectorAll('img').length,executed:window.__fileMarkupExecuted??null};})()`);
 write(path.join(OUT,label+'-dom.json'),JSON.stringify(actual,null,2)+'\n');
 const sources=e.sources.map(s=>({heading:'Source '+(s.index+1)+' · '+s.label,facts:{'Displayed week':s.snapshot.state.weekStart,'Recorded source mode':s.snapshot.state.sourceMode,'Received timestamp':s.snapshot.receivedAt,'Saved timestamp':s.snapshot.savedAt,'Original picks':String(s.snapshot.state.picks.length),'Calendar identity':s.snapshot.calendarId===null?'Not recorded':s.snapshot.calendarId},inputs:JSON.stringify(s.snapshot.inputs,null,2),notes:s.snapshot.response.plan.notes,model:typeof s.snapshot.response.model_message==='string'&&s.snapshot.response.model_message.length?s.snapshot.response.model_message:null}));
 const matches=e.matches.map(m=>({kind:m.kind,identity:m.entityId,occurrences:m.occurrences.map(o=>({heading:'Source '+(o.sourceIndex+1)+' · '+o.key,label:e.sources[o.sourceIndex].label,facts:{'Recorded name':o.pick.name,'Original explanation':o.pick.why,'Originally suggested day':o.originalDay,'Current arrangement':o.date===null?'Kept off the displayed week':o.day+' · '+o.date,'Recorded affinity':o.pick.affinity==null?'Not recorded':String(o.pick.affinity),'Widened / fallback pick':o.pick.fallback===undefined?'Not recorded':o.pick.fallback?'Yes':'No'}}))}));
 equal(label+' full source disclosures',actual.sources,sources);equal(label+' all occurrence disclosures',actual.matches,matches);
 equal(label+' exact counts',actual.summary,e.counts.commonIdentities+' common recorded identities across '+e.counts.sources+' sources · '+e.counts.occurrences+' original occurrences retained.');
 check(label+' literal markup',actual.authoredImages===0&&actual.executed===null);
 check(label+' context',/unsigned/.test(actual.notice)&&/heuristic/.test(actual.notice)&&/current suitability/.test(actual.notice)&&/shared availability/.test(actual.notice)&&/reservation/.test(actual.notice)&&/medical or dietary advice/.test(actual.notice));
 return actual;
}
async function group(id,fn){activeGroup=id;const g={id,started:new Date().toISOString(),status:'running'};result.groups.push(g);try{await fn();g.status='passed';}catch(e){g.status='failed';g.error=String(e.stack||e);throw e;}finally{g.finished=new Date().toISOString();write(path.join(OUT,'group-'+id+'.json'),JSON.stringify({group:g,checks:result.checks.filter(c=>c.group===id)},null,2)+'\n');}}
try {
 server=await startServer({source,out:OUT,manifest});
 b=await startNative({root:ROOT,out:path.join(OUT,'browser'),allowedOrigin:server.origin});page=b.page;
 await page.send('Page.addScriptToEvaluateOnNewDocument',{source:hookSource});
 await b.viewport(1280,960);await b.openURL(server.origin+'/static/common-suggestions.html');
 await wait(page,'document.querySelectorAll("#source-slots fieldset").length===2','module initialized');
 await group('initial-and-physical-intake',async()=>{
  const initial=await snapshot('01-initial');equal('two initial numbered slots',initial.slots.map(s=>s.legend),['Source 1','Source 2']);
  check('labels and accessible status',initial.slots.every(s=>s.labelFor===s.input&&s.label&&s.role==='status'&&s.live==='polite'));
  check('initial controls',initial.compareDisabled&&initial.downloadDisabled&&initial.printDisabled&&initial.slots.every(s=>s.removeDisabled&&s.clearDisabled)&&!initial.addDisabled);
  await file(0,first);const one=await state();check('first physical accepted but comparison disabled',accepted(one,0,first)&&one.compareDisabled);
  await file(1,second);const two=await snapshot('02-physical-intake');check('both physical accepted no implicit comparison',accepted(two,0,first)&&accepted(two,1,second)&&!two.compareDisabled&&two.resultHidden);
  await shot('01-desktop-inputs.png','#input-panel');
 });
 await group('rich-literal-result',async()=>{
  const f=await tabTo(b,'#compare-sources');check('trusted Tab focus visible',f.focusVisible&&parseFloat(f.outlineWidth)>=1,f);
  await b.key('Enter');await wait(page,'!document.querySelector("#comparison-result").hidden','trusted Enter comparison');
  await domResult('03-rich',expected.rich);equal('hand-frozen counts',expected.rich.counts,{sources:2,commonIdentities:3,occurrences:8});
  equal('hand-frozen identity order',expected.rich.matches.map(x=>x.entityId),['B','A','same-out']);
  await shot('02-desktop-summary.png','#comparison-result');await shot('03-desktop-occurrences.png','#common-matches');
 });
 await group('native-keyboard-export-print',async()=>{
  const before=await state();await page.evaluate('window.__receiving.failExport=true');const focus=await tabTo(b,'#download-comparison');check('download keyboard focus',focus.focusVisible,focus);await b.key('Enter');
  const failed=await snapshot('04-export-refused');check('controlled export failure current result survives',!failed.resultHidden&&!failed.downloadDisabled&&failed.summary===before.summary&&/controlled export preparation refusal/.test(failed.exportStatus)&&/retry/.test(failed.exportStatus));
  result.controlledBoundaries.push({type:'URL.createObjectURL preparation throw',filesystemFailureClaim:false});
  const d=await downloaded(b,OUT,'rich',()=>b.key('Enter'));equal('actual rich physical JSON full value',d.parsed,expected.rich);result.downloads.push({...d,parsed:undefined});
  await tabTo(b,'#print-comparison');await b.key(' ');const s=await state();check('trusted Space current print intercepted once',s.printCalls===1);
  await page.send('Emulation.setEmulatedMedia',{media:'print'});const pm=await page.evaluate('({input:getComputedStyle(document.querySelector("#input-panel")).display,actions:getComputedStyle(document.querySelector(".result-actions")).display,sources:document.querySelectorAll(".source-card").length,matches:document.querySelectorAll(".match-card").length,occurrences:document.querySelectorAll(".occurrences > li").length})');
  equal('print media complete current result and hidden inputs',pm,{input:'none',actions:'none',sources:2,matches:3,occurrences:8});
  await shot('04-print-current-sources.png','#source-details');await page.send('Emulation.setEmulatedMedia',{media:''});
 });
 await group('replacement-refusals-and-cancel',async()=>{
  for(const [i,name] of ['Malformed replacement.json','Invalid UTF8.json','Oversized replacement.json'].entries()){
   if(i)await compareNow();
   await file(0,name);const s=await snapshot('05-refusal-'+i);
   check('refusal keeps accepted first '+name,accepted(s,0,first)&&accepted(s,1,second));
   check('refusal error and retired result '+name,s.slots[0].error&&s.slots[0].role==='status'&&s.slots[0].status.includes('previous accepted file remains')&&retired(s)&&!s.compareDisabled);
   await page.evaluate('document.querySelector("#print-comparison").click()');check('retired print cannot run '+name,(await state()).printCalls===1);
  }
  await compareNow();await page.evaluate('window.__receiving.failReadName='+JSON.stringify(second));await file(0,second);const failed=await snapshot('06-read-rejection');
  check('controlled physical read refusal retained and retired',accepted(failed,0,first)&&failed.slots[0].error&&failed.slots[0].status.includes('controlled File.arrayBuffer rejection')&&retired(failed));
  result.controlledBoundaries.push({type:'File.arrayBuffer reject after real original read',filesystemPermissionClaim:false});
  await compareNow();const before=await state();await physical(b,0,null);await page.evaluate('document.querySelector("#source-slots input").dispatchEvent(new Event("change",{bubbles:true}))');await delay(120);equal('empty FileList cancellation is no-op',await state(),before);
 });
 await group('source-lifecycle',async()=>{
  await click(b,'#source-slots fieldset:nth-child(1) button');let s=await state();check('Clear removes input and retires',s.slots[0].accepted==='No accepted file.'&&s.compareDisabled&&retired(s));
  await file(0,first);await compareNow();
  for(let n=3;n<=6;n++){await click(b,'#add-source');s=await state();check('add source '+n+' retires and disables',s.slots.length===n&&retired(s)&&s.compareDisabled);}
  check('Add disabled at six',s.addDisabled);await page.evaluate('document.querySelector("#add-source").click()');check('disabled Add preserves six',(await state()).slots.length===6);
  for(let n=6;n>2;n--){await click(b,'#source-slots fieldset:last-child button:nth-child(2)');s=await state();check('remove source down to '+(n-1),s.slots.length===n-1&&retired(s));}
  check('Remove disabled at two',s.slots.every(x=>x.removeDisabled));
  await file(1,first);await compareNow();await domResult('07-duplicate-positions',expected.repeat);
  const duplicate=await downloaded(b,OUT,'duplicate-positions',()=>click(b,'#download-comparison'));equal('duplicate sources physical current JSON',duplicate.parsed,expected.repeat);result.downloads.push({...duplicate,parsed:undefined});
  await file(1,'Empty source.json');await compareNow();const empty=await domResult('08-empty-success',expected.empty);check('empty success distinct from missing',empty.empty?.startsWith('No common saved suggestions:')&&!(await state()).downloadDisabled&&!(await state()).resultHidden);
  await file(1,third);await compareNow();const unknown=await domResult('09-unknown-mode',expected.unknown);check('unknown mode is not promoted',unknown.sources[1].facts['Recorded source mode']==='unknown');
  const d=await downloaded(b,OUT,'current-unknown-order',()=>click(b,'#download-comparison'));equal('current slot order physical JSON',d.parsed,expected.unknown);result.downloads.push({...d,parsed:undefined});
 });
 await group('asynchronous-retirement',async()=>{
  await page.evaluate('window.__receiving.holdName='+JSON.stringify(second));await physical(b,0,path.join(INPUT,second));await wait(page,'window.__receiving.held.length===1','actual physical bytes held');
  let s=await snapshot('10-pending-read');check('pending read disables Compare and retires',s.compareDisabled&&retired(s)&&accepted(s,0,first));
  await file(0,first);await page.evaluate('window.__receiving.release()');await delay(180);s=await state();check('older read cannot replace newer accepted selection',accepted(s,0,first)&&!s.compareDisabled&&s.resultHidden);
  await page.evaluate('window.__receiving.holdName='+JSON.stringify(second));await physical(b,0,path.join(INPUT,second));await wait(page,'window.__receiving.held.length===1','clear physical held boundary');await click(b,'#source-slots fieldset:first-child button');await page.evaluate('window.__receiving.release()');await delay(180);s=await state();check('Clear invalidates older read',s.slots[0].accepted==='No accepted file.'&&s.compareDisabled&&retired(s));
  await file(0,first);await click(b,'#add-source');await page.evaluate('window.__receiving.holdName='+JSON.stringify(second));await physical(b,2,path.join(INPUT,second));await wait(page,'window.__receiving.held.length===1','remove physical held boundary');await click(b,'#source-slots fieldset:last-child button:nth-child(2)');await page.evaluate('window.__receiving.release()');await delay(180);s=await snapshot('11-async-complete');check('Remove invalidates older read',s.slots.length===2&&accepted(s,0,first)&&accepted(s,1,third)&&!s.compareDisabled&&retired(s));
  const timing=await page.evaluate('({readStarts:window.__receiving.readStarts,held:window.__receiving.held.map(x=>({name:x.name,bytes:x.bytes})),released:window.__receiving.released})');write(path.join(OUT,'controlled-file-read-timing.json'),JSON.stringify(timing,null,2)+'\n');check('all three delayed real reads released',timing.held.length===0&&timing.released.length===3&&timing.released.every(x=>x.bytes===5355||x.bytes===5206));
  result.controlledBoundaries.push({type:'three delayed File.arrayBuffer completions using original physical bytes',naturallyOccurringOSRaceClaim:false});
 });
 await group('narrow-print-and-cleanup',async()=>{
  await file(1,second);await b.viewport(390,844);const focus=await tabTo(b,'#compare-sources');check('390px native focus',focus.focusVisible&&parseFloat(focus.outlineWidth)>=1,focus);await shot('05-narrow-keyboard-inputs.png','#input-panel');await b.key('Enter');await wait(page,'!document.querySelector("#comparison-result").hidden','narrow current comparison');
  await domResult('12-narrow-rich',expected.rich);
  const metrics=await page.evaluate('({inner:innerWidth,root:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,body:document.body.scrollWidth})');check('390px no page horizontal overflow',metrics.inner===390&&metrics.scroll<=390&&metrics.body<=390,metrics);
  await shot('06-narrow-summary.png','#comparison-result');await shot('07-narrow-source.png','#source-details');await shot('08-narrow-occurrence.png','#common-matches');
  await page.send('Emulation.setEmulatedMedia',{media:'print'});await shot('09-narrow-print.png','#source-details');
  const printState=await page.evaluate('({input:getComputedStyle(document.querySelector("#input-panel")).display,sources:[...document.querySelectorAll(".source-card")].map(n=>({text:n.innerText,display:getComputedStyle(n).display})),occurrences:document.querySelectorAll(".occurrences > li").length,hidden:document.querySelector("#comparison-result").hidden})');
  check('print all source disclosures displayed',printState.input==='none'&&printState.sources.length===2&&printState.sources.every(s=>s.display!=='none')&&printState.occurrences===8&&!printState.hidden);
  write(path.join(OUT,'print-dom.json'),JSON.stringify(printState,null,2)+'\n');
  const pdf=await page.send('Page.printToPDF',{printBackground:true,preferCSSPageSize:true,paperWidth:8.27,paperHeight:11.69});write(path.join(OUT,'current-comparison-print.pdf'),Buffer.from(pdf.data,'base64'));result.printPDF=pin(path.join(OUT,'current-comparison-print.pdf'));await page.send('Emulation.setEmulatedMedia',{media:''});
  const storage=await page.evaluate('window.__independentStorage');equal('no automatic browser storage',storage,[]);check('no external page requests',b.external.length===0,b.external);check('no runtime exceptions',b.exceptions.length===0,b.exceptions);check('no transport errors',b.transportErrors.length===0,b.transportErrors);
  result.storage=storage;
 });
} catch(error) { result.failure=String(error.stack||error);if(b){try{await shot('failure.png');write(path.join(OUT,'failure-dom.json'),JSON.stringify(await snapshot('failure-state'),null,2)+'\n');}catch(e){result.failureObservation=String(e);}}}
finally {
 if(b){try{await page.evaluate('window.__receiving?.release()');result.finalHooks=await page.evaluate('window.__receiving?({readStarts:window.__receiving.readStarts,released:window.__receiving.released,printCalls:window.__receiving.printCalls,exports:window.__receiving.exports.map(x=>({type:x.type,size:x.size,text:x.text}))}):null');}catch(e){result.finalHookRead=String(e);}result.network={requests:b.requests,external:b.external,exceptions:b.exceptions,transportErrors:b.transportErrors};try{result.cleanup=await b.close();}catch(e){result.cleanupFailure=String(e.stack||e);}}
 if(server){try{result.serverCleanup=await server.close();}catch(e){result.serverCleanupFailure=String(e.stack||e);}}
 result.finished=new Date().toISOString();result.passed=result.groups.filter(g=>g.status==='passed').length;result.failed=result.groups.filter(g=>g.status==='failed').length;
 result.clean=!!result.cleanup&&!result.cleanup.remainingBrowserProcess&&!result.cleanup.debugListener&&!!result.serverCleanup&&!result.serverCleanup.remaining;
 write(path.join(OUT,'receipt.json'),JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify({receipt:pin(path.join(OUT,'receipt.json')),passed:result.passed,failed:result.failed,clean:result.clean,failure:result.failure||null}));
 if(result.failure||!result.clean)process.exitCode=1;
}
