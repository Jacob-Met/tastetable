#!/usr/bin/env python3
"""Run one isolated, source-pinned native TasteTable qualification."""
from pathlib import Path
import datetime, hashlib, json, os, platform, subprocess, sys, time

ROOT=Path('/home/jacob/hamon-tastetable-native-1caa1d8e028a')
EXPECTED={"rosa":{"path":"/dev/shm/hamon-1caa-tastetable-cache/cli-receiving-01/candidate-rosa.json","bytes":14470,"sha256":"5d9fa0af32fb943547bd13c0c27e1f70d50d7fc3b25430758511aeb51cd4eaba","provenance":{"mode":"offline-fixtures","policy":"ScriptedModel","transport":"FixtureTransport","data":"fictional venues and hand-set affinities","checks":"existing heuristics; no live provider validation"}},"harold":{"path":"/dev/shm/hamon-1caa-tastetable-cache/cli-receiving-01/candidate-harold.json","bytes":12775,"sha256":"c9066f70349e88814c278e09e33992e8a11ff32ba24fb29f0d3c3eb8b34ff566","provenance":{"mode":"offline-fixtures","policy":"ScriptedModel","transport":"FixtureTransport","data":"fictional venues and hand-set affinities","checks":"existing heuristics; no live provider validation"}},"mei":{"path":"/dev/shm/hamon-1caa-tastetable-cache/cli-receiving-01/candidate-mei.json","bytes":9444,"sha256":"4d6ee08feea84dfb877e673844ad6f481f13449b661b153219d32ee31d7f7f76","provenance":{"mode":"offline-fixtures","policy":"ScriptedModel","transport":"FixtureTransport","data":"fictional venues and hand-set affinities","checks":"existing heuristics; no live provider validation"}}}
CLOUD_RECEIPT_SHA='f081ff41b87aed0463e82e6cd1d98256a9db0e5401c41ccc3b79dbace3cf9121'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot():
    result={}
    for item in manifest['files']:
        p=ROOT/item['path'];b=p.read_bytes();s=p.stat()
        if len(b)!=item['bytes'] or sha(b)!=item['sha256']:
            raise RuntimeError('Input identity changed: '+item['path'])
        result[item['path']]={'bytes':len(b),'sha256':sha(b),'mtime_ns':s.st_mtime_ns,'mode':s.st_mode,'inode':s.st_ino}
    return result

manifest=json.loads((ROOT/'SOURCE.json').read_bytes())
if manifest['source_commit']!='d2a3d26cb686b568ed0db0509f152e6c24e260cc':
    raise RuntimeError('Wrong source commit')
before=snapshot()
started={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'hostname':platform.node(),'uid':os.getuid(),'python':sys.version,'executable':sys.executable}
with (ROOT/'RUN_STARTED.json').open('x') as f:
    json.dump(started,f,indent=2);f.write('\n')
results=ROOT/'results'
results.mkdir(exist_ok=False)
env=dict(os.environ)
for key in ['QLOO_API_KEY','QLOO_BASE_URL','TASTETABLE_LIVE','OPENAI_API_KEY','ANTHROPIC_API_KEY','GEMINI_API_KEY']:
    env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
env['PYTHONNOUSERSITE']='1'
env['TASTETABLE_LIVE']='0'
commands=[('oracle',[sys.executable,'-B','-S',str(ROOT/'receive_cache.py'),'--source',str(ROOT/'source/qloo_client.py'),'--out',str(results/'oracle')])]
commands += [('persona-'+name,[sys.executable,'-B','-S',str(ROOT/'source/tastetable_cli.py'),'--persona',name]) for name in ['rosa','harold','mei']]
jobs=[]
print(json.dumps({'event':'started','pid':os.getpid(),'commands':len(commands)}),flush=True)
for name,argv in commands:
    if snapshot()!=before:
        raise RuntimeError('Input metadata changed before '+name)
    tick=time.monotonic()
    process=subprocess.Popen(argv,cwd=ROOT/'source',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    timed_out=False
    try:
        stdout,stderr=process.communicate(timeout=20)
    except subprocess.TimeoutExpired:
        timed_out=True
        process.kill()
        stdout,stderr=process.communicate()
    (results/(name+'.stdout')).write_bytes(stdout)
    (results/(name+'.stderr')).write_bytes(stderr)
    job={'name':name,'argv':argv,'pid':process.pid,'exit_code':process.returncode,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-tick,
         'stdout_bytes':len(stdout),'stdout_sha256':sha(stdout),'stderr_bytes':len(stderr),'stderr_sha256':sha(stderr),
         'source_bytes_mtime_mode_inode_unchanged':snapshot()==before}
    if name=='oracle':
        receipt_path=results/'oracle/receipt.json'
        if receipt_path.is_file():
            data=receipt_path.read_bytes();received=json.loads(data)
            job['receiver_receipt_sha256']=sha(data)
            job['receiver_passed']=received['passed']
            job['receiver_total']=received['total']
            job['receiver_pass']=received['pass']
            job['pass']=process.returncode==0 and received['pass'] and received['passed']==10 and received['total']==10
        else:
            job['pass']=False
    else:
        persona=name.removeprefix('persona-')
        expected=EXPECTED[persona]
        job['cloud_expected']={k:expected[k] for k in ['bytes','sha256']}
        job['stdout_matches_cloud']=len(stdout)==expected['bytes'] and sha(stdout)==expected['sha256']
        try:
            parsed=json.loads(stdout,parse_constant=lambda value:(_ for _ in ()).throw(ValueError('non-finite output')))
            job['offline_provenance_matches']=parsed.get('provenance')==expected['provenance']
        except (ValueError,TypeError):
            job['offline_provenance_matches']=False
        job['pass']=process.returncode==0 and job['stdout_matches_cloud'] and job['offline_provenance_matches']
    job['pass']=job['pass'] and not timed_out and job['source_bytes_mtime_mode_inode_unchanged']
    jobs.append(job)
    print(json.dumps({'event':'finished','name':name,'pid':process.pid,'exit_code':process.returncode,'pass':job['pass']}),flush=True)
after=snapshot()
receipt={'device_id':'d55b2499-5e82-4805-819a-d0d7ddea1efe','native_root':str(ROOT),'environment':started,'source_commit':manifest['source_commit'],
         'merge_commit':manifest['merge_commit'],'tree':manifest['tree'],'source_before':before,'source_after':after,
         'source_bytes_mtime_mode_inode_unchanged':before==after,'cloud_cli_receipt_sha256':CLOUD_RECEIPT_SHA,'jobs':jobs,
         'pass':before==after and all(j['pass'] for j in jobs),
         'scope':'Isolated native Linux/Python qualification of nine published source files and the unchanged independent receiver. Actual offline CLI uses explicit fictional FixtureTransport and ScriptedModel. No dependency installation, provider call, existing project, installed consumer or service change is claimed.'}
out=ROOT/'NATIVE_RECEIPT.json'
with out.open('x') as f:
    json.dump(receipt,f,ensure_ascii=False,indent=2);f.write('\n')
data=out.read_bytes()
print(json.dumps({'event':'complete','receipt':str(out),'receipt_bytes':len(data),'receipt_sha256':sha(data),'pass':receipt['pass'],'job_count':len(jobs)}),flush=True)
raise SystemExit(0 if receipt['pass'] else 1)
