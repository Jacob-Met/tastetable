#!/usr/bin/env node
/** Authored real-browser receiving of regular Undo #40.
 * Exact app/worksheet/model/codec/calendar; loopback fixture server only.
 * Pointer and keyboard activate controls. CDP supplies authored file selections;
 * date values use the native DOM input/change API, explicitly not OS picker input.
 * window.print is a capture sink; physical JSON/ICS/call-sheet downloads are real.
 */
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {spawn} from "node:child_process";
import {createServer} from "node:http";
import {readFile,writeFile,mkdir,mkdtemp,rm,rename,readdir} from "node:fs/promises";
import {join} from "node:path";
import {pathToFileURL} from "node:url";
const carrier="/home/jacob/snap/chromium/common/estate-runtime-tastetable-undo-3dab-20261008";
const root=join(carrier,"source"), output=join(carrier,process.argv[2]||"browser-v1");
const manifestBytes=await readFile(join(carrier,"source-pins.json"));
const sha=b=>createHash("sha256").update(b).digest("hex");
const blob=b=>createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
assert.equal(sha(manifestBytes),"ee6621eb21d8979e83a9b326e9f090f51a934f0dac4c270494f2faf3ee2d0cd0");
const manifest=JSON.parse(manifestBytes);
await mkdir(output);
const downloadPath=join(output,"downloads");await mkdir(downloadPath);
const fixturePath=join(output,"fixtures");await mkdir(fixturePath);
const profile=await mkdtemp(join(output,"profile-"));
const report={started:new Date().toISOString(),root,output,node:process.version,status:"running",manifest:sha(manifestBytes),checks:[],screenshots:[],downloads:[],pageErrors:[],blocked:[],requests:[],serverRequests:[],fileChoosers:[],limitations:["date values supplied using native DOM input/change API, not OS date picker","print sink captures ordinary handler and print-media DOM; no operating-system print dialog or paper","availability36 source not published; no future owner source qualification"]};
async function guards(){const result={};for(const p of manifest.files){const b=await readFile(join(root,p.path));const v={bytes:b.length,sha256:sha(b),git_blob:blob(b)};assert.deepEqual(v,{bytes:p.bytes,sha256:p.sha256,git_blob:p.git_blob},p.path);result[p.path]=v;}return result;}
report.before=await guards();
const {createWeekPlan}=await import(pathToFileURL(join(root,"static/week_plan.mjs")));
const {makeWeekFile,readWeekFile}=await import(pathToFileURL(join(root,"static/week_file.mjs")));
const counts={picks:3,with_qloo_entity_id:3,with_affinity_evidence:2,constraint_checked:3,unsafe_candidates_rejected:1};
const response={mock:true,plan:{meals:[
{day:"Monday",kind:"restaurant",entity_id:"authored-shared",name:"Same name <A> – café",why:"Original first explanation. Ask the venue about access.",affinity:0.8},
{day:"Wednesday",kind:"restaurant",entity_id:"authored-shared",name:"Same name <A> – café",why:"Different occurrence and original explanation.",affinity:0.6}
],outing:{day:"Saturday",kind:"outing",entity_id:"authored-gallery",name:"Authored gallery",why:"Original access explanation.",affinity:null},notes:["Authored fictional suggestions; no venue or provider contacted."],rejected:[{name:"Not scheduled",failed:[{constraint:"wheelchair",status:"unknown",reason:"Ask the venue."}]}]},llm_only:{meals:[],outing:{day:"Saturday",name:"Unverified comparison",why:"Original comparison."}},comparison:{constraints:["wheelchair"],grounded:counts,llm_only:{...counts,with_qloo_entity_id:0}},trace:[{tool:"authored_fixture",args:{literal:"<&>"},result_summary:"No provider request."}]};
const inputs={cuisines:["Italian"],music:["Björk"],films:[],city:"Authored city",constraints:["wheelchair"]};
const identity={response,inputs,state:createWeekPlan(response,"2026-10-05"),receivedAt:"2026-10-01T12:00:00.000Z",calendarId:"1234567890abcdef1234567890abcdef"};
const file=makeWeekFile(identity,new Date("2026-10-02T12:00:00.000Z"));
const fixture=join(fixturePath,"authored-week.json");
await writeFile(fixture,file.text);await writeFile(join(fixturePath,"malformed.json"),"not JSON\n");
report.fixture={bytes:Buffer.byteLength(file.text),sha256:sha(Buffer.from(file.text)),source:"explicit authored fictional response and inputs",calendarId:identity.calendarId};
const server=createServer(async(req,res)=>{try{
 report.serverRequests.push({method:req.method,url:req.url});
 if(req.method!=="GET"){res.writeHead(405);res.end("Read-only fixture server");return;}
 const path=new URL(req.url,"http://127.0.0.1").pathname;
 if(path==="/api/health"||path==="/api/personas"){res.setHeader("content-type","application/json");res.end(JSON.stringify(path.endsWith("health")?{qloo_mode:"mock"}:[]));return;}
 if(path==="/favicon.ico"){res.writeHead(204);res.end();return;}
 const relative=path==="/"?"static/index.html":path.slice(1);
 assert.ok(manifest.files.some(f=>f.path===relative),"Unprovided fixture route "+path);
 const b=await readFile(join(root,relative));
 const type=relative.endsWith(".html")?"text/html":relative.endsWith(".css")?"text/css":"text/javascript";
 res.writeHead(200,{"content-type":type+"; charset=utf-8","cache-control":"no-store"});res.end(b);
 }catch(e){report.serverError=String(e);res.writeHead(404);res.end("No route");}});
await new Promise((resolve,reject)=>{server.once("error",reject);server.listen(0,"127.0.0.1",resolve);});
const origin="http://127.0.0.1:"+server.address().port;
report.origin=origin;
let browser,socket,sessionId,sequence=0,stderr="";
const pending=new Map(),downloads=new Map();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,label){let last;for(let i=0;i<160;i++){try{if(await fn())return;}catch(e){last=e;}await sleep(75);}throw Error("Timed out "+label+(last?": "+last.message:""));}
function cmd(method,params={},scoped=true){const id=++sequence;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error("CDP timeout "+method));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));});}
async function evaluate(fn,...args){const expression=typeof fn==="string"?fn:"("+fn.toString()+")("+args.map(x=>JSON.stringify(x)).join(",")+")";const r=await cmd("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;}
async function key(name,modifiers=0){const codes={Enter:13,Tab:9,Backspace:8,Space:32,Escape:27,ArrowUp:38,ArrowDown:40,Home:36,End:35};for(const type of ["keyDown","keyUp"])await cmd("Input.dispatchKeyEvent",{type,key:name==="Space"?" ":name,code:name,modifiers,windowsVirtualKeyCode:codes[name],nativeVirtualKeyCode:codes[name],...(name==="Enter"&&type==="keyDown"?{text:"\r",unmodifiedText:"\r"}:{})});}
async function focus(selector){assert.ok(await evaluate(s=>!!document.querySelector(s),selector));await evaluate(s=>document.querySelector(s).focus(),selector);assert.ok(await evaluate(s=>document.activeElement.matches(s),selector));}
async function activate(selector){await focus(selector);await key("Enter");}
async function click(selector){const p=await evaluate(s=>{const e=document.querySelector(s);if(!e)throw Error("Missing "+s);e.scrollIntoView({block:"center"});const r=e.getBoundingClientRect();return{x:r.x+r.width/2,y:r.y+r.height/2};},selector);await cmd("Input.dispatchMouseEvent",{type:"mousePressed",button:"left",clickCount:1,...p});await cmd("Input.dispatchMouseEvent",{type:"mouseReleased",button:"left",clickCount:1,...p});}
async function fill(selector,text){await evaluate(s=>{const e=document.querySelector(s);e.focus();e.select();},selector);await key("Backspace");if(text)await cmd("Input.insertText",{text});assert.equal(await evaluate(s=>document.querySelector(s).value,selector),text);}
async function select(selector,value){const index=await evaluate((s,v)=>[...document.querySelector(s).options].findIndex(o=>o.value===v),selector,value);assert.ok(index>=0);await click(selector);await key("Home");for(let i=0;i<index;i++)await key("ArrowDown");await key("Enter");await waitFor(()=>evaluate((s,v)=>document.querySelector(s)?.value===v,selector,value),"native select "+value);}
async function date(value){await evaluate(v=>{const e=document.querySelector("#weekDate");e.value=v;e.dispatchEvent(new Event("input",{bubbles:true}));e.dispatchEvent(new Event("change",{bubbles:true}));},value);}
async function open(path){const old=report.fileChoosers.length;await activate("#openWeek");await waitFor(()=>report.fileChoosers.length>old,"file chooser");const chooser=report.fileChoosers.at(-1);await cmd("DOM.setFileInputFiles",{backendNodeId:chooser.backendNodeId,files:[path]});await waitFor(()=>evaluate(()=>document.querySelector("#form").getAttribute("aria-busy")==="false"),"file admission");}
const assignment=()=>evaluate(()=>Object.fromEntries([...document.querySelectorAll("#weekOrganizer select[data-pick-key]")].map(e=>[e.dataset.pickKey,e.value||null])));
const visit=(key,date)=>'[data-contact-key="'+key+'"]'+(date?'[data-contact-date="'+date+'"]':"");
const reply=(key,date)=>visit(key,date)+' [data-contact-field="reply"]';
async function screenshot(name,selector){if(selector)await evaluate(s=>document.querySelector(s).scrollIntoView({block:"start"}),selector);const {data}=await cmd("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});const b=Buffer.from(data,"base64");await writeFile(join(output,name),b);report.screenshots.push({name,bytes:b.length,sha256:sha(b)});}
async function download(selector,name){const old=new Set(downloads.keys());await activate(selector);let d;await waitFor(()=>{d=[...downloads.values()].find(x=>!old.has(x.guid)&&x.state==="completed");return !!d;},"download "+name);const from=join(downloadPath,d.guid),to=join(downloadPath,name),b=await readFile(from);await rename(from,to);report.downloads.push({name,suggestedFilename:d.suggestedFilename,bytes:b.length,sha256:sha(b),guid:d.guid});return{path:to,bytes:b};}
async function save(name){const d=await download("#saveWeek",name);const s=readWeekFile(d.bytes.toString("utf8"));assert.deepEqual(s.response,response);assert.deepEqual(s.inputs,inputs);assert.equal(s.receivedAt,identity.receivedAt);assert.equal(s.calendarId,identity.calendarId);assert.ok(!d.bytes.toString().includes("arrangementHistory"));return{...s,download:d};}
async function readiness(ready){assert.deepEqual(await evaluate(()=>["printWeek","saveWeek","calendarDownload"].map(id=>document.getElementById(id).disabled)),[!ready,!ready,!ready]);}
async function geometry(){return evaluate(()=>{const names=["resetWeek","undoWeek","redoWeek","printWeek","saveWeek","calendarDownload"];return{viewport:innerWidth,width:document.documentElement.scrollWidth,controls:names.map(id=>{const e=document.getElementById(id),b=e.getBoundingClientRect(),style=getComputedStyle(e);return{id,text:e.textContent,left:b.left,right:b.right,top:b.top,bottom:b.bottom,width:b.width,height:b.height,display:style.display,visibility:style.visibility};})};});}
function fits(g){assert.ok(g.width<=g.viewport+1,JSON.stringify(g));for(const r of g.controls){assert.ok(r.left>=0&&r.right<=g.viewport+1&&r.width>0&&r.height>0,r.id);assert.notEqual(r.display,"none");}for(let i=0;i<g.controls.length;i++)for(let j=i+1;j<g.controls.length;j++){const a=g.controls[i],b=g.controls[j];assert.ok(a.right<=b.left+1||b.right<=a.left+1||a.bottom<=b.top+1||b.bottom<=a.top+1,"overlap "+a.id+" "+b.id);}}
function passed(label){report.checks.push(label);console.log("PASS "+label);}
function exited(ms){if(!browser||browser.exitCode!==null||browser.signalCode!==null)return Promise.resolve(true);return new Promise(resolve=>{const done=()=>{clearTimeout(timer);browser.off("exit",done);resolve(true);};const timer=setTimeout(()=>{browser.off("exit",done);resolve(false);},ms);browser.once("exit",done);});}
try{
 browser=spawn("/snap/bin/chromium",["--headless=new","--disable-gpu","--disable-background-networking","--disable-component-update","--disable-sync","--disable-extensions","--password-store=basic","--no-first-run","--no-default-browser-check","--remote-debugging-address=127.0.0.1","--remote-debugging-port=0","--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost","--user-data-dir="+profile,"about:blank"],{stdio:["ignore","ignore","pipe"]});browser.stderr.on("data",b=>stderr+=b.toString());
 const endpoint=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error("Browser startup timeout")),45000);browser.once("error",e=>{clearTimeout(timer);reject(e);});browser.once("exit",c=>{clearTimeout(timer);reject(Error("Browser exited "+c));});browser.stderr.on("data",()=>{const m=stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});});
 socket=new WebSocket(endpoint);socket.addEventListener("message",event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}else if(m.method.startsWith("Browser.download")){const d=m.params;downloads.set(d.guid,{...downloads.get(d.guid),...d});}else if(m.method==="Page.fileChooserOpened")report.fileChoosers.push(m.params);else if(m.method==="Runtime.exceptionThrown")report.pageErrors.push(m.params);else if(m.method==="Network.requestWillBeSent")report.requests.push(m.params.request.url);else if(m.method==="Fetch.requestPaused"){const p=m.params;const allowed=p.request.url.startsWith(origin+"/");if(!allowed)report.blocked.push(p.request.url);cmd(allowed?"Fetch.continueRequest":"Fetch.failRequest",{requestId:p.requestId,...(!allowed?{errorReason:"BlockedByClient"}:{})}).catch(e=>report.pageErrors.push(String(e)));}});
 await new Promise((resolve,reject)=>{socket.addEventListener("open",resolve,{once:true});socket.addEventListener("error",reject,{once:true});});
 report.browser=await cmd("Browser.getVersion",{},false);await cmd("Browser.setDownloadBehavior",{behavior:"allowAndName",downloadPath,eventsEnabled:true},false);
 const {targetId}=await cmd("Target.createTarget",{url:"about:blank"},false);({sessionId}=await cmd("Target.attachToTarget",{targetId,flatten:true},false));
 for(const method of ["Page.enable","Runtime.enable","Network.enable","DOM.enable"])await cmd(method);
 await cmd("Network.setCacheDisabled",{cacheDisabled:true});await cmd("Network.setBypassServiceWorker",{bypass:true});await cmd("Fetch.enable",{patterns:[{urlPattern:"http://*"},{urlPattern:"https://*"}]});await cmd("Page.setInterceptFileChooserDialog",{enabled:true});
 await cmd("Page.addScriptToEvaluateOnNewDocument",{source:"window.__printSnapshots=[];window.print=()=>window.__printSnapshots.push({date:document.querySelector('#weekDate').value,week:document.querySelector('#weekOrganizer').innerText,worksheet:document.querySelector('#venueFollowup').innerText});"});
 await cmd("Emulation.setDeviceMetricsOverride",{width:1280,height:1000,deviceScaleFactor:1,mobile:false});await cmd("Page.navigate",{url:origin+"/"});await waitFor(()=>evaluate(()=>document.readyState==="complete"&&document.querySelector("#mode").textContent.includes("Demo mode")),"real app");
 await open(fixture);await waitFor(()=>evaluate(()=>!document.querySelector("#results").hidden&&!document.querySelector("#venueFollowup").hidden),"accepted source");
 assert.deepEqual(await assignment(),{"pick-0":"Monday","pick-1":"Wednesday","pick-2":"Saturday"});await readiness(true);
 assert.deepEqual(await evaluate(()=>["undoWeek","redoWeek"].map(id=>document.getElementById(id).disabled)),[true,true]);
 await save("opened-week.json");const originalCalendar=await download("#calendarDownload","original.ics");
 passed("real file chooser admits exact authored source; physical Save and calendar preserve identity");
 const monday="Monday note <literal> – café",sunday="Sunday note for the same occurrence";
 await fill(reply("pick-0","2026-10-05"),monday);
 await select(visit("pick-0")+' [data-contact-field="status"]',"reply_recorded");
 await select('select[data-pick-key="pick-0"]',"Sunday");
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),"");
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-1","2026-10-07")),"");
 await fill(reply("pick-0","2026-10-11"),sunday);await activate("#undoWeek");
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-05")),monday);
 assert.equal(await evaluate(()=>document.activeElement.id),"redoWeek");
 await activate("#redoWeek");assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),sunday);
 await select('select[data-pick-key="pick-1"]',"");
 const edited=await save("edited-week.json");const editedCalendar=await download("#calendarDownload","edited.ics");
 assert.deepEqual(edited.state.assignments,{"pick-0":"Sunday","pick-1":null,"pick-2":"Saturday"});
 await activate("#resetWeek");await activate("#undoWeek");
 assert.deepEqual(await assignment(),edited.state.assignments);
 const restored=await save("restored-week.json");const restoredCalendar=await download("#calendarDownload","restored.ics");
 assert.deepEqual(restored.state.assignments,edited.state.assignments);assert.deepEqual(restoredCalendar.bytes,editedCalendar.bytes);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),sunday);
 const callSheet=await download("[data-contact-download]","restored-call-sheet.txt");assert.ok(callSheet.bytes.toString().includes(sunday));assert.ok(!callSheet.bytes.toString().includes(monday));
 await cmd("Emulation.setEmulatedMedia",{media:"print"});assert.equal(await evaluate(()=>getComputedStyle(document.querySelector(".contact-print-note")).display),"block");assert.equal(await evaluate(s=>document.querySelector(s).textContent,visit("pick-0")+' [data-contact-print="reply"]'),sunday);await cmd("Emulation.setEmulatedMedia",{media:""});
 passed("native move/omit/reset and keyboard Undo restore whole arrangement, occurrence/date worksheet notes, calendar bytes and print projection");
 await screenshot("desktop-restored-week.png",".week-controls");await screenshot("desktop-restored-notes.png","#venueFollowup");
 await open(fixture);await select('select[data-pick-key="pick-0"]',"Sunday");await activate("#undoWeek");
 await date("2026-10-08");await activate("#printWeek");await save("same-week-noop.json");await activate("#resetWeek");
 assert.equal(await evaluate(()=>document.querySelector("#redoWeek").disabled),false);
 assert.equal(await evaluate(()=>window.__printSnapshots.length),1);
 await activate("#redoWeek");assert.equal((await assignment())["pick-0"],"Sunday");
 await activate("#undoWeek");assert.equal(await evaluate(()=>document.querySelector("#weekDate").value),"2026-10-08");assert.equal(await evaluate(()=>document.querySelector("#undoWeek").disabled),true);
 passed("input/change date API, actual Print and physical Save/no-op Reset preserve Redo and valid same-week anchor");
 await date("");await readiness(false);assert.equal(await evaluate(()=>document.querySelector("[data-contact-list]").hidden),true);
 await select('select[data-pick-key="pick-1"]',"");await readiness(false);
 await activate("#undoWeek");await readiness(true);assert.equal(await evaluate(()=>document.querySelector("#weekDate").value),"2026-10-08");assert.equal(await evaluate(()=>document.querySelector("[data-contact-list]").hidden),false);assert.equal(await evaluate(()=>document.querySelector("#undoWeek").disabled),true);
 await activate("#redoWeek");assert.equal((await assignment())["pick-1"],null);assert.equal(await evaluate(()=>document.querySelector("#weekError").textContent),"");
 await date("2026-10-15");await activate("#undoWeek");assert.equal(await evaluate(()=>document.querySelector("#weekDate").value),"2026-10-08");
 passed("invalid real date field refuses all outputs and worksheet, then explicit recovery restores valid date without phantom history");
 await cmd("Emulation.setDeviceMetricsOverride",{width:390,height:844,deviceScaleFactor:1,mobile:false});
 await activate("#undoWeek");await focus("#redoWeek");await key("Space");assert.equal((await assignment())["pick-1"],null);
 await focus("#undoWeek");assert.equal(await evaluate(()=>document.activeElement.textContent),"Undo change");await key("Tab");assert.equal(await evaluate(()=>document.activeElement.id),"redoWeek");
 report.phoneGeometry=await geometry();fits(report.phoneGeometry);await screenshot("phone-undo-controls.png",".week-controls");
 await cmd("Emulation.setDeviceMetricsOverride",{width:1280,height:1000,deviceScaleFactor:1,mobile:false});report.desktopGeometry=await geometry();fits(report.desktopGeometry);
 passed("desktop and390px controls fit without overlap; native Enter/Space and Tab retain accessible Undo/Redo flow");
 await open(join(fixturePath,"malformed.json"));assert.equal(await evaluate(()=>document.querySelector("#results").hidden),true);assert.equal(await evaluate(()=>document.querySelector("#venueFollowup").hidden),true);assert.deepEqual(await evaluate(()=>["undoWeek","redoWeek","saveWeek","calendarDownload"].map(id=>document.getElementById(id).disabled)),[true,true,true,true]);
 assert.match(await evaluate(()=>document.querySelector("#requestStatus").textContent),/could not open/i);
 await open(restored.download.path);assert.deepEqual(await assignment(),edited.state.assignments);assert.deepEqual(await evaluate(()=>["undoWeek","redoWeek"].map(id=>document.getElementById(id).disabled)),[true,true]);assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),"");
 await select('select[data-pick-key="pick-0"]',"Monday");await fill('#form input[name="city"]',"Changed authored city");assert.equal(await evaluate(()=>document.querySelector("#results").hidden),true);assert.equal(await evaluate(()=>document.querySelector("#venueFollowup").hidden),true);assert.equal(await evaluate(()=>document.querySelector("#undoWeek").disabled),true);
 passed("failed Open and real changed planning input retire source/history/worksheet; reopening physical saved copy starts fresh without notes");
 assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.blocked,[]);assert.ok(!report.serverError);assert.ok(report.serverRequests.every(r=>r.method==="GET"));assert.ok(report.requests.every(u=>u.startsWith(origin+"/")||u.startsWith("blob:")));
 report.after=await guards();assert.deepEqual(report.before,report.after);
 passed("all15 exact inputs unchanged; isolated served source only, no provider/account/mutation requests or page exceptions");
 report.status="passed";
}catch(error){report.status="failed";report.error=error.stack??String(error);process.exitCode=1;console.error(report.error);if(sessionId)try{report.lastPage=await evaluate(()=>({url:location.href,text:document.body.innerText.slice(0,20000),focus:document.activeElement.outerHTML}));await screenshot("failed-state.png");}catch{}}
finally{
 try{report.after=await guards();assert.deepEqual(report.after,report.before);}catch(e){report.guardError=e.stack;report.status="failed";process.exitCode=1;}
 if(socket?.readyState===WebSocket.OPEN)try{await cmd("Browser.close",{},false);}catch{}socket?.close();for(const p of pending.values())clearTimeout(p.timer);
 if(!await exited(5000)){browser.kill("SIGTERM");if(!await exited(5000)){browser.kill("SIGKILL");await exited(5000);}}
 try{assert.ok(!browser||browser.exitCode!==null||browser.signalCode!==null);await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:150});report.cleanup={profile,pid:browser?.pid,exitCode:browser?.exitCode,signal:browser?.signalCode,removed:true};}catch(e){report.cleanup={profile,error:e.stack};report.status="failed";process.exitCode=1;}
 await new Promise(resolve=>server.close(resolve));report.finished=new Date().toISOString();await writeFile(join(output,"browser-stderr.txt"),stderr);await writeFile(join(output,"browser-report.json"),JSON.stringify(report,null,2)+"\n");
 console.log("REGULAR_UNDO_BROWSER_"+(report.status==="passed"?"OK":"FAILED")+" checks="+report.checks.length+" failures="+(report.status==="passed"?0:1));
}
