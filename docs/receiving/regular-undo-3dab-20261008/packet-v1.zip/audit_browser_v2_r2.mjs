#!/usr/bin/env node
// Recorded-evidence audit only. Never launches a browser or rewrites a raw report.
import assert from "node:assert/strict";
import {readFile,writeFile,stat,access} from "node:fs/promises";
import {join} from "node:path";
import {createHash} from "node:crypto";
import {pathToFileURL} from "node:url";
const root="/home/jacob/snap/chromium/common/estate-runtime-tastetable-undo-3dab-20261008";
const sha=b=>createHash("sha256").update(b).digest("hex");
const blob=b=>createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const reportBytes=await readFile(join(root,"browser-v2/browser-report.json"));
const d=JSON.parse(reportBytes);
const out={schema:"tastetable.undo.recorded-browser-audit/1",started:new Date().toISOString(),rawReport:{path:"browser-v2/browser-report.json",bytes:reportBytes.length,sha256:sha(reportBytes),git_blob:blob(reportBytes)},originalProcessStatus:"failed",originalProcessExit:1,checks:[],status:"running"};
function pass(label){out.checks.push(label);}
try{
 assert.equal(d.status,"failed");assert.equal(d.checks.length,6);
 assert.match(d.error,/assert\.ok\(report\.requests\.every\(u=>u\.startsWith\(origin\+"\/"\)\|\|u\.startsWith\("blob:"\)\)\)/);
 assert.ok(!d.guardError);assert.ok(!d.serverError);
 out.observedInteractionGroups=d.checks;pass("original failed process and six completed groups remain separately attributed");
 const pBytes=await readFile(join(root,"source-pins.json"));assert.equal(sha(pBytes),"ee6621eb21d8979e83a9b326e9f090f51a934f0dac4c270494f2faf3ee2d0cd0");
 const manifest=JSON.parse(pBytes);assert.equal(manifest.files.length,15);
 const current={};for(const f of manifest.files){const path=join(root,"source",f.path),b=await readFile(path);const pin={bytes:b.length,sha256:sha(b),git_blob:blob(b)};assert.deepEqual(pin,{bytes:f.bytes,sha256:f.sha256,git_blob:f.git_blob},f.path);const mode=(await stat(path)).mode&0o777;assert.equal(mode&0o111,0,"Non-executable Git source mode");(out.nativePosixModes??={})[f.path]=mode.toString(8);current[f.path]=pin;}
 assert.deepEqual(current,d.before);assert.deepEqual(current,d.after);
 out.source=current;out.sourceManifest=sha(pBytes);pass("all15 executed/current input bytes, SHA256, Git blobs and non-executable Git modes equal frozen pins and both raw guard maps");
 const origin=new URL(d.origin);assert.equal(origin.protocol,"http:");assert.equal(origin.hostname,"127.0.0.1");assert.ok(/^[1-9][0-9]*$/.test(origin.port));
 assert.deepEqual(d.pageErrors,[]);assert.deepEqual(d.blocked,[]);
 const extra=d.requests.filter(u=>!u.startsWith(d.origin+"/")&&!u.startsWith("blob:"));
 assert.equal(extra.length,1);assert.ok(extra[0].startsWith("data:image/svg+xml;base64,"));
 const decoded=Buffer.from(extra[0].split(",")[1],"base64");
 const expected='<svg xmlns="http://www.w3.org/2000/svg" width="16" height="15" viewBox="0 0 24 24"><path fill="WindowText" d="M20 3h-1V1h-2v2H7V1H5v2H4c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 18H4V8h16v13z"/><path fill="none" d="M0 0h24v24H0z"/></svg>';
 assert.equal(decoded.toString("utf8"),expected);
 const allowed=new Set(["/","/favicon.ico","/api/health","/api/personas",...manifest.files.filter(f=>f.path.startsWith("static/")).map(f=>"/"+f.path)]);
 assert.equal(d.serverRequests.length,14);
 for(const r of d.serverRequests){assert.equal(r.method,"GET");assert.ok(allowed.has(r.url),r.url);}
 for(const u of d.requests){if(u.startsWith("http:")||u.startsWith("https:")){const v=new URL(u);assert.equal(v.origin,d.origin);assert.ok(allowed.has(v.pathname));}}
 out.network={observedPageRequests:d.requests.length,loopbackServerGets:d.serverRequests.length,mutations:0,externalHttp:0,blocked:[],pageErrors:[],inlineCalendarIcon:{url:extra[0],decoded_utf8:expected,bytes:decoded.length,sha256:sha(decoded)}};
 pass("only14 allowed loopback GETs and one exact inline two-path calendar SVG; no remote request or executable/external SVG content");
 assert.equal(d.downloads.length,8);out.downloads=[];
 for(const f of d.downloads){const b=await readFile(join(root,"browser-v2/downloads",f.name));assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);out.downloads.push({...f,git_blob:blob(b)});}
 const {readWeekFile}=await import(pathToFileURL(join(root,"source/static/week_file.mjs")));
 const base=readWeekFile(await readFile(join(root,"browser-v2/fixtures/authored-week.json"),"utf8"));
 for(const name of ["opened-week.json","edited-week.json","restored-week.json","same-week-noop.json"]){const text=await readFile(join(root,"browser-v2/downloads",name),"utf8"),x=readWeekFile(text);assert.deepEqual(x.response,base.response);assert.deepEqual(x.inputs,base.inputs);assert.equal(x.calendarId,base.calendarId);assert.equal(x.receivedAt,base.receivedAt);assert.ok(!text.includes("arrangementHistory"));assert.ok(!text.includes("Sunday note for the same occurrence"));const edited=/^(edited|restored)/.test(name);assert.deepEqual(x.state.assignments,{"pick-0":edited?"Sunday":"Monday","pick-1":edited?null:"Wednesday","pick-2":"Saturday"});}
 const edited=await readFile(join(root,"browser-v2/downloads/edited.ics")),restored=await readFile(join(root,"browser-v2/downloads/restored.ics"));assert.deepEqual(edited,restored);assert.match(edited.toString(),/DTSTART;VALUE=DATE:20261011/);assert.ok(!edited.toString().includes("DTSTART;VALUE=DATE:20261007"));
 const calls=await readFile(join(root,"browser-v2/downloads/restored-call-sheet.txt"),"utf8");assert.ok(calls.includes("Sunday note for the same occurrence"));assert.ok(!calls.includes("Monday note <literal>"));assert.ok(calls.includes("Caregiver-entered notes."));
 pass("all8 physical outputs hash-verify; actual codec retains source/calendar identity and restored assignments; restored ICS bytes equal; call-sheet notes remain date-specific");
 out.frames=[];for(const f of d.screenshots){const b=await readFile(join(root,"browser-v2",f.name));assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);out.frames.push({...f,git_blob:blob(b)});}
 assert.equal(d.cleanup.exitCode,0);assert.equal(d.cleanup.signal,null);assert.equal(d.cleanup.removed,true);assert.ok(d.cleanup.profile.startsWith(join(root,"browser-v2/profile-")));
 await assert.rejects(access(d.cleanup.profile),{code:"ENOENT"});out.cleanup=d.cleanup;
 pass("all4 raw frames hash-verify and only the owned browser/profile were closed/removed");
 out.status="passed";out.meaning="Six observed real-browser product groups are received with this separate source/network/output audit. V2 remains an overall failed process due to an overly narrow inline-resource assertion; no raw result is relabelled.";
}catch(e){out.status="failed";out.error=e.stack;process.exitCode=1;}
out.finished=new Date().toISOString();await writeFile(join(root,"browser-v2-audit-r2.json"),JSON.stringify(out,null,2)+"\n");
console.log("REGULAR_UNDO_RECORDED_AUDIT_"+(out.status==="passed"?"OK":"FAILED")+" checks="+out.checks.length+" failures="+(out.status==="passed"?0:1));
if(out.error)console.error(out.error);
