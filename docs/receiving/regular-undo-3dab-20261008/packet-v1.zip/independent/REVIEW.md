# Regular planner Undo/Redo: independent source and authored-evidence review

Reviewed 2026-10-08 by estate-3dab0b9d2ce9 / root for TasteTable issue40. Subject: frozen V1 based on main 2b347cee4ff4e2b806362730a8520a3360b45f5a, tree 66d62a724c1667913cb581fb35e4b6db6111dae8.

## Decision

Approve this six-path source contribution and its existing eight-group authored consumer evidence for actual browser receiving. No source defect was found. Actual input/focus/layout, physical file downloads and the real worksheet's date-specific notes remain separate browser gates. Availability issue36 has no successor source in this subject; preserve its agreed renderWeek integration point and receive any actual intervening change before integration.

## Material reviewed

Root read the complete 22,008-byte application, immutable week model, regular history helper, production diff, markup changes, guide, Python wrapper and complete 16,719-byte Node consumer. Root also read both baseline failure logs, the passing candidate logs and receipt, the wrapper's missing-pytest failure and subsequent pass, and all source-intake/freeze metadata.

An independent read-only hash check verified all thirteen frozen inputs with byte counts, SHA256, Git blob identity and mode; all nine original intake inputs; and all seven inherited frozen files outside the contributed paths. The generated two-file production diff exactly matches the actual baseline and candidate app/markup. The regular helper's entire runtime body is identical to the received offline helper; only its first comment differs. The offline file is unchanged.

Candidate receipt source-before and source-after maps are equal. Its raw stdout/stderr reproduce their recorded hashes; its receiver bytes equal the frozen committed test. The eight authored groups pass with zero failures/skips under Node v24.19.0. This is a source/evidence review, not a rerun.

## Consequential behavior

History is tied both to the acceptedPlan object and to the immutable week source identities. An accepted generated response or saved-week response establishes a fresh origin. A state belonging to a different accepted source cannot reuse prior history.

Every successful displayed arrangement passes through the existing renderWeek path. The view is prepared before history/view commitment, and calendar, Save, worksheet sync and history-control refresh follow. Date changes, individual moves/omissions, complete reset, Undo and Redo therefore use the same downstream consumers.

A semantically equal week and assignment map does not append an entry or discard future entries. Same-week date edits may refresh a valid anchor without consuming a change. Print and Save call the existing date application path; their duplicate render does not turn Undo into a new edit. A real new arrangement after Undo clears the redo branch. Multi-pick Restore suggested days produces one complete state, so a single Undo recovers the prior complete assignment map.

Invalid date drafts do not enter a snapshot. If a move/omission occurs while the date field is invalid, arrangementDate uses the previous valid anchor for that arranged week, or the state's valid Monday. The ordinary export checks remain disabled against the invalid field. Undo/Redo restores its entry's valid date, clears the field error and refreshes the normal outputs.

The unchanged helper bounds history at twenty distinct changes. Undo/Redo retain sourcePlan, picks, constraints and sourceMode by identity. They restore occurrence assignments rather than matching names or provider IDs, so the two authored occurrences with identical displayed name and entity ID remain distinct. Calendar session and accepted-plan identity are not recreated by these transitions.

retirePlan clears both history references and refreshes disabled controls before clearing the displayed state. Existing request-controller invalidation still handles changed planning inputs, another request or file read, cancellation and pagehide. A failed or late file read cannot recover the earlier history.

The existing worksheet mount, accept, sync and retire hooks remain in place. History does not absorb or edit the worksheet's note store. Real DOM receiving must show that a note remains associated with its original occurrence and date when changing and recovering the week.

## Authored evidence and limits

The existing-transaction control passed on both old and new app source. Both retained baseline runs show one pass and seven failures caused by absent Undo/Redo controls. The final candidate shows all eight groups passing. The first wrapper attempt failed before tests because that Python runtime lacked pytest; the later wrapper output reports one test passed. These failures remain distinct from product behavior.

The Node receiver evaluates the actual application modules, native week model, saved-week codec, request controller and calendar writer. It declares its DOM, fixture transport, print sink and worksheet mount as doubles. Its passing scenarios establish:

- Multi-pick reset Undo restores the entire assignment map and exact calendar bytes while preserving source and saved-calendar identity.
- Same-week input/change, Print, Save and no-op reset preserve Redo.
- Invalid date followed by omission then Undo restores a valid date without a phantom history entry.
- New edits clear Redo; explicit saved-file replacement starts fresh.
- Starting/failing Open retires immediately; a late file result after input invalidation cannot revive the old plan.
- Generated-plan admission establishes the same source-bound history and pagehide retires it.
- An empty accepted week has no reset change but can recover a different week date.

The receiver checks codec output from Blob bytes and event-driven consumer functions; it does not establish a physical browser download or the real worksheet DOM. Its date-validity double is deliberately limited; real date input behavior remains a browser boundary.

No provider request, account write, installed service change or production data mutation was part of this independent review. The six contribution paths remain unchanged.
