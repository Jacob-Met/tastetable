import pathlib,json,hashlib,subprocess,sys,os,datetime
root=pathlib.Path('/home/jacob/hamon-universal-e3a41d2b3368-tastetable-batch-baseline')
source=root/'baseline';out=root/'baseline-evidence';out.mkdir(exist_ok=False)
guard=root/'audit-guard';guard.mkdir(exist_ok=False)
(guard/'sitecustomize.py').write_text("import sys,os,json\nfrom pathlib import Path\ndef guard(event,args):\n if event in ('socket.connect','socket.connect_ex','http.client.connect','urllib.Request'):\n  with open(os.environ['TASTETABLE_BASELINE_AUDIT'],'a') as f:f.write(json.dumps({'event':event})+'\\n')\n  raise RuntimeError('Native baseline network guard: '+event)\nsys.addaudithook(guard)\n")
tmp=root/'tmp';tmp.mkdir(exist_ok=False)
baseenv=os.environ.copy()
baseenv.update({'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(tmp),'QLOO_API_KEY':'SYNTHETIC-NOT-A-KEY','TASTETABLE_LIVE':'1','TASTETABLE_LLM_BASE_URL':'https://synthetic.invalid/v1','TASTETABLE_LLM_API_KEY':'SYNTHETIC-NOT-A-KEY','TASTETABLE_LLM_MODEL':'synthetic-model'})
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((root/'BASELINE-SOURCE.json').read_text())
def check_source():
 for path,pin in manifest['files'].items():assert sha((source/path).read_bytes())==pin['sha256'],path
check_source()
profiles={label:root/'profiles'/label/'profile.json'for label in ['a','b','invalid']}
profileBefore={label:sha(path.read_bytes())for label,path in profiles.items()}
observed=[]
def run(name,args,expected,guarded=True):
 env=baseenv.copy()
 if guarded:
  env['PYTHONPATH']=str(guard)
  env['TASTETABLE_BASELINE_AUDIT']=str(out/(name+'.audit.jsonl'))
 result=subprocess.run(args,cwd=source,env=env,input=b'',capture_output=True,timeout=45)
 (out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr)
 record={'name':name,'argv':args,'returnCode':result.returncode,'stdoutBytes':len(result.stdout),'stdoutSha256':sha(result.stdout),'stderrBytes':len(result.stderr),'stderrSha256':sha(result.stderr)}
 if guarded:
  audit=out/(name+'.audit.jsonl');record['networkAttempts']=len(audit.read_text().splitlines())if audit.exists()else 0
  assert record['networkAttempts']==0,record
 observed.append(record)
 assert result.returncode==expected,(record,result.stderr.decode('utf-8','replace'))
 return result
cli=str(source/'tastetable_cli.py')
run('help',[sys.executable,cli,'--help'],0)
a=run('single-a',[sys.executable,cli,'--profile',str(profiles['a'])],0)
b=run('single-b',[sys.executable,cli,'--profile',str(profiles['b'])],0)
repeated=run('repeated-profile-option',[sys.executable,cli,'--profile',str(profiles['a']),'--profile',str(profiles['b'])],0)
assert repeated.stdout==b.stdout
assert json.loads(a.stdout)['profile']!=json.loads(b.stdout)['profile']
proposed=root/'baseline-requested-bundle.zip'
missing=run('no-batch-week-route',[sys.executable,cli,'--profile',str(profiles['a']),'--profile',str(profiles['b']),'--week','2026-10-08','--output',str(proposed)],2)
assert not proposed.exists() and not missing.stdout
invalid=run('invalid-profile',[sys.executable,cli,'--profile',str(profiles['invalid'])],2)
assert not invalid.stdout
node='/usr/bin/node'
nodeVersion=run('node-version',[node,'--version'],0,False).stdout.decode().strip()
for label in ['a','b']:
 run('convert-'+label,[node,str(source/'tools/native_plan_to_week.mjs'),'--input',str(out/('single-'+label+'.stdout')),'--week','2026-10-08','--output',str(out/(label+'-week.json'))],0,False)
run('existing-week-codec',[node,str(root/'receive-baseline-weeks.mjs')],0,False)
suite=run('maintained-native-cli',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_native_plan_cli.py','-v'],0,False)
assert b'Ran 16 tests' in suite.stderr and b'OK' in suite.stderr
check_source()
assert profileBefore=={label:sha(path.read_bytes())for label,path in profiles.items()}
receipt={'schema':'tastetable.native-multi-profile-baseline.v1','source':manifest['source'],'tree':manifest['tree'],'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'pythonExecutable':sys.executable,'node':nodeVersion,'nodeExecutable':str(pathlib.Path(node).resolve()),'commands':observed,'maintainedNativeCLI':16,'sourceFilesUnchanged':len(manifest['files']),'profilesUnchanged':profileBefore,'findings':{'documentedCLIProducesOneProfile':True,'repeatedProfileOptionSelectsLastOnly':True,'batchWeekOutputRouteAbsent':True,'twoSeparateProducerConverterRunsYieldAcceptedWeeks':True},'interpretation':'The existing CLI promises one profile. This is a missing multi-profile consumer, not an assertion of a regression in that documented contract. No new production source was written.','receiverSha256':sha(pathlib.Path(__file__).read_bytes()),'weekReceiverSha256':sha((root/'receive-baseline-weeks.mjs').read_bytes())}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'result':'pass','commands':len(observed),'maintainedNativeCLI':16,'sourceFilesUnchanged':len(manifest['files']),'receipt':str(out/'receipt.json'),'receiptSha256':sha((out/'receipt.json').read_bytes()),'findings':receipt['findings']},indent=2))
