import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {readWeekFile} from './baseline/static/week_file.mjs';
const sha=b=>createHash('sha256').update(b).digest('hex');
const results=[];
for (const label of ['a','b']) {
  const nativeBytes=await readFile(new URL('./baseline-evidence/single-'+label+'.stdout',import.meta.url));
  const native=JSON.parse(nativeBytes);
  const weekBytes=await readFile(new URL('./baseline-evidence/'+label+'-week.json',import.meta.url));
  const received=readWeekFile(weekBytes.toString('utf8'));
  assert.deepEqual(received.response,native.response);
  assert.deepEqual(received.inputs,native.profile);
  assert.equal(received.state.weekStart,'2026-10-05');
  assert.equal(native.provenance.mode,'offline-fixtures');
  assert.equal(native.response.mock,true);
  results.push({label,nativeSha256:sha(nativeBytes),weekSha256:sha(weekBytes),
    weekStart:received.state.weekStart,picks:received.state.picks.length,
    calendarId:received.calendarId,fullProfileAndResponsePreserved:true});
}
assert.notEqual(results[0].calendarId,results[1].calendarId);
console.log(JSON.stringify({node:process.version,nodeExecutable:process.execPath,groups:2,result:'pass',results},null,2));
