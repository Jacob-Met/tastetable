
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const {readWeekFile} = await import(pathToFileURL(process.argv[1]).href);
const dir = process.argv[2];
const index = JSON.parse(await readFile(join(dir, 'index.json'), 'utf8'));
const received = [];
for (const item of index.entries.filter(item => item.status === 'saved')) {
  const native = JSON.parse(await readFile(join(dir, item.nativePlan.file), 'utf8'));
  const week = readWeekFile(await readFile(join(dir, item.savedWeek.file), 'utf8'));
  assert.deepEqual(week.inputs, native.profile);
  assert.deepEqual(week.response, native.response);
  assert.equal(week.state.weekStart, index.weekStart);
  assert.equal(native.provenance.mode, 'offline-fixtures');
  assert.equal(native.response.mock, true);
  assert.equal(week.calendarId, item.conversion.calendarId);
  received.push({position: item.position, calendarId: week.calendarId, profile: week.inputs,
                 picks: week.state.picks.length, weekStart: week.state.weekStart});
}
console.log(JSON.stringify(received));
