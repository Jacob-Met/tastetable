"""Independent offline FixtureTransport tag-limit contracts; source stays immutable."""
from pathlib import Path
import argparse, copy, hashlib, importlib.util, json, os, sys
ap=argparse.ArgumentParser()
ap.add_argument("--source",type=Path,required=True)
ap.add_argument("--out",type=Path,required=True)
a=ap.parse_args()
source=a.source.resolve();out=a.out.resolve();out.mkdir(exist_ok=False)
def identity(path):
 data=path.read_bytes();s=path.stat()
 return {"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"mtime_ns":s.st_mtime_ns,"mode":s.st_mode,"inode":s.st_ino}
before={str(p.relative_to(source)):identity(p) for p in source.rglob("*") if p.is_file()}
spec=importlib.util.spec_from_file_location("qloo_client",source/"qloo_client.py")
module=importlib.util.module_from_spec(spec);sys.modules["qloo_client"]=module;spec.loader.exec_module(module)
fixture=source/"fixtures/qloo_fixtures.json"
checks=[]
def record(name,operation):
 try:
  result=operation();passed=result.pop("pass");checks.append({"name":name,"pass":passed,**result})
 except Exception as exc:
  checks.append({"name":name,"pass":False,"error_type":type(exc).__name__,"error":str(exc)})
def client():
 transport=module.FixtureTransport(fixture)
 return module.QlooClient(api_key="SYNTHETIC-RECEIVER",transport=transport),transport
def ids(rows):
 return [r["tag_id"] for r in rows]
bundled=json.loads(fixture.read_text(encoding="utf-8"))
expected_bundled=[{"tag_id":t["id"],"name":t["name"],"type":t["type"]} for t in bundled["tags"] if "a" in t["name"].lower() or "a" in [v.lower() for v in t.get("aka",[])]]
if len(expected_bundled)<5:raise RuntimeError("Bundled oracle needs at least five original matching tags")
for take in [1,2,3,5,99,0]:
 def course(take=take):
  c,t=client();data_before=copy.deepcopy(t.data)
  actual=c.find_tags("a",take=take);expected=expected_bundled[:take]
  return {"pass":actual==expected and t.data==data_before and len(t.log)==1,"take":take,"actual":actual,"expected":expected,"request_count":len(t.log),"fixture_data_unchanged":t.data==data_before}
 record("bundled explicit take "+str(take),course)
def default():
 c,t=client();actual=c.find_tags("a")
 return {"pass":actual==expected_bundled[:3] and t.log[0]["params"]["take"]==3,"actual":actual,"expected":expected_bundled[:3],"params":t.log[0]["params"]}
record("public default is three",default)
authored=[
 {"id":"skip-1","name":"Spruce","type":"kind:x","aka":["not-a"]},
 {"id":"first","name":"Alpha","type":"kind:x"},
 {"id":"skip-2","name":"Elm","type":"kind:y","aka":["alphabet"]},
 {"id":"second","name":"Pine","type":"kind:y","aka":["A","needle"]},
 {"id":"third","name":"Cedar","type":"kind:x"},
 {"id":"fourth","name":"Maple","type":"kind:y"},
]
authored_expected=[{"tag_id":t["id"],"name":t["name"],"type":t["type"]} for t in [authored[1],authored[3],authored[4],authored[5]]]
def authored_client():
 c,t=client();t.data["tags"]=copy.deepcopy(authored)
 return c,t
def filter_then_limit():
 c,t=authored_client();saved=copy.deepcopy(t.data)
 actual=c.find_tags(" A ",take=2)
 return {"pass":actual==authored_expected[:2] and t.data==saved,"actual":actual,"expected":authored_expected[:2],"fixture_data_unchanged":t.data==saved}
record("filter and alias matching precede stable prefix",filter_then_limit)
def omitted_transport_limit():
 _,t=authored_client();p={"filter.query":"a"}
 actual=t("/v2/tags",p,{"X-Api-Key":"SYNTHETIC-RECEIVER"})
 expected=[{"id":x["tag_id"],"name":x["name"],"type":x["type"]} for x in authored_expected]
 return {"pass":actual=={"success":True,"results":{"tags":expected}} and p=={"filter.query":"a"},"actual":actual,"expected":expected,"params_unchanged":p=={"filter.query":"a"}}
record("direct transport without take retains all matches",omitted_transport_limit)
def empty_alias_and_type():
 c,t=authored_client()
 empty=c.find_tags("   ",take=2);missing=c.find_tags("unmatched",take=2)
 alias=c.find_tags(" NeEdLe ",take=1);substring=c.find_tags("need",take=1)
 typed=c.find_tags("a",tag_type="deliberately-ignored-type",take=2)
 expected_alias=[authored_expected[1]]
 return {"pass":empty==[] and missing==[] and alias==expected_alias and substring==[] and typed==authored_expected[:2],"empty":empty,"missing":missing,"exact_alias":alias,"alias_substring":substring,"typed_result":typed,"request_count":len(t.log)}
record("empty queries exact aliases and existing type behavior",empty_alias_and_type)
def cache_and_detachment():
 c,t=authored_client();saved=copy.deepcopy(t.data)
 first=c.find_tags("a",take=1);first[0]["name"]="caller annotation"
 repeated=c.find_tags("a",take=1)
 larger=c.find_tags("a",take=2)
 repeated[0]["tag_id"]="caller-only"
 later=c.find_tags("a",take=1)
 return {"pass":larger==authored_expected[:2] and later==authored_expected[:1] and len(t.log)==2 and t.data==saved,
         "larger":larger,"later":later,"request_count":len(t.log),"fixture_data_unchanged":t.data==saved}
record("take cache keys and returned values stay detached",cache_and_detachment)
def unrelated_consumers():
 c,t=client()
 search=c.search("a",take=1)
 places=c.insights("urn:entity:place",take=1)
 return {"pass":len(search)<=1 and len(places)<=1,"search_count":len(search),"insights_count":len(places)}
record("existing search and insight limits remain bounded",unrelated_consumers)
after={str(p.relative_to(source)):identity(p) for p in source.rglob("*") if p.is_file()}
receipt={"source":str(source),"python":sys.version,"pid":os.getpid(),"source_before":before,"source_after":after,"source_unchanged":before==after,"checks":checks,"passed":sum(x["pass"] for x in checks),"total":len(checks),"scope":"Native isolated published-source public client/FixtureTransport qualification with fictional fixture data; no provider or installed-adoption claim"}
receipt["pass"]=all(x["pass"] for x in checks) and before==after
(out/"receipt.json").write_text(json.dumps(receipt,indent=2,ensure_ascii=True)+"\n")
print(json.dumps({"receipt":str(out/"receipt.json"),"passed":receipt["passed"],"total":receipt["total"],"source_unchanged":receipt["source_unchanged"],"failed":[x["name"] for x in checks if not x["pass"]]}))
sys.exit(0 if receipt["pass"] else 1)
