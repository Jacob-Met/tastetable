#!/usr/bin/env python3
"""Actual public fixture calls and ordinary persona CLI byte comparison."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

def pin(path):
    raw = path.read_bytes()
    st = path.stat()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "mtime_ns": st.st_mtime_ns, "mode": st.st_mode, "inode": st.st_ino}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--reference", type=Path)
    a = ap.parse_args()
    a.out.mkdir()
    before = {str(p.relative_to(a.source)): pin(p) for p in a.source.rglob("*") if p.is_file()}
    sys.path.insert(0, str(a.source))
    from qloo_client import FixtureTransport, QlooClient
    expected = ["Cuban", "Mexican", "Japanese", "Italian", "Jazz Club",
                "Movie Theater", "Concert Hall"]
    t = FixtureTransport(a.source / "fixtures/qloo_fixtures.json")
    q = QlooClient(api_key="MOCK-NOT-A-KEY", transport=t)
    original_data = json.dumps(t.data, sort_keys=True)
    cases = []
    for name, kwargs, names in [
        ("default-three", {}, expected[:3]),
        ("zero", {"take": 0}, []),
        ("one", {"take": 1}, expected[:1]),
        ("two", {"take": 2}, expected[:2]),
        ("five", {"take": 5}, expected[:5]),
        ("exact-match-count", {"take": 7}, expected),
        ("above-match-count", {"take": 99}, expected),
        ("trimmed-case-query", {"take": 2}, expected[:2]),
    ]:
        query = " A " if name == "trimmed-case-query" else "a"
        result = q.find_tags(query, **kwargs)
        got = [x["name"] for x in result]
        cases.append({"name": name, "query": query, "arguments": kwargs,
                      "expected_names": names, "actual_names": got, "pass": got == names})
    calls = len(t.log)
    warm = q.find_tags("a", take=1)
    cases.append({"name": "warm-cache", "pass": len(t.log) == calls,
                  "transport_calls": len(t.log)})
    warm[0]["name"] = "caller changed result"
    fresh = q.find_tags("a", take=1)
    cases.append({"name": "caller-detachment", "pass": fresh[0]["name"] == "Cuban"
                  and json.dumps(t.data, sort_keys=True) == original_data})
    direct = t("/v2/tags", {"filter.query": "a"}, {"X-Api-Key": "MOCK-NOT-A-KEY"})
    cases.append({"name": "direct-no-take-compatibility",
                  "pass": [x["name"] for x in direct["results"]["tags"]] == expected})
    for persona in ("rosa", "harold", "mei"):
        cmd = [sys.executable, "-B", str(a.source / "tastetable_cli.py"), "--persona", persona]
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        done = subprocess.run(cmd, cwd=a.source, env=env, capture_output=True, timeout=30)
        stdout = a.out / (persona + ".stdout")
        stderr = a.out / (persona + ".stderr")
        stdout.write_bytes(done.stdout)
        stderr.write_bytes(done.stderr)
        same = None if a.reference is None else done.stdout == (a.reference / stdout.name).read_bytes()
        cases.append({"name": "persona-" + persona, "command": cmd,
                      "exit_code": done.returncode, "stdout": pin(stdout), "stderr": pin(stderr),
                      "byte_exact_reference": same,
                      "pass": done.returncode == 0 and not done.stderr and same is not False})
    after = {str(p.relative_to(a.source)): pin(p) for p in a.source.rglob("*") if p.is_file()}
    receipt = {"source": str(a.source), "python": sys.version, "host": platform.node(),
               "cases": cases, "passed": sum(c["pass"] for c in cases), "total": len(cases),
               "transport_log": t.log, "source_before": before, "source_after": after,
               "source_guard_pass": before == after}
    (a.out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"passed": receipt["passed"], "total": len(cases),
                      "source_guard": before == after,
                      "receipt_sha256": hashlib.sha256((a.out / "receipt.json").read_bytes()).hexdigest()}))
    return 0 if all(c["pass"] for c in cases) and before == after else 1

if __name__ == "__main__":
    raise SystemExit(main())
