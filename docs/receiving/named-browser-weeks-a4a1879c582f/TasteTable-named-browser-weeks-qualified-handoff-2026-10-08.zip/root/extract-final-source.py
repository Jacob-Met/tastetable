#!/usr/bin/env python3
"""Extract ten reviewed source files into a NEW directory; no Git or network action."""
import hashlib, io, json, sys, zipfile
from pathlib import Path, PurePosixPath
capsule, destination = map(Path, sys.argv[1:])
with zipfile.ZipFile(capsule) as z:
    manifest = json.loads(z.read("root/FINAL-SOURCE-MANIFEST.json"))
    adaptations = json.loads(z.read(manifest["adaptations"]))
    outputs = {}
    for item in manifest["paths"]:
        name = PurePosixPath(item["path"])
        assert not name.is_absolute() and ".." not in name.parts
        with zipfile.ZipFile(io.BytesIO(z.read(item["container"]))) as nested:
            raw = nested.read(item["member"])
        assert hashlib.sha256(raw).hexdigest() == item["original_sha256"]
        text = raw.decode("utf-8")
        for op in adaptations.get(item["path"], []):
            if op["operation"] == "replace":
                assert text.count(op["before"]) == op["count"]
                text = text.replace(op["before"], op["after"], op["count"])
            elif op["operation"] == "append":
                text += op["text"]
            else:
                raise ValueError("Unsupported adaptation")
        data = text.encode("utf-8")
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == item["git_blob"]
        outputs[item["path"]] = data
destination.mkdir()
for name, data in outputs.items():
    path = destination / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
    path.chmod(0o644)
    assert path.read_bytes() == data
print(json.dumps({"base": manifest["base_commit"], "source_files": len(outputs), "destination": str(destination), "readback": "exact"}))
