# Collection / owner Undo compatibility handoff

This is a source-only analysis and an unapplied owner-adoption proposal. No browser, VM consumer suite, workflow, Git commit, branch, PR or merge was run or created. Both qualified collection and owner source remain unchanged.

The owner remains estate-3dab0b9d2ce9/estate_runtime. Its live PR51 is draft at d45da659d3e918829c12ec03c742aa81e29a02c9. The object reviewed here is its separately preserved, unattached current-main composition tree 887d32489a0ed84b9ffc8c2e754420a36b5149df, referenced by https://github.com/Jacob-Met/hamon/issues/140#issuecomment-6068617037. It is not a successor commit or an abandoned scope.

Both complete tree reads were untruncated. The owner's 797-leaf tree differs in exactly 16 paths from our qualified 328df51 parent tree df0251092f77d96169daa097abaec409ecabe6ba (786 leaves). The owner composition already retains the PR52 Visit record link and PR49 venue-note source. Root separately reports main1cba173 adds a README paragraph without changing these shared runtime leaves; that documentation is outside this proposal and must be retained.

## Product lifecycle result

No incompatible product behavior was identified in the source. The collection app delta consists of five insertion-only hunks and its index delta of three insertion-only hunks. The one coincident insertion boundary is the import list; the proposal keeps the owner history import first and adds the collection import next. Removing our inserted segments recovers both owner files byte for byte. Combined HTML IDs are unique and equal the union of both inputs.

| Event | Preserved owner semantics | Collection interaction |
|---|---|---|
| New collection Open | Existing controller calls onStart/retirePlan before asynchronous payload read. Owner clears arrangementHistory/historyPlan and disables both history controls immediately. | openSaved delegates to that controller before store.get. No additional history pathway or admission parser is introduced. |
| Successful Open | render establishes native immutable state; acceptedPlan is assigned; calendar and worksheet are accepted; a fresh history is then created and bound to that acceptedPlan object. | capture uses current acceptedPlan and weekState. The existing post-acceptedPlan refresh makes collection Save usable; it does not require history to have been seeded yet. |
| Undo / Redo | Owner restores whole state/date, preserves the accepted source identity, then uses history-aware renderWeek. Its same-arrangement record is a no-op. | renderWeek still calls refreshWeekSave, which now refreshes collection capture from the restored state. Saving the copy itself creates no history entry. |
| Invalid date | Owner leaves invalid draft text out of history and refreshes export/history controls. | capture refuses a date whose canonical week does not match; collection Save stays disabled. |
| Rename / remove / preview | No plan acceptance or arrangement mutation occurs. | Local metadata and targeted IDB operations cannot change history. Explicit Open remains the only collection plan-replacement callback. |
| Late Open refusal | The unchanged request controller suppresses onError/onIdle for an obsolete generation. | B's seeded history follows the same protection as B's plan. This is source reasoning; the prior native late-refusal receipt did not include Undo. |

The owner accepted-origin getter and every venue-note accept/sync/retire call are preserved. Collection snapshots still exclude venue notes and history. All shared codec/model/controller/calendar/worksheet/style dependency blobs match the qualified collection source.

## Concrete receiving conflicts and proposed resolution

Blindly composing app/index is insufficient for the owner gates.

1. Both fixture receivers admit static routes only from an explicit source list. Their lists omit saved_weeks.mjs, saved_week_store.mjs, saved_week_ui.mjs and saved_weeks.css. The new owner notes/Undo receiver asserts manifest membership at line57 and returns404 on failure; the combined app's new module import would therefore fail. Add precisely those four existing collection assets to BOTH lists, preserving every old guard and assertion.
2. The owner VM consumer's Element.querySelectorAll currently admits only form constraints and throws for all other selectors. The real collection's initial unavailable-IDB refresh queries the four buttons under #savedWeeks. Add just that specific four-button lookup to the existing DOM fixture. This retains the real collection module and unavailable-storage refusal; no no-op substitute, deleted assertion or new backend/IDB simulation is proposed.

PROPOSED-OWNER-ADOPTION.patch contains five small shared-file diffs: app, index, both receivers and that DOM-fixture capability. required-collection-assets contains the exact four already-qualified assets to add unchanged. Every proposed receiver/test change is insertion-only and reversible to the owner byte for byte. The two owner workflows, including --experimental-vm-modules and the new notes/Undo receiving step, are retained byte-identically and are not part of the patch.

The app and three proposed JS receiver/test files passed syntax parsing only. No existing behavior suite was repeated and no combined-source acceptance is claimed. Current Actions hold remains controlling, and normal exact-head gates remain required. Owner review, full current-tree preservation, and one bounded combined behavior receiving are still prerequisites to future integration. In particular, the combined two-feature controls/layout and history after asynchronous collection Open are not covered by either feature's separate historical receipt.

The archive contains exact source inputs, immutable source/coordination pins, the complete 16-path owner delta, proposed files/patch, mechanical proof and a per-member hash manifest. Its two frozen source archives were hash-checked before use. Qualified collection and remote owner files were not modified.
