#!/usr/bin/env node
/** Focused receiving of venue-note files across regular Undo/Redo (#40, PR49).
 * Actual current application, keyboard/pointer controls, native File.arrayBuffer and
 * physical Chrome downloads. GET-only authored fixture server; no provider calls.
 */
import assert from "node:assert/strict";
import {createHash} from "node:crypto";
import {spawn} from "node:child_process";
import {createServer} from "node:http";
import {readFile,writeFile,mkdir,mkdtemp,rm,rename,readdir} from "node:fs/promises";
import {join,dirname,resolve} from "node:path";
import {pathToFileURL,fileURLToPath} from "node:url";
const args=process.argv.slice(2);
const option=(name,fallback)=>args.includes(name)?args[args.indexOf(name)+1]:fallback;
const root=resolve(option("--root",join(dirname(fileURLToPath(import.meta.url)),"..")));
const output=resolve(option("--output",join(root,"regular-undo-notes-receiving")));
const executable=option("--browser","google-chrome");
const sha=b=>createHash("sha256").update(b).digest("hex");
const blob=b=>createHash("sha1").update(Buffer.from("blob "+b.length+"\0")).update(b).digest("hex");
const sourcePaths=[
 "static/app.js","static/index.html","static/arrangement_history.mjs",
 "static/saved_weeks.mjs","static/saved_week_store.mjs","static/saved_week_ui.mjs","static/saved_weeks.css",
 "static/venue_followup.mjs","static/venue_note_file.mjs","static/venue_followup.css",
 "static/week_file.mjs","static/week_plan.mjs","static/calendar.js","static/calendar.css",
 "static/plan-request.js","static/style.css","tools/check_regular_undo_notes_browser.mjs",
 ".github/workflows/native-plan-week-browser.yml",
];
const manifest={files:await Promise.all(sourcePaths.map(async path=>{const b=await readFile(join(root,path));return{path,bytes:b.length,sha256:sha(b),git_blob:blob(b)};}))};
const manifestBytes=Buffer.from(JSON.stringify(manifest,null,2)+"\n");
await mkdir(output);
await writeFile(join(output,"source-pins.json"),manifestBytes);
const downloadPath=join(output,"downloads");await mkdir(downloadPath);
const fixturePath=join(output,"fixtures");await mkdir(fixturePath);
const profile=await mkdtemp(join(output,"profile-"));
const report={schema:"tastetable.regular-undo-note-file/1",started:new Date().toISOString(),root,output,executable,node:process.version,checkout:process.env.GITHUB_SHA??null,status:"running",manifest:sha(manifestBytes),checks:[],screenshots:[],downloads:[],pageErrors:[],blocked:[],requests:[],serverRequests:[],fileChoosers:[],limits:["Authored fictional saved week and notes; no venue/provider request.","Current source served through an isolated GET-only loopback fixture server; no deployment claim.","CDP supplies selected local files to real intercepted browser file choosers; production File.arrayBuffer and note parsing remain unchanged."]};
async function guards(){const result={};for(const p of manifest.files){const b=await readFile(join(root,p.path));const v={bytes:b.length,sha256:sha(b),git_blob:blob(b)};assert.deepEqual(v,{bytes:p.bytes,sha256:p.sha256,git_blob:p.git_blob},p.path);result[p.path]=v;}return result;}
report.before=await guards();
const {createWeekPlan}=await import(pathToFileURL(join(root,"static/week_plan.mjs")));
const {makeWeekFile}=await import(pathToFileURL(join(root,"static/week_file.mjs")));
const counts={picks:3,with_qloo_entity_id:3,with_affinity_evidence:2,constraint_checked:3,unsafe_candidates_rejected:1};
const response={mock:true,plan:{meals:[
{day:"Monday",kind:"restaurant",entity_id:"authored-shared",name:"Same name <A> – café",why:"Original first explanation. Ask the venue about access.",affinity:0.8},
{day:"Wednesday",kind:"restaurant",entity_id:"authored-shared",name:"Same name <A> – café",why:"Different occurrence and original explanation.",affinity:0.6}
],outing:{day:"Saturday",kind:"outing",entity_id:"authored-gallery",name:"Authored gallery",why:"Original access explanation.",affinity:null},notes:["Authored fictional suggestions; no venue or provider contacted."],rejected:[{name:"Not scheduled",failed:[{constraint:"wheelchair",status:"unknown",reason:"Ask the venue."}]}]},llm_only:{meals:[],outing:{day:"Saturday",name:"Unverified comparison",why:"Original comparison."}},comparison:{constraints:["wheelchair"],grounded:counts,llm_only:{...counts,with_qloo_entity_id:0}},trace:[{tool:"authored_fixture",args:{literal:"<&>"},result_summary:"No provider request."}]};
const inputs={cuisines:["Italian"],music:["Björk"],films:[],city:"Authored city",constraints:["wheelchair"]};
const identity={response,inputs,state:createWeekPlan(response,"2026-10-05"),receivedAt:"2026-10-01T12:00:00.000Z",calendarId:"1234567890abcdef1234567890abcdef"};
const file=makeWeekFile(identity,new Date("2026-10-02T12:00:00.000Z"));
const fixture=join(fixturePath,"authored-week.json");
await writeFile(fixture,file.text);await writeFile(join(fixturePath,"malformed.json"),"not JSON\n");
report.fixture={bytes:Buffer.byteLength(file.text),sha256:sha(Buffer.from(file.text)),source:"explicit authored fictional response and inputs",calendarId:identity.calendarId};
const server=createServer(async(req,res)=>{try{
 report.serverRequests.push({method:req.method,url:req.url});
 if(req.method!=="GET"){res.writeHead(405);res.end("Read-only fixture server");return;}
 const path=new URL(req.url,"http://127.0.0.1").pathname;
 if(path==="/api/health"||path==="/api/personas"){res.setHeader("content-type","application/json");res.end(JSON.stringify(path.endsWith("health")?{qloo_mode:"mock"}:[]));return;}
 if(path==="/favicon.ico"){res.writeHead(204);res.end();return;}
 const relative=path==="/"?"static/index.html":path.slice(1);
 assert.ok(manifest.files.some(f=>f.path===relative),"Unprovided fixture route "+path);
 const b=await readFile(join(root,relative));
 const type=relative.endsWith(".html")?"text/html":relative.endsWith(".css")?"text/css":"text/javascript";
 res.writeHead(200,{"content-type":type+"; charset=utf-8","cache-control":"no-store"});res.end(b);
 }catch(e){report.serverError=String(e);res.writeHead(404);res.end("No route");}});
await new Promise((resolve,reject)=>{server.once("error",reject);server.listen(0,"127.0.0.1",resolve);});
const origin="http://127.0.0.1:"+server.address().port;
report.origin=origin;
let browser,socket,sessionId,sequence=0,stderr="";
const pending=new Map(),downloads=new Map();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,label){let last;for(let i=0;i<160;i++){try{if(await fn())return;}catch(e){last=e;}await sleep(75);}throw Error("Timed out "+label+(last?": "+last.message:""));}
function cmd(method,params={},scoped=true){const id=++sequence;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{pending.delete(id);reject(Error("CDP timeout "+method));},15000);pending.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));});}
async function evaluate(fn,...args){const expression=typeof fn==="string"?fn:"("+fn.toString()+")("+args.map(x=>JSON.stringify(x)).join(",")+")";const r=await cmd("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);return r.result.value;}
async function key(name,modifiers=0){const codes={Enter:13,Tab:9,Backspace:8,Space:32,Escape:27,ArrowUp:38,ArrowDown:40,Home:36,End:35};for(const type of ["keyDown","keyUp"])await cmd("Input.dispatchKeyEvent",{type,key:name==="Space"?" ":name,code:name,modifiers,windowsVirtualKeyCode:codes[name],nativeVirtualKeyCode:codes[name],...(name==="Enter"&&type==="keyDown"?{text:"\r",unmodifiedText:"\r"}:{})});}
async function focus(selector){assert.ok(await evaluate(s=>!!document.querySelector(s),selector));await evaluate(s=>document.querySelector(s).focus(),selector);assert.ok(await evaluate(s=>document.activeElement.matches(s),selector));}
async function activate(selector){await focus(selector);await key("Enter");}
async function click(selector){const p=await evaluate(async s=>{const e=document.querySelector(s);if(!e)throw Error("Missing "+s);e.scrollIntoView({block:"center",behavior:"instant"});await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));const b=e.getBoundingClientRect(),x=b.x+b.width/2,y=b.y+b.height/2;if(document.elementFromPoint(x,y)!==e)throw Error("Pointer target obscured "+s);return{x,y};},selector);await cmd("Input.dispatchMouseEvent",{type:"mousePressed",button:"left",clickCount:1,...p});await cmd("Input.dispatchMouseEvent",{type:"mouseReleased",button:"left",clickCount:1,...p});}
async function fill(selector,text){await evaluate(s=>{const e=document.querySelector(s);e.focus();e.select();},selector);await key("Backspace");if(text)await cmd("Input.insertText",{text});assert.equal(await evaluate(s=>document.querySelector(s).value,selector),text);}
async function select(selector,value){const index=await evaluate((s,v)=>[...document.querySelector(s).options].findIndex(o=>o.value===v),selector,value);assert.ok(index>=0);await click(selector);await key("Home");for(let i=0;i<index;i++)await key("ArrowDown");await key("Enter");await waitFor(()=>evaluate((s,v)=>document.querySelector(s)?.value===v,selector,value),"native select "+value);}

async function choose(selector,inputId,path){const old=report.fileChoosers.length;await activate(selector);await waitFor(()=>report.fileChoosers.length>old,"file chooser "+inputId);const chooser=report.fileChoosers.at(-1);assert.equal(chooser.mode,"selectSingle");const identity={backendNodeId:chooser.backendNodeId};const {node}=await cmd("DOM.describeNode",identity);const a=Object.fromEntries(Array.from({length:node.attributes.length/2},(_,i)=>node.attributes.slice(i*2,i*2+2)));assert.equal(a.id,inputId);assert.equal(a.type,"file");await cmd("DOM.setFileInputFiles",{...identity,files:[path]});}
async function open(path){await choose("#openWeek","weekFile",path);await waitFor(()=>evaluate(()=>document.querySelector("#form").getAttribute("aria-busy")==="false"),"week admission");}
async function openNotes(path){await choose("[data-contact-file-open]","venueNotesFile",path);await waitFor(()=>evaluate(()=>!document.querySelector("[data-contact-file-preview]").hidden),"note preview");assert.equal(await evaluate(()=>document.querySelector("[data-contact-file-apply]").disabled),false);}
const history=()=>evaluate(()=>["undoWeek","redoWeek"].map(id=>document.getElementById(id).disabled));
const noteUI=()=>evaluate(()=>({preview:!document.querySelector("[data-contact-file-preview]").hidden,applyDisabled:document.querySelector("[data-contact-file-apply]").disabled,status:document.querySelector("[data-contact-file-status]").textContent,saveDisabled:document.querySelector("[data-contact-file-save]").disabled,openDisabled:document.querySelector("[data-contact-file-open]").disabled}));

const assignment=()=>evaluate(()=>Object.fromEntries([...document.querySelectorAll("#weekOrganizer select[data-pick-key]")].map(e=>[e.dataset.pickKey,e.value||null])));
const visit=(key,date)=>'[data-contact-key="'+key+'"]'+(date?'[data-contact-date="'+date+'"]':"");
const reply=(key,date)=>visit(key,date)+' [data-contact-field="reply"]';
async function screenshot(name,selector){if(selector)await evaluate(s=>document.querySelector(s).scrollIntoView({block:"start"}),selector);const {data}=await cmd("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});const b=Buffer.from(data,"base64");await writeFile(join(output,name),b);report.screenshots.push({name,bytes:b.length,sha256:sha(b)});}
async function download(selector,name){const old=new Set(downloads.keys());await activate(selector);let d;await waitFor(()=>{d=[...downloads.values()].find(x=>!old.has(x.guid)&&x.state==="completed");return !!d;},"download "+name);const from=join(downloadPath,d.guid),to=join(downloadPath,name),b=await readFile(from);await rename(from,to);report.downloads.push({name,suggestedFilename:d.suggestedFilename,bytes:b.length,sha256:sha(b),guid:d.guid});return{path:to,bytes:b};}

function passed(label){report.checks.push(label);console.log("PASS "+label);}
function exited(ms){if(!browser||browser.exitCode!==null||browser.signalCode!==null)return Promise.resolve(true);return new Promise(resolve=>{const done=()=>{clearTimeout(timer);browser.off("exit",done);resolve(true);};const timer=setTimeout(()=>{browser.off("exit",done);resolve(false);},ms);browser.once("exit",done);});}
try{
 browser=spawn(executable,["--headless=new","--disable-gpu","--disable-background-networking","--disable-component-update","--disable-sync","--disable-extensions","--password-store=basic","--no-first-run","--no-default-browser-check","--remote-debugging-address=127.0.0.1","--remote-debugging-port=0","--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1, EXCLUDE localhost","--user-data-dir="+profile,"about:blank"],{stdio:["ignore","ignore","pipe"]});browser.stderr.on("data",b=>stderr+=b.toString());
 const endpoint=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error("Browser startup timeout")),45000);browser.once("error",e=>{clearTimeout(timer);reject(e);});browser.once("exit",c=>{clearTimeout(timer);reject(Error("Browser exited "+c));});browser.stderr.on("data",()=>{const m=stderr.match(/DevTools listening on (ws:\/\/127\.0\.0\.1:[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});});
 socket=new WebSocket(endpoint);socket.addEventListener("message",event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(!p)return;pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}else if(m.method.startsWith("Browser.download")){const d=m.params;downloads.set(d.guid,{...downloads.get(d.guid),...d});}else if(m.method==="Page.fileChooserOpened")report.fileChoosers.push(m.params);else if(m.method==="Runtime.exceptionThrown")report.pageErrors.push(m.params);else if(m.method==="Network.requestWillBeSent")report.requests.push(m.params.request.url);else if(m.method==="Fetch.requestPaused"){const p=m.params;const allowed=p.request.url.startsWith(origin+"/");if(!allowed)report.blocked.push(p.request.url);cmd(allowed?"Fetch.continueRequest":"Fetch.failRequest",{requestId:p.requestId,...(!allowed?{errorReason:"BlockedByClient"}:{})}).catch(e=>report.pageErrors.push(String(e)));}});
 await new Promise((resolve,reject)=>{socket.addEventListener("open",resolve,{once:true});socket.addEventListener("error",reject,{once:true});});
 report.browser=await cmd("Browser.getVersion",{},false);await cmd("Browser.setDownloadBehavior",{behavior:"allowAndName",downloadPath,eventsEnabled:true},false);
 const {targetId}=await cmd("Target.createTarget",{url:"about:blank"},false);({sessionId}=await cmd("Target.attachToTarget",{targetId,flatten:true},false));
 for(const method of ["Page.enable","Runtime.enable","Network.enable","DOM.enable"])await cmd(method);
 await cmd("Network.setCacheDisabled",{cacheDisabled:true});await cmd("Network.setBypassServiceWorker",{bypass:true});await cmd("Fetch.enable",{patterns:[{urlPattern:"http://*"},{urlPattern:"https://*"}]});await cmd("Page.setInterceptFileChooserDialog",{enabled:true});

 await cmd("Emulation.setDeviceMetricsOverride",{width:1280,height:1000,deviceScaleFactor:1,mobile:false});await cmd("Page.navigate",{url:origin+"/"});await waitFor(()=>evaluate(()=>document.readyState==="complete"&&document.querySelector("#mode").textContent.includes("Demo mode")),"real app");

 await open(fixture);await waitFor(()=>evaluate(()=>!document.querySelector("#results").hidden&&!document.querySelector("#venueFollowup").hidden),"accepted source");
 const original={"pick-0":"Monday","pick-1":"Wednesday","pick-2":"Saturday"};
 const moved={...original,"pick-0":"Sunday"};
 assert.deepEqual(await assignment(),original);assert.deepEqual(await history(),[true,true]);
 assert.equal((await noteUI()).saveDisabled,false);
 const savedNote="Saved Monday note <literal> – café",editedNote="Edited Monday retained until explicit replacement",sundayNote="Sunday-only note for the moved occurrence";
 await fill(reply("pick-0","2026-10-05"),savedNote);
 const saved=await download("[data-contact-file-save]","saved-venue-notes.json"),envelope=JSON.parse(saved.bytes.toString("utf8"));
 assert.equal(envelope.format,"tastetable.venue-notes.v1");
 assert.deepEqual(envelope.origin,{receivedAt:identity.receivedAt,calendarId:identity.calendarId,inputs,response});
 assert.equal(envelope.records.length,1);assert.equal(envelope.records[0].key,"pick-0");assert.equal(envelope.records[0].date,"2026-10-05");assert.equal(envelope.records[0].note.reply,savedNote);
 passed("actual saved-week chooser and physical venue-note download retain complete accepted origin and occurrence/date identity");
 await fill(reply("pick-0","2026-10-05"),editedNote);
 await select('select[data-pick-key="pick-0"]',"Sunday");
 await fill(reply("pick-0","2026-10-11"),sundayNote);
 await openNotes(saved.path);assert.deepEqual(await assignment(),moved);
 assert.match(await evaluate(()=>document.querySelector("[data-contact-file-description]").textContent),/0 match visits currently scheduled, 1 are for other dates/);
 await activate("#undoWeek");assert.deepEqual(await assignment(),original);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-05")),editedNote);
 assert.equal((await noteUI()).preview,false);assert.equal((await noteUI()).applyDisabled,true);assert.match((await noteUI()).status,/changed.*Open the notes file again/);
 await activate("#redoWeek");assert.deepEqual(await assignment(),moved);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),sundayNote);
 passed("Undo invalidates a pending physical note-file replacement; Undo/Redo still recover the existing occurrence/date notes");
 await openNotes(saved.path);const arrangementBefore=await assignment(),historyBefore=await history();
 await activate("[data-contact-file-apply]");
 assert.match((await noteUI()).status,/Venue notes replaced/);
 assert.deepEqual(await assignment(),arrangementBefore);assert.deepEqual(await history(),historyBefore);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),"");
 await activate("#undoWeek");assert.deepEqual(await assignment(),original);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-05")),savedNote);
 assert.deepEqual(await history(),[true,false]); // replacement did not add an arrangement entry
 await screenshot("replaced-notes-after-undo.png","#venueFollowup");
 await activate("#redoWeek");assert.deepEqual(await assignment(),moved);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-11")),"");
 const replaced=await download("[data-contact-file-save]","replaced-venue-notes.json"),replacedEnvelope=JSON.parse(replaced.bytes.toString("utf8"));
 assert.deepEqual(replacedEnvelope.origin,envelope.origin);assert.deepEqual(replacedEnvelope.records,envelope.records);
 passed("explicit replacement changes only notes; Undo/Redo project the replacement records without restoring discarded notes or adding history");
 await openNotes(saved.path);
 await open(join(fixturePath,"malformed.json"));await waitFor(()=>evaluate(()=>/could not open/i.test(document.querySelector("#requestStatus").textContent)),"failed week Open");
 assert.equal(await evaluate(()=>document.querySelector("#results").hidden&&document.querySelector("#venueFollowup").hidden),true);
 assert.deepEqual(await history(),[true,true]);const retired=await noteUI();
 assert.equal(retired.preview,false);assert.equal(retired.applyDisabled,true);assert.equal(retired.saveDisabled,true);assert.equal(retired.openDisabled,true);
 await open(fixture);await waitFor(()=>evaluate(()=>!document.querySelector("#results").hidden&&!document.querySelector("#venueFollowup").hidden),"reopened source");
 assert.deepEqual(await history(),[true,true]);assert.deepEqual(await assignment(),original);
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-05")),"");
 await openNotes(saved.path);await activate("[data-contact-file-apply]");
 assert.equal(await evaluate(s=>document.querySelector(s).value,reply("pick-0","2026-10-05")),savedNote);
 assert.deepEqual(await history(),[true,true]);assert.deepEqual(await assignment(),original);
 await screenshot("reopened-notes-fresh-history.png","#venueFollowup");
 passed("failed saved-week Open retires pending notes and history; actual matching-file reopen starts fresh and explicitly restores notes");
 assert.deepEqual(report.pageErrors,[]);assert.deepEqual(report.blocked,[]);assert.ok(!report.serverError);
 assert.ok(report.serverRequests.every(r=>r.method==="GET"));
 assert.ok(report.requests.every(u=>u.startsWith(origin+"/")||u.startsWith("blob:"+origin+"/")||u.startsWith("data:image/svg+xml,")));
 report.after=await guards();assert.deepEqual(report.before,report.after);
 passed("current checkout source guards remain exact; only loopback GETs and browser-local outputs, with no page exceptions");
 report.status="passed";
}catch(error){report.status="failed";report.error=error.stack??String(error);process.exitCode=1;console.error(report.error);if(sessionId)try{report.lastPage=await evaluate(()=>({url:location.href,text:document.body.innerText.slice(0,20000),focus:document.activeElement.outerHTML}));await screenshot("failed-state.png");}catch{}}
finally{
 try{report.after=await guards();assert.deepEqual(report.after,report.before);}catch(e){report.guardError=e.stack;report.status="failed";process.exitCode=1;}
 if(socket?.readyState===WebSocket.OPEN)try{await cmd("Browser.close",{},false);}catch{}socket?.close();for(const p of pending.values())clearTimeout(p.timer);
 if(!await exited(5000)){browser.kill("SIGTERM");if(!await exited(5000)){browser.kill("SIGKILL");await exited(5000);}}
 try{assert.ok(!browser||browser.exitCode!==null||browser.signalCode!==null);await rm(profile,{recursive:true,force:true,maxRetries:5,retryDelay:150});report.cleanup={profile,pid:browser?.pid,exitCode:browser?.exitCode,signal:browser?.signalCode,removed:true};}catch(e){report.cleanup={profile,error:e.stack};report.status="failed";process.exitCode=1;}
 await new Promise(resolve=>server.close(resolve));report.finished=new Date().toISOString();await writeFile(join(output,"browser-stderr.txt"),stderr);await writeFile(join(output,"browser-report.json"),JSON.stringify(report,null,2)+"\n");
 console.log("REGULAR_UNDO_NOTES_"+(report.status==="passed"?"OK":"FAILED")+" checks="+report.checks.length+" failures="+(report.status==="passed"?0:1));
}
