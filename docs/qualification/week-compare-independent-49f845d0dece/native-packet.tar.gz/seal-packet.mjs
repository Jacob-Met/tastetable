import assert from 'node:assert/strict';
import {readFile,writeFile,readdir,mkdir,chmod,stat} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {join,relative} from 'node:path';
import {createHash} from 'node:crypto';
const root='/Users/me/workspace/estate/tastetable-week-compare-receiving-49f845d0dece-mac',packet='/Users/me/workspace/estate/tastetable-week-compare-packet-49f845d0dece-mac';
const hash=(b,a='sha256')=>createHash(a).update(b).digest('hex');
const blob=b=>hash(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b]),'sha1');
await mkdir(packet,{recursive:true});
const baseline=JSON.parse(await readFile(join(root,'evidence/baseline-source-manifest.json'),'utf8'));
const candidate=JSON.parse(await readFile(join(root,'evidence/candidate-runtime-manifest.json'),'utf8'));
for(const [dir,files]of [['baseline-source',baseline.files],['candidate-771b2eb',candidate.files]])for(const f of files){const p=join(root,dir,f.path),b=await readFile(p);assert.equal(hash(b),f.sha256);assert.equal(blob(b),f.gitBlobSha1||f.sha);await chmod(p,f.mode==='100755'?0o755:0o644);}
const receipt=JSON.parse(await readFile(join(root,'evidence/candidate-browser-771b2eb-v1/receipt.json'),'utf8'));
assert.equal(receipt.status,'passed');assert.equal(receipt.groups.length,11);assert(receipt.groups.every(x=>x.status==='passed'));
assert.equal(hash(await readFile(join(root,'candidate-browser.mjs'))),'2b7374da6d96c7477993e871c192ca56ac3e43d03eea77d4dfcc1f050f22a8de');
for(const s of ['replay-candidate.mjs','candidate-browser.mjs','baseline-browser.mjs','stage-and-produce.mjs'])execFileSync(process.execPath,['--check',join(root,s)],{encoding:'utf8'});
const core=[];
async function walk(dir){for(const e of(await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){if(e.name==='.git'||e.name==='core-manifest.json')continue;const p=join(dir,e.name);if(e.isDirectory())await walk(p);else if(e.isFile()){const b=await readFile(p),s=await stat(p);core.push({path:relative(root,p),bytes:b.length,mode:(s.mode&0o111)?'100755':'100644',sha256:hash(b),gitBlobSha1:blob(b)});}}}
await walk(root);
await writeFile(join(root,'core-manifest.json'),JSON.stringify({owner:'estate-49f845d0dece/recall_import_receiving',candidate:'771b2ebfa41aef093e58b4801aae93ef24a152ce',contract:'7eb3f5098c8cd5510a68da5299859e0f0543721e',excludes:'This self-referential manifest and native .git only',files:core},null,2)+'\n');
const git=args=>execFileSync('/usr/bin/git',['-C',root,...args],{encoding:'utf8'});
git(['init','-b','estate/week-compare-native-49f845d0dece']);git(['add','--all']);
git(['-c','user.name=HAMON independent receiving','-c','user.email=estate-49f845d0dece@local.invalid','-c','commit.gpgsign=false','commit','-m','Seal independent saved-week comparison native producer and 11 browser receiving groups']);
const head=git(['rev-parse','HEAD']).trim(),tree=git(['rev-parse','HEAD^{tree}']).trim();
assert.equal(git(['status','--porcelain']).trim(),'');
const archive=join(packet,'native-packet.tar.gz');git(['archive','--format=tar.gz','--output='+archive,'HEAD']);
const ab=await readFile(archive);
const info={nativeHead:head,nativeTree:tree,coreFiles:core.length,coreBytes:core.reduce((n,x)=>n+x.bytes,0),coreManifestSha256:hash(await readFile(join(root,'core-manifest.json'))),archive:{name:'native-packet.tar.gz',bytes:ab.length,sha256:hash(ab),gitBlobSha1:blob(ab)},candidatePublic:'771b2ebfa41aef093e58b4801aae93ef24a152ce',candidateRuntimeManifestSha256:hash(await readFile(join(root,'evidence/candidate-runtime-manifest.json'))),receiverSha256:hash(await readFile(join(root,'candidate-browser.mjs'))),result:'11/11 passed',sourceFilesUnchangedAfterBrowser:32};
await writeFile(join(packet,'packet-info.json'),JSON.stringify(info,null,2)+'\n');
const selected=[['README.md','README.md'],['core-manifest.json','core-manifest.json'],['RECEIVING-CONTRACT.md','RECEIVING-CONTRACT.md'],['expected-arrangements.json','expected-arrangements.json'],['native-producer-receipt.json','evidence/native-producer-receipt.json'],['authentic-input-seal.json','evidence/authentic-input-seal.json'],['candidate-runtime-manifest.json','evidence/candidate-runtime-manifest.json'],['baseline-browser-receipt.json','evidence/baseline-browser/receipt.json'],['candidate-browser-receipt.json','evidence/candidate-browser-771b2eb-v1/receipt.json'],['refusal-design-witness.json','evidence/candidate-browser-771b2eb-v1/refusal-design-witness.json'],['environment-history.json','evidence/environment-history.json'],['thinkpad-native-producer-receipt.json','evidence/thinkpad-native-producer-receipt.json'],['receiver/candidate-browser-mac.mjs','candidate-browser.mjs'],['receiver/baseline-browser-mac.mjs','baseline-browser.mjs'],['receiver/stage-and-produce-mac.mjs','stage-and-produce.mjs'],['receiver/replay-candidate.mjs','replay-candidate.mjs'],['comparison-desktop.png','evidence/candidate-browser-771b2eb-v1/comparison-desktop.png'],['comparison-phone.png','evidence/candidate-browser-771b2eb-v1/comparison-phone.png']];
const files=[];
for(const [path,native]of selected){const b=await readFile(join(root,native)),binary=path.endsWith('.png');files.push({path,bytes:b.length,sha256:hash(b),gitBlobSha1:blob(b),encoding:binary?'base64':'utf-8',content:b.toString(binary?'base64':'utf8')});}
for(const path of ['native-packet.tar.gz','packet-info.json']){const b=await readFile(join(packet,path)),binary=path.endsWith('.gz');files.push({path,bytes:b.length,sha256:hash(b),gitBlobSha1:blob(b),encoding:binary?'base64':'utf-8',content:b.toString(binary?'base64':'utf8')});}
await writeFile(join(packet,'public-export.json'),JSON.stringify({info,files})+'\n');
console.log(JSON.stringify({...info,exportPath:join(packet,'public-export.json'),exportBytes:(await stat(join(packet,'public-export.json'))).size}));
