import json, pathlib, subprocess, sys
root = pathlib.Path("/Users/me/tastetable-native-plan-bd1abdb2f886-20261008")
completed = subprocess.run([sys.executable, str(root / "candidate_final.py")])
if completed.returncode:
    raise SystemExit(completed.returncode)
receipt = json.loads((root / "candidate-final-receipt.json").read_text())
if receipt["returncode"] != 0:
    raise SystemExit("final package gate did not pass")
completed = subprocess.run([sys.executable, str(root / "receive_actual_cli.py")])
raise SystemExit(completed.returncode)
