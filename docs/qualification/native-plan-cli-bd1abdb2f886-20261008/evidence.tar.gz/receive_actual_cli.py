import hashlib, json, os, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path("/Users/me/tastetable-native-plan-bd1abdb2f886-20261008")
CANDIDATE, BASE = ROOT / "candidate", ROOT / "baseline"
QA = ROOT / "actual-cli"
FINAL = json.loads((ROOT / "candidate-final-receipt.json").read_text())
assert FINAL["returncode"] == 0
def sha(raw): return hashlib.sha256(raw).hexdigest()
def check_source():
    for path, pin in FINAL["source_inputs"].items():
        assert sha((CANDIDATE / path).read_bytes()) == pin["sha256"], path
    for item in json.loads((ROOT / "source-inputs.json").read_text())["files"]:
        assert (BASE / item["path"]).read_bytes() == (CANDIDATE / item["path"]).read_bytes()
def space():
    if shutil.disk_usage(ROOT).free < 256 * 1024 * 1024:
        raise RuntimeError("pre-process disk guard refused qualification")
check_source()
space()
QA.mkdir(exist_ok=False)
hook = QA / "audit-hook"
hook.mkdir()
site = """import atexit, json, os, pathlib, sys
events = {"network_attempts": [], "fixture_reads": 0}
def audit(event, args):
    if event in ("socket.connect", "socket.getaddrinfo", "urllib.Request"):
        events["network_attempts"].append(event)
        raise RuntimeError("network forbidden in actual CLI receiving")
    if event == "open" and isinstance(args[0], str) and args[0].endswith("/fixtures/qloo_fixtures.json"):
        events["fixture_reads"] += 1
sys.addaudithook(audit)
atexit.register(lambda: pathlib.Path(os.environ["TASTETABLE_RECEIVING_AUDIT"]).write_text(json.dumps(events)))
"""
(hook / "sitecustomize.py").write_text(site)
base_env = dict(os.environ)
base_env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(hook),
                TASTETABLE_LIVE="1", QLOO_API_KEY="SYNTHETIC-NOT-A-KEY",
                QLOO_BASE_URL="https://must-not-contact.invalid",
                TASTETABLE_LLM_BASE_URL="https://must-not-contact.invalid",
                TASTETABLE_LLM_MODEL="must-not-run")
records = []
def run(name, command, *, data=None, code=0, fixtures=1, cwd=CANDIDATE, keep_stdin_open=False):
    space()
    check_source()
    audit_path = QA / (name + ".audit.json")
    env = dict(base_env, TASTETABLE_RECEIVING_AUDIT=str(audit_path))
    if keep_stdin_open:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            process.wait(timeout=5)
            process.stdin.close()
            process.stdin = None
            out, err = process.communicate(timeout=5)
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()
        returncode = process.returncode
    else:
        process = subprocess.run(command, cwd=cwd, env=env, input=data,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        out, err, returncode = process.stdout, process.stderr, process.returncode
    (QA / (name + ".stdout.json")).write_bytes(out)
    (QA / (name + ".stderr.txt")).write_bytes(err)
    audit = json.loads(audit_path.read_text())
    record = {"name":name,"command":command,"cwd":str(cwd),"returncode":returncode,
              "stdout_sha256":sha(out),"stderr_sha256":sha(err),
              "audit":audit,"audit_sha256":sha(audit_path.read_bytes()),
              "stdin_left_open_without_bytes":keep_stdin_open}
    records.append(record)
    assert returncode == code, record
    assert audit == {"network_attempts":[],"fixture_reads":fixtures}, record
    if code: assert out == b"", record
    if not code: assert err == b"", record
    return out
cli = [sys.executable, str(CANDIDATE / "tastetable_cli.py")]
reference_code = """import json,sys
from agent import ScriptedModel,run_agent
from qloo_client import QlooClient,FixtureTransport
profile=json.loads(open(sys.argv[1],encoding="utf-8").read())
print(json.dumps(run_agent(profile,qloo=QlooClient(api_key="MOCK-NOT-A-KEY",transport=FixtureTransport()),model=ScriptedModel()),allow_nan=False,indent=2))
"""
example = CANDIDATE / "examples/native-profile.json"
example_before = example.read_bytes()
example_reference = json.loads(run("baseline-example-producer",
    [sys.executable,"-c",reference_code,str(example)],cwd=BASE))
unknown_profile = {"cuisines":["Cuban"],"music":["Celia Cruz"],"films":[],
                   "constraints":["wheelchair"],"city":"Outside Fixture City"}
unknown = QA / "authored-unknown-city.json"
unknown.write_text(json.dumps(unknown_profile)+"\n")
unknown_before = unknown.read_bytes()
unknown_reference = json.loads(run("baseline-authored-producer",
    [sys.executable,"-c",reference_code,str(unknown)],cwd=BASE))
mei = json.loads(run("persona-mei",cli+["--persona","mei"]))
old_mei = json.loads((ROOT / "native_mei_full_reference.stdout.json").read_bytes())
assert mei["response"] == old_mei
file_bytes = run("profile-example-file",cli+["--profile",str(example)])
file_result = json.loads(file_bytes)
stdin_bytes = run("profile-example-stdin",cli+["--profile","-"],data=example_before)
assert file_bytes == stdin_bytes
assert file_result["response"] == example_reference
unknown_result = json.loads(run("profile-authored-city",cli+["--profile",str(unknown)]))
assert unknown_result["profile"] == unknown_profile
assert unknown_result["response"] == unknown_reference
assert unknown_result["response"]["plan"]["meals"] == []
assert unknown_result["response"]["plan"]["outing"] is None
assert unknown_result["response"]["plan"]["notes"]
for envelope in (mei,file_result,unknown_result):
    assert set(envelope) == {"provenance","profile","response"}
    assert envelope["provenance"]["mode"] == "offline-fixtures"
    assert envelope["provenance"]["data"] == "fictional venues and hand-set affinities"
    assert envelope["response"]["mock"] is True
run("dual-source-open-stdin",cli+["--profile","-","--persona","mei"],
    code=2,fixtures=0,keep_stdin_open=True)
oversized = QA / "oversized.json"
oversized.write_bytes(b" " * 65537)
oversized_before = oversized.read_bytes()
run("oversized-file",cli+["--profile",str(oversized)],code=2,fixtures=0)
assert example.read_bytes() == example_before
assert unknown.read_bytes() == unknown_before
assert oversized.read_bytes() == oversized_before
check_source()
receipt = {"kind":"actual-script-command-receiving","source":FINAL["source"],
 "source_tree":FINAL["source_tree"],"python":sys.version,"cli_invocation":"python3 /absolute/path/tastetable_cli.py (no runpy wrapper)",
 "driver_sha256":sha(pathlib.Path(__file__).read_bytes()),"startup_audit_hook_sha256":sha(site.encode()),
 "final_package_receipt_sha256":sha((ROOT/"candidate-final-receipt.json").read_bytes()),
 "reused_original_mei_producer_sha256":sha((ROOT/"native_mei_full_reference.stdout.json").read_bytes()),
 "source_inputs":FINAL["source_inputs"],"processes":records,
 "actual_candidate_commands":6,"additional_original_producers":2,
 "accepted":True,"complete_response_equalities":3,"file_stdin_bytes_equal":True,
 "all_input_files_preserved":True,"all_five_original_and_nine_candidate_inputs_preserved":True,
 "network_attempts":0,"provider_environment":"synthetic live settings were present; no real credential was selected or exposed",
 "free_bytes_after":shutil.disk_usage(ROOT).free}
path = ROOT / "actual-cli-receipt.json"
path.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"receipt":str(path),"sha256":sha(path.read_bytes()),
 "candidate_commands":6,"additional_original_producers":2,"accepted":True,
 "driver_sha256":receipt["driver_sha256"],"free_bytes_after":receipt["free_bytes_after"]}))
