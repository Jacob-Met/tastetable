import hashlib, json, os, pathlib, re, shutil, subprocess, sys
ROOT = pathlib.Path("/Users/me/tastetable-native-plan-bd1abdb2f886-20261008")
CANDIDATE = ROOT / "candidate"
source = json.loads((ROOT / "source-inputs.json").read_text())
payload = json.loads((ROOT / "final-candidate-payload.json").read_text())
def digest(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
def check():
    pins = {}
    for item in source["files"]:
        raw = (ROOT / "baseline" / item["path"]).read_bytes()
        assert blob(raw) == item["sha"], item["path"]
        assert (CANDIDATE / item["path"]).read_bytes() == raw, item["path"]
        pins[item["path"]] = {"blob": blob(raw), "sha256": digest(raw)}
    for item in payload["files"]:
        raw = item["content"].encode("utf-8")
        assert (CANDIDATE / item["path"]).read_bytes() == raw, item["path"]
        pins[item["path"]] = {"blob": blob(raw), "sha256": digest(raw)}
    return pins
pins = check()
if shutil.disk_usage(ROOT).free < 256 * 1024 * 1024: raise SystemExit("insufficient free space")
assert not (ROOT / "candidate-final-receipt.json").exists()
cmd = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_native_plan_cli.py", "-v"]
p = subprocess.run(cmd, cwd=CANDIDATE, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
(ROOT / "candidate-final.stdout.txt").write_bytes(p.stdout)
(ROOT / "candidate-final.stderr.txt").write_bytes(p.stderr)
assert check() == pins
count = re.search(rb"Ran (\d+) tests", p.stderr)
receipt = {"kind":"native-candidate-final-qualification","source":source["source"],
 "source_tree":source["tree"],"python":sys.version,"command":cmd,"returncode":p.returncode,
 "tests":int(count[1]) if count else None,"source_inputs":pins,
 "all_five_original_inputs_preserved":True,"all_nine_candidate_inputs_preserved":True,
 "driver_sha256":digest(pathlib.Path(__file__).read_bytes()),
 "stdout_sha256":digest(p.stdout),"stderr_sha256":digest(p.stderr),
 "retained_initial_failure":"candidate-first-receipt.json",
 "correction":"Only the deep-array diagnostic oracle changed: implementations may reject JSON nesting during parsing or accept the array and reject its top-level shape. Exit2, empty stdout, no fixture reads and no network remain required. CLI source is unchanged.",
 "free_bytes_after":shutil.disk_usage(ROOT).free}
out = ROOT / "candidate-final-receipt.json"
out.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"receipt":str(out),"sha256":digest(out.read_bytes()),"exit":p.returncode,"tests":receipt["tests"],"pins":pins}))
if p.returncode: print(p.stderr.decode("utf-8",errors="replace")[-14000:])
raise SystemExit(p.returncode)
