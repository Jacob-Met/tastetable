import hashlib, json, os, pathlib, re, shutil, subprocess, sys
ROOT = pathlib.Path("/Users/me/tastetable-native-plan-bd1abdb2f886-20261008")
BASE, CANDIDATE = ROOT / "baseline", ROOT / "candidate"
source = json.loads((ROOT / "source-inputs.json").read_text())
payload = json.loads((ROOT / "candidate-payload.json").read_text())
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
if shutil.disk_usage(ROOT).free < 256 * 1024 * 1024:
    raise SystemExit("insufficient free space")
CANDIDATE.mkdir(exist_ok=False)
pins = {}
for item in source["files"]:
    raw = (BASE / item["path"]).read_bytes()
    assert blob(raw) == item["sha"], item["path"]
    target = CANDIDATE / item["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    pins[item["path"]] = {"blob": blob(raw), "sha256": digest(raw), "bytes": len(raw)}
authored = {}
for item in payload["files"]:
    raw = item["content"].encode("utf-8")
    target = CANDIDATE / item["path"]
    assert not target.exists(), item["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    authored[item["path"]] = {"blob": blob(raw), "sha256": digest(raw), "bytes": len(raw)}
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
command = [sys.executable, "-m", "unittest", "discover", "-s", "tests",
           "-p", "test_native_plan_cli.py", "-v"]
result = subprocess.run(command, cwd=CANDIDATE, env=env,
                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
out, err = ROOT / "candidate-first.stdout.txt", ROOT / "candidate-first.stderr.txt"
out.write_bytes(result.stdout)
err.write_bytes(result.stderr)
preserved = []
for path, pin in pins.items():
    assert digest((BASE / path).read_bytes()) == pin["sha256"], path
    assert digest((CANDIDATE / path).read_bytes()) == pin["sha256"], path
    preserved.append(path)
for path, pin in authored.items():
    assert digest((CANDIDATE / path).read_bytes()) == pin["sha256"], path
count = re.search(rb"Ran (\d+) tests", result.stderr)
receipt = {
    "kind": "native-candidate-first-qualification",
    "source": source["source"], "source_tree": source["tree"], "python": sys.version,
    "command": command, "returncode": result.returncode,
    "tests": int(count[1]) if count else None, "driver_sha256": digest(pathlib.Path(__file__).read_bytes()),
    "source_inputs": pins, "authored_inputs": authored,
    "all_original_inputs_preserved": preserved,
    "stdout_sha256": digest(result.stdout), "stderr_sha256": digest(result.stderr),
    "free_bytes_after": shutil.disk_usage(ROOT).free,
    "note": "Original demonstration/reference baseline remains separate. Maintained process controls explicitly assert no network and fixture admission ordering."
}
path = ROOT / "candidate-first-receipt.json"
path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"receipt": str(path), "sha256": digest(path.read_bytes()),
                  "exit": result.returncode, "tests": receipt["tests"],
                  "authored": authored, "preserved": len(preserved)}))
if result.returncode:
    print(result.stderr.decode("utf-8", errors="replace")[-14000:])
raise SystemExit(result.returncode)
