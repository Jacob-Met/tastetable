import hashlib, json, os, pathlib, shutil, subprocess, sys, time

ROOT = pathlib.Path("/Users/me/tastetable-native-plan-bd1abdb2f886-20261008")
BUNDLE = ROOT / "source-inputs.json"
DATA = json.loads(BUNDLE.read_text())
BASE = ROOT / "baseline"
if shutil.disk_usage(ROOT).free < 256 * 1024 * 1024:
    raise SystemExit("insufficient free space")
BASE.mkdir(exist_ok=False)
def sha256(data):
    return hashlib.sha256(data).hexdigest()
def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
pins = {}
for item in DATA["files"]:
    raw = item["content"].encode("utf-8")
    assert blob(raw) == item["sha"], item["path"]
    dst = BASE / item["path"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(raw)
    pins[item["path"]] = {"blob": blob(raw), "sha256": sha256(raw), "bytes": len(raw)}
guard = '''import atexit, json, sys
network = []
def audit(event, args):
    if event in ("socket.connect", "socket.getaddrinfo", "urllib.Request"):
        network.append(event)
        raise RuntimeError("network forbidden in native qualification")
sys.addaudithook(audit)
atexit.register(lambda: print(json.dumps({"network_attempts": network}), file=sys.stderr))
'''
old = guard + '''import runpy
sys.argv = ["agent.py"] + sys.argv[1:]
runpy.run_path("agent.py", run_name="__main__")
'''
reference = guard + '''from agent import run_agent, ScriptedModel
from qloo_client import QlooClient, FixtureTransport
from personas import PERSONAS
result = run_agent(PERSONAS["mei"], qloo=QlooClient(api_key="MOCK-NOT-A-KEY", transport=FixtureTransport()), model=ScriptedModel())
print(json.dumps(result, allow_nan=False, indent=2))
'''
env = dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE="1", TASTETABLE_LIVE="0")
records = {}
for name, code, args in [
    ("original_demo", old, []),
    ("original_extra_persona_mei", old, ["--persona", "mei"]),
    ("native_mei_full_reference", reference, []),
]:
    process = subprocess.run([sys.executable, "-c", code, *args], cwd=BASE, env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    (ROOT / (name + ".stdout.json")).write_bytes(process.stdout)
    (ROOT / (name + ".stderr.txt")).write_bytes(process.stderr)
    assert process.returncode == 0, (name, process.returncode, process.stderr)
    audit_result = json.loads(process.stderr.decode("utf-8"))
    assert audit_result == {"network_attempts": []}, audit_result
    records[name] = {"returncode": process.returncode,
                     "stdout_sha256": sha256(process.stdout),
                     "stderr_sha256": sha256(process.stderr),
                     "network_attempts": [], "result": json.loads(process.stdout)}
original = records["original_demo"]["result"]
extra = records["original_extra_persona_mei"]["result"]
reference_result = records["native_mei_full_reference"]["result"]
assert original == extra
assert reference_result["mock"] is True
assert reference_result["plan"] != original
assert set(reference_result) == {"plan", "llm_only", "comparison", "trace", "model_message", "mock"}
assert reference_result["trace"]
for path, identity in pins.items():
    assert sha256((BASE / path).read_bytes()) == identity["sha256"], path
receipt = {
    "kind": "native-existing-consumer-gap-baseline",
    "source": DATA["source"], "tree": DATA["tree"], "python": sys.version,
    "driver_sha256": sha256(pathlib.Path(__file__).read_bytes()),
    "source_bundle_sha256": sha256(BUNDLE.read_bytes()), "source_inputs": pins,
    "controls": [
        {"name": "existing demo ignores --persona mei", "passed": original == extra},
        {"name": "unchanged native planner can produce a distinct Mei full response",
         "passed": reference_result["plan"] != original},
        {"name": "all source inputs unchanged and all three processes attempted no network", "passed": True},
    ],
    "processes": records,
    "limitation": "The existing entry point is a documented hardwired demo, not a promised argument interface. This establishes the missing consumer, not a regression against an existing CLI contract.",
    "free_bytes_after": shutil.disk_usage(ROOT).free
}
out = ROOT / "baseline-receipt.json"
out.write_text(json.dumps(receipt, indent=2, ensure_ascii=True, allow_nan=False) + "\n")
print(json.dumps({"receipt": str(out), "sha256": sha256(out.read_bytes()),
                  "source_files": len(pins), "processes": len(records),
                  "all_controls_pass": True, "free_bytes_after": receipt["free_bytes_after"]}))
