import atexit, json, os, pathlib, sys
events = {"network_attempts": [], "fixture_reads": 0}
def audit(event, args):
    if event in ("socket.connect", "socket.getaddrinfo", "urllib.Request"):
        events["network_attempts"].append(event)
        raise RuntimeError("network forbidden in actual CLI receiving")
    if event == "open" and isinstance(args[0], str) and args[0].endswith("/fixtures/qloo_fixtures.json"):
        events["fixture_reads"] += 1
sys.addaudithook(audit)
atexit.register(lambda: pathlib.Path(os.environ["TASTETABLE_RECEIVING_AUDIT"]).write_text(json.dumps(events)))
