import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const receiving = '/workspace/scratch/45d4289ccf6c/agents/github_receiving';
const output = '/workspace/scratch/45d4289ccf6c/agents/production_recovery/tastetable-audit';
const read = (name) => JSON.parse(fs.readFileSync(path.join(receiving, name), 'utf8'));
const sha = (bytes, algorithm = 'sha256') => createHash(algorithm).update(bytes).digest('hex');
const manifest = read('receiving-manifest.json');
const manifestMismatches = manifest.files.filter((row) => {
  const bytes = fs.readFileSync(path.join(receiving, row.path));
  return bytes.length !== row.bytes || sha(bytes) !== row.sha256;
}).map((row) => row.path);
const sources = [];
const folders = { candidate: 'tastetable', main: 'tastetable-main', pr2: 'tastetable-pr2' };
for (const [key, source] of Object.entries(read('all-source-verification.json'))) {
  const dir = path.join(receiving, folders[key]);
  const actualLeaves = [];
  function collect(base, relative = '') {
    for (const entry of fs.readdirSync(base, { withFileTypes: true })) {
      const name = path.join(relative, entry.name);
      if (entry.isDirectory()) collect(path.join(base, entry.name), name);
      else actualLeaves.push(name);
    }
  }
  collect(dir);
  const errors = [];
  for (const row of source.blobs) {
    const file = path.join(dir, row.path);
    const bytes = fs.readFileSync(file);
    const git = createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex');
    const mode = fs.statSync(file).mode & 0o111 ? '100755' : '100644';
    if (sha(bytes) !== row.sha256 || git !== row.git_blob || mode !== row.mode) errors.push(row.path);
  }
  const expected = source.blobs.map((row) => row.path).sort();
  sources.push({ name: key, commit: source.source, leaves: expected.length,
    exact: !errors.length && JSON.stringify(actualLeaves.sort()) === JSON.stringify(expected), errors });
}
const original = read('http-candidate.json');
const replay = JSON.parse(fs.readFileSync(path.join(output, 'http-candidate-replay.json'), 'utf8'));
const signature = (report) => JSON.stringify(report.records.map((row) => ({
  mode: row.mode, case: row.case, persona: row.persona, route: row.route,
  status: row.status, response_sha256: row.response_sha256,
  violations: row.violations, wire: row.wire,
})));
const crossSourceControls = [];
for (const source of ['main', 'pr2']) {
  for (const row of read(`http-${source}.json`).records) {
    if (row.status !== 200 || !(row.case.startsWith('healthy-') || row.case === 'recovered')) continue;
    const matching = replay.records.find((r) => r.mode === row.mode && r.case === row.case && r.route === row.route && r.persona === row.persona);
    crossSourceControls.push({ source, mode: row.mode, case: row.case, route: row.route,
      unchanged: matching?.response_sha256 === row.response_sha256 });
  }
}
const suites = Object.fromEntries(['main', 'pr2', 'candidate'].map((name) => {
  const log = fs.readFileSync(path.join(output, `suite-${name}-replay.log`), 'utf8');
  const match = log.match(/^(\d+) passed, .*$/m);
  return [name, { passed: match ? Number(match[1]) : null, summary: match?.[0] ?? null, log_sha256: sha(log) }];
}));
const receipt = {
  reviewer: 'estate-45d4289ccf6c/production_recovery',
  receivingManifestSha256: sha(fs.readFileSync(path.join(receiving, 'receiving-manifest.json'))),
  receivingManifestEntries: manifest.files.length,
  manifestMismatches,
  sourceVerificationAfterReplays: sources,
  suiteReplays: suites,
  httpReplay: { cases: replay.cases, passed: replay.passed, failed: replay.failed,
    serversStopped: replay.server_stopped, exactBehavioralRecords: signature(replay) === signature(original),
    sha256: sha(fs.readFileSync(path.join(output, 'http-candidate-replay.json'))) },
  crossSourceControls,
  sourceReview: {
    pr2: 'Only the model_name default/selection boundary changes; explicit overrides and ordinary scripted defaults remain covered.',
    pr3: 'Only the two primary/outing result candidate reads change to .get("candidates", []). The existing tool-error envelope and deterministic assembly remain unchanged.',
    acceptanceBasis: 'Exact narrow source changes, full native suites, real local HTTP routing/error counterexamples, candidate replay, and unchanged healthy responses across predecessors.',
  },
  limits: [
    'The HTTP model peer executes this same source\'s scripted policy. It verifies transport, serialization, configured model routing and application composition; it is not independent inference behavior.',
    'Qloo outage numbers are synthetic fixture-call positions. No live Qloo, production provider, caregiver study, deployment or medical/scientific validity is established.',
    'HTTP pick admission checks trace membership, not independent constraint re-evaluation. The existing native suite re-evaluates healthy fixture meals, and unchanged deterministic assembly was independently inspected.',
    'Suite counts 19/25/30 reflect added test modules, not a standalone before/after outcome metric. The identical HTTP matrix supplies the comparative behavioral evidence.',
    'The original optimized source suite is reviewed evidence; this peer independently reran the three ordinary suites and the candidate HTTP matrix.',
    'Remote source/draft/head checks in github-receiving.json were supplied by github_receiving. Root retains current expected-head integration and custody checks.',
  ],
  decision: 'accepted for source-only receiving of original PR2 followed by stacked PR3; no material defect found within their claimed scope',
  sourceMutations: false,
};
if (manifestMismatches.length || sources.some((row) => !row.exact) ||
    [suites.main.passed, suites.pr2.passed, suites.candidate.passed].join() !== '19,25,30' ||
    replay.cases !== 26 || replay.failed !== 0 || !replay.server_stopped ||
    signature(replay) !== signature(original) || crossSourceControls.some((row) => !row.unchanged)) {
  throw new Error('Independent audit evidence mismatch; no accepting receipt written');
}
fs.writeFileSync(path.join(output, 'independent-audit.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify({ decision: receipt.decision, manifestEntries: manifest.files.length,
  exactSourceLeaves: sources.reduce((n, s) => n + s.leaves, 0),
  suiteCounts: [suites.main.passed, suites.pr2.passed, suites.candidate.passed],
  httpPassed: replay.passed, healthyCrossSourceControls: crossSourceControls.length }, null, 2));
