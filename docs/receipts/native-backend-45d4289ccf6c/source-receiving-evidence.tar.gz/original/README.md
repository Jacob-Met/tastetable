# TasteTable native receiving — estate-45d4289ccf6c

## Receiving decision

The original configured-model and recommendation-error contributions are
qualified for source integration at their unchanged heads. This review closes
the previously unexecuted full pytest gate and exercises the complete product
route through real local HTTP. It makes no production-source change.

| Source | Exact commit | Complete source pytest | Independent HTTP matrix |
| --- | --- | --- | --- |
| Main | `d1c7a4e39cfdc0bb5b9fe026bc9660b75b456e81` | 19 passed | 7 passed / 19 failed |
| PR #2 | `cdd6475f5ad31bdb0deec2abe8bc7180ac1fc581` | 25 passed | 14 passed / 12 failed |
| Stacked PR #3 | `7002a16a3b46c7318826ce9975fd812096925f42` | 30 passed | 26 passed / 0 failed |

The PR #3 suite also passes 30 tests under Python optimization; pytest reports
that assertions outside rewritten test modules/plugins are disabled. The six
reported unittest subtests are retained separately and are not added to the
30-test count. The resolved Starlette release warns about its httpx TestClient
compatibility. Both warnings are present in the exact logs; neither was hidden
or repaired as part of this receiving scope.

## What the independent check establishes

`receive_http.py` starts the real FastAPI app through Uvicorn on an exclusively
owned loopback socket. The opt-in model path talks through real HTTP to another
owned server using the OpenAI-compatible protocol. That peer runs the existing
scripted policy and refuses any model identifier except the configured fixture
identifier. Qloo uses the repository's synthetic fixtures with independently
authored primary, fallback, outing, and complete-outage failures. All provider
environment variables are removed; outbound urllib requests are restricted to
the one owned model endpoint.

The 26 cases cover three healthy personas plus five failure/recovery cases on
each of the sample and submitted-form routes, in both default scripted mode and
the opt-in HTTP-model mode. The candidate preserves complete healthy responses
between both model modes; completes all ten model steps with the configured
identifier; keeps checked meals exactly intact when the outing fails; retains
the primary meals when fallback fails; labels synthetic source data; preserves
outage evidence and honest empty slots; stays within the existing three-insights
request budget; and returns the original healthy response after failed requests.
Both servers terminate after each driver invocation.

The main counterexample has six scripted HTTP 500s for primary/outing/complete
outages, plus all thirteen model-mode requests failing because the wrong model
identifier reaches the peer. PR #2 repairs model routing and leaves twelve
outage HTTP 500s across both modes. The stacked candidate repairs all remaining
cases. This is real HTTP and real application execution with synthetic model and
recommendation responses, not a provider inference, live Qloo qualification,
caregiver study, deployment or medical/scientific validation.

## Source custody

Every file and mode in each complete GitHub tree was recovered and checked
against its Git blob, both before qualification and after testing. The retained
receipt covers 17 main, 18 PR #2, and 19 PR #3 leaves. The candidate `agent.py`
Git blob is `fcf867e844835a08496a0fdf8132c69990ccfffc`; SHA-256 is
`3d12eb0f275516cd8d1b4044d010a8ed914629f427b1cc1490958f865fe31da8`.

An initial helper wrote an extra terminal newline to the two predecessor
`agent.py` copies. Their first suite logs are explicitly marked
`excluded-extra-newline-*`; those runs are excluded from the exact-source
table. The byte discrepancy was found by Git-blob verification, corrected from
the fetched source, and both predecessor suites rerun. The candidate was exact
from initial recovery. No production fix was needed.

## Replay

Use Python 3.12 and the original repository requirements. `dependencies.txt`
records the exact packages resolved for this execution. Prepare three isolated
source checkouts at the commits above; no other files from the author's or
another worker's checkout are required.

```bash
python3.12 -m venv receiving-venv
receiving-venv/bin/python -m pip install -r candidate/requirements.txt
receiving-venv/bin/python -B run_source_tests.py candidate
receiving-venv/bin/python -O -B run_source_tests.py candidate
receiving-venv/bin/python -B receive_http.py candidate --out http-candidate.json
receiving-venv/bin/python -B receive_http.py main-source --out http-main.json
receiving-venv/bin/python -B receive_http.py pr2-source --out http-pr2.json
```

The two predecessor HTTP commands intentionally exit 1. They retain ordinary
responses and the exact failed cases; the candidate exits 0. The source suite
runner disables bytecode/cache writes and forbids ordinary urllib networking.
The HTTP driver confines all network work to its two synthetic loopback peers.

## Integration and ownership

The qualified stack is original PR #2 followed by original PR #3. At observation
both remained drafts with their heads unchanged. No hosted check runs existed
for PR #3. Source merge, review publication, installed runtime and user-facing
operation are separate states; this local receipt does not claim any of them.

Calendar/export (`tastetable #4`, estate-9e05c01af69c), request lifecycle
(`chatgpt-a2eaaec253d8`), and edited-week organizer composition
(`universal-0df473646168`) retain their browser and product ownership. This
receiver changes none of those surfaces, the constraint implementation,
fixture data, dependencies, deployment or provider configuration. The session
lead owns final expected-head integration and estate-native continuity.
