"""Run the real TasteTable ASGI app behind synthetic receiving boundaries.

Used only by check-backend-receiving.mjs. No application files are rewritten,
and provider HTTP calls are either synthesized in memory or refused.
"""
from __future__ import annotations

import argparse
import io
import json
import os
from pathlib import Path
import socket
import sys
import urllib.request


parser = argparse.ArgumentParser()
parser.add_argument("--project", type=Path, required=True)
parser.add_argument("--scenario", choices=("healthy", "outing_503", "primary_429", "all_429", "configured"), required=True)
parser.add_argument("--receipt", type=Path, required=True)
args = parser.parse_args()

for name in ("QLOO_API_KEY", "TASTETABLE_LIVE", "QLOO_BASE_URL", "TASTETABLE_LLM_BASE_URL",
             "TASTETABLE_LLM_MODEL", "TASTETABLE_LLM_API_KEY", "TASTETABLE_SOURCE_ROOT"):
    os.environ.pop(name, None)

MODEL_URL = "https://model.receiving.invalid/v1/chat/completions"
MODEL_NAME = "receiving-configured-model"
if args.scenario == "configured":
    os.environ["TASTETABLE_LLM_BASE_URL"] = MODEL_URL.removesuffix("/chat/completions")
    os.environ["TASTETABLE_LLM_MODEL"] = MODEL_NAME

sys.path.insert(0, str(args.project.resolve()))
import agent
import app as web
from qloo_client import FixtureTransport, QlooClient, QlooError
import uvicorn

record = {"scenario": args.scenario, "application": str(Path(web.__file__).resolve()),
          "provider_network_attempts": 0, "model_names": [], "fixtures": [],
          "requests": [], "exceptions": []}
failures = {"healthy": {}, "configured": {}, "outing_503": {3: 503},
            "primary_429": {1: 429}, "all_429": {1: 429, 2: 429, 3: 429}}[args.scenario]


class ReceivingFixture(FixtureTransport):
    def __init__(self):
        super().__init__()
        self.calls = []
        record["fixtures"].append(self.calls)

    def __call__(self, path, params, headers):
        if path == "/v2/insights":
            number = len(self.calls) + 1
            status = failures.get(number, 200)
            self.calls.append({"number": number, "status": status,
                               "filter_tags": params.get("filter.tags", "")})
            if status != 200:
                raise QlooError(status, "receiving fixture refusal")
        return super().__call__(path, params, headers)


def fixture_client(cls):
    return cls(api_key="RECEIVING-SYNTHETIC-ONLY", transport=ReceivingFixture())


def guarded_urlopen(request, *unused_args, **unused_kwargs):
    if args.scenario == "configured" and getattr(request, "full_url", None) == MODEL_URL:
        body = json.loads(request.data)
        record["model_names"].append(body.get("model"))
        completion = agent.ScriptedModel().chat.completions.create(**body)
        return io.BytesIO(json.dumps(completion).encode())
    record["provider_network_attempts"] += 1
    raise AssertionError("receiving run forbids provider network requests")


QlooClient.from_env = classmethod(fixture_client)
urllib.request.urlopen = guarded_urlopen


async def recorded_app(scope, receive, send):
    event = None
    if scope["type"] == "http":
        event = {"method": scope["method"], "path": scope["path"], "status": None}
        record["requests"].append(event)

    async def recorded_send(message):
        if event is not None and message["type"] == "http.response.start":
            event["status"] = message["status"]
        await send(message)

    try:
        await web.app(scope, receive, recorded_send)
    except Exception as exc:
        record["exceptions"].append({"path": scope.get("path"), "type": type(exc).__name__,
                                     "message": str(exc)})
        raise


listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
listener.bind(("127.0.0.1", 0))
listener.listen(128)
print(json.dumps({"origin": f"http://127.0.0.1:{listener.getsockname()[1]}"}), flush=True)
server = uvicorn.Server(uvicorn.Config(recorded_app, log_level="critical", access_log=False))
try:
    server.run(sockets=[listener])
finally:
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    listener.close()
