/** Real loopback FastAPI/browser receiving for the original PR #2/#3 stack. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const options = {};
for (let i = 2; i < process.argv.length; i += 2) {
  assert.match(process.argv[i], /^--[a-z]+$/);
  assert.ok(process.argv[i + 1], `Missing value for ${process.argv[i]}`);
  options[process.argv[i].slice(2)] = process.argv[i + 1];
}
for (const key of ['project', 'python', 'playwright', 'chromium', 'output', 'expect']) {
  assert.ok(options[key], `Required: --${key}`);
}
assert.ok(['original', 'fixed'].includes(options.expect));
const project = path.resolve(options.project);
const output = path.resolve(options.output);
const here = path.dirname(fileURLToPath(import.meta.url));
const { chromium } = await import(pathToFileURL(path.resolve(options.playwright)).href);
const hash = value => createHash('sha256').update(value).digest('hex');
const env = { ...process.env, PYTHONDONTWRITEBYTECODE: '1', PYTHONUNBUFFERED: '1' };
for (const key of ['QLOO_API_KEY', 'TASTETABLE_LIVE', 'QLOO_BASE_URL', 'TASTETABLE_LLM_BASE_URL',
  'TASTETABLE_LLM_MODEL', 'TASTETABLE_LLM_API_KEY', 'TASTETABLE_SOURCE_ROOT']) delete env[key];
await mkdir(output, { recursive: true });
const git = (...args) => {
  const result = spawnSync('git', ['-C', project, ...args], { encoding: 'utf8', env });
  assert.equal(result.status, 0, result.stderr);
  return result.stdout.trim();
};
const receipt = {
  started_at: new Date().toISOString(), expected_behavior: options.expect,
  source: { root: project, commit: git('rev-parse', 'HEAD'), tracked_diff: git('diff', '--name-only'), files: {} },
  runtime: { node: process.version }, scenarios: [], checks: [], passed: false,
};
for (const file of ['app.py', 'agent.py', 'qloo_client.py', 'static/app.js', 'static/index.html',
  'static/style.css', 'fixtures/qloo_fixtures.json']) receipt.source.files[file] = hash(await readFile(path.join(project, file)));
const check = (name, fn) => {
  try { fn(); receipt.checks.push({ name, passed: true }); }
  catch (error) { receipt.checks.push({ name, passed: false, error: error.message }); throw error; }
};
const bounded = async (promise, label, milliseconds = 15000) => {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`Timeout: ${label}`)), milliseconds);
    })]);
  } finally { clearTimeout(timer); }
};

async function startServer(scenario) {
  const telemetryPath = path.join(output, `${scenario}-server.json`);
  const child = spawn(options.python, ['-u', path.join(here, 'receiving_server.py'),
    '--project', project, '--scenario', scenario, '--receipt', telemetryPath], { env, stdio: ['ignore', 'pipe', 'pipe'] });
  let stdout = '', stderr = '';
  child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
  const done = once(child, 'exit');
  const origin = await bounded(new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', code => reject(new Error(`Server exited during startup (${code}): ${stderr}`)));
    child.stderr.on('data', data => { stderr += data; });
    child.stdout.on('data', data => {
      stdout += data;
      const line = stdout.split('\n')[0];
      if (stdout.includes('\n')) {
        try { resolve(JSON.parse(line).origin); } catch (error) { reject(error); }
      }
    });
  }), `${scenario} server startup`);
  return { origin, stop: async () => {
    child.kill('SIGINT');
    await bounded(done, `${scenario} server shutdown`);
    await writeFile(path.join(output, `${scenario}-server.log`), stdout + stderr);
    return JSON.parse(await readFile(telemetryPath, 'utf8'));
  } };
}

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
let browser;
try {
  browser = await chromium.launch({ executablePath: options.chromium, headless: true, args: ['--no-sandbox'] });
  receipt.runtime.chromium = browser.version();
  for (const scenario of ['healthy', 'outing_503', 'primary_429', 'all_429', 'configured']) {
    const server = await startServer(scenario);
    const row = { scenario, responses: [], dialogs: [], page_errors: [], blocked_requests: [] };
    receipt.scenarios.push(row);
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    await context.route('**/*', route => {
      if (new URL(route.request().url()).origin === server.origin) return route.continue();
      row.blocked_requests.push(route.request().url());
      return route.abort('blockedbyclient');
    });
    const page = await context.newPage();
    page.on('pageerror', error => row.page_errors.push(error.message));
    let dialogSignal;
    page.on('dialog', async dialog => {
      row.dialogs.push(dialog.message());
      await dialog.dismiss();
      dialogSignal?.();
    });
    try {
      await page.goto(server.origin, { waitUntil: 'networkidle' });
      await page.waitForFunction(() => document.querySelectorAll('#personaSel option').length === 3);
      const mode = await page.locator('#mode').innerText();
      check(`${scenario}: actual static app is in mock mode`, () => assert.match(mode, /Demo mode.*synthetic fixture/));

      async function plan(kind, persona = 'rosa') {
        const label = kind === 'sample' ? persona : 'form';
        const endpoint = kind === 'sample' ? `/api/plan/sample/${persona}` : '/api/plan';
        if (kind === 'sample') await page.locator('#personaSel').selectOption(persona);
        else {
          await page.locator('[name=cuisines]').fill('Cuban, Mexican');
          await page.locator('[name=music]').fill('Celia Cruz');
          await page.locator('[name=films]').fill('West Side Story');
          await page.locator('[name=city]').fill('Pasadena');
          for (const constraint of ['soft_foods', 'low_sodium', 'wheelchair']) {
            await page.locator(`[name=constraints][value=${constraint}]`).check();
          }
        }
        const dialogPromise = new Promise(resolve => { dialogSignal = resolve; });
        const responsePromise = page.waitForResponse(response =>
          new URL(response.url()).pathname === endpoint && response.request().method() === 'POST');
        await page.locator(kind === 'sample' ? '#sampleBtn' : '#form button[type=submit]').click();
        const response = await responsePromise;
        const body = await response.body();
        const status = response.status();
        const originalFailure = options.expect === 'original' && ['outing_503', 'primary_429', 'all_429'].includes(scenario);
        check(`${scenario}/${label}: real API status`, () => assert.equal(status, originalFailure ? 500 : 200));
        const saved = `${scenario}-${label}.${status === 200 ? 'json' : 'txt'}`;
        await writeFile(path.join(output, saved), body);
        const observed = { action: kind, persona, path: endpoint, status, body_sha256: hash(body), response_file: saved };
        row.responses.push(observed);
        if (originalFailure) {
          await bounded(dialogPromise, `${scenario}/${label} frontend error alert`);
          const hidden = await page.locator('#results').evaluate(node => node.hidden);
          check(`${scenario}/${label}: original request loses the plan`, () => assert.equal(hidden, true));
          return;
        }
        const result = JSON.parse(body.toString('utf8'));
        const items = [...result.plan.meals, ...(result.plan.outing ? [result.plan.outing] : [])]
          .sort((a, b) => days.indexOf(a.day) - days.indexOf(b.day));
        await page.waitForFunction(expected => {
          const nodes = [...document.querySelectorAll('#plan > li')];
          return !document.querySelector('#results').hidden && nodes.length === expected.length &&
            nodes.every((node, index) => ['day', 'name', 'entity_id'].every(key => node.textContent.includes(expected[index][key])));
        }, items);
        const renderedPicks = Number(await page.locator('#compare tr').nth(1).locator('td').nth(1).innerText());
        const errors = result.trace.filter(entry => entry.tool === 'qloo_recs' && entry.result_summary.startsWith('QlooError:'));
        observed.meals = result.plan.meals.length;
        observed.outing = result.plan.outing?.entity_id ?? null;
        observed.errors = errors.map(entry => entry.result_summary);
        observed.plan_sha256 = hash(JSON.stringify(result.plan));
        observed.meals_sha256 = hash(JSON.stringify(result.plan.meals));
        check(`${scenario}/${label}: rendered picks and provenance match API`, () => {
          assert.equal(renderedPicks, items.length);
          assert.equal(result.comparison.grounded.with_qloo_entity_id, items.length);
          assert.equal(result.comparison.grounded.constraint_checked, items.length);
          assert.equal(result.mock, true);
        });
        if (scenario === 'healthy' || scenario === 'configured') {
          check(`${scenario}/${label}: complete checked plan`, () => {
            assert.equal(result.plan.meals.length, 4); assert.ok(result.plan.outing); assert.equal(errors.length, 0);
          });
        } else if (scenario === 'outing_503') {
          const healthy = receipt.scenarios[0].responses.find(item => item.persona === 'rosa');
          check(`${scenario}/${label}: checked meals survive failed outing exactly`, () => {
            assert.equal(result.plan.meals.length, 4);
            assert.equal(observed.meals_sha256, healthy.meals_sha256);
            assert.equal(result.plan.outing, null);
            assert.equal(errors.length, 1); assert.match(errors[0].result_summary, /503/);
          });
          const trace = await page.locator('#trace').textContent();
          check(`${scenario}/${label}: failed outing remains inspectable`, () => assert.match(trace, /QlooError:.*503/));
        } else if (scenario === 'primary_429') {
          check(`${scenario}/${label}: widened checked meals remain usable`, () => {
            assert.ok(result.plan.meals.length > 0); assert.ok(result.plan.outing);
            assert.equal(errors.length, 1); assert.match(errors[0].result_summary, /429/);
          });
        } else if (scenario === 'all_429') {
          const note = await page.locator('#notes').innerText();
          check(`${scenario}/${label}: all refused recommendations leave slots open`, () => {
            assert.equal(items.length, 0); assert.equal(errors.length, 3);
            assert.match(note, /Only 0 restaurants passed every constraint/);
          });
        }
        if (options.expect === 'fixed' && scenario === 'outing_503') {
          const viewport = kind === 'sample' ? { width: 1280, height: 900 } : { width: 390, height: 844 };
          await page.setViewportSize(viewport);
          await page.screenshot({ path: path.join(output, `checked-meals-${viewport.width}.png`), fullPage: true });
          const dimensions = await page.evaluate(() => ({ width: document.documentElement.clientWidth, content: document.documentElement.scrollWidth }));
          observed.viewport = { ...viewport, ...dimensions };
        }
      }

      for (const persona of scenario === 'healthy' ? ['rosa', 'harold', 'mei'] : ['rosa']) await plan('sample', persona);
      if (scenario === 'outing_503') await plan('form');
      check(`${scenario}: no JavaScript page errors`, () => assert.deepEqual(row.page_errors, []));
      check(`${scenario}: browser stayed on loopback`, () => assert.deepEqual(row.blocked_requests, []));
      if (options.expect === 'fixed' || ['healthy', 'configured'].includes(scenario)) {
        check(`${scenario}: successful workflows show no error alerts`, () => assert.deepEqual(row.dialogs, []));
      }
    } finally {
      await context.close();
      row.server = await server.stop();
    }
    check(`${scenario}: provider network remained unused`, () => assert.equal(row.server.provider_network_attempts, 0));
    check(`${scenario}: recommendation attempts remain bounded`, () => {
      for (const calls of row.server.fixtures) assert.ok(calls.length <= 3);
    });
    if (scenario === 'configured') {
      const expectedModel = options.expect === 'fixed' ? 'receiving-configured-model' : 'scripted-stub';
      check(`${scenario}: actual app preserves observed backend model identity`, () => {
        assert.ok(row.server.model_names.length > 1);
        assert.deepEqual([...new Set(row.server.model_names)], [expectedModel]);
      });
    }
  }
  receipt.passed = true;
} catch (error) {
  receipt.failure = { message: error.message, stack: error.stack };
  process.exitCode = 1;
} finally {
  await browser?.close();
  receipt.finished_at = new Date().toISOString();
  await writeFile(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify({ passed: receipt.passed, expectation: options.expect, checks: receipt.checks.length,
    output, failure: receipt.failure?.message }));
}
