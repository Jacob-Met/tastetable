#!/usr/bin/env node
// One receiving history for the existing owners' frozen composition. No provider calls.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');

const [sourceArg, outputArg, expectedAppHash] = process.argv.slice(2);
if (!sourceArg || !outputArg || !/^[0-9a-f]{64}$/.test(expectedAppHash || '')) {
  throw new Error('Usage: node check_composed_handoff.cjs FROZEN_SOURCE NEW_EVIDENCE_DIR EXPECTED_APP_SHA256');
}
const source = path.resolve(sourceArg);
const output = path.resolve(outputArg);
if (fs.existsSync(output)) throw new Error('Use a new evidence directory; earlier histories must be retained.');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function sourceManifest() {
  return fs.readdirSync(path.join(source, 'static')).filter(name => /\.(?:m?js|html|css)$/.test(name)).sort()
    .map(name => ({ path: `static/${name}`, sha256: hash(fs.readFileSync(path.join(source, 'static', name))) }));
}
const before = sourceManifest();
assert.equal(before.find(x => x.path === 'static/app.js')?.sha256, expectedAppHash, 'Frozen composed app pin must match');
assert.equal(before.find(x => x.path === 'static/plan-request.js')?.sha256,
  'b35d09ca6270cf6150bcc40501d2d6a6728aa592597bb8d3e49aa3ae26cdf995', 'Receive the exact accepted request controller');
for (const name of ['week_plan.mjs', 'calendar.js']) assert(before.some(x => x.path === `static/${name}`), `Missing composition source ${name}`);

const { chromium } = require(process.env.TASTETABLE_PLAYWRIGHT || 'playwright');
const personas = [
  { id: 'sample-a', label: 'Fictional A', cuisines: ['Cuisine A'], music: [], films: [], city: 'City A', constraints: ['wheelchair'] },
  { id: 'sample-b', label: 'Fictional B', cuisines: ['Cuisine B'], music: [], films: [], city: 'City B', constraints: ['low_sodium'] },
];
function plan(label, constraints) {
  const pick = (day, kind, index) => ({ day, kind, entity_id: `COMPOSED-FIXTURE-${index}`,
    name: `${label} venue ${index}`, affinity: 0.8, why: 'Authored composed-handoff receiving fixture.', fallback: false });
  return { mock: true,
    plan: { meals: [pick('Monday', 'restaurant', 0), pick('Wednesday', 'restaurant', 1), pick('Friday', 'restaurant', 2)],
      outing: pick('Saturday', 'outing', 3), notes: ['Fictional suggestions for a local receiving check.'], rejected: [] },
    llm_only: { meals: [], outing: { day: 'Sunday', name: 'Unverified fictional comparison', why: 'Fixture only.' } },
    comparison: { constraints, grounded: { picks: 4, with_qloo_entity_id: 4, with_affinity_evidence: 4,
      constraint_checked: 4, unsafe_candidates_rejected: 0 }, llm_only: { picks: 1 } },
    trace: [{ tool: 'authored_fixture', args: {}, result_summary: 'No provider call.' }] };
}
const requests = [];
const errors = [];
const unexpectedNetwork = [];
const states = {};
const downloads = {};
const checks = {};
const server = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://fixture.invalid');
    if (request.method === 'POST' && url.pathname.startsWith('/api/plan')) {
      let raw = '';
      for await (const chunk of request) raw += chunk;
      const body = raw ? JSON.parse(raw) : null;
      requests.push({ path: url.pathname, body });
      const persona = personas.find(x => url.pathname.endsWith('/' + x.id));
      const label = persona?.id === 'sample-a' ? 'Delayed A' : persona?.id === 'sample-b' ? 'Fresh B' : 'Initial';
      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.end(JSON.stringify(plan(label, persona?.constraints || body?.constraints || [])));
      return;
    }
    const json = url.pathname === '/api/health' ? { ok: true, qloo_mode: 'mock' }
      : url.pathname === '/api/personas' ? personas : null;
    if (json) { response.writeHead(200, { 'Content-Type': 'application/json' }); response.end(JSON.stringify(json)); return; }
    const file = url.pathname === '/' ? 'static/index.html'
      : /^\/static\/[a-zA-Z0-9_-]+\.(?:m?js|css)$/.test(url.pathname) ? url.pathname.slice(1) : null;
    if (!file || !fs.existsSync(path.join(source, file))) { response.writeHead(404); response.end(); return; }
    response.writeHead(200, { 'Content-Type': /\.m?js$/.test(file) ? 'text/javascript'
      : file.endsWith('.css') ? 'text/css' : 'text/html' });
    response.end(fs.readFileSync(path.join(source, file)));
  } catch (error) { errors.push(`Fixture server: ${error.message}`); response.writeHead(500); response.end(); }
});

async function snapshot(page) {
  return page.evaluate(() => {
    const q = s => document.querySelector(s);
    const available = s => Boolean(q(s) && q(s).getClientRects().length && !q(s).disabled);
    return {
      persona: q('#personaSel').value,
      form: Object.fromEntries(['cuisines', 'music', 'films', 'city'].map(name => [name, q(`[name=${name}]`).value])),
      constraints: [...document.querySelectorAll('[name=constraints]:checked')].map(x => x.value),
      weekInput: q('#weekDate')?.value ?? null,
      resultsHidden: q('#results').hidden,
      resultsVisible: Boolean(q('#results').getClientRects().length),
      printDisabled: !q('#printWeek') || q('#printWeek').disabled,
      downloadDisabled: !q('#calendarDownload') || q('#calendarDownload').disabled,
      printAvailable: available('#printWeek'), downloadAvailable: available('#calendarDownload'),
      assignments: Object.fromEntries([...document.querySelectorAll('#weekOrganizer select[data-pick-key]')]
        .map(x => [x.dataset.pickKey, x.value])),
      scheduled: [...document.querySelectorAll('#weekDays .week-day')].flatMap(row =>
        [...row.querySelectorAll('.scheduled-pick')].map(pick => ({ day: row.dataset.day,
          date: row.querySelector('time')?.dateTime, name: pick.querySelector('h4')?.textContent }))),
      status: q('#requestStatus').textContent,
      busy: q('#form').getAttribute('aria-busy'),
      reads: window.__compositionReads.map(x => ({ url: x.url, aborted: x.signal?.aborted || false, released: x.released })),
    };
  });
}
async function release(page, index) {
  await page.waitForFunction(i => window.__compositionReads.length > i, index);
  await page.evaluate(i => window.__compositionReads[i].release(), index);
  await page.waitForFunction(i => window.__compositionReads[i].released, index);
  await page.evaluate(() => new Promise(requestAnimationFrame));
}
function icsEvents(text) {
  const unfolded = text.replace(/\r\n[ \t]/g, '');
  const unescape = s => s.replace(/\\([nN,;\\])/g, (_, c) => /[nN]/.test(c) ? '\n' : c);
  return [...unfolded.matchAll(/BEGIN:VEVENT\r\n([\s\S]*?)\r\nEND:VEVENT/g)].map(match => {
    const lines = match[1].split('\r\n');
    const field = prefix => lines.find(line => line.startsWith(prefix))?.slice(prefix.length);
    return { uid: field('UID:'), date: field('DTSTART;VALUE=DATE:')?.replace(/^(\d{4})(\d{2})(\d{2})$/, '$1-$2-$3'),
      name: unescape(field('SUMMARY:') || '').replace(/^\[DEMO\] TasteTable suggestion: /, '') };
  });
}
const pairs = items => items.map(({ date, name }) => ({ date, name })).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
async function download(page, name) {
  const [item] = await Promise.all([
    page.waitForEvent('download'), page.locator('#calendarDownload').click(),
  ]);
  const file = path.join(output, name + '.ics');
  await item.saveAs(file);
  const text = fs.readFileSync(file, 'utf8');
  const record = { path: path.basename(file), suggestedFilename: item.suggestedFilename(), sha256: hash(text), events: icsEvents(text) };
  downloads[name] = record;
  return record;
}

(async () => {
  fs.mkdirSync(output, { recursive: false });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  let browser;
  let failure = null;
  try {
    browser = await chromium.launch({ headless: true, executablePath: process.env.TASTETABLE_CHROMIUM || undefined,
      args: ['--no-sandbox'] });
    const page = await browser.newPage({ viewport: { width: 1200, height: 1000 }, acceptDownloads: true });
    page.setDefaultTimeout(7000);
    page.on('pageerror', error => errors.push(error.message));
    await page.route('**/*', route => {
      const url = route.request().url();
      if (url.startsWith(origin + '/') || /^(?:data:|blob:)/.test(url)) return route.continue();
      unexpectedNetwork.push(url); return route.abort();
    });
    await page.addInitScript(() => {
      const nativeFetch = window.fetch.bind(window);
      window.__compositionReads = [];
      window.fetch = async (url, options) => {
        const response = await nativeFetch(url, options);
        if (options?.method === 'POST' && String(url).startsWith('/api/plan')) {
          const read = response.json.bind(response);
          response.json = async () => {
            const data = await read();
            const record = { url: String(url), signal: options.signal, released: false };
            const gate = new Promise(resolve => { record.release = resolve; });
            window.__compositionReads.push(record);
            await gate; record.released = true; return data;
          };
        }
        return response;
      };
    });
    await page.goto(origin);
    await page.waitForFunction(() => document.querySelector('#personaSel').options.length === 2);
    await page.locator('[name=cuisines]').fill('Fictional initial cuisine');
    await page.locator('[name=city]').fill('Initial City');
    await page.locator('#form button[type=submit]').click();
    await release(page, 0);
    await page.locator('#weekDate').fill('2026-11-18');
    await page.locator('#weekOrganizer select[data-pick-key="pick-0"]').selectOption('Wednesday');
    await page.locator('#weekOrganizer select[data-pick-key="pick-2"]').selectOption('');
    states.edited = await snapshot(page);
    assert.equal(states.edited.scheduled.length, 3, 'One omitted pick should leave three scheduled occurrences');
    assert.equal(states.edited.scheduled.filter(x => x.day === 'Wednesday').length, 2, 'Two same-kind picks share Wednesday');
    const editedExport = await download(page, 'edited-initial');
    checks.editedExportMatchesWeek = JSON.stringify(pairs(editedExport.events)) === JSON.stringify(pairs(states.edited.scheduled));
    checks.editedPrintReady = states.edited.printAvailable;
    checks.organizerEditsSendNoRequest = requests.length === 1;

    await page.locator('#sampleBtn').click();
    await page.waitForFunction(() => window.__compositionReads.length === 2);
    states.pendingA = await snapshot(page);
    await page.locator('#personaSel').selectOption('sample-b');
    states.afterSelection = await snapshot(page);
    const afterSelectionRequestCount = requests.length;
    await release(page, 1);
    states.afterLateA = await snapshot(page);
    await page.screenshot({ path: path.join(output, 'after-late-a.png'), fullPage: true });
    const retired = s => s.resultsHidden && !s.resultsVisible && s.printDisabled && s.downloadDisabled;
    checks.startRetiresOldHandoff = retired(states.pendingA);
    checks.selectionAbortsReader = states.afterSelection.reads[1].aborted;
    checks.selectionStartsNoRequest = afterSelectionRequestCount === 2;
    checks.selectionPreservesFields = JSON.stringify(states.afterSelection.form) === JSON.stringify(states.pendingA.form)
      && JSON.stringify(states.afterSelection.constraints) === JSON.stringify(states.pendingA.constraints);
    checks.lateReaderCannotRestoreHandoff = retired(states.afterLateA);
    checks.weekPreferenceSurvivesRetirement = states.afterLateA.weekInput === '2026-11-18';

    await page.locator('#sampleBtn').click();
    await release(page, 2);
    states.freshB = await snapshot(page);
    const freshExport = await download(page, 'fresh-b');
    checks.freshPlanSeedsOneNewWeek = states.freshB.resultsVisible && states.freshB.scheduled.length === 4
      && states.freshB.scheduled.every(x => x.name.startsWith('Fresh B'))
      && JSON.stringify(states.freshB.assignments) === JSON.stringify({ 'pick-0': 'Monday', 'pick-1': 'Wednesday', 'pick-2': 'Friday', 'pick-3': 'Saturday' });
    checks.freshWeekPreferencePreserved = states.freshB.weekInput === '2026-11-18'
      && states.freshB.scheduled.find(x => x.day === 'Monday')?.date === '2026-11-16';
    checks.freshExportMatchesWeek = JSON.stringify(pairs(freshExport.events)) === JSON.stringify(pairs(states.freshB.scheduled));
    checks.freshPrintReady = states.freshB.printAvailable;
    await page.locator('#weekOrganizer select[data-pick-key="pick-0"]').selectOption('Tuesday');
    states.rearrangedB = await snapshot(page);
    const rearranged = await download(page, 'rearranged-b');
    checks.rearrangeDoesNotInvalidatePlan = states.rearrangedB.resultsVisible && states.rearrangedB.printAvailable
      && states.rearrangedB.downloadAvailable && requests.length === 3;
    checks.rearrangedExportMatchesWeek = JSON.stringify(pairs(rearranged.events)) === JSON.stringify(pairs(states.rearrangedB.scheduled));
    checks.samePlanExportIdentitySurvivesMove = JSON.stringify(freshExport.events.map(x => x.uid).sort())
      === JSON.stringify(rearranged.events.map(x => x.uid).sort());
    await page.screenshot({ path: path.join(output, 'fresh-rearranged-week.png'), fullPage: true });
  } catch (error) {
    failure = { name: error.name, message: error.message };
  } finally {
    const after = sourceManifest();
    checks.sourceUnchanged = JSON.stringify(before) === JSON.stringify(after);
    checks.noPageErrors = errors.length === 0;
    checks.noExternalNetwork = unexpectedNetwork.length === 0;
    let sourceCommit = null;
    try { sourceCommit = execFileSync('git', ['-C', source, 'rev-parse', 'HEAD'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); } catch {}
    const receipt = { schema: 'hamon.composed_ui_receiving.v1', reviewer: 'chatgpt-a2eaaec253d8/production_receiving',
      checkedAt: new Date().toISOString(), source, sourceCommit, sourceBefore: before, sourceAfter: after,
      verifierSha256: hash(fs.readFileSync(__filename)), node: process.version, chromium: browser?.version() || null,
      scenarioCount: 1, scenario: 'Edited week/export, delayed parsed A after persona B selection, fresh B and another local day edit.',
      boundary: 'Actual loopback fetch and JSON parsing finish before a held reader resolves after abort.',
      requests, states, downloads, checks, errors, unexpectedNetwork, failure,
      passed: !failure && Object.values(checks).every(Boolean),
      limits: ['Authored fictional loopback responses; no backend/provider/calendar-service execution.',
        'Print availability is checked in the composed UI; no physical printer or calendar import is used.',
        'This is one composed handoff history; it does not rerun all standalone request, organizer or calendar suites.'] };
    fs.writeFileSync(path.join(output, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
    console.log(JSON.stringify({ passed: receipt.passed, failure, checks, receipt: path.join(output, 'receipt.json') }, null, 2));
    if (!receipt.passed) process.exitCode = 1;
    if (browser) await browser.close();
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
  }
})().catch(error => { console.error(error.message); process.exitCode = 1; server.closeAllConnections(); server.close(); });
