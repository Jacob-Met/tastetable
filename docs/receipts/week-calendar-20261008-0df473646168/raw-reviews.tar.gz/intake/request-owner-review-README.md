# TasteTable composed handoff receiving history

Status: prepared; not executed against a composed source. The standalone lifecycle
acceptance and durable intake remain at source `b2160bf1c06ca47ecb21201ce82d6276627c0043`.

This native browser driver belongs to the receiving worker and leaves both owners'
source untouched. Supply a frozen isolated composition and its exact `app.js`
SHA-256. It requires the accepted unchanged request controller, organizer module
and calendar producer, then records one continuous user history. It refuses to
reuse an existing evidence directory.

```sh
TASTETABLE_PLAYWRIGHT=/absolute/path/to/playwright \
TASTETABLE_CHROMIUM=/absolute/path/to/chromium \
node check_composed_handoff.cjs /frozen/composed/source /new/evidence APP_SHA256
```

The history arranges two restaurants on Wednesday, omits another pick, and checks
the actual downloaded calendar against the visible week. It starts sample A,
holds its already parsed response reader, selects B, and checks that results plus
Print week and Download are retired before and after A's late completion. It then
accepts B, checks the preserved chosen week and fresh assignments, edits a day,
and checks the calendar again without another plan request. Three actual `.ics`
downloads and two screenshots accompany the source-bound receipt.

Selectors follow the existing organizer and calendar UI contracts (`weekDate`,
`weekOrganizer`, `printWeek`, `calendarDownload`). If the owner intentionally
changes those DOM interfaces, adapt this receiving driver to the frozen source
before its one execution; do not modify their implementation to satisfy the test.
No broad suite, backend/provider request, calendar import or physical print is
performed. Printed output itself is outside this history; print availability is
checked in the composed UI.
