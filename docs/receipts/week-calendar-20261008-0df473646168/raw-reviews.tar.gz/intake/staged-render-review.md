# TasteTable staged renderer: independent receiving review

The staged renderer candidate passes the unchanged organizer browser suite, the unchanged malformed-notes probe, and seven additional malformed-response controls. No candidate source files were edited by the reviewer.

## Exact source boundary

Receiving repository: `Jacob-Met/tastetable`, whose recovered main baseline was `d1c7a4e39cfdc0bb5b9fe026bc9660b75b456e81`. This review compares the active organizer owner's frozen source with the parent's narrow rendering supplement; it does not claim either is integrated into main.

| File | Frozen organizer SHA256 | Reviewed staged candidate SHA256 |
| --- | --- | --- |
| `static/app.js` | `cb666959df8a4921987e67b98efbeca0f0399502184f3743e732c7c295cfd395` | `376fb899f912b9e74b5869c0cc05eb863e86bc812602295f54af85802d15705c` |
| `static/week_plan.mjs` | `e739adc10d9ae9ba1cb82c6d800c453e8f7bec53e343e0685adeabe98e6f4809` | Same |
| `static/index.html` | `ddd912eb1af81611551c2ddb10f6f1fbd9fceb9e2a691b7ba35746ba08f9404d` | Same |
| `static/style.css` | `0d58ae4d0fef286374808eda0dc90b5e8249432a248b8332441738eb04dc0840` | Same |

Candidate source: `/workspace/scratch/31a349052b90/taste-atomic/candidate`.

Frozen organizer source: `/workspace/scratch/31a349052b90/product-execution/taste-review/organizer-snapshot`.

## Existing behavior preserved

The original browser harness remains byte unchanged at SHA256 `105b33bf6142af7cc1d3100d0f3c93d592861a9aabb12a14f0380afc2821c12e`. All eight checkpoints pass: all 56 meal/outing day moves, occupied-day coexistence, omission/restoration, original-day reset across a year boundary, replacement by a partial response, stale older success, stale older failure, and empty results with no stale picks. It also checks preserved source evidence and no extra plan requests during local scheduling.

The unchanged `plan.notes = null` probe now passes. Its retained original-source report demonstrates the prior partial-render failure.

## Additional failure and recovery controls

The separate `review-week-late-render.cjs` harness has SHA256 `a5b7cd6bf6840a7b17215fd52e404650cc91db7c907e48ed9987b5f397b5b5f3`. It was run unchanged against both sources.

| Authored malformed HTTP 200 response | Frozen organizer | Staged candidate |
| --- | --- | --- |
| `trace = null` | Fails: displayed evidence changes before rejection | Pass |
| `comparison.constraints = "wheelchair"` | Fails after original fragments and part of week view change | Pass |
| `comparison.constraints = {0: "wheelchair", length: 1}` | Fails after original fragments and part of week view change | Pass |
| `llm_only.meals = null` | Fails: plan and notes change before rejection | Pass |
| `llm_only.outing = null` | Fails: plan and notes change before rejection | Pass |
| `plan.meals[0].affinity = "0.90"` | Pass: the original renderer already throws before its first DOM write | Pass |
| `plan.rejected[0].failed = null` | Fails after earlier source fragments change | Pass |

Each successful control starts from an edited eight-pick plan, with one omitted meal, two occurrences sharing Thursday, and the date input set to Wednesday `2026-12-30` for the week beginning `2026-12-28`. The incoming fixture deliberately carries a different source label. The test compares the entire captured visible plan, original evidence, assignments, dates, source label, week text/markup, and controls before and after the error. It then edits the preserved plan without a network request, accepts a subsequent valid partial result with fresh assignments, and edits that replacement successfully. These assertions pass for every candidate case.

The negative control is six failures and one pass. The preserved early affinity failure gives a useful control: this suite distinguishes late partial rendering from any malformed-response error.

## Runtime and evidence

All browser results use real headless Chromium `153.0.8010.0`, Playwright, an ephemeral local HTTP fixture server, authored response data, an isolated temporary browser profile, blocked service workers, and blocked page requests outside the fixture origin. Both candidate runs reported no unhandled page errors and no external page request attempts. No Qloo, venue, or recommendation provider was called. Fixtures with `mock: false` exercise the UI's source-label preservation only.

Reproduction commands from this directory:

```sh
node review-week-browser.cjs --root /workspace/scratch/31a349052b90/taste-atomic/candidate --output atomic-receiving
node review-week-browser.cjs --probe-malformed --root /workspace/scratch/31a349052b90/taste-atomic/candidate --output atomic-malformed
node review-week-late-render.cjs --root /workspace/scratch/31a349052b90/taste-atomic/candidate --output atomic-late
node review-week-late-render.cjs --root organizer-snapshot --output baseline-late
```

Primary reports:

- `atomic-receiving/browser-receiving-report.json`: eight passing checkpoints.
- `atomic-malformed/malformed-render-report.json`: original malformed-notes probe passes.
- `atomic-late/late-render-report.json`: seven passing failure/recovery controls, with fixture and before/after evidence.
- `baseline-late/late-render-report.json`: same late-render harness, six failures and one preserved control.
- `evidence/malformed-render-report.json`: retained original malformed-notes negative control.

## Scope of the conclusion

The repair stages response-dependent original fragments and the complete next-week view before its DOM/model commit. The browser evidence supports atomic handling of the tested renderer exceptions while preserving existing organizer behavior. It is not a general response-schema validator: for example, a constraints object without a nonzero `length` is treated as no listed constraints by both versions and does not trigger this error path. Calendar composition, cancellation, provider correctness, deployment, and main integration are not qualified here.
