# Saved-week receiving contract

This extension lets a caregiver save an arranged TasteTable week, close the page,
and explicitly reopen the file to continue editing without asking the provider
for another plan. The predecessor only keeps arrangements during a page visit.

The receiving source is the independently accepted consumer-v1 composition,
whose app SHA-256 is `faa47a7c5b71a5c12f004868e68b71df33d4486002b983943185c3d9928dd5e1`.
The initial public main is `9f9105c29ab1a68a501b5f4c0b7180f0db968d38`.
Root will identify the published composition parent before integration.

## Observable behavior

- Save week downloads an ordinary UTF-8 JSON file only after the user selects
  the button. Open saved week uses a native file picker. There is no automatic
  browser persistence, server storage, or plan/provider request for either action.
- A file retains the complete accepted response and its original plan, the input
  snapshot associated with that response, the selected Monday and every original
  occurrence assignment, including null assignments and duplicate entity IDs.
  Reopening reconstructs state with the unchanged native week module.
- The file keeps the original browser acceptance time and its own save time.
  These are client timestamps, not evidence of a provider's observation time.
  The page and printed handoff identify the opened filename and saved-copy status.
  Source mode remains exactly the response's declared demo/live/unknown mode.
- Opening a file is a replacement through the unchanged request controller.
  The old result is retired immediately. Only the latest active load may commit.
  Input edits, another plan/load, cancellation and page departure keep an older
  asynchronous file read from restoring stale results. A failed open retains
  editable form inputs and leaves the old result retired.
- A reopened plan fills the form with its own inputs and restores its saved date.
  Later moves, omissions, resets, printing and calendar export use that restored
  current state. Original recommendations, checks, counts and trace are unchanged.
- Files are versioned local snapshots, not authenticated provider receipts or
  fresh checks. JSON syntax, format/version, input/source consistency, exact
  occurrence coverage and native dates/assignments must be usable by this client;
  incomplete/malformed files fail before rendering commits. Unknown source mode
  and an empty week retain the calendar writer's existing download behavior.
- The file also retains the accepted plan's calendar ID. The writer's existing
  `id` and `createdAt` options preserve same-week occurrence UIDs and unchanged
  file output after reopening. Where browser randomness is unavailable, a null
  ID leaves that optional continuity unknown. Calendar imports are still not
  synced or cancelled by TasteTable, and calendar-app update behavior is unclaimed.

## Scope

New `static/week_file.mjs`, focused tests and feature evidence; small app/index/
README hooks. `week_plan.mjs`, `calendar.js`, `plan-request.js`, all backend and
constraint code, and other owners' frozen publication artifacts stay unchanged.
Original qualified calendar/controller tests are supporting regression checks,
not new independent reviews. Root arranges independent receiving of this source.
