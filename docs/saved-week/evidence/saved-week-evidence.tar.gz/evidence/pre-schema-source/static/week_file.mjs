/** Portable, user-opened snapshots of an existing TasteTable week. */
import { createWeekPlan, setPickDay } from "./week_plan.mjs";

export const WEEK_FILE_FORMAT = "tastetable.saved-week.v1";

const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const copy = (value) => structuredClone(value);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

function requireValue(condition, message) {
  if (!condition) throw new TypeError(message);
}

function timestamp(value) {
  requireValue(typeof value === "string", "The saved week is missing a valid timestamp.");
  const date = new Date(value);
  requireValue(Number.isFinite(date.getTime()) && date.toISOString() === value,
    "The saved week is missing a valid timestamp.");
  return value;
}

function readInputs(value) {
  requireValue(object(value), "The saved week is missing its original inputs.");
  for (const key of ["cuisines", "music", "films", "constraints"]) {
    requireValue(Array.isArray(value[key]) && value[key].every((item) => typeof item === "string"),
      "The saved week has invalid " + key + " inputs.");
  }
  requireValue(typeof value.city === "string", "The saved week has an invalid city input.");
  return copy(value);
}

function restore(value) {
  requireValue(object(value) && value.format === WEEK_FILE_FORMAT,
    "Choose a TasteTable saved-week file in the supported v1 format.");
  const receivedAt = timestamp(value.receivedAt);
  const savedAt = timestamp(value.savedAt);
  requireValue(value.calendarId === null || (typeof value.calendarId === "string" && /^[0-9a-f]{32}$/.test(value.calendarId)),
    "The saved week has an invalid calendar identity.");
  const inputs = readInputs(value.inputs);
  requireValue(object(value.response), "The saved week is missing its original response.");
  requireValue(object(value.week) && object(value.week.assignments),
    "The saved week is missing its arrangement.");
  const response = copy(value.response);
  let state = createWeekPlan(response, value.week.start);
  requireValue(state.weekStart === value.week.start,
    "The saved week must identify the Monday of its displayed week.");
  requireValue(same(inputs.constraints, state.constraints),
    "The saved inputs and the original response have different constraints.");
  const keys = state.picks.map(({ key }) => key);
  requireValue(Object.keys(value.week.assignments).length === keys.length
    && keys.every((key) => Object.hasOwn(value.week.assignments, key)),
  "The saved arrangement must include every original pick exactly once.");
  for (const key of keys) state = setPickDay(state, key, value.week.assignments[key]);
  return { response, inputs, state, receivedAt, savedAt, calendarId: value.calendarId };
}

/** The response is retained whole, including source explanations and tool trace. */
export function makeWeekFile({ response, inputs, state, receivedAt, calendarId }, now = new Date()) {
  const envelope = {
    format: WEEK_FILE_FORMAT,
    receivedAt,
    savedAt: now.toISOString(),
    calendarId,
    inputs: copy(inputs),
    response: copy(response),
    week: { start: state?.weekStart, assignments: copy(state?.assignments) },
  };
  const restored = restore(envelope);
  requireValue(same(state, restored.state),
    "The arranged week no longer matches its original response.");
  return {
    filename: `tastetable-week-${state.weekStart}.json`,
    text: JSON.stringify(envelope, null, 2) + "\n",
  };
}

/** Recreate native immutable state; serialized derived picks are never trusted. */
export function readWeekFile(text) {
  requireValue(typeof text === "string", "The saved week must be a JSON text file.");
  let value;
  try {
    // A UTF-8 BOM is accepted for ordinary editor/file interoperability.
    value = JSON.parse(text.replace(/^\uFEFF/, ""));
  } catch {
    throw new TypeError("This file is not valid JSON. Choose a saved TasteTable week.");
  }
  return restore(value);
}
