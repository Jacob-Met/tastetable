import assert from "node:assert/strict";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";
import { createHash } from "node:crypto";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const source = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
assert(!existsSync(output), "Use a fresh receiving receipt");
const { makeWeekFile, readWeekFile } = await import(pathToFileURL(resolve(source, "static/week_file.mjs")));
const { createWeekPlan, setPickDay } = await import(pathToFileURL(resolve(source, "static/week_plan.mjs")));
const raw = readFileSync(resolve(root, "evidence/native-b8-recovery.json"));
const native = JSON.parse(raw);
const rows = [];
for (const item of native.cases) {
  try {
    const state = setPickDay(createWeekPlan(item.response, "2026-12-31"), "pick-0", "Sunday");
    const saved = makeWeekFile({ response: item.response, inputs: item.inputs, state,
      receivedAt: "2026-10-08T10:25:00.000Z", calendarId: "8313914c64cc4e9db0e181ed316cabcb" },
      new Date("2026-10-08T10:30:00.000Z"));
    const opened = readWeekFile(saved.text);
    assert.deepEqual(opened.response, item.response);
    assert.deepEqual(opened.state.sourcePlan, item.response.plan);
    assert.equal(opened.state.assignments["pick-0"], "Sunday");
    assert.deepEqual(opened.response.trace.at(-1).args, item.response.trace.at(-1).args);
    rows.push({ case: item.case, passed: true, traceArgs: opened.response.trace.at(-1).args,
      sourceIDs: opened.state.picks.map((p) => p.pick.entity_id), assignment: opened.state.assignments["pick-0"] });
  } catch (error) {
    rows.push({ case: item.case, passed: false, error: error.message, stack: error.stack });
  }
}
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const result = { schema: "tastetable.saved-week.native-recovery-consumer.v1", source,
  weekFileSHA256: hash(readFileSync(resolve(source, "static/week_file.mjs"))),
  nativeResponseSHA256: hash(raw), nativeCommit: native.source.commit, node: process.version,
  driverSHA256: hash(readFileSync(fileURLToPath(import.meta.url))), cases: rows };
writeFileSync(output, JSON.stringify(result, null, 2) + "\n");
console.log(JSON.stringify(result));
if (rows.some((row) => !row.passed)) process.exitCode = 1;
