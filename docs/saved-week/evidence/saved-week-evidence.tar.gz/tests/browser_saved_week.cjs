"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");
const crypto = require("node:crypto");
const { pathToFileURL } = require("node:url");
const { execFileSync } = require("node:child_process");
const { chromium } = require(require.resolve("playwright", {
  paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || process.cwd()],
}));

const root = path.resolve(__dirname, "..");
const source = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
const baseline = process.argv.includes("--baseline");
const htmlBoundaryOnly = process.argv.includes("--html-boundary");
const nativeRecoveryOnly = process.argv.includes("--native-recovery");
const hash = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex");
const clone = (value) => structuredClone(value);
const native = JSON.parse(fs.readFileSync(path.join(root, "intake/native-responses.json"), "utf8"));
const personaMap = JSON.parse(fs.readFileSync(path.join(root, "intake/personas.json"), "utf8"));
const personas = Object.values(personaMap);
const sourcePins = () => Object.fromEntries(fs.readdirSync(path.join(source, "static")).sort()
  .map((name) => ["static/" + name, hash(fs.readFileSync(path.join(source, "static", name)))]));
const before = sourcePins();
const inherited = {
  "static/week_plan.mjs": "e739adc10d9ae9ba1cb82c6d800c453e8f7bec53e343e0685adeabe98e6f4809",
  "static/calendar.js": "09dfe98a95da6c7fd0b7ee531c3ec4cf9ae5697dc730fab6cffdd07d8bd94b3b",
  "static/plan-request.js": "b35d09ca6270cf6150bcc40501d2d6a6728aa592597bb8d3e49aa3ae26cdf995",
};
for (const [name, digest] of Object.entries(inherited)) assert.equal(before[name], digest);
assert(!fs.existsSync(output), "Use a fresh output directory");
fs.mkdirSync(output, { recursive: true });

const requests = [], external = [], pageErrors = [], served = {}, groups = [], snapshots = {};
const files = {};
let browser, page, origin, failure = null;
let responseOverride = null;
const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url, "http://fixture.invalid").pathname;
  if (req.method === "POST" && pathname.startsWith("/api/plan")) {
    let raw = "";
    for await (const part of req) raw += part;
    requests.push({ path: pathname, body: raw ? JSON.parse(raw) : null });
    const id = pathname.split("/").at(-1);
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(responseOverride || native[id] || native.rosa));
    return;
  }
  if (pathname === "/api/health" || pathname === "/api/personas") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(pathname.endsWith("health") ? { qloo_mode: "mock" } : personas));
    return;
  }
  const file = pathname === "/" ? "static/index.html"
    : /^\/static\/[a-zA-Z0-9_.-]+$/.test(pathname) ? pathname.slice(1) : null;
  if (!file || !fs.existsSync(path.join(source, file))) { res.writeHead(404); res.end(); return; }
  const bytes = fs.readFileSync(path.join(source, file));
  served[file] = hash(bytes);
  res.writeHead(200, { "Content-Type": /\.m?js$/.test(file) ? "text/javascript"
    : file.endsWith(".css") ? "text/css" : "text/html" });
  res.end(bytes);
});

async function snapshot() {
  return page.evaluate(() => {
    const q = (id) => document.getElementById(id);
    const form = q("form");
    return {
      hidden: q("results").hidden,
      date: q("weekDate").value,
      source: q("weekSource").textContent,
      savedSource: q("savedWeekSource")?.textContent || null,
      savedSourceHidden: q("savedWeekSource")?.hidden ?? null,
      printDisabled: q("printWeek").disabled,
      saveDisabled: q("saveWeek")?.disabled ?? null,
      calendarDisabled: q("calendarDownload").disabled,
      input: Object.fromEntries(["cuisines", "music", "films", "city"].map((key) => [key, form[key].value])),
      constraints: [...form.querySelectorAll("[name=constraints]:checked")].map((f) => f.value),
      assignments: Object.fromEntries([...q("weekOrganizer").querySelectorAll("select[data-pick-key]")]
        .map((e) => [e.dataset.pickKey, e.value || null])),
      original: Object.fromEntries(["plan", "notes", "baseline", "compare", "rejected", "trace"].map((id) => [id, q(id).innerHTML])),
      week: [...q("weekDays").children].map((row) => ({
        day: row.dataset.day, date: row.querySelector("time").dateTime,
        keys: [...row.querySelectorAll("select[data-pick-key]")].map((e) => e.dataset.pickKey),
      })),
      status: q("requestStatus").textContent,
      storage: { local: localStorage.length, session: sessionStorage.length },
    };
  });
}

async function opened() {
  await page.waitForFunction(() => !document.getElementById("results").hidden && document.getElementById("form").getAttribute("aria-busy") === "false");
}
async function retired() {
  await page.waitForFunction(() => document.getElementById("results").hidden && document.getElementById("form").getAttribute("aria-busy") === "false");
}
async function sample(id = "rosa") {
  await page.locator("#personaSel").selectOption(id);
  await page.locator("#sampleBtn").click();
  await opened();
}
async function move(key, day) {
  await page.locator(`select[data-pick-key="${key}"]`).selectOption(day ?? "");
}
async function download(selector, name) {
  const waiting = page.waitForEvent("download");
  await page.locator(selector).click();
  const item = await waiting;
  const destination = path.join(output, name);
  await item.saveAs(destination);
  const data = fs.readFileSync(destination);
  files[name] = { filename: item.suggestedFilename(), bytes: data.length, sha256: hash(data) };
  return { data, filename: item.suggestedFilename(), path: destination };
}
async function openFile(file, { wait = true } = {}) {
  const waiting = page.waitForEvent("filechooser");
  await page.locator("#openWeek").click();
  const picker = await waiting;
  await picker.setFiles(file);
  if (wait) await opened();
}
function variant(value, name) {
  const destination = path.join(output, name);
  fs.writeFileSync(destination, typeof value === "string" ? value : JSON.stringify(value, null, 2) + "\n");
  return destination;
}
async function group(name, task) {
  await task();
  groups.push({ name, passed: true });
  console.log("PASS", name);
}

(async () => {
  try {
    await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
    origin = `http://127.0.0.1:${server.address().port}`;
    browser = await chromium.launch({
      executablePath: process.env.TASTETABLE_CHROMIUM || "/workspace/scratch/0c6c4d37eb0f/native-product-worker/browser-runtime/chromium",
      headless: true,
    });
    const context = await browser.newContext({ acceptDownloads: true, viewport: { width: 1280, height: 900 } });
    await context.route("**/*", async (route) => {
      const url = route.request().url();
      if (!url.startsWith(origin + "/")) { external.push(url); await route.abort(); }
      else await route.continue();
    });
    page = await context.newPage();
    page.on("pageerror", (error) => pageErrors.push(error.stack || String(error)));
    await page.goto(origin);
    await page.locator("#sampleBtn").waitFor({ state: "visible" });
    await page.waitForFunction(() => !document.getElementById("sampleBtn").disabled);
    await sample();
    await page.locator("#weekDate").fill("2026-12-31");
    await move("pick-0", "Saturday");
    await move("pick-1", "Saturday");
    await move("pick-2", null);
    snapshots.arranged = await snapshot();

    if (baseline) {
      const buttons = { save: await page.locator("#saveWeek").count(), open: await page.locator("#openWeek").count() };
      await page.reload();
      await page.waitForFunction(() => !document.getElementById("sampleBtn").disabled);
      snapshots.afterReload = await snapshot();
      const restored = !snapshots.afterReload.hidden && JSON.stringify(snapshots.afterReload.assignments) === JSON.stringify(snapshots.arranged.assignments);
      failure = { name: "saved-week continuation absent", expected: "An explicit saved file can reopen the original edited week after reload", observed: { buttons, restored, planRequests: requests.length } };
      console.log(JSON.stringify(failure));
      process.exitCode = 1;
      return;
    }

    if (htmlBoundaryOnly) {
      const original = await download("#saveWeek", "html-control-week.json");
      const value = JSON.parse(original.data);
      const observations = [];
      for (const [family, metric] of [["grounded", "picks"], ["llm_only", "with_affinity_evidence"]]) {
        await openFile(original.path);
        const previous = await snapshot();
        await page.evaluate(() => { window.savedFileHTMLExecuted = false; });
        const bad = clone(value);
        bad.response.comparison[family][metric] = '<img src="/count-fixture-missing.png" onerror="window.savedFileHTMLExecuted=true">';
        const name = `html-${family}-${metric}.json`;
        await openFile(variant(bad, name), { wait: false });
        await page.waitForFunction(() => document.getElementById("form").getAttribute("aria-busy") === "false");
        await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
        const current = await snapshot();
        observations.push({ family, metric, hidden: current.hidden,
          comparisonImages: await page.locator("#compare img").count(),
          markerExecuted: await page.evaluate(() => window.savedFileHTMLExecuted),
          originalUnchanged: JSON.stringify(current.original) === JSON.stringify(previous.original),
          saveDisabled: current.saveDisabled, status: current.status });
      }
      snapshots.htmlBoundary = observations;
      const literal = clone(value);
      const text = '<img src="/literal-fixture.png" onerror="window.savedFileHTMLExecuted=true">';
      literal.response.plan.notes.push(text);
      literal.response.plan.meals[0].name = text;
      await page.evaluate(() => { window.savedFileHTMLExecuted = false; });
      await openFile(variant(literal, "literal-source-text.json"));
      snapshots.literalSource = {
        noteText: await page.locator("#notes").textContent(),
        noteImages: await page.locator("#notes img").count(),
        planImages: await page.locator("#plan img").count(),
        markerExecuted: await page.evaluate(() => window.savedFileHTMLExecuted),
      };
      for (const item of observations) {
        assert.equal(item.hidden, true, "Non-numeric comparison evidence must not become a rendered saved plan");
        assert.equal(item.comparisonImages, 0);
        assert.equal(item.markerExecuted, false);
        assert.equal(item.originalUnchanged, true);
        assert.equal(item.saveDisabled, true);
      }
      assert.match(snapshots.literalSource.noteText, /<img src=/);
      assert.equal(snapshots.literalSource.noteImages, 0);
      assert.equal(snapshots.literalSource.planImages, 0);
      assert.equal(snapshots.literalSource.markerExecuted, false);
      groups.push({ name: "file comparison-count admission and literal source-text rendering", passed: true });
      return;
    }

    if (nativeRecoveryOnly) {
      const captured = JSON.parse(fs.readFileSync(path.join(root, "evidence/native-b8-recovery.json"), "utf8"));
      for (const item of captured.cases) {
        responseOverride = item.response;
        await sample();
        responseOverride = null;
        await move("pick-0", "Sunday");
        const beforeOpen = await snapshot();
        const saved = await download("#saveWeek", `native-${item.case}.json`);
        assert.deepEqual(JSON.parse(saved.data).response, item.response);
        await openFile(saved.path);
        const afterOpen = snapshots[item.case] = await snapshot();
        assert.deepEqual(afterOpen.week, beforeOpen.week);
        assert.deepEqual(afterOpen.original, beforeOpen.original);
        assert.equal(afterOpen.assignments["pick-0"], "Sunday");
        assert.match(await page.locator("#trace").textContent(), item.case === "invalid_json" ? /qloo_recs\(null\)/ : /qloo_recs\(\[\]\)/);
        assert.equal(afterOpen.saveDisabled, false);
        assert.equal(afterOpen.calendarDisabled, false);
        const second = await download("#saveWeek", `native-${item.case}-resaved.json`);
        assert.deepEqual(JSON.parse(second.data).response, item.response);
        groups.push({ name: "actual native recovery response: " + item.case, passed: true });
      }
      assert.equal(requests.length, 3);
      assert.deepEqual(external, []);
      assert.deepEqual(pageErrors, []);
      return;
    }

    let saved, envelope, calendarBefore, calendarAfter;
    await group("actual download preserves response, inputs and all assignments", async () => {
      saved = await download("#saveWeek", "first-week.json");
      calendarBefore = await download("#calendarDownload", "before-reopen.ics");
      envelope = JSON.parse(saved.data.toString("utf8"));
      assert.equal(envelope.format, "tastetable.saved-week.v1");
      assert.deepEqual(envelope.response, native.rosa);
      assert.deepEqual(envelope.inputs, Object.fromEntries(["cuisines", "music", "films", "city", "constraints"].map((key) => [key, personaMap.rosa[key]])));
      assert.deepEqual(envelope.week.assignments, snapshots.arranged.assignments);
      assert.equal(envelope.week.start, "2026-12-28");
      assert.match(envelope.calendarId, /^[0-9a-f]{32}$/);
      assert.equal(requests.length, 1);
      assert.deepEqual(requests[0], { path: "/api/plan/sample/rosa", body: null });
      assert.deepEqual((await snapshot()).storage, { local: 0, session: 0 });
    });

    await group("a fresh page reopens the same editable week and calendar identity", async () => {
      await page.reload();
      await page.waitForFunction(() => !document.getElementById("sampleBtn").disabled);
      assert.equal((await snapshot()).hidden, true, "No automatic restoration");
      await page.locator("[name=city]").fill("Unsaved new input");
      await openFile(saved.path);
      const after = snapshots.reopened = await snapshot();
      assert.deepEqual(after.week, snapshots.arranged.week);
      assert.deepEqual(after.assignments, snapshots.arranged.assignments);
      assert.deepEqual(after.original, snapshots.arranged.original);
      assert.deepEqual(after.input, snapshots.arranged.input);
      assert.deepEqual(after.constraints, snapshots.arranged.constraints);
      assert.equal(after.date, "2026-12-28");
      assert.match(after.savedSource, /Saved copy opened from “first-week.json”/);
      assert.match(after.savedSource, /not been run again/);
      assert.equal(after.savedSourceHidden, false);
      calendarAfter = await download("#calendarDownload", "after-reopen.ics");
      assert.deepEqual(calendarAfter.data, calendarBefore.data);
      assert.equal(requests.length, 1, "Opening did not request another plan");
      await page.emulateMedia({ media: "print" });
      assert.equal(await page.locator("#savedWeekSource").isVisible(), true);
      const pdf = path.join(output, "reopened-week.pdf");
      await page.pdf({ path: pdf, format: "A4", printBackground: true });
      const printed = execFileSync("pdftotext", [pdf, "-"], { encoding: "utf8" });
      fs.writeFileSync(path.join(output, "reopened-week-print.txt"), printed);
      assert.match(printed, /Saved copy opened from/);
      assert.match(printed, /first-week\.json/);
      assert.match(printed, /Not scheduled this week/);
      await page.emulateMedia({ media: "screen" });
      await page.setViewportSize({ width: 390, height: 844 });
      assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
      await page.setViewportSize({ width: 1280, height: 900 });
    });

    await group("continued edits and resaving keep original evidence and acceptance identity", async () => {
      await move("pick-2", "Sunday");
      await page.locator("#weekDate").fill("2027-01-06");
      const again = await download("#saveWeek", "second-week.json");
      const parsed = JSON.parse(again.data);
      assert.equal(parsed.week.start, "2027-01-04");
      assert.equal(parsed.week.assignments["pick-2"], "Sunday");
      assert.equal(parsed.calendarId, envelope.calendarId);
      assert.equal(parsed.receivedAt, envelope.receivedAt);
      assert.deepEqual(parsed.response, native.rosa);
      assert.deepEqual((await snapshot()).original, snapshots.arranged.original);
      await page.locator("#resetWeek").click();
      const reset = snapshots.reset = await snapshot();
      assert.equal(reset.date, "2027-01-06");
      assert.equal(reset.assignments["pick-0"], "Monday");
      assert.equal(reset.assignments["pick-1"], "Wednesday");
      assert.equal(reset.assignments["pick-2"], "Friday");
      assert.deepEqual(reset.original, snapshots.arranged.original);
    });

    await group("malformed opens retire prior output without mixing evidence or losing inputs", async () => {
      const bad = [
        ["bad-json.json", "{"],
        ["bad-version.json", { ...envelope, format: "unknown" }],
        ["bad-assignments.json", { ...envelope, week: { ...envelope.week, assignments: {} } }],
        ["bad-inputs.json", { ...envelope, inputs: { ...envelope.inputs, constraints: [] } }],
        ["bad-late-trace.json", { ...envelope, response: { ...envelope.response, trace: null } }],
      ];
      const unsupported = clone(envelope);
      unsupported.inputs.constraints.push("unsupported-fixture-constraint");
      unsupported.response.comparison.constraints.push("unsupported-fixture-constraint");
      bad.push(["unsupported-constraint.json", unsupported]);
      for (const [name, value] of bad) {
        await openFile(saved.path);
        const previous = await snapshot();
        await openFile(variant(value, name), { wait: false });
        await retired();
        const current = snapshots[name] = await snapshot();
        assert.equal(current.hidden, true);
        assert.equal(current.saveDisabled, true);
        assert.equal(current.printDisabled, true);
        assert.equal(current.calendarDisabled, true);
        assert.deepEqual(current.input, previous.input);
        assert.deepEqual(current.original, previous.original);
        assert.match(current.status, /could not open this saved week/);
      }
      assert.equal(requests.length, 1);
    });

    await group("the existing lifecycle rejects late file reads after edit, replacement and cancellation", async () => {
      await page.evaluate(() => {
        const read = File.prototype.text;
        File.prototype.text = function () {
          if (this.name !== "slow-week.json") return read.call(this);
          return new Promise((resolve, reject) => {
            window.releaseWeekFile = () => read.call(this).then(resolve, reject);
          });
        };
      });
      const slow = variant(envelope, "slow-week.json");
      const startSlow = async () => {
        await page.evaluate(() => { window.releaseWeekFile = null; });
        await openFile(slow, { wait: false });
        await page.waitForFunction(() => typeof window.releaseWeekFile === "function");
        const pending = await snapshot();
        assert.equal(pending.hidden, true);
        assert.equal(pending.saveDisabled, true);
        assert.equal(pending.calendarDisabled, true);
      };
      const release = async () => {
        await page.evaluate(async () => { await window.releaseWeekFile(); await new Promise((resolve) => setTimeout(resolve, 0)); });
      };
      await openFile(saved.path);
      await startSlow();
      await page.locator("[name=city]").fill("Edited during file read");
      await release();
      const edited = snapshots.lateAfterInput = await snapshot();
      assert.equal(edited.hidden, true);
      assert.equal(edited.input.city, "Edited during file read");
      assert.match(edited.status, /Inputs changed/);
      await startSlow();
      await sample("mei");
      const newer = await snapshot();
      await release();
      assert.deepEqual(await snapshot(), newer);
      assert.equal(newer.input.music, "The Beatles");
      await startSlow();
      await page.locator("#cancelPlan").click();
      await release();
      const cancelled = snapshots.lateAfterCancel = await snapshot();
      assert.equal(cancelled.hidden, true);
      assert.equal(cancelled.saveDisabled, true);
      assert.match(cancelled.status, /Stopped waiting/);
      assert.equal(requests.length, 2);
    });

    await group("date refusal, all-off and unknown-source snapshots retain native handoff behavior", async () => {
      await openFile(saved.path);
      await page.locator("#weekDate").fill("");
      await move("pick-0", "Tuesday");
      await page.locator("#resetWeek").click();
      const invalid = snapshots.invalidDate = await snapshot();
      assert.equal(invalid.saveDisabled, true);
      assert.equal(invalid.calendarDisabled, true);
      assert.equal(invalid.printDisabled, true);
      await openFile(saved.path);
      assert.equal((await snapshot()).saveDisabled, false);
      const allOff = clone(envelope);
      Object.keys(allOff.week.assignments).forEach((key) => { allOff.week.assignments[key] = null; });
      await openFile(variant(allOff, "all-off.json"));
      const off = snapshots.allOff = await snapshot();
      assert.equal(off.saveDisabled, false);
      assert.equal(off.printDisabled, false);
      assert.equal(off.calendarDisabled, true);
      assert(off.week.every((day) => !day.keys.length));
      const unknown = clone(envelope);
      delete unknown.response.mock;
      await openFile(variant(unknown, "unknown-source.json"));
      const held = snapshots.unknownSource = await snapshot();
      assert.match(held.source, /did not specify its data source/);
      assert.equal(held.calendarDisabled, true);
      assert.equal(held.saveDisabled, false);
      const outputFile = await download("#saveWeek", "unknown-resaved.json");
      assert.equal(Object.hasOwn(JSON.parse(outputFile.data).response, "mock"), false);
    });

    await group("manual requests keep the native body and retire saved-copy identity", async () => {
      await openFile(saved.path);
      await page.locator("#form button[type=submit]").click();
      await opened();
      assert.equal(requests.length, 3);
      assert.deepEqual(requests[2], { path: "/api/plan", body: envelope.inputs });
      const current = snapshots.generatedAgain = await snapshot();
      assert.equal(current.savedSource, null);
      assert.equal(current.savedSourceHidden, true);
      assert.equal(current.saveDisabled, false);
      assert.equal(current.calendarDisabled, false);
      assert.deepEqual(current.storage, { local: 0, session: 0 });
    });
    assert.deepEqual(external, []);
    assert.deepEqual(pageErrors, []);
  } catch (error) {
    failure = { message: error.message, stack: error.stack };
    console.error(error.stack);
    process.exitCode = 1;
  } finally {
    const after = sourcePins();
    const receipt = {
      schema: "tastetable.saved-week.browser.v1", recordedAt: new Date().toISOString(),
      run: baseline ? "original capability absence" : htmlBoundaryOnly ? "saved-file HTML boundary" : nativeRecoveryOnly ? "native PR11 recovery response receiving" : "saved-week candidate receiving",
      source, node: process.version, browser: browser ? await browser.version() : null,
      sourcesBefore: before, sourcesAfter: after, sourcesUnchanged: JSON.stringify(before) === JSON.stringify(after),
      nativeFixtureSHA256: hash(fs.readFileSync(path.join(root, "intake/native-responses.json"))),
      groups, failure, requests, externalRequests: external, pageErrors, served, files, snapshots,
      limits: ["Actual Chromium over unchanged synthetic native response fixtures; no live provider call.",
        "Calendar-app import/update behavior and deployment are unmeasured.",
        "File.prototype.text is delayed only in the explicit ignored-abort receiving control."],
    };
    fs.writeFileSync(path.join(output, "receipt.json"), JSON.stringify(receipt, null, 2) + "\n");
    if (browser) await browser.close();
    await new Promise((resolve) => server.close(resolve));
    console.log(JSON.stringify({ groups: groups.length, failure, sourcesUnchanged: receipt.sourcesUnchanged, files: Object.keys(files).length, externalRequests: external.length, pageErrors: pageErrors.length }));
  }
})();
