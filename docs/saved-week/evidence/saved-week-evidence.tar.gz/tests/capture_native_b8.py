"""Capture two real PR11 recovery responses using its unchanged native tools.

The call shape follows PR11's test_tool_argument_recovery.py. This is a new
local execution by the saved-week author, not another independent owner run.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
source = root / "intake/native-b8"
output = root / "evidence/native-b8-recovery.json"
if output.exists():
    raise SystemExit("Use a fresh receiving output")
manifest = json.loads((root / "intake/native-b8-source.json").read_text())
for item in manifest["files"]:
    assert hashlib.sha256((source / item["path"]).read_bytes()).hexdigest() == item["sha256"]
sys.path.insert(0, str(source))
import agent
from personas import PERSONAS
from qloo_client import FixtureTransport, QlooClient


class Replies:
    def __init__(self, raw):
        self.messages = []
        self.batches = iter([
            [agent._call("fetched", "qloo_recs", {"filter_type": "urn:entity:place", "purpose": "restaurant", "tag_ids": ["urn:tag:genre:restaurant:Cuban"]})],
            [agent._call("checked", "constraint_check", {"entity_ids": ["FIX-P-01", "FIX-P-04"], "constraints": PERSONAS["rosa"]["constraints"], "kind": "restaurant"})],
            [{"id": "malformed", "type": "function", "function": {"name": "qloo_recs", "arguments": raw}}],
        ])
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))

    def create(self, **kwargs):
        self.messages.append(copy.deepcopy(kwargs["messages"]))
        calls = next(self.batches, [])
        return agent._completion(None if calls else "Native recovery capture complete", tool_calls=calls)


rows = []
with patch.dict(agent.os.environ, {}, clear=True), patch("urllib.request.urlopen", side_effect=AssertionError("No external request allowed")):
    for label, raw in [("invalid_json", "{"), ("decoded_list", "[]")]:
        model = Replies(raw)
        fixture = FixtureTransport()
        response = agent.run_agent(PERSONAS["rosa"], qloo=QlooClient(api_key="synthetic-saved-week-receiving", transport=fixture), model=model)
        assert [item["entity_id"] for item in response["plan"]["meals"]] == ["FIX-P-01"]
        assert len(fixture.log) == 1
        assert response["trace"][-1]["args"] == (None if label == "invalid_json" else [])
        rows.append({"case": label, "response": response, "fixture_transport": fixture.log,
                     "model_messages": model.messages, "inputs": {key: PERSONAS["rosa"][key] for key in ("cuisines", "music", "films", "city", "constraints")}})
for item in manifest["files"]:
    assert hashlib.sha256((source / item["path"]).read_bytes()).hexdigest() == item["sha256"]
receipt = {"schema": "tastetable.saved-week.native-b8-receiving.v1", "source": manifest,
           "python": sys.version, "source_unchanged": True, "external_requests": 0, "cases": rows}
output.write_text(json.dumps(receipt, ensure_ascii=False, allow_nan=False, indent=2) + "\n")
print(json.dumps({"cases": len(rows), "source_commit": manifest["commit"], "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest()}))
