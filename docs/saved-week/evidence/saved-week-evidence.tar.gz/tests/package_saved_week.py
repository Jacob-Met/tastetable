"""Build the root-owned publication packet from exact preserved local inputs."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import shutil
import tarfile

root = Path(__file__).resolve().parents[1]
source = root / "candidate-v3"
doc = source / "docs/saved-week"
destination = doc / "evidence"
destination.mkdir(parents=True, exist_ok=True)
copies = {
    "source-freeze-v3.json": "source-freeze.json",
    "composition-receipt-v3.json": "receiving-base.json",
    "qualification-v3.json": "author-qualification.json",
    "evidence/native-week-file-v3.log": "native-tests.log",
    "evidence/browser-v3/receipt.json": "browser-receipt.json",
    "evidence/html-v3-capacity/receipt.json": "html-boundary-receipt.json",
    "evidence/native-browser-v3-capacity/receipt.json": "native-browser-receipt.json",
    "evidence/native-recovery-v3-pass.json": "native-recovery-receipt.json",
    "intake/native-b8-source.json": "native-source-manifest.json",
}
for original, name in copies.items():
    shutil.copyfile(root / original, destination / name)

paths = []
for name in ["baseline", "candidate", "evidence", "intake", "tests"]:
    paths.extend(p for p in (root / name).rglob("*") if p.is_file())
paths.extend(p for p in source.rglob("*") if p.is_file() and "docs" not in p.relative_to(source).parts)
paths.extend(root / name for name in ["CONTRACT.md", "source-freeze.json", "source-freeze-v3.json",
                                   "saved-week.patch", "saved-week-v3.patch", "composition-receipt-v3.json", "qualification-v3.json"])
paths = sorted(set(paths), key=lambda p: p.relative_to(root).as_posix())
manifest = []
buffer = io.BytesIO()
with gzip.GzipFile(filename="", mode="wb", fileobj=buffer, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tar:
        for path in paths:
            data = path.read_bytes()
            relative = path.relative_to(root).as_posix()
            info = tarfile.TarInfo(relative)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
            manifest.append({"path": relative, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
archive_bytes = buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as tar:
    for item in manifest:
        data = tar.extractfile(item["path"]).read()
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]
archive = destination / "saved-week-evidence.tar.gz"
pending = archive.with_suffix(".partial")
pending.write_bytes(archive_bytes)
pending.replace(archive)
record = {"schema": "tastetable.saved-week.evidence.v3", "archive": {
    "path": "docs/saved-week/evidence/saved-week-evidence.tar.gz", "bytes": len(archive_bytes),
    "sha256": hashlib.sha256(archive_bytes).hexdigest(), "members": len(manifest), "all_members_verified": True}, "members": manifest}
(destination / "evidence-manifest.json").write_text(json.dumps(record, indent=2) + "\n")

parent = json.loads((root / "intake/receiving-parent.json").read_text())
leaves = {x["path"]: x for x in parent["leaves"]}
freeze = json.loads((root / "source-freeze-v3.json").read_text())
allowed = [row["path"] for row in freeze["source_paths"]]
allowed += [p.relative_to(source).as_posix() for p in sorted(doc.rglob("*")) if p.is_file()]
rows = []
for relative in allowed:
    path = source / relative
    data = path.read_bytes()
    binary = relative.endswith(".tar.gz")
    if not binary:
        data.decode("utf-8")
    rows.append({"path": relative, "local_path": str(path), "mode": "100644", "type": "blob",
                 "encoding": "base64" if binary else "utf-8", "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                 "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
                 "before_git_blob": leaves.get(relative, {}).get("sha")})
for frozen in freeze["source_paths"]:
    observed = next(row for row in rows if row["path"] == frozen["path"])
    assert observed["sha256"] == frozen["sha256"]
    assert observed["before_git_blob"] == frozen["before_git_blob"]
allowlist = {"schema": "gitdata.publication.allowlist.v1", "repository": "Jacob-Met/tastetable",
             "base_branch": parent["branch"], "base_commit": parent["commit"], "base_tree": parent["tree"],
             "proposed_branch": "work/saved-week-0df473646168", "purpose": "Explicit local saved-week continuation on the existing calendar/lifecycle composition",
             "source_freeze": str(root / "source-freeze-v3.json"),
             "source_freeze_sha256": hashlib.sha256((root / "source-freeze-v3.json").read_bytes()).hexdigest(),
             "file_count": len(rows), "files": rows, "publication_owner": "root only",
             "independent_receiving": "root review pending; author runs are not independent receiving",
             "runtime_disposition": "Earlier RAM/Chromium and archive ENOSPC failures are retained. Unchanged final source subsequently completed every author browser mode after ordinary capacity returned."}
(root / "publication-allowlist-v3.json").write_text(json.dumps(allowlist, indent=2) + "\n")
print(json.dumps({"paths": len(rows), "archive": record["archive"],
                  "allowlist_sha256": hashlib.sha256((root / "publication-allowlist-v3.json").read_bytes()).hexdigest()}, indent=2))
