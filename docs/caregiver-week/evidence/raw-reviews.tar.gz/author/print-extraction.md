<!-- Page: 1 -->
# TasteTable 

 Not medical or dietary advice. Constraint checks are heuristics over public venue tags and menu keywords. Always confirm accessibility, texture and sodium needs with the venue and the person's care team. Sample personas are fictional; do not enter real health information. 

## Week of Oct 5, 2026 

##### Oct 5, 2026 – Oct 11, 2026 

##### Demo plan: fictional venues from a synthetic fixture. 

#### Requested constraints: soft foods, low sodium, wheelchair access. 

##### 5 of 5 suggested picks scheduled. 2 open days. 

## Monday Oct 5, 2026 

## Casa Habana Kitchen 

 restaurant affinity 0.91 

 Qloo affinity 0.91 for audiences who like Celia Cruz, West Side Story (tag match: Cuban). Checks: Soft foods: pass (soft options listed: black bean soup, flan, made to order); Low sodium: pass (lower-sodium signals: made to order); Wheelchair: pass (tagged 'wheelchair accessible entrance'). Qloo id: FIX-P-01 

## Tuesday Oct 6, 2026 

##### Open day 

##### No pick scheduled. 

## Wednesday Oct 7, 2026 

## Abuela's Table 

 restaurant affinity 0.83 Qloo affinity 0.83 for audiences who like Celia Cruz, West Side Story (tag match: Mexican). Checks: Soft foods: pass (soft options listed: caldo de pollo, refried beans); Low sodium: pass (lower-sodium signals: low sodium options); Wheelchair: pass (tagged 'wheelchair accessible entrance'). Qloo id: FIX-P-03 

## Thursday Oct 8, 2026 

##### Open day 

##### No pick scheduled. 



<!-- Page: 2 -->
## Friday Oct 9, 2026 

### Blue Plate Diner 

 restaurant widened affinity 0.26 

 Qloo affinity 0.26 for audiences who like Celia Cruz, West Side Story (tag match: Diner). Weak taste signal: chosen mainly because it passes the care constraints. Widened pick: outside the stated cuisines because too few matches passed constraints. Checks: Soft foods: pass (soft options listed: made to order, mashed potatoes, soups); Low sodium: pass (lower-sodium signals: made to order); Wheelchair: pass (tagged 'wheelchair accessible entrance'). Qloo id: FIX-P-07 

## Saturday Oct 10, 2026 

### Arroyo Museum of Latin Music (fictional) 

 outing affinity 0.96 

 Qloo affinity 0.96 for audiences who like Celia Cruz, West Side Story (tag match: Museum). Checks: Wheelchair: pass (tagged 'wheelchair accessible entrance'). Qloo id: FIX-V-03 

## Sunday Oct 11, 2026 

### Trattoria Nonna Lucia 

 restaurant widened affinity 0.26 Qloo affinity 0.26 for audiences who like Celia Cruz, West Side Story (tag match: Italian). Weak taste signal: chosen mainly because it passes the care constraints. Widened pick: outside the stated cuisines because too few matches passed constraints. Checks: Soft foods: pass (soft options listed: made to order, polenta, risotto); Low sodium: pass (lower-sodium signals: made to order); Wheelchair: pass (tagged 'wheelchair accessible entrance'). Qloo id: FIX-P-11 

 Planning draft. Dates are your choices, not reservations or confirmed opening hours. Confirm the venue, accessibility and food needs with the venue and care team before going. 

MIT licensed · Uses Qloo's Taste AI insights. Qloo results describe aggregate affinities, not facts about any individual. 



