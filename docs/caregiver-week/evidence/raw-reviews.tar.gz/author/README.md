# TasteTable caregiver week — source and receiving evidence

## Receiving identity

- Repository: `Jacob-Met/tastetable`.
- GitHub base: `d1c7a4e39cfdc0bb5b9fe026bc9660b75b456e81` (`main`, source recovered 2026-10-08).
- Contribution identity: `universal-0df473646168 / estate_product`.
- Coordination: HAMON memory issue #8, parent scope comment `6054631928`.
- Local source snapshot: `5a813d7a8bf34e98e1705b983d73de3f3623c3f4`.
- Frozen local candidate: `02c5e91f2c3e7220162b651ba3c1ec589ac2eea2`.
- The local snapshot has its own ancestry. Apply `week-plan.patch` to the named GitHub base, or publish the six exact blobs in `candidate_manifest.json`; do not present the local snapshot commit as a GitHub commit.

The source catalogue contained 17 files and no AGENTS/continuation file. All 17 input blobs
were verified, including CRLF/no final newline in the existing synthetic fixture. At recovery,
open TasteTable PR #1 covered CI/Docker and PR #2/#3 covered configured model selection and
tool-error preservation. This contribution changes none of those implementation paths.

## Product behavior

The original interface displayed five checked picks on fixed weekdays. The receiving browser
baseline confirms Monday, Wednesday, Friday, Saturday and Sunday, with no date input, schedule
controls or dedicated print control.

The candidate gives the caregiver a Monday–Sunday calendar for a chosen week. A pick can move
to another day, share a day with another pick, or remain off the week with a visible restore
control. Reset restores the suggested weekdays while retaining the chosen week. Seven days
remain visible for partial and empty plans. Each item carries its original ID, affinity,
widened label and check explanation. Original suggestions and comparison counts stay in a
separate collapsible evidence panel.

Print opens the browser's own dialog for the dated handoff. The observed two-page PDF includes
all five fixture picks, open days, original evidence, requested constraints, the synthetic
fixture label and care/availability caveats. Scheduling is local to the current page visit.
No additional recommendation request, new venue, constraint evaluation, reservation, persistence
store or sending operation is introduced.

Only six paths differ: README, the existing three static UI files, `static/week_plan.mjs`
and `tests/test_week_plan.mjs`. `native-preservation.json` accounts for the other 13 original
blobs and confirms all three complete native fixture persona responses are unchanged.

## Verification

| Check | Result | Evidence |
|---|---|---|
| Node state/calendar tests | 11 passed | `node-tests.log` |
| Existing Python client/constraint/agent tests | 18 passed; web test deselected | `python-regression.log` |
| Native Chromium baseline | 2 checkpoints passed | `baseline-browser.json` |
| Native Chromium candidate | 11 checkpoints passed | `browser-final.json` |
| Original source and persona outputs | All retained source blobs and all three complete responses agree | `native-preservation.json` |
| Printed PDF | 2 pages, visibly inspected and text extracted | `week-handoff.pdf`, `print-extraction.md` |
| Desktop and 390px screen | Inspected; no horizontal overflow in browser check | `week-desktop.png`, `week-mobile.png` |

State checks cover source detachment/immutability, move/omit/restore/reset, shared days,
duplicate source IDs, rejected/absent picks, explicit unknown source, calendar validity,
leap/year transitions and opposite time zones across a daylight-saving week. The browser
drives the actual static app using native Chromium keyboard events and captured native
synthetic API responses. It checks focus, identity/evidence preservation, lack of extra API
calls while editing, print visibility, empty-date print refusal, mobile layout, delayed
response ordering, failed request preservation, HTML escaping and a zero-pick native result.

Browser runtime: ThinkPad UID 1000, Node `22.22.1`, Chromium `153.0.8010.47` snap, fresh owned
profile and ephemeral loopback-only fixture server. Both terminate after each run. The exact
static source hashes are recorded in each report. The server returns `run_agent` output
captured from the unchanged native `FixtureTransport`, plus a native `assemble_plan` empty
result and explicitly authored transport/escaping variants. It uses no provider or live data.

The full FastAPI route test was not run: FastAPI/httpx were unavailable in this local runtime.
The existing non-web pytest methods ran using an available read-only interpreter with bytecode
and pytest cache writes disabled. Browser HTTP responses are fixtures, not a claim that a
production FastAPI service was tested or deployed. No installed source or service was changed.

## Retained test-harness failures

`browser-initial-focus-check.json` retains the first failure after seven successful browser
checkpoints: the test incorrectly expected focus to stay on a pick after the user explicitly
clicked the sample button. The corrected check compares plan state and evidence, allowing
that deliberate focus move.

`browser-r2-request-check.json` and `browser-r3-request-detail.json` retain the second failure
and its diagnostic replay. Chromium requests an embedded `data:image/svg+xml` calendar icon
for the native date input. The old predicate incorrectly called that an external request.
The final predicate permits embedded data URLs and still rejects external page requests.
The application source did not change during these harness corrections. The original packet
`browser-inputs.tar.gz` preserves the initial baseline/candidate inputs and first harness.

## Reproduction

In a checkout of the candidate:

```sh
node --test tests/test_week_plan.mjs
python -m pytest tests/test_tastetable.py
```

The browser harness requires Node 22+ and a Chromium executable, and writes only to its own
output/profile directory. Keep `check_browser.mjs` and `browser_fixture.json` together:

```sh
node check_browser.mjs --root /absolute/candidate --output /absolute/owned-results --browser /absolute/chromium
node check_browser.mjs --root /absolute/baseline --output /absolute/owned-baseline-results --browser /absolute/chromium --baseline
```

`source-snapshot.tar.gz` contains the complete tracked candidate source. `browser-inputs.tar.gz`
contains the three untouched baseline static files for the baseline browser command. The
final harness SHA-256 is `67be1f4a23f2e1e789173b53c95dfcbd3a8be842ffa373650e577f269c3e78d2`.

Root owns independent review, repository publication and integration. This packet establishes
source behavior under the stated tests; it does not claim live adoption or current venue data.
