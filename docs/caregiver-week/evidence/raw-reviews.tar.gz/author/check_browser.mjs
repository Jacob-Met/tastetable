/** Source-only browser acceptance. Node 22+, fresh Chromium profile, native synthetic API fixtures. */
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { readFile, writeFile, mkdir, mkdtemp, rm } from "node:fs/promises";
import { dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const options = process.argv.slice(2);
const option = (key, fallback) => options.includes(key) ? options[options.indexOf(key) + 1] : fallback;
const project = resolve(option("--root", join(here, "../tastetable")));
const executable = option("--browser", "chromium");
const output = resolve(option("--output", join(here, "browser-output")));
const baseline = options.includes("--baseline");
const fixture = JSON.parse(await readFile(join(here, "browser_fixture.json"), "utf8"));
await mkdir(output, {recursive:true});
const profile = await mkdtemp(join(output, "profile-"));
const report = {status:"running", baseline, project, executable, checks:[], screenshots:[], sourceSha256:{}, apiRequests:[]};
for (const path of ["static/index.html", "static/app.js", "static/style.css", "static/week_plan.mjs"]) {
  try { report.sourceSha256[path] = createHash("sha256").update(await readFile(join(project, path))).digest("hex"); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
}
report.fixtureSha256 = createHash("sha256").update(await readFile(join(here,"browser_fixture.json"))).digest("hex");
const queuedReplies = [];
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve,ms));
const server = createServer(async (request,response) => {
  try {
    const path = new URL(request.url,"http://localhost").pathname;
    let body = "";
    for await (const chunk of request) body += chunk;
    if (path.startsWith("/api/")) {
      report.apiRequests.push({path, method:request.method, body:body ? JSON.parse(body) : null});
      let data;
      if (path === "/api/health") data = {qloo_mode:"mock"};
      else if (path === "/api/personas") data = fixture.personas;
      else if (path.startsWith("/api/plan")) {
        const reply = queuedReplies.shift();
        if (reply?.delay) await sleep(reply.delay);
        if (reply?.error) {response.writeHead(503,{"Content-Type":"application/json"});response.end(JSON.stringify({detail:"authored unavailable response"}));return;}
        data = reply?.data ?? fixture.responses[path.split("/").at(-1)] ?? fixture.responses.rosa;
      } else {response.writeHead(404).end();return;}
      response.writeHead(200,{"Content-Type":"application/json"});response.end(JSON.stringify(data));return;
    }
    const file = resolve(project, path === "/" ? "static/index.html" : `.${decodeURIComponent(path)}`);
    if (!file.startsWith(`${project}/`)) {response.writeHead(403).end();return;}
    const data = await readFile(file);
    const type = {".html":"text/html", ".js":"text/javascript", ".mjs":"text/javascript", ".css":"text/css"}[extname(file)];
    response.writeHead(200,{"Content-Type":`${type || "application/octet-stream"}; charset=utf-8`});response.end(data);
  } catch {response.writeHead(404).end();}
});
await new Promise((resolve) => server.listen(0,"127.0.0.1",resolve));
const base = `http://127.0.0.1:${server.address().port}`;
let browser, socket, sessionId, browserLog = "", sequence = 0;
const pending = new Map(), pageErrors = [], pageRequests = [];
async function waitFor(check,label) {
  let last;
  for (let attempt=0;attempt<150;attempt++) {
    try {if(await check())return;} catch(error){last=error;}
    await sleep(100);
  }
  throw new Error(`Timed out: ${label}${last ? ` (${last.message})` : ""}`);
}
function command(method,params={},scoped=true) {
  const id=++sequence;
  return new Promise((resolve,reject) => {
    const timer=setTimeout(()=>{pending.delete(id);reject(new Error(`CDP timeout: ${method}`));},10000);
    pending.set(id,{resolve,reject,timer});
    socket.send(JSON.stringify({id,method,params,...(scoped&&sessionId?{sessionId}:{})}));
  });
}
async function evaluate(expression) {
  const r=await command("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});
  if(r.exceptionDetails)throw new Error(r.exceptionDetails.exception?.description??r.exceptionDetails.text);
  return r.result.value;
}
async function key(name,code) {
  for(const type of ["keyDown","keyUp"])await command("Input.dispatchKeyEvent",{type,key:name,code:name,windowsVirtualKeyCode:code,nativeVirtualKeyCode:code,...(name==="Enter"&&type==="keyDown"?{text:"\r",unmodifiedText:"\r"}:{})});
}
async function activate(selector) {
  await evaluate(`document.querySelector(${JSON.stringify(selector)}).focus()`);
  await key("Enter",13);
}
async function select(selector,value) {
  await evaluate(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});e.value=${JSON.stringify(value)};e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
}
async function date(value) {
  await evaluate(`(()=>{const e=document.querySelector('#weekDate');e.value=${JSON.stringify(value)};e.dispatchEvent(new Event('input',{bubbles:true}));})()`);
}
async function snapshot() {
  return evaluate(`({
    title:document.querySelector('#weekTitle')?.textContent,
    summary:document.querySelector('#weekSummary')?.textContent,
    source:document.querySelector('#weekSource')?.textContent,
    dates:[...document.querySelectorAll('#weekDays time')].map(e=>e.dateTime),
    assignments:[...document.querySelectorAll('#weekOrganizer select[data-pick-key]')].map(e=>({key:e.dataset.pickKey,value:e.value})).sort((a,b)=>a.key.localeCompare(b.key)),
    evidence:[...document.querySelectorAll('#weekOrganizer .scheduled-pick')].map(e=>({name:e.querySelector('h4').textContent,why:e.querySelector('.why').textContent,id:e.querySelector('.mono').textContent})).sort((a,b)=>a.id.localeCompare(b.id)),
    open:document.querySelectorAll('#weekDays .open-day').length,
    omitted:document.querySelectorAll('#omittedPicks > li').length,
    original:document.querySelector('#plan').textContent,
    comparison:document.querySelector('#compare').textContent,
    focus:document.activeElement.dataset.pickKey,
    overflow:document.documentElement.scrollWidth>innerWidth
  })`);
}
async function screenshot(name,selector="#weekOrganizer") {
  if(selector)await evaluate(`document.querySelector(${JSON.stringify(selector)}).scrollIntoView({block:'start'})`);
  const {data}=await command("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});
  await writeFile(join(output,name),Buffer.from(data,"base64"));report.screenshots.push(name);
}
const passed=(name)=>{report.checks.push(name);console.log(`PASS ${name}`);};

try {
  browser=spawn(executable,["--headless=new","--no-sandbox","--disable-gpu","--disable-background-networking","--disable-component-update","--disable-sync","--no-first-run","--no-default-browser-check","--remote-debugging-address=127.0.0.1","--remote-debugging-port=0",`--user-data-dir=${profile}`,"about:blank"],{stdio:["ignore","ignore","pipe"]});
  browser.stderr.on("data",data=>{browserLog=(browserLog+data.toString()).slice(-6000);});
  let launchError;
  browser.on("error",error=>{launchError=error;});
  let port,endpoint;
  await waitFor(async()=>{
    if(launchError)throw launchError;
    if(browser.exitCode!==null)throw new Error(`Browser exited ${browser.exitCode}: ${browserLog}`);
    [port,endpoint]=(await readFile(join(profile,"DevToolsActivePort"),"utf8")).trim().split("\n");
    return Boolean(port&&endpoint);
  },"browser startup");
  socket=new WebSocket(`ws://127.0.0.1:${port}${endpoint}`);
  socket.addEventListener("message",event=>{
    const message=JSON.parse(event.data);
    if(message.id){const request=pending.get(message.id);if(!request)return;pending.delete(message.id);clearTimeout(request.timer);if(message.error)request.reject(new Error(message.error.message));else request.resolve(message.result);}
    else if(message.method==="Runtime.exceptionThrown")pageErrors.push(message.params.exceptionDetails.exception?.description??message.params.exceptionDetails.text);
    else if(message.method==="Network.requestWillBeSent")pageRequests.push(message.params.request.url);
  });
  await new Promise((resolve,reject)=>{socket.addEventListener("open",resolve,{once:true});socket.addEventListener("error",reject,{once:true});});
  report.browser=await command("Browser.getVersion",{},false);
  const {targetId}=await command("Target.createTarget",{url:"about:blank"},false);
  ({sessionId}=await command("Target.attachToTarget",{targetId,flatten:true},false));
  await command("Page.enable");await command("Runtime.enable");await command("Network.enable");
  await command("Emulation.setDeviceMetricsOverride",{width:1280,height:1000,deviceScaleFactor:1,mobile:false});
  await command("Page.navigate",{url:base});
  await waitFor(()=>evaluate("document.querySelector('#personaSel')?.options.length===3"),"native app initialized");
  await select("#personaSel","rosa");await activate("#sampleBtn");
  await waitFor(()=>evaluate("!document.querySelector('#results').hidden"),"native response rendered");

  if(baseline){
    report.original=await evaluate("({days:[...document.querySelectorAll('#plan > li > strong')].map(e=>e.textContent),picks:document.querySelectorAll('#plan > li').length,weekDate:!!document.querySelector('#weekDate'),scheduleControls:document.querySelectorAll('#results select').length,printControl:!!document.querySelector('#printWeek')})");
    assert.equal(report.original.picks,5);
    assert.deepEqual(report.original.days,["Monday","Wednesday","Friday","Saturday","Sunday"]);
    assert.equal(report.original.weekDate,false);assert.equal(report.original.scheduleControls,0);assert.equal(report.original.printControl,false);
    await screenshot("baseline-fixed-plan.png","#results");
    passed("untouched native app returns five fixed-day picks with no week/date/schedule/print controls");
  }else{
    const initial=await snapshot();report.initial=initial;
    assert.equal(initial.assignments.length,5);assert.equal(initial.open,2);assert.equal(initial.dates.length,7);assert.match(initial.source,/fictional/);assert.equal(initial.overflow,false);
    passed("actual native response becomes seven days with all five original source identities");
    const requestCount=report.apiRequests.length;
    await evaluate("document.querySelector('[data-pick-key=pick-0]').focus()");
    await key("ArrowDown",40);
    await waitFor(async()=>((await snapshot()).assignments[0].value==="Tuesday"),"native keyboard day change");
    assert.equal((await snapshot()).focus,"pick-0");
    passed("native keyboard day change updates the calendar and retains focus");
    await select("[data-pick-key=pick-0]","Wednesday");
    assert.equal(await evaluate("document.querySelectorAll('[data-day=Wednesday] .scheduled-pick').length"),2);
    await select("[data-pick-key=pick-0]","");
    const omitted=await snapshot();assert.equal(omitted.omitted,1);assert.match(omitted.summary,/4 of 5/);assert.deepEqual(omitted.evidence,initial.evidence);assert.equal(omitted.original,initial.original);assert.equal(omitted.comparison,initial.comparison);
    await select("#omittedPicks [data-pick-key=pick-0]","Sunday");
    assert.equal((await snapshot()).omitted,0);
    assert.equal(await evaluate("document.querySelectorAll('[data-day=Sunday] .scheduled-pick').length"),2);
    assert.equal(report.apiRequests.length,requestCount);
    passed("move/omit/restore permits shared days, preserves all evidence and makes no API requests");
    await date("2024-02-29");await activate("#resetWeek");
    const reset=await snapshot();assert.deepEqual(reset.assignments,initial.assignments);assert.deepEqual(reset.dates,["2024-02-26","2024-02-27","2024-02-28","2024-02-29","2024-03-01","2024-03-02","2024-03-03"]);
    await date("2027-01-01");assert.deepEqual((await snapshot()).dates,["2026-12-28","2026-12-29","2026-12-30","2026-12-31","2027-01-01","2027-01-02","2027-01-03"]);
    await date("");assert.equal(await evaluate("document.querySelector('#printWeek').disabled"),true);assert.match(await evaluate("document.querySelector('#weekError').textContent"),/valid/);assert.equal((await snapshot()).dates[0],"2026-12-28");
    await date("2026-10-08");
    passed("leap/year transitions and an empty date retain a valid week and hold the print button");
    await screenshot("week-desktop.png");
    await command("Emulation.setEmulatedMedia",{media:"print"});
    const print=await evaluate("({source:document.querySelector('#weekSource').textContent,title:document.querySelector('#weekTitle').textContent,care:document.querySelector('.handoff-note').textContent,form:getComputedStyle(document.querySelector('.taste-form')).display,controls:getComputedStyle(document.querySelector('.pick-control')).display,original:getComputedStyle(document.querySelector('.original-evidence')).display,disclaimer:getComputedStyle(document.querySelector('.disclaimer')).display})");
    assert.match(print.source,/fictional/);assert.match(print.care,/not reservations/);assert.equal(print.form,"none");assert.equal(print.controls,"none");assert.equal(print.original,"none");assert.notEqual(print.disclaimer,"none");report.print=print;
    const pdf=await command("Page.printToPDF",{printBackground:true,preferCSSPageSize:true});await writeFile(join(output,"week-handoff.pdf"),Buffer.from(pdf.data,"base64"));
    await command("Emulation.setEmulatedMedia",{media:""});
    await evaluate("window.__printCalls=0;window.print=()=>{window.__printCalls++}");await activate("#printWeek");assert.equal(await evaluate("window.__printCalls"),1);
    passed("print handoff contains dates, source and care limits while hiding controls and original comparison");
    await command("Emulation.setDeviceMetricsOverride",{width:390,height:844,deviceScaleFactor:1,mobile:false});
    assert.equal((await snapshot()).overflow,false);await screenshot("week-mobile.png");
    passed("390px mobile calendar has no horizontal overflow");
    await command("Emulation.setDeviceMetricsOverride",{width:1280,height:1000,deviceScaleFactor:1,mobile:false});
    queuedReplies.push({data:fixture.responses.rosa,delay:700},{data:fixture.responses.harold});
    await select("#personaSel","rosa");await activate("#sampleBtn");await select("#personaSel","harold");await activate("#sampleBtn");
    await waitFor(()=>evaluate(`document.querySelector('#weekDays').textContent.includes(${JSON.stringify(fixture.responses.harold.plan.meals[0].name)})`),"newer response");
    await select("[data-pick-key=pick-0]","Thursday");const newer=await snapshot();await sleep(900);assert.deepEqual(await snapshot(),newer);
    passed("late older responses cannot replace a newer plan or overwrite its local edits");
    queuedReplies.push({error:true});await activate("#sampleBtn");await waitFor(()=>evaluate("document.querySelector('#requestStatus').textContent.includes('Could not prepare')"),"authored error");
    const afterError=await snapshot(),expectedAfterError=structuredClone(newer);
    delete afterError.focus;delete expectedAfterError.focus;
    assert.deepEqual(afterError,expectedAfterError);
    passed("an unavailable new response preserves the current edited week");
    const hostile=structuredClone(fixture.responses.rosa);hostile.plan.meals[0].name="<img src=x onerror=window.__injected=1>";hostile.plan.meals[0].why="</p><script>window.__injected=2</script>";hostile.plan.meals[0].entity_id='fixture-" onmouseover="window.__injected=3';hostile.plan.notes=['<svg onload="window.__injected=4">'];delete hostile.mock;
    queuedReplies.push({data:hostile});await activate("#sampleBtn");await waitFor(()=>evaluate("document.querySelector('#weekSource').textContent.includes('did not specify')"),"unknown source fixture");
    assert.equal(await evaluate("window.__injected===undefined"),true);assert.equal(await evaluate("document.querySelectorAll('#results img,#results svg,#results script').length"),0);assert.equal(await evaluate("document.querySelector('#weekDays h4').textContent"),hostile.plan.meals[0].name);
    await command("Emulation.setEmulatedMedia",{media:"print"});assert.equal(await evaluate("document.querySelector('#weekDays .why').textContent"),hostile.plan.meals[0].why);await command("Emulation.setEmulatedMedia",{media:""});
    passed("hostile source strings remain literal in screen/print and missing source stays unknown");
    queuedReplies.push({data:fixture.responses.empty});await activate("#sampleBtn");await waitFor(()=>evaluate("document.querySelector('#weekSummary').textContent.includes('0 of 0')"),"empty native plan");
    assert.equal((await snapshot()).open,7);assert.equal((await snapshot()).assignments.length,0);assert.match(await evaluate("document.querySelector('#weekNotes').textContent"),/Only 0 restaurants/);
    passed("a native zero-pick plan keeps seven open days and its original constraint-shortage note");
    assert.equal(report.apiRequests.filter(r=>r.path.startsWith('/api/plan')).every(r=>r.body===null||!('week' in r.body||'weekStart' in r.body||'assignments' in r.body)),true);
  }
  report.pageRequests=pageRequests;
  // Chromium's native date input requests an embedded data: SVG calendar icon.
  const localRequest=(url)=>url.startsWith(base)||url==='about:blank'||url.startsWith('data:');
  assert.deepEqual(pageErrors,[]);assert.ok(pageRequests.every(localRequest), JSON.stringify(pageRequests.filter(url=>!localRequest(url))));
  passed("tested browser paths have no JavaScript errors and no external page requests");
  report.status="passed";
}catch(error){
  report.status="failed";report.error=error.stack??String(error);report.browserLog=browserLog;report.pageErrors=pageErrors;
  if(sessionId){try{report.lastPage=await evaluate("({url:location.href,text:document.body.innerText.slice(0,7000),focus:document.activeElement.outerHTML})");await screenshot("failure.png",null);}catch{}}
  console.error(report.error);process.exitCode=1;
}finally{
  if(socket?.readyState===WebSocket.OPEN){try{await command("Browser.close",{},false);}catch{}}
  socket?.close();for(const request of pending.values())clearTimeout(request.timer);
  if(browser&&browser.exitCode===null)browser.kill("SIGTERM");
  server.closeAllConnections();await new Promise(resolve=>server.close(resolve));await sleep(300);await rm(profile,{recursive:true,force:true});
  await writeFile(join(output,"browser-report.json"),`${JSON.stringify(report,null,2)}\n`);
  console.log(`${report.status.toUpperCase()}: ${report.checks.length} browser checkpoints; ${join(output,"browser-report.json")}`);
}
