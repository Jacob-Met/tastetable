"""Recreate independent fixture inputs without provider, model, or HTTP calls."""
import datetime
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
root = Path(os.environ.get(
    "TASTETABLE_REVIEW_SOURCE",
    "/workspace/scratch/0df473646168/agents/product/tastetable",
))
out = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from agent import ScriptedModel, run_agent
from personas import PERSONAS
from qloo_client import FixtureTransport, QlooClient

responses = {
    pid: run_agent(
        persona,
        qloo=QlooClient(api_key="INDEPENDENT-FIXTURE-ONLY", transport=FixtureTransport()),
        model=ScriptedModel(),
    )
    for pid, persona in PERSONAS.items()
}
(out / "native-fixture-responses.json").write_text(json.dumps(responses, indent=2) + "\n")

anchors = set()
for year in [1, 4, 99, 100, 400, 1600, 1700, 1800, 1900, 1999, 2000, 2024, 2026, 2100, 2400, 9998, 9999]:
    for month, day in [(1, 1), (1, 3), (2, 28), (3, 1), (3, 8), (10, 25), (11, 1), (12, 28), (12, 31)]:
        anchors.add(datetime.date(year, month, day))
    try:
        anchors.add(datetime.date(year, 2, 29))
    except ValueError:
        pass

vectors = []
for date in sorted(anchors):
    start = date - datetime.timedelta(days=date.weekday())
    try:
        start + datetime.timedelta(days=6)
    except OverflowError:
        vectors.append({"anchor": date.isoformat(), "throws": True})
        continue
    vectors.append({
        "anchor": date.isoformat(),
        "dates": [(start + datetime.timedelta(days=i)).isoformat() for i in range(7)],
    })
(out / "calendar-python-oracle.json").write_text(json.dumps(vectors, indent=2) + "\n")
