import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import vm from "node:vm";
import test from "node:test";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = process.env.TASTETABLE_REVIEW_SOURCE || "/workspace/scratch/0df473646168/agents/product/tastetable";
const read = (relative) => readFile(path.join(root, relative), "utf8");
const [appSource, weekSource, html, css] = await Promise.all([
  read("static/app.js"), read("static/week_plan.mjs"), read("static/index.html"), read("static/style.css"),
]);
const responses = JSON.parse(await readFile(path.join(here, "native-fixture-responses.json"), "utf8"));
const calendarOracle = JSON.parse(await readFile(path.join(here, "calendar-python-oracle.json"), "utf8"));
const week = await import(pathToFileURL(path.join(root, "static/week_plan.mjs")));
const normalize = (value) => JSON.parse(JSON.stringify(value));
const sourcePicks = (response) => [...response.plan.meals, ...(response.plan.outing ? [response.plan.outing] : [])];
const escapeHTML = (s) => String(s).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");

// Execute the exact app and state module bytes. The only appended app text exports
// observations and existing functions to the reviewer; production files stay intact.
// This intentionally small DOM stores rendered markup/events; it is not a browser,
// layout engine, HTTP server, or a substitute for the author's Chromium checks.
async function appHarness() {
  const nodes = new Map();
  class Element {
    constructor(id) {
      this.id = id; this.value = ""; this.textContent = ""; this.innerHTML = "";
      this.hidden = false; this.disabled = false; this.attributes = new Map(); this.events = new Map();
    }
    addEventListener(name, callback) { this.events.set(name, callback); }
    setAttribute(name, value) { this.attributes.set(name, value); }
    removeAttribute(name) { this.attributes.delete(name); }
    scrollIntoView() {}
    focus() { this.focused = true; }
    async emit(name, event = {}) {
      return await this.events.get(name)?.({ target: this, preventDefault() {}, ...event });
    }
  }
  for (const [, id] of html.matchAll(/\bid="([^"]+)"/g)) nodes.set(`#${id}`, new Element(id));
  const querySelector = (selector) => {
    if (nodes.has(selector)) return nodes.get(selector);
    const match = /^#weekOrganizer select\[data-pick-key="([^"]+)"\]$/.exec(selector);
    if (match) {
      assert.ok((nodes.get("#weekDays").innerHTML + nodes.get("#omittedPicks").innerHTML).includes(`data-pick-key="${match[1]}"`));
      return new Element(selector);
    }
    throw new Error(`Unexpected DOM query: ${selector}`);
  };
  const form = nodes.get("#form");
  for (const name of ["cuisines", "music", "films", "city"]) form[name] = new Element(name);
  form.cuisines.value = "Cuban";
  form.city.value = "Pasadena";
  form.querySelectorAll = () => [{ value: "wheelchair", checked: true }];
  const requests = [], prints = [], pending = new Map();
  const snapshot = () => Object.fromEntries([...nodes].map(([key, node]) => [key, {
    text: node.textContent, markup: node.innerHTML, hidden: node.hidden, disabled: node.disabled,
  }]));
  const context = vm.createContext({
    document: { querySelector }, Date, Intl, structuredClone,
    window: { print() { prints.push(snapshot()); } },
    fetch: async (url, options) => {
      requests.push({ url, options: normalize(options || {}) });
      if (url === "/api/health") return { json: async () => ({ qloo_mode: "live" }) };
      if (url === "/api/personas") return { json: async () => [] };
      assert.ok(pending.has(url), `Unexpected request: ${url}`);
      const body = await pending.get(url);
      return { ok: true, json: async () => body };
    },
  });
  const library = new vm.SourceTextModule(weekSource, { context, identifier: path.join(root, "static/week_plan.mjs") });
  const app = new vm.SourceTextModule(appSource + "\nexport const review = {render, requestPlan, get state() {return weekState;}};\n", {
    context, identifier: path.join(root, "static/app.js"),
  });
  await app.link((specifier) => {
    assert.equal(specifier, "./week_plan.mjs");
    return library;
  });
  await app.evaluate();
  await new Promise(setImmediate);
  assert.deepEqual(requests.map((entry) => entry.url), ["/api/health", "/api/personas"]);
  return {
    nodes, requests, prints, pending, review: app.namespace.review,
    async changeDate(value) {
      nodes.get("#weekDate").value = value;
      await nodes.get("#weekDate").emit("input");
    },
    async schedule(key, day) {
      const target = { dataset: { pickKey: key }, value: day ?? "", closest() { return this; } };
      await nodes.get("#weekOrganizer").emit("change", { target });
    },
    async reset() { await nodes.get("#resetWeek").emit("click"); },
    async print() { await nodes.get("#printWeek").emit("click"); },
  };
}

test("159 independent Python date vectors agree with calendar weeks, including century exceptions and bounds", () => {
  assert.equal(calendarOracle.length, 159);
  for (const item of calendarOracle) {
    if (item.throws) assert.throws(() => week.calendarWeek(item.anchor), RangeError, item.anchor);
    else assert.deepEqual(week.calendarWeek(item.anchor).map((row) => row.date), item.dates, item.anchor);
  }
});

test("all native persona plans conserve source identities and evidence through 900 deterministic operations", () => {
  let seed = 7312026;
  const random = (n) => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) % n);
  for (const [pid, response] of Object.entries(responses)) {
    const incoming = structuredClone(response), before = JSON.stringify(incoming);
    let state = week.createWeekPlan(incoming, "2026-10-08");
    const first = state, checked = sourcePicks(response);
    const assignments = Object.fromEntries(checked.map((pick, index) => [`pick-${index}`, pick.day]));
    for (let i = 0; i < 300; i++) {
      const operation = random(10);
      if (operation < 8) {
        const index = random(checked.length), day = operation === 7 ? null : week.DAYS[operation];
        state = week.setPickDay(state, `pick-${index}`, day);
        assignments[`pick-${index}`] = day;
      } else if (operation === 8) {
        state = week.setWeek(state, i % 2 ? "2024-02-29" : "2027-01-01");
      } else {
        const selectedWeek = state.weekStart;
        state = week.resetDays(state);
        for (let j = 0; j < checked.length; j++) assignments[`pick-${j}`] = checked[j].day;
        assert.equal(state.weekStart, selectedWeek);
      }
      assert.deepEqual(state.assignments, assignments, `${pid}: step ${i}`);
      const scheduled = week.weekRows(state).flatMap((row) => row.picks);
      const omitted = week.offWeekPicks(state);
      const all = [...scheduled, ...omitted].sort((a, b) => a.key.localeCompare(b.key));
      assert.equal(all.length, checked.length);
      assert.equal(new Set(all.map((pick) => pick.key)).size, checked.length);
      assert.deepEqual(all.map((entry) => entry.pick), checked);
      assert.equal(state.sourcePlan, first.sourcePlan);
      assert.equal(JSON.stringify(incoming), before);
      assert.deepEqual(state.sourcePlan, response.plan);
      assert.deepEqual(state.constraints, response.comparison.constraints);
      for (const entry of all) assert.ok(Object.isFrozen(entry.pick));
    }
    const exposedRows = week.weekRows(state);
    exposedRows[0].picks.length = 0;
    assert.deepEqual(state.sourcePlan, response.plan);
  }
});

test("actual page handlers move, omit, restore and reset without rewriting original suggestions or issuing a request", async () => {
  const h = await appHarness(), received = structuredClone(responses.rosa);
  h.review.render(received);
  await h.changeDate("2027-01-01");
  const original = h.review.state.sourcePlan;
  const panelIDs = ["#plan", "#notes", "#compare", "#rejected", "#trace"];
  const panels = panelIDs.map((id) => h.nodes.get(id).innerHTML);
  const incoming = JSON.stringify(received);
  await h.schedule("pick-0", "Wednesday");
  await h.schedule("pick-1", null);
  assert.equal(h.review.state.assignments["pick-0"], "Wednesday");
  assert.equal(h.review.state.assignments["pick-1"], null);
  assert.equal(h.nodes.get("#omittedSection").hidden, false);
  await h.print();
  assert.equal(h.prints.length, 1);
  const printed = h.prints[0];
  assert.match(printed["#weekDays"].markup, /datetime="2026-12-28"/);
  assert.match(printed["#weekDays"].markup, /datetime="2027-01-03"/);
  assert.match(printed["#weekSource"].text, /^Demo plan: fictional venues/);
  assert.match(printed["#weekConstraints"].text, /soft foods, low sodium, wheelchair access/);
  for (const pick of sourcePicks(received)) {
    const allMarkup = printed["#weekDays"].markup + printed["#omittedPicks"].markup;
    assert.ok(allMarkup.includes(`Qloo id: ${escapeHTML(pick.entity_id)}`));
    assert.ok(allMarkup.includes(escapeHTML(pick.why)));
    if (typeof pick.affinity === "number") assert.ok(allMarkup.includes(`affinity ${pick.affinity.toFixed(2)}`));
  }
  await h.schedule("pick-1", "Sunday");
  assert.equal(h.nodes.get("#omittedSection").hidden, true);
  await h.reset();
  assert.equal(h.review.state.weekStart, "2026-12-28");
  assert.deepEqual(normalize(h.review.state.assignments), Object.fromEntries(sourcePicks(received).map((pick, index) => [`pick-${index}`, pick.day])));
  assert.equal(h.review.state.sourcePlan, original);
  assert.equal(JSON.stringify(received), incoming);
  assert.deepEqual(panelIDs.map((id) => h.nodes.get(id).innerHTML), panels);
  assert.equal(h.requests.length, 2, "no request after initialization");
});

test("invalid actual date input blocks the print handler while retaining assignments and recovers on valid input", async () => {
  const h = await appHarness();
  h.review.render(structuredClone(responses.mei));
  await h.changeDate("2024-02-29");
  await h.schedule("pick-0", null);
  const before = JSON.stringify(h.review.state);
  for (const date of ["", "2026-02-29", "9999-12-31"]) {
    await h.changeDate(date);
    assert.equal(JSON.stringify(h.review.state), before);
    assert.equal(h.nodes.get("#printWeek").disabled, true);
    assert.equal(h.nodes.get("#weekDate").attributes.get("aria-invalid"), "true");
    await h.print();
    assert.equal(h.prints.length, 0);
  }
  await h.changeDate("0001-01-01");
  assert.equal(h.review.state.weekStart, "0001-01-01");
  assert.equal(h.review.state.assignments["pick-0"], null);
  assert.equal(h.nodes.get("#printWeek").disabled, false);
  assert.equal(h.nodes.get("#weekDate").attributes.has("aria-invalid"), false);
  await h.print();
  assert.equal(h.prints.length, 1);
  assert.equal(h.requests.length, 2);
});

test("printed source label follows each received response, including absent and nonboolean mode, despite live health", async () => {
  const h = await appHarness();
  for (const [mode, prefix] of [[true, "Demo plan:"], [false, "Plan returned by Qloo."], [undefined, "The response did not specify"], ["false", "The response did not specify"]]) {
    const received = structuredClone(responses.harold);
    if (mode === undefined) delete received.mock; else received.mock = mode;
    h.review.render(received);
    await h.print();
    assert.ok(h.prints.at(-1)["#weekSource"].text.startsWith(prefix));
  }
  assert.match(h.nodes.get("#mode").textContent, /^Live mode/);
  assert.equal(h.requests.length, 2);
});

test("a new actual form request sends tastes and constraints, keeps the chosen week, and resets assignments", async () => {
  const h = await appHarness();
  h.review.render(structuredClone(responses.rosa));
  await h.changeDate("2026-12-31");
  await h.schedule("pick-0", null);
  h.pending.set("/api/plan", structuredClone(responses.mei));
  await h.nodes.get("#form").emit("submit");
  assert.equal(h.requests.length, 3);
  const payload = JSON.parse(h.requests.at(-1).options.body);
  assert.deepEqual(Object.keys(payload).sort(), ["city", "constraints", "cuisines", "films", "music"]);
  assert.equal(h.review.state.weekStart, "2026-12-28");
  assert.deepEqual(normalize(h.review.state.sourcePlan), responses.mei.plan);
  assert.equal(h.review.state.assignments["pick-0"], responses.mei.plan.meals[0].day);
  assert.equal(h.nodes.get("#results").attributes.has("aria-busy"), false);
});

test("out-of-order request completion cannot replace the newest plan or its user edits", async () => {
  const h = await appHarness();
  let resolveFirst, resolveSecond;
  h.pending.set("/api/plan/first", new Promise((resolve) => { resolveFirst = resolve; }));
  h.pending.set("/api/plan/second", new Promise((resolve) => { resolveSecond = resolve; }));
  const first = h.review.requestPlan("/api/plan/first", { cuisines: ["Cuban"] });
  const second = h.review.requestPlan("/api/plan/second", { cuisines: ["Japanese"] });
  resolveSecond(structuredClone(responses.mei));
  await second;
  await h.changeDate("2027-01-01");
  await h.schedule("pick-0", "Sunday");
  const current = JSON.stringify(h.review.state);
  resolveFirst(structuredClone(responses.rosa));
  await first;
  assert.equal(JSON.stringify(h.review.state), current);
  assert.equal(h.requests.length, 4);
  assert.equal(h.nodes.get("#results").attributes.has("aria-busy"), false);
});

test("print markup preserves escaped source details and explicit empty days without manufacturing a pick", async () => {
  const h = await appHarness(), received = structuredClone(responses.rosa);
  received.plan.meals = [received.plan.meals[0]];
  received.plan.outing = null;
  received.plan.meals[0].name = '<script>review marker</script> & "name"';
  received.plan.meals[0].why = 'Original <check> & "explanation"';
  received.plan.notes = ['Original note <sentinel>'];
  h.review.render(received);
  await h.schedule("pick-0", null);
  await h.print();
  const printed = h.prints[0];
  assert.equal((printed["#weekDays"].markup.match(/class="open-day"/g) || []).length, 7);
  assert.equal((printed["#weekDays"].markup.match(/class="scheduled-pick"/g) || []).length, 0);
  assert.equal((printed["#omittedPicks"].markup.match(/class="scheduled-pick"/g) || []).length, 1);
  assert.ok(printed["#omittedPicks"].markup.includes(escapeHTML(received.plan.meals[0].name)));
  assert.ok(printed["#omittedPicks"].markup.includes(escapeHTML(received.plan.meals[0].why)));
  assert.ok(!printed["#omittedPicks"].markup.includes("<script>"));
  assert.ok(printed["#weekNotes"].markup.includes("Original recommendation note: Original note &lt;sentinel&gt;"));
  assert.equal(printed["#omittedSection"].hidden, false);
  assert.match(printed["#weekSummary"].text, /^0 of 1 suggested picks scheduled\. 7 open days\.$/);
});

test("print stylesheet retains response provenance and care caveats while hiding editing controls and original comparison", () => {
  const printRules = css.slice(css.indexOf("@media print"));
  assert.match(printRules, /header #mode, \.taste-form, \.original-evidence, \.week-controls, \.pick-control, \.organizer-help \{ display:none !important; \}/);
  assert.match(printRules, /#weekSource \{ color:#111; font-weight:600; \}/);
  assert.match(printRules, /\.disclaimer \{ font-size:9pt; \}/);
  assert.match(html, /Not medical or dietary advice/);
  assert.match(html, /Dates are your choices, not reservations or confirmed opening hours/);
  assert.match(html, /Qloo results describe aggregate affinities, not facts about any individual/);
});
