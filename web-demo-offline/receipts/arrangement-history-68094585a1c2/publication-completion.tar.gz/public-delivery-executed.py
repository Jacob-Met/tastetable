import datetime,hashlib,json,pathlib,subprocess,tarfile,zipfile
root=pathlib.Path('/Users/me/hamon-tastetable-history-68094585a1c2')
out=root/'publication-v1'/'public-merge-v1';out.mkdir(exist_ok=False)
manifest=json.loads((root/'contribution-manifest.json').read_text())
merge="34afd379c1a7032b3025079b5fe6ccc9cd47c637"
wanted=[x for x in manifest['files'] if x['path'].endswith('tastetable-offline-studio.zip') or x['path'].endswith('native-evidence.tar.gz')]
records=[]
for entry in wanted:
    target=out/pathlib.PurePosixPath(entry['path']).name
    url='https://raw.githubusercontent.com/Jacob-Met/tastetable/'+merge+'/'+entry['path']
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    command=['/usr/bin/curl','--fail','--silent','--show-error','--location','--max-time','20','--output',str(target),'--write-out','%{http_code}\n%{url_effective}\n%{size_download}\n',url]
    result=subprocess.run(command,capture_output=True,text=True,timeout=25)
    finished=datetime.datetime.now(datetime.timezone.utc).isoformat()
    raw=result.stdout.splitlines()
    record={'path':entry['path'],'requested_url':url,'started_at':started,'finished_at':finished,'curl_exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    (out/(target.name+'.response.json')).write_text(json.dumps(record,indent=2)+'\n')
    assert result.returncode==0 and len(raw)==3 and raw[0]=='200', record
    data=target.read_bytes()
    actual={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}
    assert all(actual[k]==entry[k] for k in actual), actual
    assert data==(root/'contribution'/entry['path']).read_bytes()
    record.update(actual);record.update({'http_status':int(raw[0]),'effective_url':raw[1],'curl_size_download':int(raw[2]),'exact_sealed_bytes':True})
    members=[]
    if target.suffix=='.zip':
        with zipfile.ZipFile(target) as downloaded,zipfile.ZipFile(root/'contribution'/entry['path']) as accepted:
            assert downloaded.namelist()==accepted.namelist() and len(downloaded.namelist())==39
            for item in downloaded.infolist():
                b=downloaded.read(item.filename);assert b==accepted.read(item.filename)
                members.append({'path':item.filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    else:
        with tarfile.open(target,'r:gz') as downloaded,tarfile.open(root/'contribution'/entry['path'],'r:gz') as accepted:
            items=downloaded.getmembers();other=accepted.getmembers()
            assert [x.name for x in items]==[x.name for x in other] and len(items)==49
            for item in items:
                assert item.isfile()
                b=downloaded.extractfile(item).read();assert b==accepted.extractfile(item.name).read()
                members.append({'path':item.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    record['members']=members;records.append(record)
receipt={'format':'tastetable-public-portable-delivery/1','merge':merge,'files':records,'browser_rerun':False,'delivery':'Public immutable-commit portable ZIP and evidence capsule; this is not a hosted app deployment claim.','qualified_portable_runtime_files':39,'all_downloaded_archive_members_match_accepted_bytes':True}
raw=(json.dumps(receipt,indent=2)+'\n').encode();(out/'receipt.json').write_bytes(raw)
print(json.dumps({'receipt':str(out/'receipt.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'deliveries':[{'path':x['path'],'http':x['http_status'],'bytes':x['bytes'],'sha256':x['sha256'],'members':len(x['members'])} for x in records]}))