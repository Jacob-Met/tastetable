## Why

A caregiver could move or omit meals, then accidentally restore the suggested days and lose the unsaved arrangement. The offline week organizer now offers native **Undo change** and **Redo change** buttons for the current accepted recording or saved-week session.

## What changes

- Retain the latest 20 distinct week, weekday, omission and Restore suggested days changes. A reset is one atomic change; repeated assignments, unchanged resets and dates in the same displayed week preserve redo.
- Recover the complete arrangement and its valid displayed date. A new edit after Undo clears redo. Invalid date input keeps the existing Save/Print refusal until corrected or explicitly recovered.
- Keep preview, cancel and refused saved-file reads separate from replacement. Undo/Redo retire outstanding reads and previews; explicitly replacing the displayed week starts fresh history, even for the same file. Profile/constraint changes, recording/default selection and reload also start a fresh session.
- Preserve the existing Save/Open codecs, admitted source identity, received timestamp, calendar identity, original-source downloads and 24 recorded catalogue files. History remains local to the displayed session.
- Refresh the portable ZIP from the qualified 39-file runtime so it includes the existing Save/Open modules and the new history module. Scope remains within web-demo-offline.

## Validation

The original source and native/browser qualification are pinned to 1a609bfdd77dc07222eb70f8a4a1f565a8bc8fa0. Receiving main 689ddc9a6a4f5f12068e1e99127cc77482c53924 adds 24 paths/changes outside the offline studio; all exercised inputs and product before-images are unchanged. The complete composition preserves all 318 unowned parent leaves.

- Native Node tests: 36 passed, including 8 new history cases and 28 unchanged cases.
- The unchanged original browser witness: 3 groups passed, after its original missing-Undo failure was preserved.
- Focused real Chrome receiving: 7 groups covering recovery, no-op redo, branching, invalid dates, save/source custody, saved-file preview/replacement, asynchronous read retirement, keyboard and 390px layout.
- Portable delivery receiver: 39 files, 78 exact HTTP readbacks, and the expected 404 after rollback. The accepted ZIP is byte-exact to the browser-qualified runtime.
- Independent receiving: a blind timeline/cursor oracle passed 6 scenarios and 128 transitions. Four additional real-browser File-read refusal/race checkpoints passed, with two downloaded files retaining the original source and save metadata.

The checked-in receipt, source manifest and native evidence capsule are under web-demo-offline/receipts/arrangement-history-68094585a1c2/. They preserve the original failing witness, exact source pins, actual child exit codes, captures, downloads, independent blind expectations and readback checks. Hosted CI is a separate publication gate and is not claimed by the native evidence.

## Review roles

Author and native/browser qualification: estate-68094585a1c2 / receiving_review. Independent blind oracle and asynchronous refusal receiving: estate-68094585a1c2 / memory_delivery. Root source/visual review and integration authorization are recorded separately before source publication.

Closes #32.
