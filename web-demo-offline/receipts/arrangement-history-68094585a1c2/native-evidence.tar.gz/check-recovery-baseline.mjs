import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
import {createHash} from 'node:crypto';
import {chromium} from '/Users/me/longwater-author-tests-566d51f04b31/node_modules/playwright/index.mjs';

const [rootArg,outArg]=process.argv.slice(2);
assert(rootArg&&outArg,'Pass source root and a fresh evidence directory.');
const root=resolve(rootArg),out=resolve(outArg);
await mkdir(out,{recursive:false});
const sha=b=>createHash('sha256').update(b).digest('hex');
const manifest=JSON.parse(await readFile(resolve(root,'../baseline-inputs.json'),'utf8'));
const before={};
for(const file of manifest.files)before[file.path]=sha(await readFile(resolve(root,file.path)));
const source=resolve(root,'web-demo-offline');
const report={format:'tastetable-arrangement-recovery-browser/1',startedAt:new Date().toISOString(),root,checks:[],sourceBefore:before,requests:[],pageErrors:[],snapshots:{},downloads:[]};
let browser,server;
const pass=name=>{report.checks.push(name);console.log('PASS '+name);};
const snapshot=page=>page.evaluate(()=>({
 recordKey:document.querySelector('#results').dataset.recordKey,
 selectedDate:document.querySelector('#weekDate').value,
 days:[...document.querySelectorAll('#weekDays > li')].map(li=>({day:li.dataset.day,date:li.querySelector('time').dateTime,picks:[...li.querySelectorAll('select[data-pick-key]')].map(s=>({key:s.dataset.pickKey,day:s.value,name:s.closest('article').querySelector('h4').textContent}))})),
 omitted:[...document.querySelectorAll('#omittedPicks select[data-pick-key]')].map(s=>({key:s.dataset.pickKey,day:s.value,name:s.closest('article').querySelector('h4').textContent})),
 sourceHref:document.querySelector('#downloadRecord').getAttribute('href'),
 sourceText:document.querySelector('#weekSource').textContent,
 constraints:document.querySelector('#weekConstraints').textContent,
 notes:document.querySelector('#weekNotes').textContent
}));
try {
 server=createServer(async(req,res)=>{
  try{
   const path=resolve(source,'.'+new URL(req.url,'http://localhost').pathname+(new URL(req.url,'http://localhost').pathname==='/'?'index.html':''));
   if(!path.startsWith(source+sep)){res.writeHead(403).end();return;}
   const b=await readFile(path);
   res.writeHead(200,{'Content-Type':{'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'}[extname(path)]||'application/octet-stream'});res.end(b);
  }catch{res.writeHead(404).end();}
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const origin='http://127.0.0.1:'+server.address().port;report.origin=origin;
 browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disk-cache-size=1048576']});
 report.browserVersion=browser.version();
 const context=await browser.newContext({viewport:{width:1280,height:1000},locale:'en-US',timezoneId:'UTC',acceptDownloads:true,reducedMotion:'reduce'});
 const page=await context.newPage();
 page.on('pageerror',e=>report.pageErrors.push(String(e)));
 page.on('request',r=>report.requests.push(r.url()));
 await page.goto(origin+'/',{waitUntil:'domcontentloaded',timeout:15000});
 await page.locator('#results').waitFor({state:'visible',timeout:15000});
 await page.locator('#weekDate').fill('2026-10-21');
 await page.locator('#weekDate').blur();
 report.snapshots.initial=await snapshot(page);
 const first=page.locator('select[data-pick-key="pick-0"]');
 const second=page.locator('select[data-pick-key="pick-1"]');
 await first.selectOption('Sunday');
 await second.selectOption('');
 report.snapshots.arranged=await snapshot(page);
 assert.equal(report.snapshots.arranged.days.find(d=>d.day==='Sunday').picks.some(p=>p.key==='pick-0'),true);
 assert.equal(report.snapshots.arranged.omitted.some(p=>p.key==='pick-1'),true);
 const downloadPromise=page.waitForEvent('download');
 await page.locator('#saveWeek').click();
 const downloaded=await downloadPromise;
 const savedPath=resolve(out,'arranged-week.json');
 await downloaded.saveAs(savedPath);
 const saved=await readFile(savedPath);
 report.downloads.push({path:'arranged-week.json',bytes:saved.length,sha256:sha(saved)});
 assert.deepEqual(await snapshot(page),report.snapshots.arranged);
 pass('Actual move and omission produce a valid saved week without changing the displayed arrangement.');
 await page.locator('#resetWeek').click();
 report.snapshots.reset=await snapshot(page);
 assert.notDeepEqual(report.snapshots.reset,report.snapshots.arranged);
 assert.equal(report.snapshots.reset.omitted.length,0);
 assert.equal(report.snapshots.reset.sourceHref,report.snapshots.arranged.sourceHref);
 pass('Restore suggested days replaces the custom arrangement while preserving its recorded source.');
 report.undoControls=await page.getByRole('button',{name:/^Undo change/}).count();
 await page.locator('#weekOrganizer').scrollIntoViewIfNeeded();
 await page.screenshot({path:resolve(out,'after-reset.png')});
 assert.equal(report.undoControls,1,'A caregiver needs an Undo change control to recover the prior unsaved arrangement after reset.');
 await page.getByRole('button',{name:/^Undo change/}).focus();
 await page.keyboard.press('Enter');
 report.snapshots.recovered=await snapshot(page);
 assert.deepEqual(report.snapshots.recovered,report.snapshots.arranged);
 pass('Keyboard Undo restores the exact prior week, occurrences, omissions, source and displayed date.');
 assert.deepEqual(report.pageErrors,[]);
 assert(report.requests.every(url=>url.startsWith(origin+'/')||url.startsWith('blob:')));
 report.status='passed';
} catch(error){
 report.status='failed';report.error=error.stack;console.error(error.stack);process.exitCode=1;
} finally {
 if(browser)await browser.close();
 if(server)await new Promise(r=>server.close(r));
 report.sourceAfter={};
 for(const file of manifest.files)report.sourceAfter[file.path]=sha(await readFile(resolve(root,file.path)));
 report.sourceStable=JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter);
 if(!report.sourceStable){report.status='failed';process.exitCode=1;}
 report.finishedAt=new Date().toISOString();
 await writeFile(resolve(out,'receipt.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({status:report.status,checks:report.checks.length,sourceStable:report.sourceStable,undoControls:report.undoControls,receipt:resolve(out,'receipt.json')}));
}
