import pathlib,json,hashlib,subprocess,datetime,os
root=pathlib.Path("/Users/me/hamon-tastetable-history-68094585a1c2")
source=root/"candidate-v1"/"web-demo-offline"
out=root/"qualification-browser-v1"
out.mkdir()
def pins():
 result={}
 for p in sorted(source.rglob("*")):
  if p.is_file():
   data=p.read_bytes()
   result[p.relative_to(source).as_posix()]={"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(("blob "+str(len(data))+"\0").encode()+data).hexdigest()}
 return result
env=os.environ.copy()
env["TASTETABLE_PLAYWRIGHT_MODULE"]="/Users/me/longwater-author-tests-566d51f04b31/node_modules/playwright/index.mjs"
env["TASTETABLE_BROWSER_EXECUTABLE"]="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
report={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_before":pins(),"commands":[]}
commands=[
 ("portable-receiver",["/usr/local/bin/python3",str(source/"tools/receive_static.py"),str(source),str(root/"portable-v1"),str(root/"portable-receiving-v1")],30),
 ("browser-history",["/opt/homebrew/bin/node",str(source/"tools/check_arrangement_history_browser.mjs"),str(root/"portable-v1"),str(root/"browser-history-v1")],120)
]
for name,argv,timeout in commands:
 start=datetime.datetime.now(datetime.timezone.utc)
 try:
  with (out/(name+".log")).open("wb") as log:
   result=subprocess.run(argv,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
  code=result.returncode
 except subprocess.TimeoutExpired:code="timeout"
 report["commands"].append({"name":name,"argv":argv,"exit_code":code,"started_at":start.isoformat(),"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"log":str(out/(name+".log"))})
 print(json.dumps(report["commands"][-1]),flush=True)
 if code!=0:break
report["source_after"]=pins()
report["source_stable"]=report["source_before"]==report["source_after"]
report["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/"receipt.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"receipt":str(out/"receipt.json"),"source_files":len(report["source_before"]),"source_stable":report["source_stable"],"commands":len(report["commands"])}),flush=True)
