import pathlib,json,hashlib,subprocess,datetime
root=pathlib.Path("/Users/me/hamon-tastetable-history-68094585a1c2")
candidate=root/"candidate-v1"
out=root/"qualification-native-v1"
out.mkdir()
def pins():
 result={}
 for p in sorted(candidate.rglob("*")):
  if p.is_file():
   data=p.read_bytes()
   result[p.relative_to(candidate).as_posix()]={"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"git_blob":hashlib.sha1(("blob "+str(len(data))+"\0").encode()+data).hexdigest()}
 return result
report={"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_before":pins(),"commands":[]}
commands=[
 ("native-tests",["/opt/homebrew/bin/node","--test","web-demo-offline/tests/catalogue.test.mjs","web-demo-offline/tests/saved_week.test.mjs","web-demo-offline/tests/arrangement_history.test.mjs"]),
 ("original-browser-replay",["/opt/homebrew/bin/node",str(root/"check-recovery-baseline.mjs"),str(candidate),str(root/"evidence-original-replay-v1")])
]
for name,argv in commands:
 start=datetime.datetime.now(datetime.timezone.utc)
 try:
  with (out/(name+".log")).open("wb") as log:
   result=subprocess.run(argv,cwd=candidate,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  code=result.returncode
 except subprocess.TimeoutExpired:
  code="timeout"
 report["commands"].append({"name":name,"argv":argv,"exit_code":code,"started_at":start.isoformat(),"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"log":str(out/(name+".log"))})
 print(json.dumps(report["commands"][-1]),flush=True)
 if code!=0: break
report["source_after"]=pins()
report["source_stable"]=report["source_before"]==report["source_after"]
report["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/"receipt.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"receipt":str(out/"receipt.json"),"source_files":len(report["source_before"]),"source_stable":report["source_stable"],"commands":len(report["commands"])}),flush=True)
