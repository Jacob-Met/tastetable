import { createServer } from "node:http";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve, relative, extname, join } from "node:path";
import { createHash } from "node:crypto";
import { chromium } from "/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs";

const root = resolve("/Users/me/tastetable-calendar-066deeadcc8b");
const source = join(root, "current-source");
const output = join(root, "current-evidence/browser-v1");
await mkdir(output);
const qualification = JSON.parse(await readFile(join(root, "current-evidence/unit.json"), "utf8"));
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const before = {};
for (const name of Object.keys(qualification.before)) before[name] = sha(await readFile(join(source, name)));
const report = { canonicalParent: "e0f6fbaf1f81fbb1e9926948294549c744228def", browser: null, requests: [], errors: [], checks: [], downloads: [], sourceBefore: before };
let group = "setup";
function check(name, condition, actual) {
  const row = { group, name, pass: Boolean(condition), actual };
  report.checks.push(row);
  if (!row.pass) console.log(JSON.stringify({ failed: row }));
}
function equal(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function eventList(text) {
  const lines = text.replace(/\r\n[ \t]/g, "").split("\r\n");
  const result = []; let event = null;
  for (const line of lines) {
    if (line === "BEGIN:VEVENT") event = {};
    else if (line === "END:VEVENT") { result.push(event); event = null; }
    else if (event) { const i = line.indexOf(":"); event[line.slice(0, i)] = line.slice(i + 1); }
  }
  return result;
}
function textValue(value) { return value.replace(/\\([\\,;n])/g, (_, c) => c === "n" ? "\n" : c); }
function inspectCalendar(text, saved, name) {
  const actual = eventList(text);
  const original = [...saved.response.plan.meals, ...(saved.response.plan.outing ? [saved.response.plan.outing] : [])];
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const expected = original.map((pick, i) => ({ pick, key: "pick-" + i, day: saved.week.assignments["pick-" + i] }))
    .filter(row => row.day !== null).sort((a, b) => days.indexOf(a.day) - days.indexOf(b.day) || original.indexOf(a.pick) - original.indexOf(b.pick));
  check(name + ": occurrence count and identity", actual.length === expected.length && new Set(actual.map(item => item.UID)).size === expected.length,
    { actual: actual.length, expected: expected.length });
  actual.forEach((event, i) => {
    const item = expected[i]; if (!item) return;
    const date = new Date(saved.week.start + "T00:00:00Z"); date.setUTCDate(date.getUTCDate() + days.indexOf(item.day));
    const start = date.toISOString().slice(0, 10).replaceAll("-", ""); date.setUTCDate(date.getUTCDate() + 1);
    const end = date.toISOString().slice(0, 10).replaceAll("-", "");
    check(name + ": exact event " + item.key, event["DTSTART;VALUE=DATE"] === start && event["DTEND;VALUE=DATE"] === end
      && event.UID === saved.calendarId + "-" + saved.week.start.replaceAll("-", "") + "-" + item.key + "@tastetable.invalid"
      && event.DTSTAMP === saved.receivedAt.replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z")
      && event.STATUS === "TENTATIVE" && event.TRANSP === "TRANSPARENT" && event.CLASS === "PRIVATE"
      && textValue(event.SUMMARY) === "[DEMO] TasteTable suggestion: " + item.pick.name
      && textValue(event.DESCRIPTION).includes(item.pick.entity_id)
      && textValue(event.DESCRIPTION).includes(item.pick.why)
      && textValue(event.DESCRIPTION).includes("these venues are fictional"),
    { event, sourceOccurrence: item.key });
  });
  check(name + ": CRLF and UTF-8 folding", text.endsWith("\r\n")
    && !text.replaceAll("\r\n", "").includes("\n") && text.split("\r\n").every(line => Buffer.byteLength(line) <= 75), true);
  return actual;
}
const server = createServer(async (req, res) => {
  try {
    const part = decodeURIComponent(new URL(req.url, "http://local.invalid").pathname);
    const path = resolve(source, "web-demo-offline", "." + (part === "/" ? "/index.html" : part));
    const name = relative(source, path).split("\\").join("/");
    if (!Object.hasOwn(qualification.before, name)) { res.writeHead(404).end(); return; }
    const mime = { ".html": "text/html;charset=utf-8", ".mjs": "text/javascript;charset=utf-8", ".js": "text/javascript;charset=utf-8", ".css": "text/css;charset=utf-8", ".json": "application/json;charset=utf-8" };
    res.writeHead(200, { "Content-Type": mime[extname(path)] || "text/plain;charset=utf-8", "Cache-Control": "no-store" });
    res.end(await readFile(path));
  } catch { res.writeHead(500).end(); }
});
await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
const origin = "http://127.0.0.1:" + server.address().port;
let browser; let actualDownloadCount = 0;
async function openPage(width = 1100) {
  const context = await browser.newContext({ viewport: { width, height: 900 }, acceptDownloads: true });
  const page = await context.newPage();
  page.on("download", () => actualDownloadCount++);
  page.on("pageerror", problem => report.errors.push(String(problem)));
  page.on("request", request => report.requests.push({ method: request.method(), url: request.url() }));
  await page.route("**/*", route => route.request().url().startsWith(origin + "/") ? route.continue() : route.abort());
  await page.goto(origin + "/");
  await page.locator("#results").waitFor({ state: "visible" });
  return { context, page };
}
async function download(page, selector, name, keyboard = false) {
  const waiting = page.waitForEvent("download");
  if (keyboard) await page.keyboard.press("Enter"); else await page.locator(selector).click();
  const file = await waiting; const path = join(output, name);
  await file.saveAs(path);
  const bytes = await readFile(path);
  report.downloads.push({ group, path: name, suggestedFilename: file.suggestedFilename(), bytes: bytes.length, sha256: sha(bytes) });
  return { path, text: bytes.toString("utf8"), bytes };
}
async function save(page, name) { return JSON.parse((await download(page, "#saveWeek", name)).text); }
async function noDownload(page, name, action) {
  const before = actualDownloadCount;
  await action(); await page.waitForTimeout(80);
  check(name, actualDownloadCount === before, { before, after: actualDownloadCount });
}
try {
  browser = await chromium.launch({ executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", headless: true });
  report.browser = browser.version();
  let { context, page } = await openPage();
  group = "initial-preview";
  check("calendar action is reachable", await page.getByRole("button", { name: "Download calendar (.ics)", exact: true }).count() === 1, 1);
  check("five current suggestions are previewed", await page.locator("#offlineCalendarPreview li").count() === 5, await page.locator("#offlineCalendarPreview li").count());
  const beforeExport = await save(page, "01-before-calendar.json");
  check("preview alone leaves calendar identity absent", beforeExport.calendarId === null, beforeExport.calendarId);

  group = "arrangement-and-first-export";
  await page.locator("#weekDate").fill("2026-10-07");
  await page.locator('[data-pick-key="pick-0"]').selectOption("Sunday");
  await page.locator('[data-pick-key="pick-1"]').selectOption("Sunday");
  await page.locator('[data-pick-key="pick-2"]').selectOption("");
  const preview = await page.locator("#offlineCalendarPreview li").evaluateAll(rows => rows.map(row => ({
    date: row.querySelector("time").dateTime, when: row.querySelector("time").textContent, venue: row.querySelector("span").textContent
  })));
  check("preview retains both Sunday occurrences and omits one visit", preview.length === 4 && preview.filter(row => row.date === "2026-10-11").length >= 2, preview);
  const first = await download(page, "#offlineCalendarDownload", "02-first-calendar.ics");
  const savedFirst = await save(page, "03-after-calendar.json");
  check("calendar preparation retains a valid ID in the existing saved format", /^[0-9a-f]{32}$/.test(savedFirst.calendarId), savedFirst.calendarId);
  const firstEvents = inspectCalendar(first.text, savedFirst, "first");
  check("saved original record is unchanged", equal(savedFirst.response, beforeExport.response) && equal(savedFirst.inputs, beforeExport.inputs), true);

  group = "repeat-and-source-download";
  const repeated = await download(page, "#offlineCalendarDownload", "04-repeated-calendar.ics");
  check("same arranged-week exports are byte-identical", repeated.bytes.equals(first.bytes), sha(repeated.bytes));
  const sourceDownload = await download(page, "#downloadRecord", "05-original-source.json");
  const originalSource = await readFile(join(source, "web-demo-offline/data/records/rosa-7.json"));
  check("source record remains byte-exact after arranging and calendar export", sourceDownload.bytes.equals(originalSource), sha(sourceDownload.bytes));
  await context.close();

  group = "fresh-open-and-calendar-continuity";
  ({ context, page } = await openPage());
  await page.locator("#weekFile").setInputFiles(join(output, "03-after-calendar.json"));
  await page.locator("#weekPreview").waitFor({ state: "visible" });
  await page.locator("#replaceWeek").click();
  const reopened = await download(page, "#offlineCalendarDownload", "06-reopened-calendar.ics");
  check("fresh page reopens exact saved calendar bytes", reopened.bytes.equals(first.bytes), sha(reopened.bytes));
  const reopenedSaved = await save(page, "07-reopened-week.json");
  check("fresh page retains original receipt time and ID", reopenedSaved.receivedAt === savedFirst.receivedAt
    && reopenedSaved.calendarId === savedFirst.calendarId, { receivedAt: reopenedSaved.receivedAt, calendarId: reopenedSaved.calendarId });

  group = "move-and-different-week";
  await page.locator('[data-pick-key="pick-0"]').selectOption("Monday");
  const moved = await download(page, "#offlineCalendarDownload", "08-moved-calendar.ics");
  const movedSaved = await save(page, "09-moved-week.json");
  const movedEvents = inspectCalendar(moved.text, movedSaved, "moved");
  check("move retains each occurrence UID", equal(movedEvents.map(event => event.UID).sort(), firstEvents.map(event => event.UID).sort()), movedEvents.map(event => event.UID));
  await page.locator("#weekDate").fill("2026-10-14");
  const otherWeek = await download(page, "#offlineCalendarDownload", "10-next-week-calendar.ics");
  const otherSaved = await save(page, "11-next-week.json");
  const otherEvents = inspectCalendar(otherWeek.text, otherSaved, "next week");
  check("another week has different event UIDs", otherEvents.every(event => !firstEvents.some(old => old.UID === event.UID)), otherEvents.map(event => event.UID));

  group = "invalid-displayed-date";
  await page.locator("#weekDate").fill("");
  check("invalid visible date disables download", await page.locator("#offlineCalendarDownload").isDisabled(), await page.locator("#offlineCalendarError").innerText());
  await noDownload(page, "invalid date cannot export the last valid arrangement", () => page.locator("#offlineCalendarDownload").dispatchEvent("click"));
  await page.locator("#weekDate").fill("2026-10-14");
  await page.evaluate(() => { document.querySelector("#weekDate").value = "2026-11-12"; });
  await noDownload(page, "uncommitted date change refuses stale state", () => page.locator("#offlineCalendarDownload").click());
  check("uncommitted week mismatch is explained", (await page.locator("#offlineCalendarError").innerText()).includes("displayed week date"), await page.locator("#offlineCalendarError").innerText());
  await page.locator("#weekDate").fill("2026-10-14");

  group = "empty-arrangement";
  const keys = await page.locator("#weekOrganizer [data-pick-key]").evaluateAll(items => items.map(item => item.dataset.pickKey));
  for (const key of keys) await page.locator('[data-pick-key="' + key + '"]').selectOption("");
  check("all-omitted arrangement has no preview event", await page.locator("#offlineCalendarPreview li").count() === 0, 0);
  check("all-omitted download is disabled and explained", await page.locator("#offlineCalendarDownload").isDisabled()
    && (await page.locator("#offlineCalendarStatus").innerText()).includes("No visits are scheduled"), await page.locator("#offlineCalendarStatus").innerText());
  await noDownload(page, "empty arrangement makes no file", () => page.locator("#offlineCalendarDownload").dispatchEvent("click"));

  group = "source-retirement";
  await page.locator("#personaSel").selectOption("mei");
  check("changing source retires calendar preview immediately", await page.locator("#results").isHidden()
    && await page.locator("#offlineCalendar").isHidden() && await page.locator("#offlineCalendarDownload").isDisabled(), true);
  await noDownload(page, "retired source cannot export", () => page.locator("#offlineCalendarDownload").dispatchEvent("click"));
  await page.locator("#showPlan").click();
  const newSource = await download(page, "#offlineCalendarDownload", "12-mei-calendar.ics");
  const newSourceSaved = await save(page, "13-mei-week.json");
  inspectCalendar(newSource.text, newSourceSaved, "new source");
  check("new accepted source has a separate calendar ID", newSourceSaved.calendarId !== savedFirst.calendarId, newSourceSaved.calendarId);

  group = "preparation-failure-and-explicit-retry";
  await page.locator("#showPlan").click();
  await page.evaluate(() => {
    const original = URL.createObjectURL;
    URL.createObjectURL = function () { URL.createObjectURL = original; throw new Error("Authored Blob URL refusal"); };
  });
  await noDownload(page, "preparation failure makes no file", () => page.locator("#offlineCalendarDownload").click());
  check("preparation failure is visible", (await page.locator("#offlineCalendarError").innerText()).includes("Authored Blob URL refusal"), await page.locator("#offlineCalendarError").innerText());
  const refusedSaved = await save(page, "14-after-refusal.json");
  check("failed preparation preserves absent ID", refusedSaved.calendarId === null, refusedSaved.calendarId);
  const retry = await download(page, "#offlineCalendarDownload", "15-retry-calendar.ics");
  const retrySaved = await save(page, "16-retry-week.json");
  inspectCalendar(retry.text, retrySaved, "retry");

  group = "source-replaced-during-preparation";
  await page.locator("#showPlan").click();
  await page.evaluate(() => {
    const original = URL.createObjectURL;
    URL.createObjectURL = function (blob) {
      URL.createObjectURL = original;
      const url = original.call(URL, blob);
      const select = document.querySelector("#personaSel");
      select.value = "harold"; select.dispatchEvent(new Event("change", { bubbles: true }));
      return url;
    };
  });
  await noDownload(page, "source replaced during preparation cannot dispatch its old file", () => page.locator("#offlineCalendarDownload").click());
  check("replacement stays retired", await page.locator("#results").isHidden() && await page.locator("#offlineCalendar").isHidden(), true);
  await page.locator("#showPlan").click();
  const replacedSaved = await save(page, "17-after-source-replacement.json");
  check("retired source did not donate its prepared ID", replacedSaved.calendarId === null, replacedSaved.calendarId);
  await context.close();

  group = "fresh-phone-keyboard";
  ({ context, page } = await openPage(375));
  await page.locator("#weekDate").fill("2026-12-31");
  await page.locator("#weekOrganizer [data-pick-key]").last().focus();
  await page.keyboard.press("Tab");
  check("calendar button is reached through ordinary Tab order", await page.evaluate(() => document.activeElement.id) === "offlineCalendarDownload",
    await page.evaluate(() => document.activeElement.id));
  const keyboard = await download(page, null, "18-phone-keyboard-calendar.ics", true);
  const phoneSaved = await save(page, "19-phone-week.json");
  inspectCalendar(keyboard.text, phoneSaved, "phone");
  await page.locator("#offlineCalendar").scrollIntoViewIfNeeded();
  check("fresh phone page has no horizontal overflow", await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth),
    await page.evaluate(() => ({ width: innerWidth, document: document.documentElement.scrollWidth })));
  await page.screenshot({ path: join(output, "phone-calendar.png") });
  await page.emulateMedia({ media: "print" });
  check("print keeps original week and omits duplicate calendar controls", await page.locator("#offlineCalendar").isHidden()
    && await page.locator("#weekDays").isVisible(), true);
  await page.emulateMedia({ media: "screen" });
  await context.close();

  group = "preservation";
  check("only local static GET requests occur", report.requests.every(request => request.method === "GET" && request.url.startsWith(origin + "/")), report.requests);
  check("no application exceptions", report.errors.length === 0, report.errors);
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
  report.sourceAfter = {};
  for (const name of Object.keys(qualification.before)) report.sourceAfter[name] = sha(await readFile(join(source, name)));
  check("all 55 source/runtime/data files remain byte-exact", equal(before, report.sourceAfter)
    && Object.keys(before).every(name => before[name] === qualification.before[name].sha256), Object.keys(before).length);
  report.totals = { groups: new Set(report.checks.map(item => item.group)).size, passed: report.checks.filter(item => item.pass).length,
    failed: report.checks.filter(item => !item.pass).length, actualDownloads: report.downloads.length, observedDownloadEvents: actualDownloadCount };
  await writeFile(join(output, "report.json"), JSON.stringify(report, null, 2) + "\n");
}
console.log(JSON.stringify({ browser: report.browser, totals: report.totals, failed: report.checks.filter(item => !item.pass).map(item => item.name), output }));
if (report.totals.failed) process.exitCode = 1;
