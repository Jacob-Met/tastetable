import { createServer } from "node:http";
import { readFile,writeFile,mkdir } from "node:fs/promises";
import { join,resolve,relative,extname } from "node:path";
import { createHash } from "node:crypto";
import { chromium } from "/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs";
const root="/Users/me/tastetable-calendar-066deeadcc8b",source=join(root,"current-source"),out=join(root,"current-evidence/history-browser-v1");
await mkdir(out);
const manifest=JSON.parse(await readFile(join(root,"current-evidence/unit.json"),"utf8")).before;
const sha=b=>createHash("sha256").update(b).digest("hex");
const report={parent:"e0f6fbaf1f81fbb1e9926948294549c744228def",checks:[],downloads:[],requests:[],errors:[],before:{},after:{}};
const check=(name,pass,actual)=>{report.checks.push({name,pass:Boolean(pass),actual});if(!pass)console.log(JSON.stringify({failed:name,actual}));};
for(const name of Object.keys(manifest)){
 report.before[name]=sha(await readFile(join(source,name)));
 if(report.before[name]!==manifest[name].sha256)throw Error("source changed: "+name);
}
const server=createServer(async(req,res)=>{
 try{
  const pathname=decodeURIComponent(new URL(req.url,"http://local.invalid").pathname);
  const file=resolve(source,"web-demo-offline","."+(pathname==="/" ? "/index.html":pathname));const name=relative(source,file);
  if(!Object.hasOwn(manifest,name)){res.writeHead(404).end();return;}
  const mime={".html":"text/html",".js":"text/javascript",".mjs":"text/javascript",".css":"text/css",".json":"application/json"};
  res.writeHead(200,{"Content-Type":(mime[extname(file)]||"text/plain")+";charset=utf-8","Cache-Control":"no-store"});res.end(await readFile(file));
 }catch{res.writeHead(500).end();}
});
await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
const origin="http://127.0.0.1:"+server.address().port;let browser,context,page;
const uids=b=>b.toString("utf8").replace(/\r\n[ \t]/g,"").split("\r\n").filter(x=>x.startsWith("UID:")).map(x=>x.slice(4)).sort();
async function download(selector,name){
 const waiting=page.waitForEvent("download");await page.locator(selector).click();const d=await waiting;
 await d.saveAs(join(out,name));const b=await readFile(join(out,name));report.downloads.push({path:name,filename:d.suggestedFilename(),bytes:b.length,sha256:sha(b)});return b;
}
async function calendar(name){return download("#offlineCalendarDownload",name);}
async function saved(name){return JSON.parse((await download("#saveWeek",name)).toString("utf8"));}
try{
 browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true});
 report.browser=browser.version();context=await browser.newContext({viewport:{width:375,height:900},acceptDownloads:true});page=await context.newPage();
 page.on("request",r=>report.requests.push({method:r.method(),url:r.url()}));page.on("pageerror",e=>report.errors.push(String(e)));
 await page.route("**/*",route=>route.request().url().startsWith(origin+"/")?route.continue():route.abort());
 await page.goto(origin+"/");await page.locator("#offlineCalendar").waitFor({state:"visible"});
 await page.locator("#weekDate").fill("2026-10-07");
 const initial=await calendar("01-initial.ics");const initialSaved=await saved("02-initial.json");
 check("calendar preparation and Save do not create an undo step",await page.locator("#undoWeek").isDisabled()&&await page.locator("#redoWeek").isDisabled(),true);
 await page.locator('[data-pick-key="pick-0"]').selectOption("Sunday");
 const moved=await calendar("03-moved.ics");const movedSaved=await saved("04-moved.json");
 check("arrangement history records the move while retaining calendar identity",await page.locator("#undoWeek").isEnabled()&&movedSaved.calendarId===initialSaved.calendarId&&movedSaved.week.assignments["pick-0"]==="Sunday",movedSaved.week);
 check("same-week move retains every occurrence UID",JSON.stringify(uids(moved))===JSON.stringify(uids(initial)),uids(moved));
 await page.locator("#undoWeek").click();const undone=await calendar("05-undone.ics");
 check("Undo refreshes calendar preview and exact original calendar bytes",undone.equals(initial)&&await page.locator("#weekDate").inputValue()==="2026-10-07",sha(undone));
 check("export after Undo preserves the available Redo",await page.locator("#redoWeek").isEnabled()&&await page.locator("#undoWeek").isDisabled(),true);
 await page.locator("#redoWeek").click();const redone=await calendar("06-redone.ics");
 check("Redo restores exact moved calendar bytes",redone.equals(moved),sha(redone));
 await page.locator("#weekDate").fill("2026-10-14");
 const next=await calendar("07-next-week.ics");const nextSaved=await saved("08-next-week.json");
 check("a history-recorded week change keeps source identity but changes week-specific UIDs",nextSaved.calendarId===initialSaved.calendarId&&nextSaved.week.start==="2026-10-12"&&!uids(next).some(id=>uids(moved).includes(id)),nextSaved.week);
 await page.locator("#undoWeek").click();const oldWeek=await calendar("09-old-week.ics");
 check("Undo week change restores prior calendar bytes and literal date anchor",oldWeek.equals(moved)&&await page.locator("#weekDate").inputValue()==="2026-10-07",sha(oldWeek));
 await page.locator("#weekDate").fill("");
 check("invalid date draft disables calendar while keeping valid Redo",await page.locator("#offlineCalendarDownload").isDisabled()&&await page.locator("#redoWeek").isEnabled(),await page.locator("#offlineCalendarError").textContent());
 await page.locator("#redoWeek").click();const validRedo=await calendar("10-valid-redone.ics");
 check("Redo recovers invalid date draft and updates calendar in the same render",validRedo.equals(next)&&await page.locator("#weekDate").inputValue()==="2026-10-14"&&await page.locator("#offlineCalendarError").textContent()==="",sha(validRedo));
 await page.locator('[data-pick-key="pick-1"]').selectOption("");
 const omitted=await calendar("11-omitted.ics");const omittedSaved=await saved("12-omitted.json");
 check("omission history exports only included occurrences",omittedSaved.week.assignments["pick-1"]===null&&uids(omitted).length===uids(next).length-1&&!uids(omitted).some(x=>x.endsWith("-pick-1@tastetable.invalid")),uids(omitted));
 await page.locator("#undoWeek").click();const restored=await calendar("13-restored.ics");
 check("Undo omission restores identical complete calendar bytes",restored.equals(next),sha(restored));
 await page.locator("#weekFile").setInputFiles(join(out,"02-initial.json"));await page.locator("#weekPreview").waitFor({state:"visible"});
 await page.locator("#undoWeek").click();const afterPreview=await calendar("14-after-pending-open.ics");
 check("Undo retires a pending saved-week replacement while calendar follows the recovered arrangement",await page.locator("#weekPreview").isHidden()&&await page.locator("#replaceWeek").isDisabled()&&afterPreview.equals(moved),sha(afterPreview));
 await page.locator("#personaSel").selectOption("mei");
 check("source retirement clears history and disables the old calendar action",await page.locator("#undoWeek").isDisabled()&&await page.locator("#redoWeek").isDisabled()&&await page.locator("#offlineCalendar").isHidden()&&await page.locator("#offlineCalendarDownload").isDisabled(),true);
 await page.locator("#showPlan").click();await page.locator("#offlineCalendar").waitFor({state:"visible"});
 await calendar("15-new-source.ics");const fresh=await saved("16-new-source.json");
 check("a newly accepted source starts separate calendar identity and empty history",fresh.calendarId!==initialSaved.calendarId&&await page.locator("#undoWeek").isDisabled()&&await page.locator("#redoWeek").isDisabled(),fresh.calendarId);
 const geometry=await page.evaluate(()=>({width:innerWidth,document:document.documentElement.scrollWidth}));
 check("combined history and calendar controls fit a fresh 375px page",geometry.width===375&&geometry.document<=375,geometry);
 await page.locator("#offlineCalendar").scrollIntoViewIfNeeded();await page.screenshot({path:join(out,"phone-history-calendar.png")});
 check("combined page makes only local static GET requests",report.requests.every(r=>r.method==="GET"&&r.url.startsWith(origin+"/")),report.requests);
 check("no combined-page application exception",report.errors.length===0,report.errors);
}finally{
 if(context)await context.close();if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));
 for(const name of Object.keys(manifest))report.after[name]=sha(await readFile(join(source,name)));
 check("all 55 source files stay byte-exact",JSON.stringify(report.before)===JSON.stringify(report.after),Object.keys(report.after).length);
 report.totals={passed:report.checks.filter(x=>x.pass).length,failed:report.checks.filter(x=>!x.pass).length,actualDownloads:report.downloads.length};
 await writeFile(join(out,"report.json"),JSON.stringify(report,null,2)+"\n");console.log(JSON.stringify(report.totals));if(report.totals.failed)process.exitCode=1;
}
