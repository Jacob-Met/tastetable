from pathlib import Path
import json, hashlib, subprocess, datetime, shutil, os
r=Path("/Users/me/tastetable-calendar-066deeadcc8b"); s=r/"current-source"; e=r/"current-evidence"
def fail(m): raise RuntimeError(m)
def sha(b): return hashlib.sha256(b).hexdigest()
def meta(b): return {"bytes":len(b),"sha256":sha(b),"git_blob":hashlib.sha1(b"blob "+str(len(b)).encode()+bytes([0])+b).hexdigest(),"mode":"100644"}
def write(p,x): p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+"\n")
bundle=json.loads((r/"baseline-source.json").read_text()); inp=json.loads((r/"current-composition-input.json").read_text()); proof=json.loads((e/"source-proof.json").read_text()); old=json.loads((r/"candidate-frozen-manifest.json").read_text())
parent={k:v.encode() for k,v in bundle["files"].items()}; parent.update({k:v.encode() for k,v in inp["current_files"].items()})
zipkey="web-demo-offline/dist/tastetable-offline-studio.zip"; parent[zipkey]=(e/"parent-portable-studio.zip").read_bytes()
leaves={x["path"]:x for x in inp["tree"]["tree"] if x["type"]=="blob"}
for k,v in parent.items():
 if meta(v)["git_blob"]!=leaves[k]["sha"]: fail("canonical parent mismatch "+k)
 if k!=zipkey and meta(v)!=proof["parent_files"][k]: fail("proof parent mismatch "+k)
actual={k:(s/k).read_bytes() for k in proof["source_files"]}; actual[zipkey]=(s/zipkey).read_bytes()
if len(actual)!=56 or len(parent)!=52: fail("source count")
for k,v in proof["source_files"].items():
 if meta(actual[k])!=v: fail("qualification source mismatch "+k)
scope=sorted(list(inp["composed_files"])+[zipkey])
if len(scope)!=10: fail("scope")
for k in proof["original_new_files_unchanged"]:
 if actual[k]!=(r/"frozen-source-v1"/k).read_bytes(): fail("new source drift "+k)
for k in proof["unowned_current_files"]:
 if actual[k]!=parent[k]: fail("unowned drift "+k)
for name in ["browser-v1","history-browser-v1","portable-python-browser"]:
 rep=json.loads((e/name/"report.json").read_text())
 if rep["totals"]["failed"]!=0: fail("failed gate "+name)
if (s/".git").exists(): fail("unexpected existing current Git")
def git(*args,input=None):
 p=subprocess.run(["git","-c","user.name=HAMON product worker","-c","user.email=hamon-066deeadcc8b@localhost",*args],cwd=s,input=input,capture_output=True)
 if p.returncode: fail(p.stderr.decode())
 return p.stdout.decode().strip()
git("init","-b","work/offline-calendar-history-066deeadcc8b")
lines=[]
for k,v in sorted(parent.items()):
 obj=git("hash-object","-w","--stdin",input=v)
 if obj!=meta(v)["git_blob"]: fail("Git parent blob mismatch "+k)
 lines.append("100644 "+obj+"\t"+k+"\n")
git("update-index","--index-info",input="".join(lines).encode())
bt=git("write-tree"); bc=git("commit-tree",bt,"-m","Pinned TasteTable e0f6fbaf offline runtime projection including received arrangement history")
git("update-ref","HEAD",bc)
git("add","--",*scope)
ct=git("write-tree"); cc=git("commit-tree",ct,"-p",bc,"-m","Export the arranged offline week as a calendar file while preserving arrangement history")
git("update-ref","HEAD",cc)
if git("status","--porcelain"): fail("unexpected working tree delta")
changed=git("diff-tree","--no-commit-id","--name-only","-r",cc).splitlines()
if sorted(changed)!=scope: fail("unexpected Git scope "+repr(changed))
frozen=r/"current-frozen-source"; frozen.mkdir()
for k in scope:
 p=frozen/k; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(actual[k])
out={
"format":"tastetable-offline-calendar-current-freeze-v1",
"frozen_at":datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
"repository":"Jacob-Met/tastetable","canonical_parent":inp["parent"],"canonical_tree":inp["tree"]["sha"],
"baseline_projection":bc,"baseline_projection_tree":bt,"local_projection_commit":cc,"local_projection_tree":ct,
"original_accepted_source":old["local_projection_commit"],"original_accepted_manifest_sha256":sha((r/"candidate-frozen-manifest.json").read_bytes()),
"source_files":{k:meta(v) for k,v in sorted(actual.items())},
"scope":{k:{"before_git_blob":leaves.get(k,{}).get("sha"),**meta(actual[k])} for k in scope},
"unowned_current_files_preserved":proof["unowned_current_files"],
"original_new_files_unchanged":proof["original_new_files_unchanged"],
"source_proof":meta((e/"source-proof.json").read_bytes()),
"native_gates":{"unit_methods":69,"full_browser_checks":73,"full_browser_groups":12,"full_browser_downloads":19,"history_browser_checks":19,"history_browser_downloads":16,"static_files":42,"exact_static_http_checks":84,"python_package_browser_checks":7,"python_package_browser_downloads":3},
"native_coordination":"Issue 34 remains the exact claim; ThinkPad was offline for the native registry append. Root holds the pending scope.",
"projection_note":"The local Git history contains only the 52-file current baseline and 56-file qualified source closure. Canonical full repository parent/tree are identified separately; publication must preserve every other current leaf.",
"attribution":"Original v1 behavior was independently received before this current arrangement-history composition. The four new source files remain byte-identical. Current author gates do not reattribute original peer evidence to a new parent."
}
write(r/"current-frozen-manifest.json",out)
write(e/"visual-inspection.json",{"inspected_at":out["frozen_at"],"observer":"product author","files":["browser-v1/phone-calendar.png","history-browser-v1/phone-history-calendar.png"],"finding":"Both actual fresh 375px captures are clear and readable; the download action, literal dates/venues and fixture label fit the viewport. The source report separately records zero horizontal overflow."})
print(json.dumps({"manifest":meta((r/"current-frozen-manifest.json").read_bytes()),"baseline_projection":bc,"baseline_tree":bt,"source_commit":cc,"source_tree":ct,"source_files":len(actual),"scope":out["scope"],"changed":changed},indent=2))
