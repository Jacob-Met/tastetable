import { spawn } from "node:child_process";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { join, extname, resolve, relative } from "node:path";
import { createHash } from "node:crypto";
import { chromium } from "/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs";
const root="/Users/me/tastetable-calendar-066deeadcc8b";
const portable=join(root,"current-portable"), output=join(root,"current-evidence/portable-python-browser");
await mkdir(output);
const custody=JSON.parse(await readFile(join(root,"current-evidence/portable.json"),"utf8"));
const sha=b=>createHash("sha256").update(b).digest("hex");
const report={archive:custody.archive,sourceBefore:{},sourceAfter:{},checks:[],requests:[],errors:[],downloads:[]};
const check=(name,pass,actual)=>{report.checks.push({name,pass:Boolean(pass),actual});if(!pass)console.log(JSON.stringify({failed:name,actual}));};
for(const [name,pin] of Object.entries(custody.members)){
 const b=await readFile(join(portable,name));report.sourceBefore[name]=sha(b);
 if(b.length!==pin.bytes||sha(b)!==pin.sha256)throw Error("portable source mismatch: "+name);
}
const pythonArgs=["-u","-m","http.server","0","--bind","127.0.0.1","--directory",join(portable,"web-demo-offline")];
const python=spawn("python3",pythonArgs,{stdio:["ignore","pipe","pipe"]});
let serverStdout="",serverStderr="";
python.stderr.on("data",b=>{serverStderr+=b.toString("utf8");});
const port=await new Promise((resolve,reject)=>{
 python.once("error",reject);
 python.once("exit",(code,signal)=>reject(Error("Python static server exited before navigation: "+code+"/"+signal)));
 python.stdout.on("data",b=>{
  serverStdout+=b.toString("utf8");
  if(!serverStdout.includes("\n"))return;
  const match=serverStdout.split("\n")[0].match(/port (\d+) /);
  if(match)resolve(Number(match[1]));else reject(Error("Unrecognized Python server startup: "+serverStdout));
 });
});
const origin="http://127.0.0.1:"+port;
const server={close(callback){
 const finish=(code,signal)=>{report.pythonServer={argv:["python3",...pythonArgs],pid:python.pid,exitCode:code,signal,teardown:"author terminated its own private static server after the browser closed"};callback();};
 if(python.exitCode!==null||python.signalCode!==null){finish(python.exitCode,python.signalCode);return;}
 python.once("close",finish);python.kill("SIGTERM");
}};
let browser;
async function open(){
 const context=await browser.newContext({viewport:{width:375,height:900},acceptDownloads:true});
 const page=await context.newPage();
 page.on("pageerror",e=>report.errors.push(String(e)));
 page.on("request",r=>report.requests.push({method:r.method(),url:r.url()}));
 await page.route("**/*",route=>route.request().url().startsWith(origin+"/")?route.continue():route.abort());
 await page.goto(origin+"/");await page.locator("#offlineCalendar").waitFor({state:"visible"});
 return {context,page};
}
async function download(page,selector,name){
 const waiting=page.waitForEvent("download");await page.locator(selector).click();
 const d=await waiting;await d.saveAs(join(output,name));const b=await readFile(join(output,name));
 report.downloads.push({path:name,filename:d.suggestedFilename(),bytes:b.length,sha256:sha(b)});return b;
}
try{
 browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true});
 report.browser=browser.version();
 let {context,page}=await open();
 await page.locator("#weekDate").fill("2026-03-08");
 await page.locator('[data-pick-key="pick-0"]').selectOption("Sunday");
 await page.locator('[data-pick-key="pick-1"]').selectOption("");
 const preview=await page.locator("#offlineCalendarPreview li").evaluateAll(rows=>rows.map(row=>({date:row.querySelector("time").dateTime,name:row.querySelector("span").textContent})));
 const first=await download(page,"#offlineCalendarDownload","first-calendar.ics");
 const savedBytes=await download(page,"#saveWeek","saved-week.json");const saved=JSON.parse(savedBytes);
 check("actual extracted package emits four arranged all-day suggestions",preview.length===4&&(first.toString("utf8").match(/BEGIN:VEVENT/g)||[]).length===4,{preview});
 check("accepted saved format retains prepared identity and omitted occurrence",/^[0-9a-f]{32}$/.test(saved.calendarId)&&saved.week.start==="2026-03-02"&&saved.week.assignments["pick-0"]==="Sunday"&&saved.week.assignments["pick-1"]===null,{calendarId:saved.calendarId,week:saved.week});
 const geometry=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));
 check("fresh 375px package fits the viewport",geometry.width===375&&geometry.scroll<=375,geometry);
 await context.close();({context,page}=await open());
 await page.locator("#weekFile").setInputFiles(join(output,"saved-week.json"));await page.locator("#weekPreview").waitFor({state:"visible"});await page.locator("#replaceWeek").click();
 const restored=await download(page,"#offlineCalendarDownload","reopened-calendar.ics");
 check("a fresh package browser reopens the exact calendar bytes",first.equals(restored),sha(first));
 await context.close();
 check("only static local GET requests occurred",report.requests.every(r=>r.method==="GET"&&r.url.startsWith(origin+"/")),report.requests);
 check("no application exception occurred",report.errors.length===0,report.errors);
}finally{
 for(const name of Object.keys(custody.members))report.sourceAfter[name]=sha(await readFile(join(portable,name)));
 check("all 42 extracted source files retain their qualified bytes",Object.keys(report.sourceAfter).length===42&&Object.keys(report.sourceBefore).every(n=>report.sourceAfter[n]===report.sourceBefore[n]),42);
 if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));
 await writeFile(join(output,"python-server.stdout"),serverStdout);await writeFile(join(output,"python-server.stderr"),serverStderr);
 report.totals={passed:report.checks.filter(x=>x.pass).length,failed:report.checks.filter(x=>!x.pass).length,actualDownloads:report.downloads.length};
 await writeFile(join(output,"report.json"),JSON.stringify(report,null,2)+"\n");
 console.log(JSON.stringify(report.totals));if(report.totals.failed)process.exitCode=1;
}
