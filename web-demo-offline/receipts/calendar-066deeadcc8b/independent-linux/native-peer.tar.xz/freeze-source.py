from pathlib import Path, PurePosixPath
import json, tarfile, hashlib, datetime, traceback, sys
root=Path('/home/jacob/hamon-root-066deeadcc8b/tastetable-calendar-review')
pub=Path('/home/jacob/hamon-product-066deeadcc8b/tastetable-publication')
packet=pub/'web-demo-offline/receipts/calendar-066deeadcc8b'
def require(value,message):
 if not value: raise RuntimeError(message)
def digest(b):
 return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':'100644'}
def ordinary_name(name):
 p=PurePosixPath(name);require(not p.is_absolute() and '..' not in p.parts and str(p)==name,'Unsafe path '+name)
def archive(name,pin):
 p=packet/name;b=p.read_bytes();require(hashlib.sha256(b).hexdigest()==pin,'Changed archive '+name)
 files={}
 with tarfile.open(p,'r:xz') as t:
  for m in t.getmembers():
   ordinary_name(m.name);require(m.isfile() and m.name not in files,'Nonordinary/duplicate member '+m.name)
   files[m.name]=t.extractfile(m).read()
 return files,digest(b)
def install(name,data):
 ordinary_name(name);p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():require(p.is_file() and not p.is_symlink() and p.read_bytes()==data,'Existing file differs '+name)
 else:
  with p.open('xb') as f:f.write(data)
try:
 primary=json.loads((root/'primary-trees.json').read_text())
 maps={k:{r['path']:r for r in primary[k]['tree'] if r['type']!='tree'} for k in ('original_tree','current_author_tree','publication_tree')}
 for k in maps:require(not primary[k]['truncated'],'Truncated primary tree')
 old,oldpin=archive('original-author/native-author.tar.xz','399c8cf82d10aedae17806dc9b8e1bf1f2b74c3170bf15333756d1a827641f64')
 cur,curpin=archive('current-author/native-current.tar.xz','27b6d0b1dfb5b0a0117fbfba5e44f639b01789022891c781d5c14d22eb6bdaf0')
 capsule=json.loads(old['baseline-source.json'])
 require(old['baseline-source.json']==cur['baseline-source.json'],'Baseline capsules differ')
 om=json.loads(old['candidate-frozen-manifest.json']);cm=json.loads(cur['current-frozen-manifest.json'])
 require(hashlib.sha256(old['candidate-frozen-manifest.json']).hexdigest()=='856b8761f80276fec0b32496144c7c40b9090ef38b9333a2effd2216772dc50b','Original freeze mismatch')
 require(hashlib.sha256(cur['current-frozen-manifest.json']).hexdigest()=='81d7e62583bc13a3f9398b010ccf2ff8055c18fc04999f5a27e9573e9660f36c','Current freeze mismatch')
 baseline={}
 leafmap={r['path']:r for r in capsule['leaves']}
 for path,text in capsule['files'].items():
  require(isinstance(text,str),'Unexpected baseline encoding '+path)
  b=text.encode('utf-8');p=digest(b);r=leafmap[path];c=maps['original_tree'][path]
  require(p['git_blob']==r['sha']==c['sha'] and len(b)==r['size']==c['size'] and r['mode']==c['mode']=='100644','Baseline primary mismatch '+path)
  baseline[path]=b
 require(len(baseline)==48==len(leafmap),'Baseline count')
 source_sets=[]
 for label,m,data,prefix,parent in [('original',om,old,'source/','original_tree'),('current',cm,cur,'current-source/','current_author_tree')]:
  sources={p[len(prefix):]:b for p,b in data.items() if p.startswith(prefix)}
  require(set(sources)==set(m['source_files']),'Source set mismatch '+label)
  unowned=[]
  for p,b in sources.items():
   h=digest(b);require(h==m['source_files'][p],'Frozen source mismatch '+label+' '+p)
   if p not in m['scope']:
    r=maps[parent].get(p);require(r and r['sha']==h['git_blob'] and r['mode']==h['mode'],'Unowned primary mismatch '+label+' '+p);unowned.append(p)
  for p,v in m['scope'].items():
   r=maps[parent].get(p);require((r['sha'] if r else None)==v['before_git_blob'],'Owned before mismatch '+label+' '+p)
  source_sets.append((sources,unowned))
 osrc,ou=source_sets[0];csrc,cu=source_sets[1]
 require(len(osrc)==53 and len(csrc)==56 and len(ou)==43 and len(cu)==46,'Source counts')
 for p in cu:
  r=maps['publication_tree'].get(p);h=digest(csrc[p]);require(r and r['sha']==h['git_blob'] and r['mode']==h['mode'],'Publication unowned changed '+p)
 for p,v in cm['scope'].items():
  r=maps['publication_tree'].get(p);require((r['sha'] if r else None)==v['before_git_blob'],'Publication owned before changed '+p)
  require((pub/p).read_bytes()==csrc[p],'Publication checkpoint differs '+p)
 for p in cm['original_new_files_unchanged']:require(osrc[p]==csrc[p],'Original new file changed '+p)
 for p,b in baseline.items():install('baseline/'+p,b)
 for p,b in csrc.items():install('candidate/'+p,b)
 install('source-provenance/original-frozen-manifest.json',old['candidate-frozen-manifest.json'])
 install('source-provenance/current-frozen-manifest.json',cur['current-frozen-manifest.json'])
 files={**{'baseline/'+p:digest(b) for p,b in baseline.items()},**{'candidate/'+p:digest(b) for p,b in csrc.items()}}
 result={'format':'tastetable.root.linux-source-freeze.v1','frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':'Jacob-Met/tastetable','original_parent':primary['original_parent'],'current_author_parent':primary['current_author_parent'],'publication_parent':primary['publication_parent'],'publication_tree':primary['publication_actual_tree'],'archives':{'original':oldpin,'current':curpin},'files':files,'baseline_files':48,'candidate_files':56,'original_source_files_checked':53,'original_unowned_primary_matched':43,'current_unowned_primary_matched':46,'publication_unowned_primary_matched':46,'owned_before_pins_matched':10,'original_new_files_unchanged':cm['original_new_files_unchanged'],'source_unchanged_from_accepted_current_mac_candidate':True,'new_linux_execution_yet':False,'mac_raw_receiving':'Unreachable on offline Mac; not reconstructed or relabelled.'}
 f=root/'source-freeze.json';require(not f.exists(),'Source freeze already exists')
 f.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':'passed','source_files':len(files),'publication_parent':result['publication_parent'],'freeze_sha256':hashlib.sha256(f.read_bytes()).hexdigest()}))
except Exception as e:
 failure={'format':'tastetable.root.source-freeze-failure.v1','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':str(e),'traceback':traceback.format_exc()}
 (root/'source-freeze-failure.json').write_text(json.dumps(failure,indent=2)+'\n')
 print(json.dumps(failure));sys.exit(1)
