#!/usr/bin/env node
// New Linux receiving; earlier Mac observations keep their own run identities.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,readdir,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {chromium} from '/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright/index.mjs';
const root=dirname(fileURLToPath(import.meta.url));
const baseline=join(root,'baseline'),candidate=join(root,'candidate');
const output=join(root,process.argv[2]||'linux-v1');
await mkdir(output,{recursive:false});
await mkdir(join(output,'downloads'));
await mkdir(join(output,'api'));
await mkdir(join(output,'controls'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const freeze=JSON.parse(await readFile(join(root,'source-freeze.json'),'utf8'));
const report={schema:'tastetable.root.linux-receiving.v1',started:new Date().toISOString(),state:'running',sourceFreezeSha256:sha(await readFile(join(root,'source-freeze.json'))),api:{cases:[],refusals:[],negativeControls:[]},browser:{groups:[],downloads:[],pairs:[],screenshots:[],pageErrors:[],requests:[],downloadEvents:[],serverRequests:[]}};
const require=createRequire(import.meta.url);
const stock=require(join(baseline,'static/calendar.js'));
const week=await import(pathToFileURL(join(baseline,'web-demo-offline/week_plan.mjs')));
const saved=await import(pathToFileURL(join(baseline,'web-demo-offline/saved_week.mjs')));
const catalogApi=await import(pathToFileURL(join(baseline,'web-demo-offline/catalogue.mjs')));
const catalogue=catalogApi.validateCatalogue(JSON.parse(await readFile(join(baseline,'web-demo-offline/data/catalogue.json'),'utf8')));
const days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const fixed='0123456789abcdef0123456789abcdef',stamp='2026-10-08T12:34:56.789Z';
const clone=x=>JSON.parse(JSON.stringify(x));
const plus=(date,n)=>{const d=new Date(date+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
function rows(state){
 return state.picks.map((row,index)=>({...row,index,day:state.assignments[row.key]}))
 .filter(row=>row.day!==null).map(row=>{assert.ok(days.includes(row.day));return {...row,date:plus(state.weekStart,days.indexOf(row.day))};})
 .sort((a,b)=>days.indexOf(a.day)-days.indexOf(b.day)||a.index-b.index);
}
function unescapeText(value){return value.replace(/\\([\\,;nN])/g,(_,x)=>x==='n'||x==='N'?'\n':x);}
function parseCalendar(bytes){
 const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
 assert.ok(text.endsWith('\r\n'),'CRLF final line');
 assert.equal(/(?<!\r)\n|\r(?!\n)/.test(text),false,'only CRLF lines');
 for(const line of text.split('\r\n'))assert.ok(Buffer.byteLength(line)<=75,'75-octet physical fold');
 const lines=text.replace(/\r\n[ \t]/g,'').split('\r\n');
 assert.equal(lines[0],'BEGIN:VCALENDAR');assert.equal(lines.at(-2),'END:VCALENDAR');
 assert.equal(lines.filter(x=>x==='VERSION:2.0').length,1);
 const events=[];let event=null;
 for(const line of lines){
  if(line==='BEGIN:VEVENT'){assert.equal(event,null);event={};}
  else if(line==='END:VEVENT'){assert.ok(event);events.push(event);event=null;}
  else if(event){const pos=line.indexOf(':');assert.ok(pos>0);const key=line.slice(0,pos);assert.equal(Object.hasOwn(event,key),false);event[key]=line.slice(pos+1);}
 }
 assert.equal(event,null);return {text,events};
}
function verifyCalendar(bytes,state,id,receivedAt){
 const parsed=parseCalendar(bytes),want=rows(state);
 assert.equal(parsed.events.length,want.length);
 for(let i=0;i<want.length;i++){
  const r=want[i],e=parsed.events[i],pick=r.pick;
  assert.equal(e.UID,id+'-'+state.weekStart.replaceAll('-','')+'-'+r.key+'@tastetable.invalid');
  assert.equal(e.DTSTAMP,new Date(receivedAt).toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z'));
  assert.equal(e['DTSTART;VALUE=DATE'],r.date.replaceAll('-',''));
  assert.equal(e['DTEND;VALUE=DATE'],plus(r.date,1).replaceAll('-',''));
  assert.equal(unescapeText(e.SUMMARY),'[DEMO] TasteTable suggestion: '+pick.name);
  assert.deepEqual([e.STATUS,e.TRANSP,e.CLASS],['TENTATIVE','TRANSPARENT','PRIVATE']);
  const description=unescapeText(e.DESCRIPTION);
  assert.ok(description.includes('DEMO: synthetic Qloo fixture; these venues are fictional.'));
  assert.ok(description.includes('Qloo entity ID: '+pick.entity_id));
  assert.ok(description.includes('Originally suggested for: '+r.originalDay+'. Arranged for: '+r.day+' '+r.date+'.'));
  assert.ok(description.includes('Why this suggestion: '+pick.why));
  for(const note of state.sourcePlan.notes)assert.ok(description.includes('Plan note: '+note));
  assert.ok(description.includes('no booking or opening hours confirmed'));
 }
 const canonical=stock.createWeekExport(state,{id,createdAt:new Date(receivedAt)}).download(state,week.weekRows(state)).text;
 assert.equal(parsed.text,canonical,'exact unchanged shipping writer bytes');
 return parsed.events;
}
async function sourceState(){
 const found={};
 async function walk(path,prefix){
  for(const e of await readdir(path,{withFileTypes:true})){
   const name=prefix+e.name,p=join(path,e.name);
   if(e.isDirectory())await walk(p,name+'/');
   else {assert.ok(e.isFile(),'ordinary source '+name);const b=await readFile(p);found[name]={bytes:b.length,sha256:sha(b),git_blob:createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+'\0'),b])).digest('hex'),mode:(await stat(p)).mode&0o111?'100755':'100644'};}
  }
 }
 await walk(baseline,'baseline/');await walk(candidate,'candidate/');
 assert.deepEqual(Object.keys(found).sort(),Object.keys(freeze.files).sort());
 for(const [path,pin]of Object.entries(freeze.files))assert.deepEqual(found[path],pin,'source pin '+path);
 return found;
}
async function artifact(path,bytes){
 const b=Buffer.isBuffer(bytes)?bytes:Buffer.from(bytes);
 await writeFile(join(output,path),b);
 return {path,bytes:b.length,sha256:sha(b)};
}
let browser,context,page,server,origin;
let stage='source-freeze';
try{
 report.sourceBefore=await sourceState();
 const writer=await readFile(join(baseline,'static/calendar.js'));
 assert.equal(createHash('sha1').update(Buffer.concat([Buffer.from('blob '+writer.length+'\0'),writer])).digest('hex'),'dbed22d2cb91090bccec9472fbffd2854eed2722');
 const api=await import(pathToFileURL(join(candidate,'web-demo-offline/offline_calendar.mjs')));
 stage='all-record API';
 for(const record of catalogue.records){
  for(const variant of ['original','arranged']){
   let state=week.createWeekPlan(record.response,'2026-12-31');
   if(variant==='arranged'){state=week.setPickDay(state,state.picks[0].key,'Sunday');state=week.setPickDay(state,state.picks[1].key,null);state=week.setPickDay(state,state.picks.at(-1).key,'Sunday');}
   const value={record,state,anchor:'2026-12-31',receivedAt:stamp,calendarId:fixed};
   const before=JSON.stringify(value),preview=api.previewOfflineCalendar(value,stock);
   assert.deepEqual(preview.items.map(x=>({key:x.key,date:x.date,name:x.name})),rows(state).map(x=>({key:x.key,date:x.date,name:x.pick.name})));
   assert.equal(preview.weekStart,state.weekStart);assert.equal(preview.totalCount,state.picks.length);
   let generated=0;const result=api.prepareOfflineCalendar(value,stock,()=>{generated++;return 'f'.repeat(32);});
   assert.equal(generated,0);assert.equal(result.calendarId,fixed);assert.equal(result.filename,'tastetable-demo-'+state.weekStart+'.ics');
   const events=verifyCalendar(Buffer.from(result.text),state,fixed,stamp);
   assert.equal(result.count,events.length);assert.equal(JSON.stringify(value),before);
   const file=await artifact('api/'+record.key+'-'+variant+'.ics',result.text);
   report.api.cases.push({name:record.key+'/'+variant,variant,context:value,events:events.length,...file});
  }
 }
 const record=catalogue.records[0],state=week.createWeekPlan(record.response,'2026-10-14');
 const value={record,state,anchor:'2026-10-14',receivedAt:stamp,calendarId:null};
 let generated=0;const first=api.prepareOfflineCalendar(value,stock,()=>{generated++;return fixed;});
 assert.equal(generated,1);assert.equal(value.calendarId,null);
 const retained=api.prepareOfflineCalendar({...value,calendarId:first.calendarId},stock,()=>{throw Error('new identity on retained input');});
 assert.equal(retained.text,first.text);
 const laterState=week.setWeek(state,'2026-10-21'),later=api.prepareOfflineCalendar({...value,state:laterState,anchor:'2026-10-21',calendarId:fixed},stock);
 const initialEvents=verifyCalendar(Buffer.from(first.text),state,fixed,stamp),laterEvents=verifyCalendar(Buffer.from(later.text),laterState,fixed,stamp);
 assert.ok(initialEvents.every((e,i)=>e.UID!==laterEvents[i].UID));
 report.api.identity={context:{...value,calendarId:fixed},laterContext:{...value,state:laterState,anchor:'2026-10-21',calendarId:fixed},first:await artifact('api/identity-original.ics',first.text),later:await artifact('api/identity-later.ics',later.text)};
 let empty=state;for(const p of state.picks)empty=week.setPickDay(empty,p.key,null);
 assert.equal(api.previewOfflineCalendar({...value,state:empty},stock).items.length,0);
 const altered=clone(state);altered.picks[0].pick.name+=' changed';
 const invalid=[
 ['empty',{...value,state:empty}],['blank-date',{...value,anchor:''}],['impossible-date',{...value,anchor:'2026-02-30'}],
 ['different-week',{...value,anchor:'2026-10-21'}],['missing-record',{...value,record:null}],['missing-state',{...value,state:null}],
 ['invalid-stamp',{...value,receivedAt:'invalid'}],['invalid-id',{...value,calendarId:'bad'}],
 ['different-record',{...value,record:catalogue.records.find(r=>r.profile_id!==record.profile_id)}],['altered-source',{...value,state:altered}]
 ];
 for(const [name,ctx]of invalid){let n=0,error;try{api.prepareOfflineCalendar(ctx,stock,()=>{n++;return fixed;});}catch(e){error=e;}assert.ok(error instanceof Error);assert.equal(n,0);report.api.refusals.push({name,message:error.message});}
 const controls=[
 ['wrong-exclusive-end',first.text.replace('DTEND;VALUE=DATE:'+initialEvents[0]['DTEND;VALUE=DATE'],'DTEND;VALUE=DATE:'+plus(rows(state)[0].date,2).replaceAll('-',''))],
 ['lost-demo-label',first.text.replace('[DEMO] TasteTable suggestion:','TasteTable suggestion:')],
 ['wrong-occurrence',first.text.replace(initialEvents[0].UID,'f'+initialEvents[0].UID.slice(1))]
 ];
 for(const [name,text]of controls){assert.notEqual(text,first.text);let error;try{verifyCalendar(Buffer.from(text),state,fixed,stamp);}catch(e){error=e;}assert.ok(error);report.api.negativeControls.push({name,state:'rejected',message:error.message,...await artifact('controls/'+name+'.ics',text)});}
 stage='private browser server';
 server=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://127.0.0.1'),parts=decodeURIComponent(url.pathname).split('/').filter(Boolean),kind=parts.shift();
   const dir=kind==='baseline'?baseline:kind==='candidate'?candidate:null;
   if(!dir||!['GET','HEAD'].includes(req.method)||parts.some(x=>x==='.'||x==='..')){res.writeHead(404);res.end();return;}
   const path=resolve(dir,...parts);assert.ok(path.startsWith(dir+'/'));
   const b=await readFile(path),ext=path.split('.').at(-1);
   const mime={html:'text/html',mjs:'text/javascript',js:'text/javascript',css:'text/css',json:'application/json'};
   report.browser.serverRequests.push({method:req.method,path:url.pathname,status:200,bytes:b.length,sha256:sha(b)});
   res.writeHead(200,{'Content-Type':mime[ext]||'application/octet-stream','Cache-Control':'no-store'});res.end(req.method==='HEAD'?undefined:b);
  }catch(error){report.browser.serverRequests.push({method:req.method,path:req.url,status:404});res.writeHead(404);res.end();}
 });
 await new Promise((ok,bad)=>{server.once('error',bad);server.listen(0,'127.0.0.1',ok);});
 origin='http://127.0.0.1:'+server.address().port;report.browser.origin=origin;
 const self=await fetch(origin+'/baseline/web-demo-offline/index.html');assert.equal(self.status,200);
 assert.deepEqual(Buffer.from(await self.arrayBuffer()),await readFile(join(baseline,'web-demo-offline/index.html')));
 browser=await chromium.launch({executablePath:'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome',headless:true});
 report.browser.version=browser.version();
 context=await browser.newContext({viewport:{width:1280,height:1000},acceptDownloads:true});
 page=await context.newPage();
 page.on('pageerror',e=>report.browser.pageErrors.push(e.stack||e.message));
 page.on('request',r=>report.browser.requests.push(r.url()));
 page.on('download',d=>report.browser.downloadEvents.push({name:d.suggestedFilename(),url:d.url()}));
 const group=name=>report.browser.groups.push(name);
 const go=async kind=>{await page.goto(origin+'/'+kind+'/web-demo-offline/index.html');await page.waitForFunction(()=>document.querySelector('#weekOrganizer select[data-pick-key]'));};
 const date=async value=>{await page.locator('#weekDate').fill(value);await page.locator('#weekDate').dispatchEvent('change');};
 async function download(selector){
  const [d]=await Promise.all([page.waitForEvent('download',{timeout:15000}),page.locator(selector).click()]);
  const name=d.suggestedFilename(),path='downloads/'+String(report.browser.downloads.length+1).padStart(3,'0')+'-'+name.replace(/[^A-Za-z0-9._-]/g,'_');
  await d.saveAs(join(output,path));assert.equal(await d.failure(),null);
  const b=await readFile(join(output,path)),entry={path,suggestedFilename:name,bytes:b.length,sha256:sha(b)};
  report.browser.downloads.push(entry);return {entry,bytes:b,path:join(output,path)};
 }
 const readSaved=async file=>saved.readOfflineWeekFile(new File([file.bytes],file.entry.suggestedFilename,{type:'application/json'}),catalogue);
 async function pair(name){
  const calendar=await download('#offlineCalendarDownload'),file=await download('#saveWeek'),value=await readSaved(file);
  assert.match(calendar.entry.suggestedFilename,/^tastetable-demo-\d{4}-\d{2}-\d{2}\.ics$/);
  assert.equal(calendar.entry.suggestedFilename,'tastetable-demo-'+value.state.weekStart+'.ics');
  const events=verifyCalendar(calendar.bytes,value.state,value.calendarId,value.receivedAt);
  const preview=await page.locator('#offlineCalendarPreview li').evaluateAll(es=>es.map(e=>({date:e.querySelector('time').getAttribute('datetime'),name:e.querySelector('span').textContent})));
  assert.deepEqual(preview,rows(value.state).map(x=>({date:x.date,name:x.pick.name})));
  assert.equal(await page.locator('#results').getAttribute('data-record-key'),value.record.key);
  report.browser.pairs.push({name,calendarPath:calendar.entry.path,weekPath:file.entry.path,calendarId:value.calendarId,receivedAt:value.receivedAt,recordKey:value.record.key,state:value.state,events:events.length,preview});
  return {calendar,file,value,events};
 }
 const same=async (reference,label)=>{const f=await download('#offlineCalendarDownload');assert.deepEqual(f.bytes,reference.bytes,label);report.browser.byteEqualities??=[];report.browser.byteEqualities.push({path:f.entry.path,reference:reference.entry.path,label});return f;};
 async function screen(name){
  await page.locator('#offlineCalendar').evaluate(e=>e.scrollIntoView({block:'start',behavior:'instant'}));
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  const b=await page.screenshot({fullPage:false});
  report.browser.screenshots.push(await artifact(name,b));
 }
 stage='baseline absence';await go('baseline');
 assert.equal(await page.locator('#offlineCalendarDownload').count(),0);group('Original baseline has no calendar export control');
 stage='identity and actual files';await go('candidate');
 await page.waitForFunction(()=>!document.querySelector('#offlineCalendarDownload').disabled);
 await date('2026-10-14');
 const previewFile=await download('#saveWeek'),previewSaved=await readSaved(previewFile);
 assert.equal(previewSaved.calendarId,null);
 report.browser.previewBeforeIdentity={path:previewFile.entry.path,calendarId:previewSaved.calendarId};
 const initial=await pair('initial');assert.match(initial.value.calendarId,/^[0-9a-f]{32}$/);
 await same(initial.calendar,'repeat unchanged current arrangement');
 group('Preview allocates no identity; actual ICS and Save week retain one identity and repeat exact bytes');
 const keys=await page.locator('#weekOrganizer select[data-pick-key]').evaluateAll(es=>es.map(e=>e.dataset.pickKey));
 stage='move and history';
 await page.locator('select[data-pick-key="'+keys[0]+'"]').selectOption('Sunday');
 const moved=await pair('moved');assert.equal(moved.value.calendarId,initial.value.calendarId);
 await page.locator('#undoWeek').click();await same(initial.calendar,'undo move');
 await page.locator('#redoWeek').click();await same(moved.calendar,'redo move');
 group('Move, Undo and Redo preserve exact source and calendar bytes');
 stage='omission and history';
 await page.locator('select[data-pick-key="'+keys[1]+'"]').selectOption('');
 const omitted=await pair('omitted');assert.equal(omitted.value.calendarId,initial.value.calendarId);
 assert.ok(omitted.events.every(e=>initial.events.some(v=>v.UID===e.UID)));
 await page.locator('#undoWeek').click();await same(moved.calendar,'undo omission');
 await page.locator('#redoWeek').click();await same(omitted.calendar,'redo omission');
 await screen('calendar-desktop.png');
 group('Omitted picks disappear; Undo and Redo restore exact occurrences and surviving UIDs');
 stage='invalid date';
 await date('');assert.equal(await page.locator('#offlineCalendarDownload').isDisabled(),true);
 assert.equal(await page.locator('#offlineCalendarPreview li').count(),0);
 const before=report.browser.downloadEvents.length;
 const box=await page.locator('#offlineCalendarDownload').boundingBox();assert.ok(box);
 await page.mouse.click(box.x+box.width/2,box.y+box.height/2);
 await new Promise(r=>setTimeout(r,180));assert.equal(report.browser.downloadEvents.length,before);
 await date('2026-10-14');await same(omitted.calendar,'repair invalid visible date');
 group('Invalid visible date retires the preview and actual disabled output; repair restores exact bytes');
 stage='different week and invalid history recovery';
 await date('2026-10-21');const next=await pair('other-week');assert.equal(next.value.calendarId,initial.value.calendarId);
 assert.ok(next.events.every(e=>!omitted.events.some(v=>v.UID===e.UID)));
 await date('');assert.equal(await page.locator('#offlineCalendarDownload').isDisabled(),true);
 await page.locator('#undoWeek').click();await same(omitted.calendar,'history recovery after invalid date');
 await page.locator('#redoWeek').click();await same(next.calendar,'redo other week after recovery');
 group('Changed weeks get separate occurrence UIDs; history recovers exact valid calendars after invalid input');
 stage='pending import history';
 await page.locator('#weekFile').setInputFiles(initial.file.path);
 await page.locator('#weekPreview').waitFor({state:'visible'});
 await page.locator('#undoWeek').click();assert.equal(await page.locator('#weekPreview').isHidden(),true);
 assert.equal(await page.locator('#replaceWeek').isDisabled(),true);
 await same(omitted.calendar,'undo retires pending saved-week replacement');
 group('Undo retires the pending saved-week replacement and retains the restored current calendar');
 stage='all omitted';
 for(const key of keys)await page.locator('select[data-pick-key="'+key+'"]').selectOption('');
 assert.equal(await page.locator('#offlineCalendarPreview li').count(),0);
 assert.equal(await page.locator('#offlineCalendarDownload').isDisabled(),true);
 group('A wholly omitted arrangement cannot export an empty calendar');
 stage='fresh saved-week reopen';await go('candidate');
 const beforePreview=await page.locator('#weekOrganizer select[data-pick-key]').evaluateAll(es=>es.map(e=>e.value));
 await page.locator('#weekFile').setInputFiles(omitted.file.path);
 await page.locator('#weekPreview').waitFor({state:'visible'});
 assert.deepEqual(await page.locator('#weekOrganizer select[data-pick-key]').evaluateAll(es=>es.map(e=>e.value)),beforePreview);
 await page.locator('#replaceWeek').click();
 const reopened=await pair('fresh-reopen');
 assert.deepEqual(reopened.calendar.bytes,omitted.calendar.bytes);
 assert.equal(reopened.value.calendarId,omitted.value.calendarId);assert.equal(reopened.value.receivedAt,omitted.value.receivedAt);
 group('A real saved file previews without changing the current arrangement and reopens with exact calendar continuity');
 stage='new source';
 const other=await page.locator('#personaSel option').nth(1).getAttribute('value');
 await page.locator('#personaSel').selectOption(other);
 assert.equal(await page.locator('#results').isHidden(),true);
 assert.equal(await page.locator('#offlineCalendarDownload').isDisabled(),true);
 assert.equal(await page.locator('#offlineCalendarPreview li').count(),0);
 await page.locator('#showPlan').click();
 const replacement=await pair('replacement-source');
 assert.equal(replacement.value.record.profile_id,other);assert.notEqual(replacement.value.calendarId,initial.value.calendarId);
 group('Changing the recorded profile retires old output and creates a separate calendar identity');
 stage='375px rendered calendar';
 await page.setViewportSize({width:375,height:1000});await screen('calendar-phone.png');
 const geometry=await page.evaluate(()=>{const e=document.querySelector('#offlineCalendar'),r=e.getBoundingClientRect();return {width:innerWidth,scroll:document.documentElement.scrollWidth,top:r.top,bottom:r.bottom,left:r.left,right:r.right,text:e.innerText};});
 assert.ok(geometry.scroll<=375&&geometry.left>=-1&&geometry.right<=375);
 assert.ok(geometry.bottom>0&&geometry.top<1000&&geometry.text.includes('Download'));
 report.browser.geometry=geometry;group('The actual calendar is rendered in a 375px page without document overflow');
 assert.deepEqual(report.browser.pageErrors,[]);
 assert.deepEqual(report.browser.requests.filter(url=>/^https?:/.test(url)&&!url.startsWith(origin+'/')),[]);
 assert.equal(report.browser.downloadEvents.length,report.browser.downloads.length);
 report.sourceAfter=await sourceState();assert.deepEqual(report.sourceAfter,report.sourceBefore);
 report.state='passed';
}catch(error){
 report.state='failed';report.stage=stage;report.failure=error.stack;process.exitCode=1;
 if(page){try{report.browser.screenshots.push(await artifact('failure.png',await page.screenshot({fullPage:false})));}catch{}}
 try{report.sourceAfter=await sourceState();}catch(e){report.sourceFailure=e.stack;}
}finally{
 if(context)await context.close().catch(()=>{});
 if(browser)await browser.close().catch(()=>{});
 if(server)await new Promise(r=>server.close(r));
 report.finished=new Date().toISOString();
 await writeFile(join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({state:report.state,apiCases:report.api.cases.length,refusals:report.api.refusals.length,negativeControls:report.api.negativeControls.length,browserGroups:report.browser.groups.length,downloads:report.browser.downloads.length,stage:report.stage,failure:report.failure}));
}
