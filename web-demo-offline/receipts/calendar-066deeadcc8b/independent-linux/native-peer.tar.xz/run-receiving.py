from pathlib import Path
import json,hashlib,datetime,subprocess,os
p=Path('/home/jacob/hamon-root-066deeadcc8b/tastetable-calendar-review')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
h=lambda b:hashlib.sha256(b).hexdigest()
source=p/'receive-linux.mjs'
if (p/'linux-v1').exists() or (p/'receiver-freeze.json').exists():raise RuntimeError('Existing receiving run/freeze; read before proceeding')
check=subprocess.run(['/usr/bin/node','--check',str(source)],cwd=p,capture_output=True)
(p/'receiver-syntax.stdout').write_bytes(check.stdout);(p/'receiver-syntax.stderr').write_bytes(check.stderr)
(p/'receiver-syntax.json').write_text(json.dumps({'command':['/usr/bin/node','--check',str(source)],'exit_code':check.returncode,'finished':now(),'stdout_sha256':h(check.stdout),'stderr_sha256':h(check.stderr)},indent=2)+'\n')
if check.returncode:raise RuntimeError('Receiver syntax gate failed')
contract={'schema':'tastetable.root.linux-receiver-freeze.v1','frozen_at':now(),'reviewer':'/root','receiver':{'path':source.name,'bytes':source.stat().st_size,'sha256':h(source.read_bytes())},'source_freeze_sha256':h((p/'source-freeze.json').read_bytes()),'node':'/usr/bin/node','node_version':subprocess.check_output(['/usr/bin/node','--version'],text=True).strip(),'browser':'/home/jacob/.cache/puppeteer/chrome/linux-154.0.8037.57/chrome-linux64/chrome','playwright':'/home/jacob/hamon-b890f0b1bfcd/browser-tools/node_modules/playwright/index.mjs','expected_contract':['All24 source records in original and moved/omitted arrangements: independently parse literal dates, exclusive all-day end, UID, original stamp, source and explanation; exact unchanged writer bytes.','Ten invalid contexts refused before allocating identity; three constructed wrong calendars rejected.','Actual browser downloads paired with actual saved-week files and current visible preview.','Stable identities and exact bytes through repeat, moves, omissions, Undo/Redo, invalid-date repair and history recovery, pending-file retirement, fresh Save/Open and new recorded profile.','No empty calendar, no provider requests, no JavaScript errors, actual375px calendar capture, full104-source stability.'],'independence':'New Linux receiver authored after prior Mac receiving and source review. It is not claimed byte-identical to original Mac observers, whose transient buffers reset while their native files remain offline. Original Mac results keep separate run identities.','new_product_run_claimed_before_execution':False}
(p/'receiver-freeze.json').write_text(json.dumps(contract,indent=2)+'\n')
command=['/usr/bin/node',str(source),'linux-v1'];started=now()
with (p/'linux-v1.stdout').open('xb') as out,(p/'linux-v1.stderr').open('xb') as err:
 result=subprocess.run(command,cwd=p,stdout=out,stderr=err)
receipt={'schema':'tastetable.root.linux-process.v1','command':command,'cwd':str(p),'started':started,'finished':now(),'exit_code':result.returncode,'receiver_sha256':h(source.read_bytes()),'receiver_freeze_sha256':h((p/'receiver-freeze.json').read_bytes()),'stdout_sha256':h((p/'linux-v1.stdout').read_bytes()),'stderr_sha256':h((p/'linux-v1.stderr').read_bytes())}
(p/'linux-v1-process.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
