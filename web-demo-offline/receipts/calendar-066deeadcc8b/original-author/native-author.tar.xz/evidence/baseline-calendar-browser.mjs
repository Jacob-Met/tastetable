import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, relative, extname, join } from 'node:path';
import { createHash } from 'node:crypto';
import { chromium } from '/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs';

const root = resolve('/Users/me/tastetable-calendar-066deeadcc8b');
const base = join(root, 'baseline');
const output = join(root, 'evidence/baseline-browser');
await mkdir(output);
const manifest = JSON.parse(await readFile(join(root, 'evidence/baseline-source-manifest.json'), 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const before = {};
for (const name of Object.keys(manifest.files)) before[name] = sha(await readFile(join(base, name)));
const report = { canonicalCommit: manifest.canonical_commit, browser: null, requests: [], errors: [], checks: [], downloads: [], sourceBefore: before };
function check(name, condition, actual) { report.checks.push({ name, pass: Boolean(condition), actual }); }
const server = createServer(async (req, res) => {
  try {
    const part = decodeURIComponent(new URL(req.url, 'http://local.invalid').pathname);
    const file = resolve(base, 'web-demo-offline', '.' + (part === '/' ? '/index.html' : part));
    const name = relative(base, file).split('\\').join('/');
    if (!Object.hasOwn(manifest.files, name)) { res.writeHead(404).end(); return; }
    const types = { '.html': 'text/html; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8' };
    res.writeHead(200, { 'Content-Type': types[extname(file)] || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(await readFile(file));
  } catch { res.writeHead(500).end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = 'http://127.0.0.1:' + server.address().port;
let browser;
try {
  browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true });
  report.browser = browser.version();
  const context = await browser.newContext({ viewport: { width: 1100, height: 900 }, acceptDownloads: true });
  const page = await context.newPage();
  page.on('pageerror', error => report.errors.push(String(error)));
  page.on('request', request => report.requests.push({ method: request.method(), url: request.url() }));
  await page.route('**/*', route => route.request().url().startsWith(origin + '/') ? route.continue() : route.abort());
  await page.goto(origin + '/');
  await page.locator('#results').waitFor({ state: 'visible' });
  check('existing recorded plan renders', await page.locator('#weekOrganizer [data-pick-key]').count() === 5,
    await page.locator('#weekOrganizer [data-pick-key]').count());
  await page.locator('#weekDate').fill('2026-10-07');
  await page.locator('[data-pick-key="pick-0"]').selectOption('Sunday');
  await page.locator('[data-pick-key="pick-1"]').selectOption('Sunday');
  await page.locator('[data-pick-key="pick-2"]').selectOption('');
  const assignments = await page.locator('#weekOrganizer [data-pick-key]').evaluateAll(elements =>
    Object.fromEntries(elements.map(element => [element.dataset.pickKey, element.value || null])));
  check('two recorded occurrences can share Sunday', assignments['pick-0'] === 'Sunday' && assignments['pick-1'] === 'Sunday', assignments);
  check('third occurrence stays available off the week', assignments['pick-2'] === null
    && await page.locator('#omittedPicks [data-pick-key="pick-2"]').count() === 1, assignments['pick-2']);
  const downloadEvent = page.waitForEvent('download');
  await page.locator('#saveWeek').click();
  const download = await downloadEvent;
  const savedPath = join(output, 'saved-week.json');
  await download.saveAs(savedPath);
  const bytes = await readFile(savedPath);
  const saved = JSON.parse(bytes);
  report.downloads.push({ suggestedFilename: download.suggestedFilename(), path: 'saved-week.json', bytes: bytes.length, sha256: sha(bytes) });
  check('actual Save week preserves the displayed occurrence assignments', Object.keys(saved.week.assignments).length === Object.keys(assignments).length && Object.entries(assignments).every(([key, day]) => saved.week.assignments[key] === day), saved.week);
  check('saved week keeps the original fictional response', saved.response.mock === true
    && saved.response.plan.meals.every(pick => pick.entity_id.startsWith('FIX-')), saved.response.mock);
  check('existing saved-week format has no calendar identity before a calendar is prepared', saved.calendarId === null, saved.calendarId);
  const calendarActions = await page.getByRole('button', { name: 'Download calendar (.ics)', exact: true }).count();
  check('offline studio offers calendar export for this valid displayed arrangement', calendarActions === 1, calendarActions);
  await page.locator('#weekOrganizer').scrollIntoViewIfNeeded();
  await page.screenshot({ path: join(output, 'week-controls.png') });
  report.dom = { weekTitle: await page.locator('#weekTitle').innerText(), summary: await page.locator('#weekSummary').innerText(), source: await page.locator('#weekSource').innerText(), assignments };
  check('only local static GET requests occur', report.requests.every(request => request.method === 'GET' && request.url.startsWith(origin + '/')), report.requests);
  check('no application exceptions', report.errors.length === 0, report.errors);
  await context.close();
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
  report.sourceAfter = {};
  for (const name of Object.keys(manifest.files)) report.sourceAfter[name] = sha(await readFile(join(base, name)));
  check('all 48 baseline source and data files remain byte-identical', JSON.stringify(report.sourceAfter) === JSON.stringify(before)
    && Object.keys(before).every(name => before[name] === manifest.files[name].sha256), Object.keys(before).length);
  report.totals = { passed: report.checks.filter(item => item.pass).length, failed: report.checks.filter(item => !item.pass).length };
  report.interpretation = 'Unmodified canonical baseline; missing calendar action is an expected capability counterfactual. Existing source and saved-week behavior are qualified separately.';
  await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
}
console.log(JSON.stringify({ browser: report.browser, totals: report.totals, failed: report.checks.filter(item => !item.pass).map(item => item.name), output }));
