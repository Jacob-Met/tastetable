import { createServer } from "node:http";
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { join, extname, resolve, relative } from "node:path";
import { createHash } from "node:crypto";
import { chromium } from "/Users/me/suite-bridge-066deeadcc8b/source/packages/suite-shell/node_modules/playwright/index.mjs";
const root="/Users/me/tastetable-calendar-066deeadcc8b";
const portable=join(root,"portable-v1"), output=join(root,"evidence/portable-browser-v1");
await mkdir(output);
const custody=JSON.parse(await readFile(join(root,"evidence/portable-v1.json"),"utf8"));
const sha=b=>createHash("sha256").update(b).digest("hex");
const report={archive:custody.archive,sourceBefore:{},sourceAfter:{},checks:[],requests:[],errors:[],downloads:[]};
const check=(name,pass,actual)=>{report.checks.push({name,pass:Boolean(pass),actual});if(!pass)console.log(JSON.stringify({failed:name,actual}));};
for(const [name,pin] of Object.entries(custody.members)){
 const b=await readFile(join(portable,name));report.sourceBefore[name]=sha(b);
 if(b.length!==pin.bytes||sha(b)!==pin.sha256)throw Error("portable source mismatch: "+name);
}
const server=createServer(async(req,res)=>{
 try{
  const pathname=decodeURIComponent(new URL(req.url,"http://local.invalid").pathname);
  const file=resolve(portable,"web-demo-offline","."+(pathname==="/" ? "/index.html" : pathname));
  const name=relative(portable,file);
  if(!Object.hasOwn(custody.members,name)){res.writeHead(404).end();return;}
  const type={".html":"text/html",".js":"text/javascript",".mjs":"text/javascript",".css":"text/css",".json":"application/json"};
  res.writeHead(200,{"Content-Type":(type[extname(file)]||"text/plain")+";charset=utf-8","Cache-Control":"no-store"});
  res.end(await readFile(file));
 }catch{res.writeHead(500).end();}
});
await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
const origin="http://127.0.0.1:"+server.address().port;
let browser;
async function open(){
 const context=await browser.newContext({viewport:{width:375,height:900},acceptDownloads:true});
 const page=await context.newPage();
 page.on("pageerror",e=>report.errors.push(String(e)));
 page.on("request",r=>report.requests.push({method:r.method(),url:r.url()}));
 await page.route("**/*",route=>route.request().url().startsWith(origin+"/")?route.continue():route.abort());
 await page.goto(origin+"/");await page.locator("#offlineCalendar").waitFor({state:"visible"});
 return {context,page};
}
async function download(page,selector,name){
 const waiting=page.waitForEvent("download");await page.locator(selector).click();
 const d=await waiting;await d.saveAs(join(output,name));const b=await readFile(join(output,name));
 report.downloads.push({path:name,filename:d.suggestedFilename(),bytes:b.length,sha256:sha(b)});return b;
}
try{
 browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true});
 report.browser=browser.version();
 let {context,page}=await open();
 await page.locator("#weekDate").fill("2026-03-08");
 await page.locator('[data-pick-key="pick-0"]').selectOption("Sunday");
 await page.locator('[data-pick-key="pick-1"]').selectOption("");
 const preview=await page.locator("#offlineCalendarPreview li").evaluateAll(rows=>rows.map(row=>({date:row.querySelector("time").dateTime,name:row.querySelector("span").textContent})));
 const first=await download(page,"#offlineCalendarDownload","first-calendar.ics");
 const savedBytes=await download(page,"#saveWeek","saved-week.json");const saved=JSON.parse(savedBytes);
 check("actual extracted package emits four arranged all-day suggestions",preview.length===4&&(first.toString("utf8").match(/BEGIN:VEVENT/g)||[]).length===4,{preview});
 check("accepted saved format retains prepared identity and omitted occurrence",/^[0-9a-f]{32}$/.test(saved.calendarId)&&saved.week.start==="2026-03-02"&&saved.week.assignments["pick-0"]==="Sunday"&&saved.week.assignments["pick-1"]===null,{calendarId:saved.calendarId,week:saved.week});
 const geometry=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));
 check("fresh 375px package fits the viewport",geometry.width===375&&geometry.scroll<=375,geometry);
 await context.close();({context,page}=await open());
 await page.locator("#weekFile").setInputFiles(join(output,"saved-week.json"));await page.locator("#weekPreview").waitFor({state:"visible"});await page.locator("#replaceWeek").click();
 const restored=await download(page,"#offlineCalendarDownload","reopened-calendar.ics");
 check("a fresh package browser reopens the exact calendar bytes",first.equals(restored),sha(first));
 await context.close();
 check("only static local GET requests occurred",report.requests.every(r=>r.method==="GET"&&r.url.startsWith(origin+"/")),report.requests);
 check("no application exception occurred",report.errors.length===0,report.errors);
}finally{
 for(const name of Object.keys(custody.members))report.sourceAfter[name]=sha(await readFile(join(portable,name)));
 check("all 41 extracted source files retain their qualified bytes",Object.keys(report.sourceAfter).length===41&&Object.keys(report.sourceBefore).every(n=>report.sourceAfter[n]===report.sourceBefore[n]),41);
 if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));
 report.totals={passed:report.checks.filter(x=>x.pass).length,failed:report.checks.filter(x=>!x.pass).length,actualDownloads:report.downloads.length};
 await writeFile(join(output,"report.json"),JSON.stringify(report,null,2)+"\n");
 console.log(JSON.stringify(report.totals));if(report.totals.failed)process.exitCode=1;
}
